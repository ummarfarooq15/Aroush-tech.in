# Session 8 — Aroush Tech website development

Date: 6 November 2026

## Live source review

Rechecked the live homepage, About, Courses, Gallery and Contact pages. The current public course catalogue contains 20 entries. The homepage currently features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. The About page publishes three team members and their role titles. The Contact page publishes `taj@aroushtech.in`, `+91 88676 92074`, and two office addresses.

The homepage still displays zero-value statistics and unrelated gambling/promotion links in its footer. These are not copied. The Contact FAQ still includes certification, job-assistance and 24/7 lab-access statements; those claims remain excluded from the new website pending owner confirmation.

## Code changes

- Added 23 permanent redirects: `/aboutus`, `/contact-us`, `/meet-our-team`, and all 20 old course-detail paths to their new local destinations.
- Added `components/source-image.tsx`, a reusable image component that handles remote WordPress media failures with an accessible fallback, asynchronous decoding and eager loading for the site logo.
- Replaced direct remote `<img>` usage in the header, homepage gallery, gallery page, team page and corporate-training page.
- Moved the responsive navigation breakpoint to 860px so the seven-link desktop navigation is replaced before tablet layouts become cramped.
- Clarified on the Services page that the ten-area expanded portfolio is based on supporting 2026 company materials, not all currently published on the live website. Availability and scope remain proposal-confirmed.
- Added the live homepage instructor introduction for Tajuddin to the new homepage, using the existing published team portrait and the original trainer introduction text.
- Added the AI & ML feature on the Courses page, explicitly labelled as the course the current AROUSH catalogue calls its “Most Popular Course”; the homepage’s three featured courses remain unchanged.
- Rechecked the live gallery image links: ten training/learner photos are represented; the separate client-logo collage is excluded. The homepage also links three company-certificate images that could not be visually fetched in this session, so they remain excluded pending inspection and reuse approval.
- Verified the company LinkedIn page and replaced the opaque numeric profile URL with its canonical company slug URL. The LinkedIn profile is used only as a social destination, not as the source for company contact addresses.
- Expanded content validation to check redirects, image fallback behaviour and the responsive navigation breakpoint.

## Validation

- `npm run validate:content`: passed; verifies 10 services, 20 public courses, 19 source-backed course outlines plus one Fortinet owner-review note, six SOC/SIEM learning paths, three team profiles, ten gallery photos, eight target-industry profiles, two published office addresses, two testimonials, 28 public routes, 23 permanent redirects and literal internal links.
- TypeScript 5.8.3 transpile syntax check: 22 `.ts`/`.tsx` files, zero diagnostics. This checks syntax, not full framework types.
- CSS structural check: 431 opening and 431 closing braces.
- `node --check next.config.mjs`: passed.
- `node --check scripts/validate-content.mjs`: passed.
- `tsc --noEmit` could not complete because Next.js/React packages and their JSX type declarations are absent.
- Dependency installation failed with `EAI_AGAIN` while resolving `registry.npmjs.org`. Full Next.js type-check, production build and browser testing remain pending.

## Not done

- No local copy of the WordPress logo, team portraits or gallery photos: outbound DNS is unavailable in the current environment and rights approval is still needed. The new fallback component prevents broken-image presentation, but local hosting remains a launch task.
- No secure enquiry backend, CMS, admin dashboard, LMS, database, GitHub push, WordPress cleanup or production deployment.

## Next steps

1. Run dependency installation and the full build in GitHub Codespaces.
2. Run `npm run typecheck`, `npm run lint` and `npm run build`.
3. Test the eight primary pages, 20 course-detail pages, responsive menu, form flow and 23 redirects in a browser.
4. Inspect the three linked company-certificate images and obtain approval before deciding whether to publish them; approve and migrate other media assets.
5. Confirm course fees, addresses, Fortinet syllabus and FAQ claims.
6. Investigate the live WordPress footer injection and complete a safe preview deployment before production.
