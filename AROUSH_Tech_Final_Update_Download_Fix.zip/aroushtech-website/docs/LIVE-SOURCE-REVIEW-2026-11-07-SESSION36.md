# Live AROUSH source review — Session 36

Review date: **7 November 2026**

Primary source: the public AROUSH website. This review records a point-in-time public crawl and does not approve commercial terms or delivery commitments.

## Pages reopened

- Homepage: https://aroushtech.in/
- Contact: https://aroushtech.in/contact-us/
- Course detail spot-check: https://aroushtech.in/ccna/
- Catalogue: https://aroushtech.in/courses/

## Current public observations

| Area | Public source observation | Rebuild treatment |
|---|---|---|
| Homepage positioning | Advertises 20+ job-ready courses and a free demo; shows six course-category themes. | Retains the discovery structure and explains that a demo and availability must be confirmed for the selected programme. |
| Featured courses | Root homepage currently shows Agentic AI with LangChain & Hugging Face at ₹35,000, CCNP Security at ₹45,000 and CEH at ₹25,000. | Current catalogue-matching amounts remain website-listed references, not final quotations. |
| Homepage counters | The live page still displays zero-value student/course/satisfaction counters. | Excluded from the rebuild; no statistics are inferred. |
| Contact | Publishes `taj@aroushtech.in` and `+91 88676 92074`. | Uses these published details, with phone contact voluntary in the enquiry form. |
| Corporate office | #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029. | Displayed as the published Corporate Office address; map link searches the address rather than asserting a verified GPS pin. |
| Registered office | AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078. | Displayed as the published Registered Office address; map link searches the address. |
| Contact FAQ claims | The live page still says certification is provided with “100% job assistance” and refers to “24/7 lab access”. | These statements are not converted into rebuild guarantees pending written owner confirmation. |
| Training-centre reference | The Contact page identifies Bengaluru (J.P. Nagar) but does not provide a complete visitor-ready street address. | Visitors are told to confirm the actual session venue before travelling. |
| Footer integrity | The current root homepage still exposes unrelated gambling/betting footer links. | Excluded from the rebuild. This warrants an authorised WordPress/hosting investigation but does not prove the entry point or full compromise. |

## Course fee reconciliation

The public catalogue lists CCNA at ₹19,999 while the individual CCNA page currently shows ₹19,000. The rebuild continues to withhold the numeric CCNA fee. The earlier CCNA DevNet conflict remains owner-review as documented in the previous source audits.

## Owner / administrator items

1. Confirm current fees and payment instructions for all courses, particularly CCNA and CCNA DevNet.
2. Confirm the approved certification, job-assistance and lab-access terms before publishing them as commitments.
3. Confirm the exact visitor-ready J.P. Nagar training venue.
4. Investigate the unrelated gambling/betting footer links using authorised WordPress/hosting access, backups, logs, user/plugin/theme/database review and Search Console. Public crawling alone cannot establish the cause.
5. Approve the reuse and local hosting of remote WordPress logo, team and gallery images.

## Change control

This review informed only the offline rebuild. No live website, WordPress, DNS, hosting account, GitHub repository, analytics property or deployment was changed.
