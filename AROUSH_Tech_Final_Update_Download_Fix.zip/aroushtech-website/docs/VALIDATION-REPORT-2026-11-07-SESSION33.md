# Validation report — Session 33

Date: 7 November 2026

## Passed source-level checks

| Check | Result |
|---|---|
| Offline validation suite | 16/16 validators passed |
| FAQ coverage and routing | Passed |
| Chatbot routing | 47 cases passed |
| TypeScript/TSX syntax | 31 files parsed; syntax only |
| JavaScript syntax | 21 `.mjs` files passed |
| Accessibility source scan | 24 TSX files checked |
| Internal routes | 31 paths checked |
| Course slugs | 20 registered |
| External-link security | 34 files scanned; 9 HTTPS hosts reviewed |
| Public marketing claims | Passed |
| Privacy and analytics policy | Passed; GA4 ID blank |
| CSS/PostCSS | 538 rules, 22 at-rules, 1,754 declarations parsed |
| ZIP integrity | Passed |
| Fresh ZIP extraction | Passed |

## Production checks attempted

| Command/check | Result | Reason |
|---|---|---|
| `node --version` | Blocked | Node.js 22.16.0 available; project requires 24.x |
| `npm ping --fetch-retries=0 --fetch-timeout=10000` | Blocked | `EAI_AGAIN` resolving `registry.npmjs.org` |
| `npm run typecheck` | Blocked | Next.js/React packages and declarations are not installed |
| `npm run lint` | Blocked | `eslint` executable is absent |
| `npm run build` | Blocked | `next` executable is absent |
| `npm run audit` | Blocked | No `package-lock.json`; npm reports `ENOLOCK` |
| Browser/device QA | Pending | No runnable production build or staging deployment |

Do not describe the syntax parser as a full TypeScript typecheck or the offline suite as a production build.
