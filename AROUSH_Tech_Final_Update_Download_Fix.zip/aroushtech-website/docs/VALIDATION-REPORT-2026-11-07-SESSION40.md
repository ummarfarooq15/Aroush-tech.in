# Validation report — Session 40

Date: 7 November 2026

## Passed

- `npm run check:offline`: all 22 dependency-free validators passed.
- Course outline filter: 17 assertions passed.
- Chatbot: 47 intent-routing cases passed.
- Enquiry path: 33 assertions passed.
- Enquiry email-draft safety: 19 assertions passed.
- TypeScript/TSX syntax: 37 files parsed with TypeScript 5.8.3 (syntax only).
- JavaScript syntax: 32 `.mjs` files passed.
- Accessibility source checks: 25 TSX files inspected.
- Internal routes: 31 paths, 20 course slugs and 23 redirects inspected.
- External-link security: 45 source files and 9 HTTPS hosts scanned.
- Privacy, GA4 consent, content, brand, UX, public-claims, learning-path, FAQ, course-sort, comparison and release-config checks passed.

## Blocked

- Node.js runtime: current 22.16.0; project requires 24.x.
- DNS lookup for `registry.npmjs.org` fails; `npm install --package-lock-only` failed with `EAI_AGAIN` while requesting `@types/node` metadata.
- No `node_modules` directory or reviewed `package-lock.json` exists.
- Full semantic TypeScript check fails because Next.js/React modules and JSX type declarations are not installed.
- ESLint cannot run because `eslint` is not installed.
- Next.js production build cannot run because `next` is not installed.
- `npm audit` cannot run without a lockfile (`ENOLOCK`).
- Android and desktop browser testing remain pending.

## Privacy / release safeguards

- GA4 Measurement ID remains blank and analytics disabled.
- No CRM, server-side lead database, payment processor or visitor-identification mechanism was added.
- No live website, WordPress, DNS, GitHub repository or deployment was changed.
