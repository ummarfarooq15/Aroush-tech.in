# Live AROUSH source review — Session 31

Review date: 7 November 2026

Pages reopened:

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Gallery: https://aroushtech.in/gallery/
- Course catalogue: https://aroushtech.in/courses/
- Contact: https://aroushtech.in/contact-us/

## Homepage

The current homepage advertises 20+ job-ready courses and a free demo, lists six course discovery families, displays three featured courses and two student testimonials, and includes an instructor introduction. The page also renders three zero-value counters (0k+ course students, 0+ courses and 0% satisfaction). Those counters are not meaningful approved performance data and remain excluded from the rebuild. The current homepage exposes 16 unrelated gambling/betting footer links to unrelated domains. They remain excluded from the rebuild and require an authorised WordPress/hosting investigation. Their presence is consistent with possible SEO-spam injection but does not prove the entry point, root cause or complete compromise.

## About and team

The About page continues to publish a vision and mission and three team profiles:

- Abdul Aleem Khan — Vertical Head Cyber Security & Cloud Security.
- Tajuddin — Technical Head Networking & Cyber Security.
- Mohammed Khalid — Technical Head For Networking Security.

Use the published role wording as the source of truth. Do not infer certifications, years of experience or other credentials beyond what the company has approved.

## Gallery

The public Gallery page continues to show training and corporate-training photographs. A separate third-party client-logo collage is not imported into the rebuild. Client names/logos should only be displayed with documented permission and owner approval.

## Courses

The public catalogue continues to list 20 courses and catalogue fee pairs. The rebuild keeps the two CCNA-related fee conflicts withheld because the catalogue and individual detail pages disagree. CEH and Fortinet long-form syllabus content remain flagged for provider attribution review. No replacement outline or duration is invented.

## Contact

The public Contact page continues to publish `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a separate J.P. Nagar training-centre reference. Confirm the exact session venue before travel. Published claims about certification, 100% job assistance and 24/7 lab access remain owner-review items and are not restated as guarantees in the rebuild.

## Rebuild actions retained

- Exclude the zero-value counters and unrelated gambling/betting links.
- Keep source-backed team, gallery, course and contact details with qualifications where necessary.
- Keep unverified checkout host blocked; the rebuild does not provide online payment.
- Keep GA4 disabled until the owner configures a valid Measurement ID and a visitor explicitly opts in.
- Keep enquiry phone number optional and do not add a server-side lead database or CRM.
