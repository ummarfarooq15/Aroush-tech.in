# Competitor UX review — Session 33

Review date: 7 November 2026

The review considered the public pages below only to identify useful information architecture and interaction patterns. Competitor prices, course durations, schedules, credentials, testimonials, ratings, student counts, placement statistics and guarantees were not copied into AROUSH content.

## Apna College

Reference: https://www.apnacollege.in/prime

Observed UX patterns:
- Separates guidance for different learner situations, including engineering students, working professionals and non-CS learners.
- Explains programme content and learning goals in scannable sections.
- Uses clear calls to action near programme information.

AROUSH application:
- Keep the goal-based learning-path page and course categories easy to scan.
- Help visitors choose by interest/starting point without claiming a formal prerequisite sequence or career outcome.

## i-Medita

References:
- https://www.imedita.com/
- https://www.imedita.com/frequently-asked-questions/
- https://www.imedita.com/courses/

Observed UX patterns:
- Makes FAQ, course catalogue, instructor and schedule information easy to find.
- Uses course-category navigation and contextual enquiry actions.
- Publishes operational details that help a visitor understand what must be confirmed before enrolling.

AROUSH application:
- Added a dedicated FAQ page, grouped by topic and linked from navigation, footer, contact page and chatbot.
- Kept schedules, prerequisites, venue and fee details explicitly subject to confirmation where the AROUSH source is incomplete or conflicting.

## PyNet Labs

References:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

Observed UX patterns:
- Provides a searchable course catalogue and visible category groupings.
- Uses programme groupings to help learners browse by technical direction.
- Places course exploration and human guidance near each other.

AROUSH application:
- Retain catalogue search/category filters and the existing learning-path collections.
- Keep human enquiry routes available without inventing live batch dates or claiming placement outcomes.

## Boundaries

This is a UX comparison, not a validation of competitor claims. No competitor marketing numbers, ratings, course prices, testimonials, guarantees, credentials or schedules were reused. AROUSH facts remain grounded in its own public pages or supplied company material, and unresolved items remain on the owner-approval checklist.
