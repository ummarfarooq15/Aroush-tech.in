# AROUSH Tech analytics, enquiries and privacy requirements

**Updated:** 7 November 2026  
**Status:** Development implementation only; no deployment or live-site integration has occurred.

## Approved scope

The owner explicitly approved the full companion visitor-intelligence application on 7 November 2026, including Supabase lead storage, voluntary email and phone OTP verification, aggregate visitor analytics and an administrator dashboard. This approval is limited to development work in the source bundle. It does not authorise production deployment, GitHub pushes, DNS changes, live WordPress edits or changes to hosting/provider accounts.

The companion app is located at `apps/visitor-intelligence`. It remains separate from the main AROUSH Tech Next.js marketing website so its API routes and dashboard do not collide with the root app. The root marketing website's enquiry form remains a review-first email handoff and does not silently submit to the companion database. No CRM integration is included or approved in this scope.

## Main website GA4 policy

- GA4 is optional and must load only after a visitor explicitly accepts analytics.
- Reject must be available alongside Accept.
- A persistent Privacy settings control must let a visitor reopen the choice and explicitly withdraw or re-accept.
- Opening settings alone must preserve the saved choice.
- `NEXT_PUBLIC_GA_MEASUREMENT_ID` remains blank until the owner supplies and configures an authorised AROUSH GA4 Measurement ID.
- Google Signals, advertising personalisation and unnecessary Enhanced Measurement events remain disabled unless separately reviewed and approved.
- Do not send phone numbers, email addresses, names, message content, personal records or sensitive values in URLs, page titles, analytics parameters or custom dimensions.

## Companion analytics policy

The companion tracker sends nothing until the visitor explicitly accepts optional analytics. Rejecting analytics leaves the website usable. A persistent Privacy control lets the visitor reopen the choice and withdraw permission.

The dashboard reports aggregate:

- page views and page paths;
- approximate active page/visit time grouped within a temporary browser-tab session;
- browser, operating system and device categories;
- referral source and non-personal UTM labels; and
- approximate city/region/country when the hosting provider supplies those values.

The temporary tab token is created only after consent, held in `sessionStorage`, and HMAC-hashed on the server. It is used only to group page views within that tab. There is no persistent visitor ID, returning-person recognition, cross-device linkage, individual visitor list or visitor-journey view. Raw or masked IP addresses, device fingerprints, screen dimensions, locale, timezone, precise GPS, contact details and form contents are not stored in analytics tables. The application does not use analytics to infer a person's identity or phone number.

Page time is approximate active-tab time. A browser close, network failure, privacy extension or blocked request can prevent the final page-time event. Bot classification is a user-agent heuristic and is not proof that an event came from a bot or a human.

## Enquiry database and OTP policy

The companion enquiry form collects only details a visitor deliberately enters: name, email, mobile number, optional company, interest and message. It has a clear, unticked-by-default contact-consent checkbox. Phone is required for this OTP-enabled enquiry path and is collected only because the visitor voluntarily enters it into the clearly described form; website visits never reveal or infer a phone number. Marketing permission is separate and is not requested by this form.

Before a lead is saved:

1. the visitor completes Cloudflare Turnstile human verification for OTP sending and final submission;
2. the email address is verified through a six-digit Resend code;
3. the mobile number is verified through a six-digit MSG91 code; and
4. the visitor ticks contact consent and submits the form.

Email OTP verification uses a database RPC to lock the challenge row, atomically increment failed attempts and consume a successful code once. SMS verification uses a single in-flight database reservation before the MSG91 call and an atomic completion RPC. Lead creation locks and consumes both verified challenges in one database transaction so concurrent requests cannot create duplicate leads from the same verification pair.

Supabase is used only by server-side routes with a secret key. RLS is enabled and direct `anon`/`authenticated` access is revoked. The administrator dashboard displays lead contact details only after signed-cookie authentication. Named staff access, strong credentials, provider account security and deletion procedures remain owner responsibilities.

## Providers

Planned providers in the companion app:

- Supabase — database storage;
- Vercel — application hosting;
- Resend — email OTP delivery;
- MSG91 — SMS OTP delivery and verification;
- Cloudflare Turnstile — human/bot challenge.

The main website's optional GA4 integration uses Google Analytics 4 only after owner configuration and visitor opt-in. No GA4 Measurement ID is included in this source package.

## Retention, deletion and legal review

No automatic retention schedule is active. Before production, the owner must approve and configure periods for analytics events, lead records, OTP challenges, rate-limit keys and provider-side logs. The owner must also approve the official privacy contact, lawful purpose and consent wording, access roles, deletion/access/grievance process, backups, incident response, provider contracts and cross-border processing disclosures.

Obtain qualified legal review for the Digital Personal Data Protection Act, 2023, DPDP Rules, 2025 and other applicable jurisdictions as of the actual launch date. This engineering note and the draft privacy notice are not legal advice.

## Owner setup checklist

1. Supply the authorised GA4 Measurement ID for the root website, if GA4 is wanted; keep it blank otherwise.
2. Create AROUSH-owned Supabase, Resend, MSG91 and Cloudflare accounts and a staging/hosting environment.
3. Configure all secrets privately in the hosting platform, including separate `OTP_PEPPER`, `RATE_LIMIT_PEPPER`, `ANALYTICS_SESSION_PEPPER` and `ADMIN_SESSION_SECRET` values.
4. Configure Turnstile hostnames and test server-side Siteverify, expired tokens and token replay rejection.
5. Run the SQL schema in a non-production Supabase project and test RLS, atomic OTP functions and one-time lead creation.
6. Approve retention periods and implement scheduled deletion.
7. Replace the privacy contact placeholder and approve the final notice with legal counsel.
8. Test consent acceptance, rejection, withdrawal and re-acceptance; confirm no tracker request before consent and no data after rejection.
9. Test email and SMS delivery with owner-controlled addresses/numbers, DLT settings and provider spend limits.
10. Complete Node 24 dependency installation, lockfile review, typecheck, lint, production builds and real mobile/desktop browser tests.
11. Obtain separate explicit deployment approval before connecting GitHub, Vercel, Supabase, DNS or the live WordPress site.

## Current deployment boundary

No live website, WordPress installation, DNS record, GitHub repository, GA4 property, Supabase project, Vercel project, Resend account or MSG91 account was modified. No tracker snippet was installed on the live site. No deployment was performed.
