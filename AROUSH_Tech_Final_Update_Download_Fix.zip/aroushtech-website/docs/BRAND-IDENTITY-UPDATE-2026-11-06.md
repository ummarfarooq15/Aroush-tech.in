# AROUSH Solutions brand identity update — 6 November 2026

## Owner-provided asset
The owner approved the supplied 3D blue AROUSH Solutions logo for use across the website. The original 4096 × 4096 transparent PNG is retained at `public/images/aroush-solutions-3d-logo.png` without modification.

## Applied placements
- Site header: a square emblem-only derivative plus a readable text wordmark, avoiding a tiny duplicate wordmark.
- Homepage hero: the emblem-only derivative beside the Bengaluru/India eyebrow.
- Site footer: the complete approved logo lockup.
- Ask AROUSH chatbot header: the emblem-only derivative.
- Browser favicon, shortcut icon and Apple touch icon: `app/icon.png`, derived from the supplied artwork and cropped to the emblem so it remains legible at small sizes.
- Organization structured data: points to the optimized local logo asset.

## Asset handling
- `public/images/aroush-solutions-logo.webp` is a transparent, 1000 × 915 WebP full-lockup derivative used in the footer and Organization structured data.
- `public/images/aroush-solutions-symbol.webp` is a transparent square WebP emblem crop used in compact header, homepage and chatbot placements.
- `public/images/aroush-solutions-logo.png` is retained as a larger transparent PNG derivative.
- The original 4096 × 4096 PNG remains unchanged for future brand work and high-resolution needs.
- The image itself has not been recoloured, redrawn or otherwise restyled.

## Validation status
- Original, display derivative and favicon files are present and non-empty.
- The shared logo references are checked by `scripts/validate-brand.mjs`.
- Responsive logo styles and text alternatives are checked by the same validator.
- Full Next.js build and browser/device checks remain subject to the Node.js 24 and dependency-installation requirements documented in the validation report.

No live site, WordPress, DNS, repository or deployment changes were made.
