# Competitor UX review — Session 35

Review date: **7 November 2026**

Only public navigation and information-discovery patterns were considered. This is not an endorsement or validation of competitor commercial claims. No competitor prices, ratings, testimonials, statistics, credentials, schedules, placement figures or guarantees were copied.

## Apna College

Reference: https://www.apnacollege.in/prime

Observed UX patterns:
- Separates information for different learner situations, including engineering students, working professionals and non-CS learners.
- Explains curriculum and programme outcomes in scannable sections.
- Keeps calls to action near the relevant programme details.

AROUSH application:
- Keep goal-based learning paths and course categories easy to scan.
- Do not infer learner prerequisites or guarantee a career outcome from a competitor's layout.

## i-Medita

Reference: https://www.imedita.com/frequently-asked-questions/

Observed UX patterns:
- Organises FAQs around practical decisions such as location, schedule, prerequisites, fees and payment.
- Makes operational information easier to find without reading every course page.
- Provides routes to a human team for details that vary by programme.

AROUSH application:
- Retain the three existing FAQ groups and browser-side question/answer search.
- Keep current fees, batch schedules, prerequisites, venue and service availability subject to direct confirmation where the AROUSH source is incomplete or conflicting.

## PyNet Labs

Reference: https://www.pynetlabs.com/courses/

Observed UX patterns:
- Places search and category filters close to the course catalogue.
- Offers technical groupings and learning-path navigation to narrow a broad catalogue.
- Keeps course exploration and human guidance discoverable.

AROUSH application:
- Retain the searchable catalogue and category filters.
- Added a simple A–Z / Z–A name sort while preserving AROUSH's original catalogue order as the default.
- Sorting only rearranges existing AROUSH records; it does not add inferred level, duration, fee, schedule or prerequisite data.

## Boundaries

This review compares UX patterns only. Competitor marketing figures, prices, ratings, testimonials, credentials, schedules, placement statistics and guarantees were not reused. AROUSH information remains grounded in its own public pages or supplied company material, and unresolved items remain in the owner-approval checklist.
