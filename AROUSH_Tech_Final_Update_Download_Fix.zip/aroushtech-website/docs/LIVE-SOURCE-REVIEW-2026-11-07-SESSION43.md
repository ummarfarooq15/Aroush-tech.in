# Live AROUSH source review — Session 43

Date: 7 November 2026

Official public pages reopened:

- https://aroushtech.in/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/courses/
- https://aroushtech.in/gallery/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/ccna/
- https://aroushtech.in/ccna-devnet/

## Current published information

### Homepage

- Advertises “20+ Job-Ready Courses” and a free demo.
- Presents six course-category themes: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing.
- Features Agentic AI with LangChain & Hugging Face at ₹35,000, CCNP Security at ₹45,000 and CEH at ₹25,000.
- Displays two named student testimonials and an instructor introduction.
- Also exposes three zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes the counters and unrelated links. An authorised WordPress/hosting investigation is needed; this crawl does not prove the injection mechanism or full compromise.

### About and team

- Vision: to be a preferred consulting and training services company providing solutions and training that empower people and businesses around the world.
- Mission: the published wording focuses on helping people realise their potential through training programmes.
- Three public profiles remain visible: Abdul Aleem Khan — Vertical Head Cyber Security & Cloud Security; Tajuddin — Technical Head Networking & Cyber Security; Mohammed Khalid — Technical Head for Networking Security.
- The page still contains zero-value course/student/satisfaction counters; these are excluded from the rebuild.

### Course catalogue

- The public catalogue contains 20 entries.
- The displayed fees for the other 18 entries are retained only as website-listed reference amounts with a confirm-before-payment note.
- CCNA and CCNA DevNet each show ₹19,999 in the catalogue but ₹19,000 on their individual pages. The rebuild withholds both numeric fees pending owner confirmation.
- The homepage featured amounts for Agentic AI with LangChain & Hugging Face (₹35,000), CCNP Security (₹45,000) and CEH (₹25,000) match the current catalogue amounts.
- The live course pages expose a third-party checkout destination on some Agentic AI pages. It remains unverified and is not used by the rebuild.

### Gallery

- The public gallery shows training and corporate-training photographs and names corporate training context involving Larsen & Toubro Infotech, Capgemini and NTT.
- The rebuild retains ten training photographs. The separate third-party logo collage is excluded pending usage and relationship confirmation.

### Contact

- Public email: `taj@aroushtech.in`.
- Public phone: `+91 88676 92074`.
- Corporate office: `#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029`.
- Registered office: `AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078`.
- The page refers to a Bengaluru J.P. Nagar training centre but does not provide a complete visitor-ready address. The office addresses must not be presented as the training venue.
- Certification, 100% job-assistance and 24/7 lab-access statements remain owner-review items; the rebuild does not state these as guarantees.

## Rebuild decisions

- Keep the 20-course catalogue and source-backed course outlines, with explicit fee and syllabus caveats where the source conflicts or attribution is uncertain.
- Keep the homepage zero counters, unrelated gambling links, third-party logo collage and unverified checkout destination out of the rebuild.
- Do not invent course schedules, fees, credentials, guarantees or a complete J.P. Nagar venue address.
- Keep course payment outside the rebuild until the owner verifies the merchant and payment process.
- Preserve the privacy-first analytics configuration: no GA4 Measurement ID is present and analytics is disabled until explicit opt-in after owner setup.

## Source URLs

- https://aroushtech.in/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/courses/
- https://aroushtech.in/gallery/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/ccna/
- https://aroushtech.in/ccna-devnet/
