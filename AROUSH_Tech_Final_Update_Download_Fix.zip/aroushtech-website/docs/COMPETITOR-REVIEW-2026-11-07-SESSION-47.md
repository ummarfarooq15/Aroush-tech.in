# Competitor UX review — Apna College, i-Medita and PyNet Labs

**Reviewed:** 7 November 2026  
**Purpose:** Identify transferable information-architecture and course-discovery patterns for AROUSH Tech. This is UX research only. No competitor wording, prices, ratings, testimonials, statistics, placement claims, guarantees, course schedules or credentials are copied into AROUSH content.

## 1. Apna College

Official pages reviewed:

- https://www.apnacollege.in/
- https://www.apnacollege.in/course/sigmax
- https://dsa.apnacollege.in/

Observed patterns:

- The main navigation surfaces current programmes and distinguishes DSA, web-development and combined placement-preparation paths.
- The SigmaX page explains the programme as a bundle, then breaks it into curriculum areas, projects, duration/access information and a large FAQ section.
- The separate DSA sheet uses a structured topic/problem roadmap and progress-oriented interaction.

Transferable AROUSH improvements:

- Make the learning goal clear before the visitor chooses an individual course.
- Keep a curriculum/outline section close to the course introduction.
- Answer practical questions—starting knowledge, format, duration, language, support and access—only when AROUSH has verified the details.
- Keep a useful FAQ beside the course enquiry path.

Already applied in the AROUSH project:

- Six goal-based learning paths link directly to published course records.
- Course detail pages display only source-supported outline topics and duration.
- Course FAQs and the grounded site chatbot provide additional navigation without inventing delivery details.
- Course comparisons and shareable catalogue state let learners review multiple options.

Not copied: Apna College batch names, placement positioning, mentor claims, learner metrics, schedules, pricing, project claims or guarantees.

## 2. i-Medita

Official pages reviewed:

- https://www.imedita.com/
- https://www.imedita.com/courses/fortinet-firewall-training/

Observed patterns:

- The homepage groups a broad catalogue by vendor/technology and makes trainer profiles, popular courses, support features and upcoming events easy to find.
- Individual course pages use a compact information block for duration, level, mode, language, lab access, certificate and support details, followed by course objectives and upcoming sessions.
- The site gives visitors a clear way to speak with a training adviser or request a demo.

Transferable AROUSH improvements:

- Keep category navigation and instructor/team information easy to reach.
- Use a consistent course-details block when the source contains the relevant facts.
- Offer an enquiry path for visitors who need help choosing or want to ask about a demo.
- Do not publish batch dates, lab availability, language, support or credential details until AROUSH confirms them.

Already applied in the AROUSH project:

- Course category filters and goal-based learning paths.
- Dedicated team page with the three profiles present on the AROUSH source site.
- Course pages show published syllabus status and duration only where verified.
- Course and business enquiries have separate routes; demo availability is phrased as a question for the team, not a promise.

Not copied: i-Medita course fees, job-guarantee language, lab/support guarantees, schedules, trainer biographies, student counts, ratings or testimonials.

## 3. PyNet Labs

Official pages reviewed:

- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

Observed patterns:

- The homepage and catalogue make technology families and featured programmes easy to scan.
- The course catalogue provides search, category and career-path navigation, sorting and additional filters.
- Course cards can surface level, duration and format, while course detail pages provide a route to the curriculum.

Transferable AROUSH improvements:

- Help learners narrow a broad catalogue by technology and learning goal.
- Keep search, category filters, sort controls and clear course-detail links visible.
- Use compact metadata only when each value is supported by AROUSH's own published source.

Already applied in the AROUSH project:

- Search across course names, skills and technologies.
- Category filters, A–Z sorting and an outline-availability filter.
- Compare up to three courses and share the filtered/comparison view in the URL.
- Display duration and fee information only when the AROUSH source provides a usable value; conflicting fee records are withheld pending confirmation.

Not copied: PyNet Labs' course counts, student numbers, ratings, provider claims, hiring partners, placements, trainer credentials, prices or guarantees.

## 4. AROUSH source-of-truth guardrails

The current public AROUSH site was reviewed alongside the existing migration notes. The source advertises IT and cybersecurity categories, individual course pages, team profiles, testimonials, a gallery and two office addresses. The website migration currently validates 20 public course records, 10 services, 3 team profiles, 10 gallery photographs, 8 industry profiles, 2 published office addresses and 2 live-site testimonials.

The catalogue currently has 18 fee pairs that match the live catalogue and 2 course fee conflicts that are withheld from the public display pending owner confirmation. Course durations and outline topics are shown only when the source page supports them. Do not fill missing levels, formats, schedules, prerequisites, lab entitlements, certification claims or job outcomes by copying competitor metadata.

## 5. Next UX priorities

1. Keep the existing catalogue filters and learning paths easy to use on narrow mobile screens.
2. Continue checking that course detail pages distinguish published facts from items the learner should confirm with AROUSH.
3. Keep the chatbot's quick replies and typed answers grounded in the same verified course/service records and link to relevant pages.
4. Improve enquiry form clarity and keep learner and business routes separate.
5. Add new course metadata only after AROUSH confirms it in its own source material.

**Conclusion:** The current AROUSH build already includes most of the useful course-discovery patterns identified in this review. The remaining gap is verified AROUSH-owned metadata—not more promotional claims or copied competitor statistics.
