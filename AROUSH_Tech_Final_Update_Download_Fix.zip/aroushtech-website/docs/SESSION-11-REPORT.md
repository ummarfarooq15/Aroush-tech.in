# Session 11 — chatbot and navigation refinement

## Changes

- Expanded the local FAQ assistant to answer common questions about course discovery, CCNA, catalogue fees, batch schedules, training formats, corporate learning, SOC/SIEM learning paths, services and contact details.
- Added contextual links from assistant answers to the relevant course, training, service or contact page.
- Added explicit caution around fees, schedules, placement/certification promises, 24×7 lab access and managed SOC monitoring; the assistant directs visitors to confirm current terms with the AROUSH team.
- Improved chatbot accessibility with clearer labels, live-region announcements, a disabled empty-message send button and keyboard focus styling.
- Added the `#soc-siem` anchor to the training page so the chatbot's SOC/SIEM link opens the correct section.
- Updated the chatbot maintenance note for future developers.

## Validation

- `node scripts/validate-content.mjs`: passed — 10 services, 20 public courses, 19 source outlines plus one owner-review note, 6 SOC/SIEM paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 office addresses, 2 testimonials, 28 public routes and 23 redirects.
- `node --check next.config.mjs`: passed.
- `node --check scripts/validate-content.mjs`: passed.
- CSS brace balance: passed (449 opening and 449 closing braces).
- Chatbot panel target and SOC/SIEM section anchor: present.

## Still blocked

- Node.js available in this execution environment is 22.16.0; project requirement is Node.js 24.x.
- `node_modules` is not present. Full framework TypeScript checking, ESLint, production build, dependency audit and browser/device QA cannot be claimed as passed.
- No GitHub push, live website edit, WordPress change, DNS update or production deployment was performed.

## Data visualisation decision

No business performance chart was added because no verified, approved time-series or KPI dataset is available. The website must not fabricate student totals, placements, satisfaction percentages, revenue or course outcomes. Add charts only after AROUSH supplies and approves the underlying data.
