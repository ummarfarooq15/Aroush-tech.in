# Session 26 — TypeScript syntax guard, source correction and live review

Date: 7 November 2026

## Summary

This session made the TypeScript/TSX syntax check repeatable in the project's normal offline validation workflow, corrected one small team-role wording drift against the current About page, refreshed the public source and competitor review, and rechecked the release blockers. No live service or repository was modified.

## Code and content changes

- Added `scripts/validate-typescript-syntax.mjs`.
  - Parses `.ts` and `.tsx` files using the project's local TypeScript package when installed.
  - Falls back to a globally installed TypeScript compiler when the local package is unavailable, so source checks can run before dependency installation.
  - Reports file, line and column for parser errors.
  - Explicitly states that syntax parsing is not semantic typechecking or module resolution.
- Added `npm run validate:typescript-syntax` and included it in `npm run check:offline`.
- Updated `scripts/validate-release-config.mjs` to require the new script and confirm it is in the offline suite.
- Corrected Mohammed Khalid's role in `lib/content.ts` from “Technical Head – Networking Security” to “Technical Head for Networking Security”, matching the current live About page's “Technical Head For Networking Security” wording in normal sentence case.
- Added a content assertion for the corrected published role.
- Updated the course-catalogue review note and privacy-notice review date to 7 November 2026.
- Updated the README, beginner developer guide, source register, competitor review, privacy documentation and incident/security notes.

## Live AROUSH source review

Reopened the public homepage, About, Courses, Gallery and Contact pages on 7 November 2026.

- Homepage: still advertises 20+ job-ready courses and a free demo, shows six discovery families, three featured courses, two testimonials and an instructor introduction. Zero-value counters remain visible and are excluded from the rebuild. The same 16 unrelated gambling/betting footer links remain visible.
- About: mission and vision remain visible. The three public team names and roles remain visible; Mohammed Khalid's role wording was corrected in the rebuild.
- Courses: 20 course cards and published fee pairs remain visible. The rebuilt 20-course catalogue remains aligned with the public listing. Fees are explicitly labelled as website-listed references and must be confirmed before payment.
- Gallery: ten training/learner photographs are represented. The separate third-party company-logo collage and unverified placement/client implications remain excluded.
- Contact: `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses, J.P. Nagar training-centre reference and online/offline/hybrid FAQ remain visible. Certification, 100% job-assistance and 24/7 lab-access wording remains excluded pending owner approval.

See `docs/LIVE-SOURCE-REVIEW-2026-11-07.md` and `docs/SOURCE-REGISTER.md`.

## Competitor UX research

Rechecked:

- Apna College Prime: structured AI/ML curriculum grouping and clear programme next steps.
- i-Medita FAQ and CCNA course: location, schedule, language, trainer/course detail and enquiry information close to the programme.
- PyNet Labs catalogue and contact: technology/category and career-path discovery plus visible human counselling routes.

Applied only general information-architecture lessons. No competitor prices, discounts, statistics, ratings, testimonials, credentials, schedules, hiring partners, placement claims or guarantees were copied.

## Dependency version review

The pinned Next.js 15.5.29 release is present on the official Next.js GitHub release page and includes the 3 November 2026 maintenance/security fixes for its 15.5 line. React 19.3.1 is present on the official React release page (14 October 2026). The project keeps these pins rather than attempting a major Next.js 16 migration without a working dependency installation and build. This version check is not a substitute for a lockfile-backed `npm audit`.

- Next.js release history: https://github.com/vercel/next.js/releases
- React release history: https://github.com/facebook/react/releases

## Validation performed

- `npm run check:offline` — passed all 15 offline/source validators, including the new TypeScript syntax check.
- `npm run validate:typescript-syntax` — passed 29 `.ts`/`.tsx` files with global TypeScript 5.8.3.
- `npm run validate:javascript` — passed 20 `.mjs` files.
- Global PostCSS parsed `app/globals.css`: 514 rules and 20 at-rules.
- Negative parser test — a temporary malformed TSX file produced four parser diagnostics; the file was removed and the clean 29-file check passed again.
- `npm run preflight:release` — correctly reports Node.js 22.16.0 instead of 24.x, no package lockfile and missing local dependencies.
- `npm run validate:content` — passed with 10 services, 20 courses, 19 source outlines plus one owner-review note, six SOC/SIEM paths, three team profiles, ten gallery photos, two office addresses and two homepage testimonials.

## Production blockers

- Full TypeScript semantic typecheck is blocked because local Next.js, React and type packages are not installed.
- ESLint is blocked because the local ESLint package is missing.
- Next.js production build is blocked because Next.js is not installed.
- npm audit is blocked because `package-lock.json` is absent (`ENOLOCK`).
- Runtime remains Node.js 22.16.0; the project requires Node.js 24.x.
- npm registry DNS resolution is still unavailable (`EAI_AGAIN` resolving `registry.npmjs.org`), so dependency installation and lockfile generation cannot complete in this runtime.
- Real Android and desktop browser testing remains pending a successful staging build.
- The live WordPress footer finding remains an owner/hosting investigation blocker. Public-page evidence does not prove the underlying compromise or identify the entry point.

## Privacy and deployment

GA4 Measurement ID remains blank. Analytics stays disabled until the owner configures a valid ID and a visitor explicitly opts in. Reject, withdrawal and persistent settings remain available. Phone number is optional and voluntarily supplied. The contact form remains mailto-only. No server-side lead database or CRM was added. No GitHub push, WordPress edit, DNS change, hosting change or production deployment was performed.
