# Live source review — 7 November 2026, Session 47

**Source of truth:** https://aroushtech.in/  
**Scope:** Public homepage, About, Courses and Contact pages, plus the migration source register. No live website changes were made.

## Source observations

- Homepage: https://aroushtech.in/ — public navigation links to About, Gallery, Team, Courses and Contact; the homepage advertises more than 20 job-ready courses and groups cybersecurity, networking, cloud/DevOps, AI/ML, Linux and web-application testing.
- About/team: https://aroushtech.in/aboutus/ — publishes the mission/vision and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid.
- Contact: https://aroushtech.in/contact-us/ — publishes `taj@aroushtech.in`, `+91 88676 92074`, a corporate office in New Gurupanapalya / Bannerghatta Main Road, Bengaluru and a registered office in Sarakki, Bengaluru. The migrated site keeps the source addresses as text and uses address-search map links rather than unverified coordinate pins.
- Course catalogue: https://aroushtech.in/ — lists individual course categories and website-listed fees. The rebuild has 20 public course records. Eighteen fee pairs match; two fee conflicts are withheld pending owner confirmation.
- Course detail pages: public course pages provide outlines and selected duration values. The rebuild includes only source-visible outline topics and durations. CEH and Fortinet long-form content remains on hold where provider-attribution wording needs AROUSH approval.
- Gallery: https://aroushtech.in/ — source gallery photographs remain referenced in the migration data; image rights and original asset collection should be confirmed before final production migration.

## Source-driven content controls

- Do not invent trainer credentials, class schedules, delivery formats, lab entitlements, prerequisites, guarantees or placement outcomes.
- Do not use competitor claims or statistics as AROUSH facts.
- Keep the two fee-conflict records withheld until the owner confirms the current fee.
- Keep provider-attributed CEH/Fortinet syllabus content on hold until AROUSH approves the wording and delivery ownership.
- Keep the current public WordPress site untouched during development. The known SEO-spam footer-link issue remains a separate owner/host investigation item; this session did not attempt live cleanup.

## Migration validation

`npm run validate:content` passed with 10 services, 20 public courses, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 published office addresses, 2 live-site testimonials, 31 public routes, 23 permanent redirects and Organization/WebSite/Course/Breadcrumb structured data.

## Deployment boundary

No live WordPress, DNS, GitHub, hosting, GA4 property or production deployment was changed.
