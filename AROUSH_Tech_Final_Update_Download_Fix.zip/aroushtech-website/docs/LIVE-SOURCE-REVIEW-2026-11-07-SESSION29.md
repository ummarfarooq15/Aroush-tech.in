# Live AROUSH source review — Session 29

Review date: 7 November 2026  
Source of truth: https://aroushtech.in  
Scope: public company, course, team, gallery and contact content. This is a public-page review only; it is not a WordPress, hosting, database or server security audit.

## Current public-page observations

| Page | What was visible during this review | Rebuild treatment |
|---|---|---|
| Homepage — https://aroushtech.in/ | Advertises 20+ job-ready courses and a free demo; lists six course discovery families; features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH; displays learner testimonials and instructor introduction; still shows zero-value counters and 16 unrelated gambling/betting footer links. | Retain source-backed course/demo positioning, published testimonials and instructor introduction. Exclude zero-value counters and unrelated footer links. |
| About — https://aroushtech.in/aboutus/ | Publishes the company vision and mission, and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid. Mohammed Khalid's published role is “Technical Head For Networking Security”. | Keep the three names and public role wording. Do not add qualifications, certifications or experience not stated on the public page. |
| Courses — https://aroushtech.in/courses/ | Lists 20 course cards with descriptions and previous/current fee pairs. | Keep the 20 catalogue entries and label listed fees as references that must be reconfirmed before payment. |
| Gallery — https://aroushtech.in/gallery/ | Shows training and learner photographs, corporate training context, placement-related wording and a separate image/logo area. | Keep the ten selected training/learner photographs already migrated. Do not use the separate client-logo collage or repeat unverified placement outcomes. |
| Contact — https://aroushtech.in/contact-us/ | Publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses, and FAQs describing online/offline/hybrid training. The same FAQ also states certification, “100% job assistance” and “24/7 lab access”. | Keep published contact information and distinguish the two offices from the separate J.P. Nagar training-centre reference. Do not repeat certification, placement or 24/7 access promises until AROUSH confirms current written terms. |
| Agentic AI with LangChain & Hugging Face — https://aroushtech.in/agentic-ai-with-langchain-hugging-face/ | Publishes a detailed outline, instructor information, a listed fee and a “Buy Course” link to `demosites.royal-elementor-addons.com`. | Keep only AROUSH-authored course outline content and listed catalogue fee with confirmation caveat. Do not copy or link the third-party checkout destination. |
| Agentic AI with LangGraph and LangChain — https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/ | Publishes a 15-topic outline, instructor information, a listed fee and a “Buy Course” link to `demosites.royal-elementor-addons.com`. No duration is stated. | Keep the published outline. Do not infer a duration or reuse the third-party checkout destination. |

## Payment-link safety decision

The two reviewed Agentic AI detail pages expose a “Buy Course” destination on `demosites.royal-elementor-addons.com`. The destination was not opened, authenticated or tested. Its merchant identity, payment processor, privacy handling, refund terms and AROUSH authorization remain unverified.

The rebuild therefore has no online course checkout. Course pages use an enquiry route and explicitly ask visitors to confirm payment instructions directly with AROUSH before paying. The external-link policy now treats the observed host as explicitly blocked, even if a future developer tries to add it to the general approved-host list. Owner approval is required before any checkout integration or external payment link is introduced.

## WordPress SEO-spam observation

The public homepage still exposes 16 unrelated gambling/betting footer links. This is consistent with possible SEO-spam injection or an unapproved integration, but the public page alone cannot identify the injection point or prove a full server compromise. An authorised WordPress/hosting administrator must inspect administrator accounts, plugins, themes, database content/options, widgets, custom code, uploads, scheduled tasks, hosting configuration, backups, logs and Search Console before migration or DNS cutover.

## Rebuild and privacy status

- No unverified third-party checkout URL is present in the rebuilt application source.
- No online payment processing is implemented.
- Course fees remain website-listed reference amounts and require confirmation.
- GA4 remains disabled and its Measurement ID remains blank.
- Analytics still requires both owner configuration and explicit visitor opt-in.
- The enquiry form remains a visitor-controlled `mailto:` handoff; it does not store leads on a server.
- Phone remains optional and is only included when the visitor chooses to provide it.
- No CRM, server-side lead database, fingerprinting or covert visitor identification was added.
- No live WordPress, GitHub repository, DNS or deployment changes were made.

## Official page references

- https://aroushtech.in/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/courses/
- https://aroushtech.in/gallery/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/agentic-ai-with-langchain-hugging-face/
- https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/
