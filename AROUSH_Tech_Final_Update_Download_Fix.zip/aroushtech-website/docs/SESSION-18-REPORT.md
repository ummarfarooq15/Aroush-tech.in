# Session 18 — chatbot intent routing, mobile accessibility and source recheck

Date: 6 November 2026

## Work completed

- Moved the rule-based chatbot answer logic into `lib/chatbot-rules.mjs`, keeping it separate from the visual React component so it can be tested without installing Next.js.
- Fixed a routing ambiguity where questions such as "cybersecurity consulting" or "firewall setup" could be mistaken for course-discovery questions. Explicit service requests now lead to `/services`; learning questions continue to lead to `/courses` or `/training`.
- Added SOC/SIEM intent handling: training questions go to `/training#soc-siem`; deployment/monitoring/service questions go to `/services#soc-siem`. SOC/SIEM pricing questions are directed to the team because no public fee is verified.
- Added a service-proposal pricing response instead of incorrectly treating service pricing as course pricing.
- Added 22 dependency-free chatbot intent-routing cases plus an unknown-question handoff (23 assertions total), including services-versus-courses, SOC/SIEM, pricing, privacy, demo enquiries and unknown-question handoff.
- Prevented the chatbot launcher from referencing a panel that is not mounted while closed.
- Kept the mobile keyboard closed when the chatbot opens and after a quick reply. The question field receives automatic focus only on larger screens; touch-sized screens focus the close control first. After a quick reply, focus moves to the conversation log rather than disappearing with the removed quick-reply buttons.
- Increased the chatbot close, quick-reply and send-control touch targets and added safe-area spacing for devices with display cut-outs.
- Updated the beginner guide, chatbot note, README, competitor review and live-source review.
- Reopened the current AROUSH homepage, About, Courses, Gallery and Contact pages. The live homepage still features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH; the 20-entry catalogue, three team profiles, gallery and contact details remain visible. The Contact FAQ still contains unconfirmed certification, job-assistance and 24/7 lab-access claims; these remain excluded from the rebuild's promises.
- Refreshed competitor UX review using the official Apna College homepage/course page, i-Medita homepage and PyNet Labs homepage/catalogue. No competitor commercial claims were copied.

## Validation results

- `node scripts/validate-content.mjs`: **PASS** — 10 services, 20 public courses (19 source outlines and one owner-review note), six SOC/SIEM learning paths, three team profiles, ten gallery references, eight target-industry profiles, two offices, two testimonials, 30 public routes and 23 redirects.
- `node scripts/validate-privacy.mjs`: **PASS** — GA4 remains opt-in only, Measurement ID blank by default, reject/withdrawal and persistent settings present, voluntary phone field, no server-side lead database or CRM.
- `node scripts/validate-brand.mjs`: **PASS** — approved original logo, full/emblem derivatives and favicon remain valid.
- `node scripts/validate-ux.mjs`: **PASS** — chatbot disclosure and controls, mobile keyboard behavior, touch-target CSS, navigation focus, course search/filter recovery and email enquiry fallback.
- `node scripts/validate-links.mjs`: **PASS** — 30 internal paths, 20 course slugs, redirects and no broken internal routes or non-HTTPS external links.
- `node scripts/validate-learning-paths.mjs`: **PASS** — four collections, 20 valid course links, six SOC/SIEM options and no prerequisite claims.
- `node scripts/validate-chatbot.mjs`: **PASS** — 22 intent-routing cases plus unknown-question handoff (23 assertions total).
- `node --check` for all `.mjs` scripts and `next.config.mjs`: **PASS**.
- Original logo integrity and asset checks: **PASS** — the approved 4096 × 4096 source image remains unchanged.
- TypeScript/TSX syntax transpilation: **PASS** — 27 `.ts`/`.tsx` files, zero syntax diagnostics using global TypeScript 5.8.3. This is not a semantic typecheck.
- CSS parsing: **PASS** — global PostCSS parsed `app/globals.css` successfully (430 top-level rules/at-rules).

## Blockers and release gates

- Environment runtime is Node.js 22.16.0 / npm 10.9.2; project requires Node.js 24.x.
- `/opt/nvm/versions/node` contains only Node 22.16.0.
- A fresh `npm ping --fetch-retries=0 --fetch-timeout=8000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`; dependencies could not be installed.
- No `node_modules` or package lockfile is present. `npm run typecheck` exits with missing `next/*`, `react` and JSX type declarations; `npm run build` and `npm run lint` exit with `next: not found`. These are environment/dependency blockers, not successful checks.
- Dependency audit remains blocked because there is no package lockfile (`npm audit` reports `ENOLOCK`).
- Real browser/Android testing remains pending a working staging build.
- Team/gallery image rights, course prices, schedules, prerequisites, service availability, training venue and marketing claims remain owner approvals.

No GitHub repository, live WordPress website, DNS, hosting or production deployment was changed.
