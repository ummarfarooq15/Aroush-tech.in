# Competitor UX review — Session 37

Review date: **7 November 2026**

This review considers information architecture and visitor experience only. Competitor prices, ratings, testimonials, credentials, schedules, statistics, placement figures and guarantees are not copied into AROUSH content.

## Apna College

Reference: https://www.apnacollege.in/prime

Observed patterns:
- Audience-aware programme entry points.
- Curriculum organised into scannable topic groups.
- Course details and calls to action appear close to the relevant learning information.

AROUSH application:
- Retain audience/goal-based learning paths.
- Keep course details and direct human enquiry easy to find.
- Do not import Apna College course claims or commercial terms.

## i-Medita

Reference: https://www.imedita.com/frequently-asked-questions/

Observed patterns:
- FAQ topics reflect practical learner decisions such as venue, schedules, language, payment and prerequisites.
- Questions can be scanned without reading every course page.
- Human contact remains available for details that depend on a particular course or batch.

AROUSH application:
- Retain searchable, grouped FAQs.
- Keep unresolved fees, schedules, prerequisites, venue and service availability clearly marked for direct confirmation.

## PyNet Labs

Reference: https://www.pynetlabs.com/courses/

Observed patterns:
- Large course catalogue with technical categories.
- Category and career-path groupings help narrow course discovery.
- Course pages are linked from catalogue entries.

AROUSH application:
- Retain AROUSH's own search, category filters and natural A–Z/Z–A sorting.
- Add an in-browser course comparison feature for up to three AROUSH courses.
- Compare only AROUSH-published fields: category, outline availability, published duration and catalogue fee/confirmation status.
- Do not infer prerequisites, schedules, certification, job outcomes or delivery modes.

## Boundaries

No competitor pricing, discounts, ratings, testimonials, student counts, placement figures, credentials, schedules, job guarantees or performance statistics were imported. The course comparison feature uses only the AROUSH catalogue and course-detail records.
