# AROUSH Tech Visitor Intelligence — security and privacy review

**Review date:** 7 November 2026  
**Status:** Development integration only — not deployed and not production-approved.

## Approved scope

The owner explicitly approved the full companion application, including Supabase lead storage, voluntary email/phone OTP verification, aggregate visitor analytics and an administrator dashboard. Approval is for development integration only. No live site, DNS, GitHub, hosting or provider account changes are authorised by this review.

## Security and privacy controls implemented in this pass

- Browser-facing APIs reject missing or non-allowlisted `Origin` headers.
- Request JSON is capped at 16 KB and must use `application/json`.
- Rate-limit keys use HMAC with a separate secret pepper; raw IP, email and phone values are not stored as rate-limit keys.
- Client rate limiting trusts only the hosting platform's `x-vercel-forwarded-for` header. If that header is absent, requests share the `unknown` key and rate limits fail closed rather than trusting arbitrary forwarded headers.
- Recipient-specific hourly limits are keyed separately from client limits.
- OTP sends use a database reservation RPC to enforce a cross-IP resend cooldown.
- Email OTP attempt increments and successful one-time verification are atomic under a database row lock.
- SMS verification uses a single in-flight database token before the provider call and an atomic completion RPC.
- Lead creation locks and consumes both verified challenges in one database transaction, preventing duplicate submissions using the same verification pair.
- Cloudflare Turnstile is checked server-side through Siteverify for admin login, OTP sends and final lead submission. The response hostname must match the request origin. Production fails closed when Turnstile is not configured or validation fails.
- Supabase credentials remain server-only. RLS is enabled and direct `anon`/`authenticated` table access is revoked.
- Admin cookies are HTTP-only, SameSite=Strict, signed and limited to four hours. Login and data access are rate-limited/authenticated.
- Analytics is aggregate-only. The tracker creates a random tab-scoped token only after consent; the server stores an HMAC digest solely to group page views in that temporary tab. No persistent visitor ID, returning-person tracking, visitor profile table, raw/masked IP, screen size, locale, timezone, device fingerprint or individual visitor journey is stored/displayed.
- Page paths are query-free and sensitive-looking email/phone/UUID patterns are redacted. UTM values are restricted to non-personal slug characters.
- Phone number is collected only when the visitor voluntarily enters it into the clearly described enquiry form. Contact details are stored separately from analytics after contact consent and both OTP checks.

## Remaining blockers before production

1. **Provider setup and test evidence:** Resend, MSG91, Turnstile, Supabase and hosting accounts have not been configured. Verify email delivery, SMS delivery, India DLT approvals, provider spending limits, Turnstile success/expiry/replay rejection and server-side RLS using owner-controlled test accounts.
2. **Retention/deletion:** no scheduled cleanup is enabled. Owner must approve periods for analytics events, leads, OTP challenges, hashed rate-limit records and provider logs, then configure deletion and data-subject request workflows.
3. **Privacy notice/legal review:** replace the placeholder privacy contact; approve purposes, consent wording, provider disclosures, retention, data access/deletion/grievance workflow and cross-border processing details. Obtain qualified legal review for applicable Indian DPDP and other jurisdictional requirements.
4. **Admin identity:** the app uses one environment-configured administrator credential. Use a unique strong password, named staff access, secret rotation and hosting-account MFA. Application-level MFA and a full audited admin identity provider are not implemented.
5. **Rate-limit platform assumption:** the implementation trusts only Vercel’s documented `x-vercel-forwarded-for` header. Confirm the app is reached directly through Vercel or follow Vercel’s verified-proxy guidance if another proxy is placed in front. For another host, configure a trusted client-address mechanism rather than falling back to user-supplied forwarding headers. Vercel documents this header at https://vercel.com/docs/headers/request-headers.
6. **Analytics semantics:** the temporary tab key is pseudonymous session data. Confirm the approved privacy notice describes this accurately. Active time is approximate; pagehide/network loss can drop a final timing event. Bot classification is heuristic.
7. **Database migration:** if the old draft visitor-profile schema was ever applied to a development database, back it up and run `supabase/migrations/20261107_aggregate_analytics_and_otp_hardening.sql`, then the current `supabase/schema.sql`. This removes old visitor-level data and stale OTP/rate-limit state while retaining leads.
8. **Build and runtime:** install dependencies and generate a reviewed lockfile using Node 24. Run separate typecheck/build for the root website and companion app. The current environment has Node 22.16.0 and no installed dependencies.
9. **Browser/device testing:** test the consent banner and persistent settings on Android Chrome and desktop browsers, plus the OTP form, admin dashboard, mobile layouts and failure states on a staging deployment.
10. **Operational readiness:** configure database backups, monitoring, incident response, authorised staff and a contact for provider outages. No operational service is live.

## Important data-flow notes

- The analytics dashboard returns aggregate breakdowns only; it does not return session keys or individual event records.
- The database still stores a temporary HMAC session key per event to compute approximate session duration. This is not an anonymous guarantee; it is pseudonymous short-lived session grouping and must be disclosed.
- The lead dashboard returns names, email addresses, phone numbers and enquiry messages to authenticated administrators. Restrict access to named staff and do not share dashboard credentials.
- `siteId` is a client-supplied label constrained to an allowlist. It is not proof of the event's origin and must not be used for security decisions.
- Turnstile tokens are single-use and expire after five minutes. The server must call Siteverify; a browser widget alone is not protection.
- The app does not infer a phone number from analytics or browser data. Phone is supplied by the visitor in the enquiry form.

## Deployment boundary

No GitHub repository, DNS record, live WordPress/site, Vercel project, Supabase project, Resend account, MSG91 account or Cloudflare account was changed. No secrets were supplied or added. No tracker was installed on the live site. No deployment was performed.

## Validation status

The dependency-free visitor-intelligence validator and TypeScript/JavaScript syntax checks are intended to run offline. Full semantic TypeScript typechecking, Next.js production builds, provider delivery tests, database/RLS tests and real browser/device tests remain pending. Do not describe the app as live or production-ready.
