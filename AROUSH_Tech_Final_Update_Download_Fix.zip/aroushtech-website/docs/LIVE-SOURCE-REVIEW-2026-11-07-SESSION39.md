# Live AROUSH source review — Session 39

Date: 7 November 2026

## Pages reopened

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Courses: https://aroushtech.in/courses/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/
- CCNA: https://aroushtech.in/ccna/
- CCNA DevNet: https://aroushtech.in/ccna-devnet/
- AI & ML: https://aroushtech.in/ai-ml/
- Agentic AI with LangGraph and LangChain: https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/

## Confirmed public content

- Homepage still advertises 20+ job-ready courses, a free-demo message and six course-category themes. Three featured course listings remain visible.
- Public course catalogue still contains 20 course entries.
- About page still publishes the company vision/mission and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid, with published role titles.
- Gallery page still contains training and corporate-training photographs. It refers to corporate training activity in Bengaluru and names organisations in its own caption; the rebuild does not turn those references into additional customer claims.
- Contact page still publishes `taj@aroushtech.in`, `+91 88676 92074`, the corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029, and the registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru 560078.
- Contact page also mentions a J.P. Nagar training centre without a complete visitor-ready address. It remains separate from the two office addresses; visitors should confirm the exact session venue before travel.
- CCNA and CCNA DevNet individual pages each list ₹19,000 while the catalogue lists ₹19,999. Both numeric fees remain withheld in the rebuild pending owner confirmation.
- AI & ML course page still publishes a 40-hour live-training duration. The Agentic AI with LangGraph/LangChain page publishes course topics but no duration.

## Items excluded or awaiting owner approval

- Homepage still exposes three zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes them. Their presence is a reason for authorised WordPress/hosting investigation, not proof of the exact compromise mechanism.
- Contact FAQ claims about certification, 100% job assistance and 24/7 lab access remain unverified owner-review items and are not restated as guarantees in the rebuild.
- The Agentic AI checkout link still points to `demosites.royal-elementor-addons.com`; it remains unverified and blocked in the rebuild.
- Course fee conflicts, provider attribution and training-centre location still require owner confirmation where noted in the existing content audit.

## Changes informed by this review

No new company facts, team details, prices, credentials, guarantees, schedules or contact details were introduced in Session 39. The review confirmed the existing content safeguards and helped keep the current source register accurate.
