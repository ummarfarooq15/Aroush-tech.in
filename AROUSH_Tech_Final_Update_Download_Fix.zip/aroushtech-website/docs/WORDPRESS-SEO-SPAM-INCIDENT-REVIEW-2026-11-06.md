# Live WordPress footer — suspicious SEO-spam links

Review date: **6 November 2026**  
Affected source: `https://aroushtech.in/`  
Status: **Owner/hosting investigation required — no live changes made**

## What was observed

A fresh public crawl of the live homepage exposed **16 unrelated outbound footer links**. The visible anchor text included gambling/betting terms such as `bettilt`, `pinup`, `pinco`, `bahsegel`, `paribahis`, `casinomub`, `rokubet`, `slotbey`, `casino siteleri` and `bahis siteleri`. The links pointed to domains unrelated to AROUSH's IT consulting or training business:

- `homelabfabric.com`
- `www.yigithidrolik.com`
- `locksmithintelaviv.com`
- `lotusdermatoloji.com`
- `breakoutfinder.com`
- `homezo.net`
- `www.caobaparis.com`
- `hbgstampede.com`
- `ormanistanbul.com`
- `zurichberg.com`
- `www.athenaiss.com`
- `shopharbourroad.com`
- `nationpacksla.com`
- `hopscotchfriday.com`
- `www.jailbreakwizard.net`
- `akidshaircompany.com`

This pattern is consistent with possible SEO-spam injection or an unapproved third-party/footer integration. A public crawl alone cannot establish the entry point, whether the links are stored in WordPress or injected at request time, or whether other files/accounts are affected. Treat it as a security finding until the owner or hosting administrator verifies it.

## Immediate actions for the authorised owner/hosting administrator

1. Preserve the current evidence: record the affected page, capture the rendered footer, save the link destinations and note the review date. Do not click the suspicious destinations from an ordinary workstation.
2. Take verified full backups of both the WordPress filesystem and database before cleanup. Keep a protected copy of the pre-cleanup backup for incident analysis.
3. Ask the hosting provider/security administrator to inspect the site and hosting account. If malicious scripts, redirects, unknown administrator accounts or broader compromise are found, follow the host's incident-containment process before restoring public service.
4. Review WordPress administrator accounts, application passwords, hosting control-panel users, SFTP/SSH keys, database users and API credentials. Remove only accounts confirmed as unauthorised; rotate credentials and enable MFA.
5. Inspect the active theme and child theme, footer/header templates, widgets, menus, reusable blocks, custom HTML, plugins, must-use plugins, `wp_options`, posts/pages, scheduled tasks, `.htaccess`, `wp-config.php`, uploads and hosting-level cron jobs for injected anchors, scripts, redirects or obfuscated payloads.
6. Search the database and filesystem for every domain and anchor phrase listed above. Also inspect for newly created files, modified timestamps, unknown PHP files in uploads, and unexpected outbound requests.
7. Update WordPress core, themes and plugins from trusted sources; remove unused or abandoned components. Do not overwrite evidence before backups and logs are preserved.
8. Run a reputable malware/integrity scan and review access, authentication, file-change and hosting logs to identify the likely entry point and affected period.
9. Check Google Search Console security issues/manual actions and review indexed results for unrelated spam pages. Request recrawling only after the owner/administrator confirms cleanup.
10. Re-crawl the homepage, footer, all page templates, sitemap and search results after remediation. Verify that the links do not return from the database, cache, CDN, theme or a third-party script.

## Rebuild safeguards

- The new AROUSH website does not reproduce these links or anchor phrases.
- `scripts/validate-external-links.mjs` scans the application, component and library source for the observed domains, gambling anchor phrases and external HTTPS hosts not on the reviewed allowlist.
- A new `npm run validate:external-links` check is included in `npm run check:offline` so a later accidental copy is caught before packaging.
- The allowlist is intentionally small. Any new external host must be reviewed and explicitly added with a reason.

## What this review does not claim

- It does not prove that the WordPress database, server or administrator accounts have been compromised.
- It does not establish which plugin, theme, credential, third party or hosting component introduced the links.
- It does not prove that the issue has been fully removed; only the authorised owner/host can inspect the underlying WordPress and hosting environment.
- It does not authorise this project to edit WordPress, hosting, DNS, Search Console or production files.

**Release recommendation:** Do not migrate or redirect the live domain until the owner/hosting administrator has investigated this finding, confirmed cleanup, and documented the result. The rebuilt website package remains separate and has not been deployed.

## Session 23 recheck — 6 November 2026

The public homepage was reopened again on 6 November 2026. The same 16 unrelated gambling/betting footer anchors and the same 16 unrelated destination domains were still present in the rendered page. The new crawl also exposed the visible anchor spelling `casinomuhub`; the source validator's phrase list has been broadened to catch that spelling as well as the earlier observed variants.

This confirms that the public-page symptom was still visible at the time of this recheck. It still does **not** identify whether the links originate from WordPress content, a theme/widget, plugin, cache/CDN, compromised account or a third-party script. No attempt was made to click the destinations, edit WordPress, clear caches, contact the host, or alter the live site.

The rebuild now has two separate source gates:

- `npm run validate:external-links` blocks known spam domains/anchor phrases and any new unreviewed external HTTPS host.
- `npm run validate:public-claims` blocks unapproved placement, hiring, high-paying, top-rated and lab/monitoring promises from public application source, while allowing explicit disclaimers and requiring the current-fee confirmation note anywhere course prices are rendered.

The owner/hosting administrator still needs to investigate the live installation and document remediation before migration or domain cutover.


## Session 24 public recheck — 6 November 2026

A fresh public crawl of the homepage still exposed the same 16 unrelated gambling/betting footer links and the same 16 unrelated destination domains. The public page also continues to show zero-value counters. The rebuild excludes both the spam links and zero-value metrics.

The external-link policy was strengthened in the rebuild during this pass: it now scans literal `http://`, `https://` and protocol-relative (`//host`) URL forms. Non-HTTPS URLs are rejected; unknown HTTPS/protocol-relative hosts require explicit approval; the known spam-domain and anchor-text blocks remain active. `scripts/test-external-link-policy.mjs` exercises approved and rejected cases.

The new scanner is a source-code safeguard only. It does not clean or inspect the live WordPress installation. The authorised owner/hosting administrator must preserve backups/logs, identify the source of the footer links, remove the cause, review access and filesystem/database integrity, and confirm the symptom is gone across templates, caches and indexed pages before migration.

## Session 25 public recheck — 6 November 2026

The live homepage was reopened again. The rendered page still exposes the same 16 unrelated gambling/betting footer links and destination domains previously recorded. The homepage also continues to display zero-value counters (`0 k+`, `0 +`, `0 %`). The public Courses page still presents 20 catalogue entries, and the About page still lists the three team profiles already captured in the rebuild. The Contact page continues to publish `taj@aroushtech.in`, `+91 88676 92074` and the two Bengaluru office addresses. Its FAQ still includes 100% job-assistance and 24/7 lab-access wording; the rebuild continues to omit these claims pending written owner approval.

This is a repeat confirmation of the public symptom, not evidence of a new attack or a determination of the source. The links may originate in WordPress content, a theme/widget, plugin, account, cache/CDN or third-party script. No suspicious destination was opened, and no WordPress, hosting, CDN, Search Console or DNS change was made.

## Session 26 public recheck — 7 November 2026

The live homepage was reopened on 7 November 2026. The rendered footer still exposes 16 unrelated gambling/betting links to 16 unrelated external domains; the visible terms include `bettilt`, `pinup`, `pinco`, `bahsegel`, `paribahis`, `casinomuhub`, `rokubet`, `slotbey`, `casino siteleri` and `bahis siteleri`. Zero-value counters remain visible as well. This is another confirmation of the same public symptom, not evidence of a new attack or proof of the WordPress/hosting entry point. The source and remediation checklist above remain unchanged. No destination was opened and no WordPress, hosting, CDN, Search Console, DNS or production change was made.
