# Validation report — Session 44

Date: 7 November 2026

## Passed checks

- `npm run check:offline`: all 24 dependency-free validators passed.
- `npm run validate:breadcrumbs`: 11 content routes passed; each has one visible trail, the course detail path is dynamic, and the privacy page uses the correct light-background variant.
- `npm run validate:accessibility`: 26 TSX files checked; breadcrumbs include a named navigation landmark, current-page announcement and visible keyboard focus.
- `npm run validate:links`: 31 internal paths and 20 course slugs checked; no broken internal paths were found.
- `npm run validate:external-links`: 48 source files scanned; 9 reviewed HTTPS hosts; no HTTP links, known spam domains or unapproved external hosts found.
- `npm run validate:public-claims`: 46 public source files scanned; no unapproved guarantees or comparative claims found.
- `npm run validate:javascript`: 35 `.mjs` files passed Node syntax checks.
- `npm run validate:typescript-syntax`: 39 `.ts`/`.tsx` files parsed with TypeScript 5.8.3. This is syntax validation only, not semantic typechecking.
- `npm run validate:release-config`: Node 24 pin, scripts, blank GA4 Measurement ID and validation wiring passed.

## Production checks and blockers

- Current Node.js: 22.16.0; project requirement: 24.x.
- npm registry DNS: `EAI_AGAIN registry.npmjs.org`.
- `node_modules` is absent.
- A reviewed `package-lock.json` is absent.
- Full `npm run typecheck`, `npm run lint`, `npm run build` and `npm run audit` cannot be completed until the required runtime, dependencies and lockfile are available.
- Android/desktop browser QA, visual responsive checks and screen-reader checks remain pending.

## Privacy and deployment

- `NEXT_PUBLIC_GA_MEASUREMENT_ID` remains blank in `.env.example`.
- GA4 remains disabled until the owner configures a Measurement ID and each visitor explicitly opts in.
- Reject and preference withdrawal remain available.
- No server-side lead database, CRM, visitor fingerprinting or covert identification was added.
- No GitHub push, live WordPress change, DNS change, hosting change or production deployment was performed.

## Release archive verification

- Archive entries: 215.
- Uncompressed content: 8,565,959 bytes.
- `unzip -t`: passed, no compressed-data errors.
- Extracted the ZIP into a fresh directory and reran `npm run check:offline`: all 24 validators passed again.
