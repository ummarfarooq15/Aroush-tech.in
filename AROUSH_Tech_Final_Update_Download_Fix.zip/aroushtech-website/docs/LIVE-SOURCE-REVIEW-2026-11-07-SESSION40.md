# Live AROUSH source review — Session 40

Date: 7 November 2026

## Pages reviewed

- https://aroushtech.in/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/courses/
- https://aroushtech.in/gallery/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/ccna/
- https://aroushtech.in/ccna-devnet/
- https://aroushtech.in/agentic-ai-with-langchain-hugging-face/
- https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/

## Confirmed current content

- Homepage continues to advertise 20+ job-ready courses, a free-demo message and six course-category themes: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing.
- Homepage featured courses remain Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. The public page shows ₹35,000, ₹45,000 and ₹25,000 respectively; the rebuild labels catalogue amounts as references and does not promise availability or a final quote.
- The Courses page contains 20 course entries. Eighteen catalogue fee pairs are consistent between the catalogue and reviewed detail pages. CCNA and CCNA DevNet remain conflicts: catalogue ₹19,999 versus individual detail pages ₹19,000. The rebuild withholds numeric fees for both.
- About page retains the published vision and mission and three team profiles: Abdul Aleem Khan — Vertical Head Cyber Security & Cloud Security; Tajuddin — Technical Head Networking & Cyber Security; Mohammed Khalid — Technical Head For Networking Security.
- Gallery page contains ten training/corporate-training photographs plus one separate third-party logo collage. The rebuild retains the ten training photographs and excludes the collage; no logo is treated as a current customer or partner endorsement.
- Contact page publishes `taj@aroushtech.in`, `+91 88676 92074`, corporate office `#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029`, and registered office `AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078`.
- Contact separately says the physical training centre is in Bengaluru (J.P. Nagar), but does not provide a complete visitor-ready address. The rebuild continues to advise visitors to confirm the exact session venue before travel.
- Contact FAQ still states certification, 100% job assistance and 24/7 lab access. These remain owner-review items and are not presented in the rebuild as guaranteed terms.
- CCNA individual page continues to publish ₹19,000; the catalogue shows ₹19,999. CCNA DevNet individual page also publishes ₹19,000 against the catalogue's ₹19,999.
- The Agentic AI course pages publish outlines but no duration. The rebuild does not invent a duration or enable the unverified third-party checkout.

## Excluded live-site defects / owner action

- Homepage still exposes three zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes them. An authorised WordPress/hosting administrator should investigate database, plugins, theme, accounts, files, logs and Search Console. The crawl does not prove the exact injection route or full compromise.
- The public Contact FAQ's certification, job-assistance and 24/7 lab claims need written owner confirmation before being repeated as commercial commitments.
- The third-party checkout host `demosites.royal-elementor-addons.com` remains unverified and blocked in the rebuild.

## Changes informed by this review

The course catalogue now lets visitors filter between all courses, courses with published outline topics, and courses whose outline needs confirmation from AROUSH. The classification uses only migrated source-backed outline records. CEH and Fortinet remain in the confirmation group because their long-form live pages include provider-attributed material.

No live website, WordPress, DNS, payment flow or production environment was changed.
