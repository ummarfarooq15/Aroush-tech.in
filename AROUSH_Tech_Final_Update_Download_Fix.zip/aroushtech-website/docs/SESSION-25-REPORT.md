# Session 25 — accessibility source checks, fresh source review and release preflight

Date: 6 November 2026

## Summary

This session added a dependency-free accessibility source validator and refreshed the official AROUSH and competitor reviews. The existing site remains unchanged. The current production blocker was rechecked: Node.js 24 is not available in this runtime, the npm cache is empty, and the npm registry DNS lookup still fails.

## Code changes

- Added `scripts/validate-accessibility.mjs`.
- Added `npm run validate:accessibility` and included it in `npm run check:offline`.
- Extended `scripts/validate-release-config.mjs` so the release configuration check requires the accessibility validator and confirms it is included in the offline suite.
- Updated the README and beginner developer guide with the new command and its limitations.

The validator scans application and component TSX source for image `alt` attributes, safe `rel` values on new-tab links, accessible button names and labelled form controls. It also checks the shared document language, skip link, main landmark, visible keyboard-focus styles, reduced-motion support, chatbot conversation announcements, course-result announcements, mobile navigation state and enquiry-form name.

This is a source-level guard only. It does not replace browser-based keyboard, zoom, touch, screen-reader or contrast testing.

## Live AROUSH source recheck

Official pages reopened on 6 November 2026:

- Homepage: https://aroushtech.in/ — continues to publish 20+ courses and a free-demo message, six course families and three featured courses. It still displays zero-value counters and 16 unrelated gambling/betting footer links.
- About: https://aroushtech.in/aboutus/ — continues to publish the mission, vision and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid, with their current role titles.
- Courses: https://aroushtech.in/courses/ — still lists 20 courses and their visible fee pairs. The rebuild's 20 title/fee records remain aligned with the public listing; amounts remain labelled as references to confirm before payment.
- Gallery: https://aroushtech.in/gallery/ — still contains training and corporate-training images, alongside placement/client-related material that is not used as a new endorsement.
- Contact: https://aroushtech.in/contact-us/ — still publishes `taj@aroushtech.in`, `+91 88676 92074`, and the corporate and registered Bengaluru office addresses. The FAQ still includes 100% job-assistance and 24/7 lab-access statements, which remain excluded pending written owner confirmation.

The 16 unrelated footer links remain consistent with possible SEO-spam injection. A public crawl does not prove the WordPress entry point or full hosting compromise. The authorised administrator must investigate and document remediation before any migration or domain cutover.

## Competitor UX recheck

- Apna College Prime: https://www.apnacollege.in/prime — scannable AI/ML curriculum structure and project-oriented programme information. Only the information-architecture lesson is relevant; no competitor claims or programme content were copied.
- i-Medita FAQ and Ethical Hacking course: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ethical-hacking-training/ — clear placement of location, schedule, language, course detail, FAQs and enquiry information. AROUSH's own FAQ and course enquiry paths remain source-backed.
- PyNet Labs catalogue and contact page: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — technology and career-path groupings, plus visible human counselling routes. AROUSH retains its own search, filters, four learning-goal collections and human contact path.

No competitor prices, statistics, ratings, testimonials, credentials, schedules, guarantees or placement claims were copied.

## Validation performed

- `npm run check:offline` — passed all 14 dependency-free validators, including the new accessibility source check.
- Global TypeScript transpile-only pass — 27 `.ts`/`.tsx` source files produced zero syntax diagnostics; this is not semantic typechecking.
- Global PostCSS parse — 514 CSS rules and 20 at-rules parsed successfully.
- Accessibility source validation — passed across 22 TSX files: image alternatives, new-tab link safety, accessible button names, labelled form controls, skip link, main landmark, focus-visible styles, reduced-motion support and live-region safeguards.
- Existing content, privacy, analytics-policy, brand, UX, link, external-link-policy, external-link security, public-claims, learning-path, chatbot, JavaScript and release-configuration checks — passed.
- `npm run preflight:release` — correctly reported blockers: Node.js 22.16.0 instead of 24.x, no package lockfile and missing Next.js/React/TypeScript/ESLint dependencies.

## Production blockers

- `npm run typecheck` cannot complete because Next.js, React and their type packages are not installed.
- `npm run lint` cannot run because ESLint is not installed.
- `npm run build` cannot run because Next.js is not installed.
- `npm run audit` cannot run because there is no package lockfile (`ENOLOCK`).
- The npm cache contains no cached package content.
- A fresh `npm ping --fetch-retries=0 --fetch-timeout=8000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- Real Android/desktop browser QA remains pending a successful staging build.
- The live WordPress footer finding still requires authorised owner/hosting investigation.

## Privacy and deployment

GA4 Measurement ID remains blank. Analytics remains disabled until owner setup and explicit visitor opt-in. Reject, withdrawal and persistent privacy settings remain in the implementation. Phone remains optional and voluntary. No server-side lead database or CRM was added. No GitHub push, WordPress edit, DNS change, hosting change or production deployment was performed.
