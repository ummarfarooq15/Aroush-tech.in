# Live AROUSH source review — Session 37

Review date: **7 November 2026**

All source facts below were rechecked against the public AROUSH website during this session. The public site is treated as the source for current published facts; where pages conflict, the rebuild preserves the conflict and asks the owner to confirm rather than selecting an amount or inventing details.

## Homepage — https://aroushtech.in/

- Main navigation links Home, About Us, Gallery, Meet Our Team, Courses and Contact Us.
- Advertises 20+ job-ready courses and a free demo.
- Shows six course-category themes: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing.
- Featured catalogue amounts displayed on the homepage: Agentic AI with LangChain & Hugging Face ₹35,000; CCNP Security ₹45,000; CEH ₹25,000.
- Shows three counters with zero values: 0k+ course students, 0+ courses and 0% satisfaction. The rebuild excludes these empty counters.
- The homepage still includes 16 unrelated gambling/betting footer links pointing at unrelated third-party domains. The rebuild excludes them. This is suspicious and warrants authorised WordPress/hosting investigation, but a public crawl does not establish the injection path or full compromise.

## Courses — https://aroushtech.in/courses/

- 20 public course entries are visible.
- The catalogue lists CCNA at ₹19,999 and CCNA DevNet at ₹19,999.
- Other catalogue fee pairs remain copied only as website-listed reference amounts with a reminder to confirm the current fee before payment.
- The two CCNA-related fee conflicts remain unresolved because their individual detail pages list ₹19,000.

## Individual course pages

- CCNA: https://aroushtech.in/ccna/ — describes CCNA 200-301 topics, online live instructor-led delivery, prerequisites, job profiles, devices/tools, learning outcomes, curriculum and lab topics. It lists ₹19,000.
- CCNA DevNet: https://aroushtech.in/ccna-devnet/ — describes DEVASC 200-901, software development, APIs, Cisco platforms, application security and infrastructure automation topics. It lists ₹19,000.
- Agentic AI with LangChain & Hugging Face: https://aroushtech.in/agentic-ai-with-langchain-hugging-face/ — publishes a detailed outline and ₹35,000. Its Buy Course link points to `demosites.royal-elementor-addons.com`; this destination remains unverified and is not used by the rebuild.
- Agentic AI with LangGraph and LangChain: https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/ — publishes a shorter outline and ₹35,000. Its Buy Course link points to the same unverified third-party host; the rebuild does not use it.
- CEH: https://aroushtech.in/ceh-certified-ethical-hacker/ — publishes a one-month duration and security-topic list, but course-provider/instructor attribution needs AROUSH confirmation before its long-form material is presented as AROUSH-authored.

## About and team — https://aroushtech.in/aboutus/

- Vision: to be a preferred consulting and training services company, providing solutions and training that empower people and businesses around the world.
- Mission: the source page describes helping people realise their potential through training programmes.
- Three public team profiles: Abdul Aleem Khan (Vertical Head Cyber Security & Cloud Security), Tajuddin (Technical Head Networking & Cyber Security), and Mohammed Khalid (Technical Head For Networking Security).
- The page still shows zero-value counters; the rebuild excludes them.

## Gallery — https://aroushtech.in/gallery/

- Publishes training and corporate-training photographs.
- Text references corporate training in Bengaluru and names Larsen & Toubro Infotech, Capgemini and NTT Level 1 & Level 2. These are source-page statements; any expanded case-study or client-logo use still requires permission and owner review.

## Contact — https://aroushtech.in/contact-us/

- Email: `taj@aroushtech.in`.
- Phone: `+91 88676 92074`.
- Corporate office: #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029.
- Registered office: AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078.
- The page separately refers to a Bengaluru (J.P. Nagar) physical training centre without a complete visitor-ready address. Confirm the exact training venue before travel.
- The page includes certification, 100% job-assistance and 24/7 lab-access statements. The rebuild does not convert these into guarantees pending written owner approval.

## Rebuild decisions

- Exclude zero-value counters and unrelated gambling/betting footer links.
- Do not use the unverified third-party course checkout host.
- Continue withholding the numeric CCNA and CCNA DevNet fees until the catalogue/detail discrepancy is resolved.
- Keep service portfolio availability subject to owner confirmation where the public site only exposes a general IT Consultation navigation item.
- Use published source details only in the course comparison feature; label missing duration/outlines as not published and unresolved fees as requiring confirmation.
- Do not add analytics, lead storage or payment processing without owner setup and approval.
