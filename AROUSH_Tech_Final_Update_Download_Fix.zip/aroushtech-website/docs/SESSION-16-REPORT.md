# Session 16 — goal-based course discovery and validation

Date: 6 November 2026

## Changes made

- Added a dedicated `/learning-paths` page to make the 20 public courses easier to browse by learning goal.
- Created four collections using only existing catalogue slugs: Networking & Infrastructure; Network Security; Cybersecurity & Penetration Testing; Cloud, Automation & AI.
- Kept all SOC/SIEM learning options on the same page using the existing six company-profile records and their documented durations.
- Added clear wording that collections are discovery groupings, not mandatory sequences, formal prerequisites or career guarantees.
- Linked the page from the homepage learning section, course catalogue and site footer; added it to the sitemap.
- Added a dependency-free validator that checks every curated slug exists in the public catalogue and that the SOC/SIEM section and non-prerequisite disclaimer remain present.
- Refreshed competitor UX notes using the current public Apna College Prime page, i-Medita demo page and PyNet Labs course catalogue.
- Updated the README and beginner guide with the new route and validator command.

## Validation results

- `node scripts/validate-content.mjs`: **PASS** — 10 services, 20 public courses, six SOC/SIEM options, three team profiles, ten gallery photographs, two offices, two testimonials, 30 public routes and 23 redirects.
- `node scripts/validate-privacy.mjs`: **PASS** — GA4 remains opt-in only, Measurement ID blank by default, reject/withdrawal and persistent settings present, voluntary phone and no server-side lead/CRM.
- `node scripts/validate-brand.mjs`: **PASS** — original logo retained and full/emblem placements validated.
- `node scripts/validate-ux.mjs`: **PASS** — chatbot, mobile-navigation, course search and enquiry safeguards.
- `node scripts/validate-links.mjs`: **PASS** — 30 internal paths, 20 course slugs, redirects and no broken internal routes/non-HTTPS links.
- `node scripts/validate-learning-paths.mjs`: **PASS** — four collections, 20 valid course links, six SOC/SIEM options and no prerequisite claims.
- TypeScript/TSX syntax transpilation: **PASS** — 27 files, zero syntax diagnostics.
- CSS/PostCSS parsing: **PASS** — 502 CSS rules parsed.
- `node --check` for Next config and validators: **PASS**.

## Remaining blockers

- Full TypeScript semantic check: **BLOCKED** because Next.js and React packages/types are not installed. The available global TypeScript run reports missing `next/*`, `react` and JSX type declarations; this is not a valid full typecheck.
- Next.js production build and lint: **BLOCKED** — `next: not found` without dependencies.
- Dependency audit: **BLOCKED** — no package lockfile exists.
- `npm install --package-lock-only`: **BLOCKED** — npm registry DNS failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- Environment Node.js is 22.16.0; the project requires Node.js 24.x.
- Real browser and Android mobile testing remain pending a working staging build.
- Team and gallery images still reference the existing WordPress media host pending owner approval and successful asset retrieval.
- Course prices, current schedules, prerequisites, delivery format, lab access and availability need owner confirmation before launch.

No GitHub repository, live WordPress website, DNS, hosting or production deployment was changed.
