# Live AROUSH source review — Session 32

Review date: **7 November 2026**

## Public AROUSH pages reopened

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Courses: https://aroushtech.in/courses/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/
- CCNA detail: https://aroushtech.in/ccna/
- CCNA DevNet detail: https://aroushtech.in/ccna-devnet/
- AI & ML detail: https://aroushtech.in/ai-ml/

## Findings

### Homepage

The public homepage continues to advertise **20+ job-ready courses** and a **free demo**, and it presents six discovery families: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing. It highlights Agentic AI with LangChain & Hugging Face, CCNP Security and CEH, with published homepage amounts. It also shows two student testimonials and an instructor introduction.

The live page still renders zero-value counters (0k+ course students, 0+ courses, 0% satisfaction) and 16 unrelated gambling/betting footer links. The rebuild continues to exclude both. The presence of these links is consistent with possible SEO-spam injection, but a public-page crawl does not prove the entry point or the extent of any compromise. An authorised WordPress/hosting administrator must investigate.

### About and team

The public About page still publishes the company vision and mission and three profiles: Abdul Aleem Khan (Vertical Head Cyber Security & Cloud Security), Tajuddin (Technical Head Networking & Cyber Security), and Mohammed Khalid (Technical Head For Networking Security). The rebuild follows the published role wording and does not add education or years-of-experience claims from the supporting company profile without owner approval.

### Courses and pricing

The catalogue still contains 20 course entries. The current catalogue shows CCNA and CCNA DevNet at ₹19,999, while the individual CCNA and CCNA DevNet detail pages show ₹19,000. The rebuild continues to withhold a numeric amount for both courses until AROUSH confirms the correct current fee.

The AI & ML page still publishes a 40-hour live training duration and a seven-module outline. The rebuild may show this duration because it is explicitly stated on the AROUSH page. Other course durations remain withheld unless their individual source page states them.

The catalogue's displayed amounts are changeable commercial information. They are labelled as website-listed references and require reconfirmation before any payment. The legacy CEH page's trainer/provider attribution and the Fortinet page's I-Medita attribution remain owner-review items; the rebuild does not reproduce those long-form provider-specific details as AROUSH-approved content.

Multiple live course detail pages still link their Buy Course action to `demosites.royal-elementor-addons.com`. The destination was not opened or used. The rebuild blocks this host and does not implement online checkout. Owner verification of merchant ownership, processor, privacy/data handling, refund terms and authorisation is required before any payment link is added.

### Gallery

The public Gallery continues to show training and corporate-training photographs and refers to corporate sessions in Bengaluru. The rebuild retains selected training photographs and does not import the third-party client-logo collage or turn gallery captions into new customer endorsements. Any named customer/programme references should remain subject to permission and owner confirmation.

### Contact

The public Contact page still publishes `taj@aroushtech.in`, `+91 88676 92074`, the corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029, and the registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru 560078. It separately refers to a J.P. Nagar training centre but does not provide a complete visitor-ready training venue address. The rebuild distinguishes the two office addresses from the unconfirmed training venue.

The live Contact FAQ still contains certification, 100% job-assistance and 24/7 lab-access claims. The rebuild does not turn those into guarantees pending written owner approval.

### Services source boundary

The current public navigation exposes an “IT Consultation” label but does not provide a dedicated public service detail page covering the complete ten-service portfolio in the rebuild. The expanded service descriptions are supported by the supplied 2026 AROUSH company profile and brochure, not inferred from competitor sites. The owner must confirm which services are currently available, delivery scope, partner involvement and operational coverage before launch.

## Competitor UX refresh

- Apna College Prime: https://www.apnacollege.in/prime — curriculum groups and scannable topic hierarchy.
- i-Medita FAQ: https://www.imedita.com/frequently-asked-questions/ and contact page: https://www.imedita.com/contact/ — common learner questions and visible human-contact paths.
- PyNet Labs catalogue: https://www.pynetlabs.com/courses/ and contact page: https://www.pynetlabs.com/contact/ — technology/category filters, learning-path groupings and human guidance.

Only interaction and information-architecture patterns were considered. No competitor prices, discounts, course counts, ratings, testimonials, credentials, schedules, partner names, placement figures or guarantees were copied.

## Rebuild decisions retained

- Keep the 20-course catalogue and searchable category discovery.
- Keep CCNA/CCNA DevNet numeric fees withheld until the fee conflict is resolved.
- Keep CEH and Fortinet provider-attribution holds.
- Keep the unverified third-party checkout host blocked.
- Keep zero-value counters and unrelated footer links excluded.
- Keep the J.P. Nagar training venue unconfirmed rather than reusing an office address.
- Keep GA4 disabled by default and require explicit opt-in plus an owner-supplied Measurement ID.
- Do not add a server-side lead database, CRM or payment processing.
