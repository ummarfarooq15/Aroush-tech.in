# Validation report — Session 49 (final development handover)

**Date:** 7 November 2026  
**Runtime:** Node.js 22.16.0 / npm 10.9.2  
**Required runtime:** Node.js 24.x

## Changes in this session

- Added `.nvmrc` and `.node-version`, both pinning Node.js 24 to make the required runtime obvious in common developer environments.
- Added `docs/FINAL-RELEASE-HANDOVER-2026-11-07.md` with project scope, content guardrails, privacy/security boundaries, release commands, staging acceptance checklist and deployment boundary.
- Re-ran the complete offline validation suite against the final package.

## Passed

`npm run check:offline` — PASS. Individual results:

- Content: 10 services, 20 public courses (18 source outlines and 2 provider-attribution review notes), 18 consistent fee pairs, 2 conflicting course fees withheld, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery photographs, 8 industry profiles, 2 published office addresses, 2 live-site testimonials, 31 routes, 23 redirects and structured data.
- Privacy and analytics: root-site GA4 disabled by default and opt-in only; reject/withdrawal available; no root-site server-side lead API; owner-approved companion app remains separate; no CRM integration.
- Visitor Intelligence: 54 source checks passed.
- Brand, UX, accessibility source checks, internal links, breadcrumbs and social cards passed.
- External-link policy tests and external-link security scan passed (46 source files, 9 HTTPS hosts reviewed).
- Public-claims scan passed (44 source files).
- Learning paths, FAQs, FAQ search, course sort, outline filter, shareable catalogue URLs and course comparison passed.
- Enquiry paths (37 checks) and enquiry safety (22 checks) passed.
- Chatbot rules: 52 intent-routing cases passed.
- JavaScript syntax: 38 files passed.
- TypeScript syntax: 70 files parsed; syntax only, not semantic typechecking.
- Release configuration passed.

## Blocked / not claimed as passed

- Node.js 22.16.0 is available; Node.js 24.x is required.
- `package-lock.json` is not present; do not run `npm ci` until a reviewed lockfile is generated in the required environment.
- Dependencies are not installed. Full semantic typecheck, ESLint and production build remain blocked by missing dependencies.
- Browser/responsive/device testing is pending a runnable staging environment.
- Supabase RLS/RPC, Resend email, MSG91 SMS and Cloudflare Turnstile require non-production provider accounts and credentials for end-to-end tests.
- Retention/deletion periods, official privacy contact, processor list, legal review and admin identities require owner approval.

## Deployment status

NOT DEPLOYED. No live website, WordPress, DNS, GitHub, hosting or provider account was changed. GA4 remains unconfigured. Companion visitor-intelligence app remains separate from the public marketing-site enquiry flow.
