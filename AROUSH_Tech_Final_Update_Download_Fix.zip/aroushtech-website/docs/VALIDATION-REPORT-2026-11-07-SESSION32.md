# Session 32 validation report

Date: 7 November 2026

## Passed checks

| Check | Result |
|---|---|
| Content validator | Passed: 10 services, 20 courses, 18 outlines, 2 attribution holds, 30 routes |
| Privacy validator | Passed: GA4 opt-in only, blank ID, reject/withdrawal, voluntary phone, no CRM/database |
| Analytics policy tests | Passed: ID validation, consent gating, query/hash stripping and safe referrers |
| Brand validator | Passed: logo variants and favicon |
| UX validator | Passed: persistent quick replies, expandable prompt list, navigation focus recovery, 404 recovery, course filters and email handoff |
| Accessibility validator | Passed: 23 TSX files plus skip link, landmarks, focus, reduced motion and live regions |
| Internal-link validator | Passed: 30 paths and course slugs |
| External-link policy tests | Passed: HTTPS allowlist, blocked checkout host and unsafe-link cases |
| External-link validator | Passed: 33 source files, 9 reviewed HTTPS hosts |
| Public-claims validator | Passed: no unapproved guarantees/comparisons |
| Learning-path validator | Passed: 4 collections, 20 course links, 6 SOC/SIEM options |
| Chatbot validator | Passed: 46 intent-routing cases plus quick-reply source assertions |
| JavaScript syntax | Passed: 20 `.mjs` files |
| TypeScript/TSX syntax | Passed: 30 files parsed by TypeScript 5.8.3; syntax only |
| Release configuration | Passed: Node 24 pin, required scripts and blank GA4 ID |
| CSS parse | Passed with PostCSS: 528 rules, 21 at-rules, 1,732 declarations |
| ZIP integrity | Passed; extracted package revalidated |

## Not passed / not run

| Check | Status | Reason |
|---|---|---|
| Full TypeScript typecheck | Blocked | Next.js/React/type dependencies not installed |
| ESLint | Blocked | ESLint packages not installed |
| Next.js production build | Blocked | Next.js package not installed |
| npm audit | Blocked | No package lockfile; registry unavailable |
| Browser QA | Pending | No browser automation/device session available in this run |

## Environment evidence

- `node -v`: `v22.16.0` (project requires `24.x`).
- `npm -v`: `10.9.2`.
- `npm ping --fetch-retries=0 --fetch-timeout=10000`: failed with `EAI_AGAIN` for `registry.npmjs.org`.
- `npm run typecheck`: blocked by unresolved `next` and React type modules (and resulting missing JSX intrinsic declarations).
- `npm run lint`: `eslint: not found`.
- `npm run build`: `next: not found`.
- `npm run audit`: `ENOLOCK` because no lockfile exists.
- No `node_modules` directory or package lockfile is included in the source archive.

Source syntax checks are not equivalent to a full typecheck or production build.
