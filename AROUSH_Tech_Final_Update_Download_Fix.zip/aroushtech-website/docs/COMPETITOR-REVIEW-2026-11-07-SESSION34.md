# Competitor UX review — Session 34

Review date: 7 November 2026

The review considered public pages only to identify broad navigation and information-discovery patterns. It is not an endorsement or verification of competitor claims. Competitor prices, course durations, schedules, credentials, testimonials, ratings, student counts, placement statistics and guarantees were not copied into AROUSH content.

## Apna College

Reference: https://www.apnacollege.in/prime

Observed UX patterns:
- Uses distinct entry points for different learner situations, such as students and working professionals.
- Explains learning goals and course components in scannable sections.
- Places programme actions near relevant programme information.

AROUSH application:
- Retain goal-based learning paths and readable course categories.
- Keep the course catalogue search and filters focused on AROUSH's own published course records.
- Do not claim a formal prerequisite sequence or a guaranteed career outcome.

## i-Medita

Reference: https://www.imedita.com/frequently-asked-questions/

Observed UX patterns:
- Groups FAQs by practical topics, including training, registration, pricing/payment and logistics.
- Makes answers to operational questions easy to locate.
- Provides a route to a human customer-service team when details need confirmation.

AROUSH application:
- Keep the FAQ content grouped into Courses & learning, Location & enquiries, and Services & business enquiries.
- Added client-side search across question and answer text, category filters, a result count and a no-results route to Contact.
- Continue to mark current fees, schedules, prerequisites and venue details as requiring confirmation where AROUSH's own source is incomplete or conflicting.

## PyNet Labs

Reference: https://www.pynetlabs.com/courses/

Observed UX patterns:
- Puts course search near the top of the catalogue.
- Uses technical categories and featured programme groupings to help visitors narrow a large catalogue.
- Keeps course exploration visible.

AROUSH application:
- Retain the searchable course catalogue and its category filters.
- Add a parallel, lightweight FAQ search so visitors can find answers without scanning every disclosure item.
- Keep human enquiry routes available without inventing live batch dates or placement outcomes.

## Boundaries

This is a UX comparison, not a validation of competitor claims. No competitor marketing numbers, ratings, course prices, testimonials, guarantees, credentials or schedules were reused. AROUSH facts remain grounded in its own public pages or supplied company material, and unresolved items remain on the owner-approval checklist.
