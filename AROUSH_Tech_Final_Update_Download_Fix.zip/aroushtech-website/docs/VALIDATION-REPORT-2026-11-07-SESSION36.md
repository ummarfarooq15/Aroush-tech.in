# Validation report — Session 36

Date: 7 November 2026

## Passed checks

- `npm run check:offline`: all 18 dependency-free validators passed.
- Content validation: 10 services, 20 public courses, 18 source-backed outlines, 2 provider-attribution review notes, 18 consistent fee pairs, 2 course-fee conflicts withheld, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 published office addresses, 2 live-site testimonials, 31 public routes and 23 permanent redirects.
- Privacy validation: GA4 opt-in only, Measurement ID blank by default, reject and withdrawal supported, persistent settings available, Google Signals/ad personalisation disabled, phone voluntary, no server-side lead database or CRM.
- Analytics-policy tests: explicit consent gating, Measurement ID validation, stored-choice normalization, query/hash stripping, safe referrers and minimal page-view payloads.
- UX validation: rule-based grounded chatbot, persistent quick replies, focus recovery, mobile touch targets, navigation, 404 recovery, course-filter recovery and voluntary email enquiries.
- Accessibility source validation: 25 TSX files checked for image alternatives, new-tab link safety, named buttons and labelled form controls; skip link, main landmark, keyboard focus, reduced motion, chatbot/FAQ live regions and course sort announcements present.
- Internal link validation: 31 internal routes checked; 20 course slugs and redirects inspected; no broken internal routes or non-HTTPS external links found.
- External-link policy tests: HTTPS allowlist, HTTP rejection, protocol-relative URLs, unknown hosts, known spam domains, unverified third-party checkout host and mailto/tel handling.
- External-link security validation: 39 source files scanned and 9 HTTPS hosts reviewed; no unapproved host, HTTP link, known spam domain or spam anchor phrase found in the rebuild.
- Public-claims validation: 37 public source files scanned; no unapproved guarantees or comparative claims found; course fee confirmation notices remain present.
- Learning-path validation: 4 collections, 20 valid public course links, 6 SOC/SIEM options and no prerequisite claims.
- FAQ validation and search tests: verified answers, navigation, categories, case-insensitive question/answer search, combined filters and empty-state recovery.
- Course-sort tests: default source order, A–Z, Z–A, natural numeric order, empty list, unknown-value fallback, source immutability, all 20 actual AROUSH course titles, visible result numbering, live sort announcement, accessible control and mobile layout.
- Chatbot regression tests: 47 intent-routing cases passed.
- JavaScript syntax: 25 `.mjs` files checked with Node.js 22.16.0.
- TypeScript/TSX syntax: 34 `.ts`/`.tsx` files parsed with TypeScript 5.8.3. This is syntax-only, not a semantic typecheck.
- CSS/PostCSS parsing: 563 rules, 24 at-rules and 1,848 declarations parsed successfully using the available global PostCSS parser.
- Release configuration: Node 24 pin, direct ESLint CLI, validation scripts and blank GA4 Measurement ID are consistent.

## Production checks blocked

Release preflight reports:

- Runtime: Node.js 22.16.0; project requires Node.js 24.x.
- `package-lock.json` is absent.
- `node_modules/` is absent; Next.js, React, React DOM, TypeScript, ESLint and eslint-config-next are not installed locally.
- `npm ping --fetch-retries=0 --fetch-timeout=10000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- `npm run typecheck` cannot resolve Next.js/React declarations and consequently emits JSX intrinsic-element/type errors. This is blocked by missing packages; syntax parsing passed separately.
- `npm run lint` cannot run because `eslint` is not installed.
- `npm run build` cannot run because `next` is not installed.
- `npm run audit` fails with `ENOLOCK` because there is no package lockfile.
- Actual Android and desktop browser QA remains pending a successful framework build or staging environment.

Do not interpret source-level checks as proof that the site builds or renders correctly in a browser.

## Privacy and change control

- `NEXT_PUBLIC_GA_MEASUREMENT_ID` remains blank. Analytics remains disabled until owner setup and explicit visitor opt-in.
- Search/sort terms are processed in the visitor's browser and are not sent to analytics or a server.
- No CRM or server-side lead database was introduced.
- No live website, WordPress, DNS, hosting, GitHub repository, analytics property or production deployment was changed.
