# Session 32 — Persistent chatbot quick replies, navigation focus and recovery paths

Date: 7 November 2026

## Changes made

1. Updated `components/site-chatbot.tsx` so four concise quick replies remain visible after the visitor receives an answer. Added an accessible “More questions” control that expands the remaining verified prompts and exposes `aria-expanded` / `aria-controls` state. Typed questions remain available.
2. Updated `app/globals.css` with a bounded, independently scrollable expanded quick-reply area, a visible expand/collapse control, and small-screen spacing for the expanded set.
3. Updated `components/primary-navigation.tsx` so keyboard focus returns to the mobile navigation toggle if the route changes while the menu is open. Existing Escape-to-close, active-page state and first-link focus remain.
4. Reworked `app/not-found.tsx` into a useful recovery page with direct links to courses, services and the contact team. Added a stacked small-screen layout.
5. Expanded `scripts/validate-ux.mjs`, `scripts/validate-accessibility.mjs` and `scripts/validate-chatbot.mjs` to check persistent quick replies, the accessible expand/collapse state, mobile navigation focus recovery and 404 recovery links.
6. Reopened the official AROUSH homepage, About, Courses, Gallery, Contact, CCNA, CCNA DevNet and AI & ML pages. Recorded the current source findings in `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION32.md`.
7. Refreshed competitor UX observations for Apna College, i-Medita and PyNet Labs without copying their commercial claims or statistics.

## Current source findings

- The homepage still advertises 20+ courses and a free demo, six course families, three featured courses, two testimonials and an instructor introduction. It also exposes three zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes those elements.
- About still lists the same three public team members and role titles. The rebuild does not add education or experience claims from the supporting company profile without owner approval.
- The Courses page still lists 20 entries. The catalogue and individual pages still disagree on CCNA and CCNA DevNet fees; numeric fees remain withheld in the rebuild.
- The AI & ML page still explicitly publishes a 40-hour duration and seven-module outline.
- Gallery remains training/corporate-training focused; the rebuild excludes the client-logo collage pending permission.
- Contact still publishes the same email, phone and two Bengaluru office addresses, while its J.P. Nagar training-centre reference remains incomplete.
- The public navigation has an “IT Consultation” label but no complete service detail page for the rebuild's ten-service portfolio. Expanded service descriptions remain based on supplied AROUSH company profile/brochure material and require owner confirmation of current availability.
- Multiple live course detail pages still expose the unverified `demosites.royal-elementor-addons.com` checkout destination. It remains blocked in the rebuild.

## Validation

- `npm run check:offline`: all 15 dependency-free validators passed.
- Chatbot rule routing: 46 intent-routing cases passed. Additional source assertions verify persistent quick replies and accessible expansion.
- Accessibility source scan: 23 TSX files checked; mobile navigation focus recovery and chatbot quick-reply state are required.
- TypeScript/TSX syntax: 30 files parsed with the globally available TypeScript 5.8.3 compiler; syntax only, not semantic typechecking.
- JavaScript syntax: 20 `.mjs` files passed.
- External-link policy: regression tests passed; 33 source files and 9 HTTPS hosts scanned.
- Internal route check: 30 public paths and course slugs checked; no broken internal paths reported.
- CSS parsed with PostCSS after the new styles were added.
- ZIP integrity and fresh extraction checked after packaging.

## Production blockers

- Available runtime: Node.js 22.16.0 with npm 10.9.2; project requires Node.js 24.x.
- `npm ping --fetch-retries=0 --fetch-timeout=10000` still fails with `EAI_AGAIN` resolving `registry.npmjs.org`.
- `node_modules` and a reviewed package lockfile are absent.
- Full TypeScript typecheck cannot resolve Next.js/React dependencies.
- ESLint and Next.js production build cannot run because their packages are not installed.
- `npm audit` cannot run meaningfully without a lockfile.
- Real Android/desktop browser testing remains pending.

Do not fabricate a lockfile or describe syntax checks as a successful production build.

## Privacy, approval and deployment

GA4 Measurement ID remains blank. Analytics stays disabled until owner setup and explicit visitor opt-in. The contact form remains a local email-draft workflow; no server-side lead database or CRM was added. No live website, WordPress installation, DNS, GitHub repository, analytics property or production deployment was changed.
