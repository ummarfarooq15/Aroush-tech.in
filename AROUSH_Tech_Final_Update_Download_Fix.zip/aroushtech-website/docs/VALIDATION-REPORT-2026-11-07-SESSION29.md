# Validation report — Session 29

Date: 7 November 2026

## Passed

Command:

```bash
npm run check:offline
```

All 15 checks completed successfully:

1. Content validation — 10 services, 20 public courses, 19 source outlines and 1 owner-review note, 6 SOC/SIEM paths, 3 team profiles, 10 gallery photographs, 8 industry profiles, 2 office addresses, 2 testimonials, 30 public routes and 23 permanent redirects.
2. Privacy validation — GA4 opt-in only, blank Measurement ID, reject/withdrawal support, persistent settings, voluntary phone and no server-side CRM/database.
3. Analytics policy tests — opt-in gating, ID validation, stored-choice normalization, query/hash stripping, safe referrers and minimal page-view payloads.
4. Brand validation — approved logo variants and favicon.
5. UX validation — chatbot, navigation, course filters, voluntary email enquiry, payment-safety disclosure and no server-side lead integration.
6. Accessibility source validation — 22 TSX files plus shared focus, skip-link, landmarks, reduced-motion and live-region checks.
7. Link validation — 30 internal paths, 20 course slugs and redirects.
8. External-link policy tests — HTTPS allowlist, HTTP rejection, protocol-relative URLs, unknown hosts, WordPress spam hosts, the explicitly blocked unverified checkout host, spam anchors and mailto/tel links.
9. External-link security — 32 source files and 9 HTTPS hosts reviewed; no unapproved host in application source.
10. Public-claims validation — 30 public source files scanned; no unapproved guarantees/comparative claims; price confirmation notices present.
11. Learning-path validation — 4 collections, 20 course links and 6 SOC/SIEM options.
12. Chatbot validation — 43 intent-routing cases, including online-payment safety routing.
13. JavaScript syntax — 20 `.mjs` files.
14. TypeScript/TSX syntax — 29 `.ts`/`.tsx` files parsed using global TypeScript 5.8.3. This is syntax validation only, not semantic typechecking.
15. Release configuration — Node 24 pin, scripts and blank GA4 Measurement ID.

## Production checks attempted but blocked

Environment:

- Node.js: `v22.16.0` (project requires `24.x`)
- npm: `10.9.2`
- No `package-lock.json`
- Required project dependencies are not installed in `node_modules`.

Results:

- `npm run preflight:release`: blocked because Node.js 24, `package-lock.json` and Next.js/React/TypeScript/ESLint dependencies are missing.
- `npm run typecheck`: failed to resolve `next`, `next/link`, `next/image`, `react` and React JSX types. The resulting JSX/implicit-any diagnostics are expected while the framework and type packages are absent; they are not treated as a code pass or as confirmed source defects.
- `npm run lint`: blocked because the `eslint` executable is not installed.
- `npm run build`: blocked because the `next` executable is not installed.
- `npm audit --audit-level=moderate`: blocked because npm requires a lockfile (`ENOLOCK`).
- `npm ping --fetch-timeout=5000 --fetch-retries=0`: failed with `EAI_AGAIN` resolving `registry.npmjs.org`.

## Required next steps

1. Open the project in GitHub Codespaces or another environment with Node.js 24.x.
2. Restore npm registry/DNS access.
3. Run `npm install` to create `package-lock.json`; review the lockfile before committing it.
4. Run `npm ci`, then `npm run typecheck`, `npm run lint`, `npm run build` and `npm audit`.
5. Test the production build on Android and desktop browsers, including the course catalogue, chatbot, enquiry handoff and privacy consent/withdrawal flow.

Do not describe source validation as a production build or real-browser test.
