# Session 37 — In-browser course comparison and fresh source review

Date: 7 November 2026

## Changes made

1. Added `lib/course-compare.mjs`, a small immutable helper for adding/removing course slugs from a comparison selection. It enforces a maximum of three selections and has no storage or network behavior.
2. Added `lib/course-compare.d.ts` so the JavaScript helper has a clear TypeScript signature.
3. Updated `components/course-catalogue.tsx` with an accessible **Add to comparison** control on each course card, a selected-course tray, remove/clear actions and an optional comparison table.
4. The comparison table uses only existing AROUSH catalogue fields: course title, category, whether a source outline is published, source-published duration when available, and the catalogue fee or an explicit fee-confirmation note. It does not infer prerequisites, schedules, outcomes, certification or delivery mode.
5. CCNA and CCNA DevNet remain marked **Confirm with AROUSH** because the current catalogue lists ₹19,999 while both individual course pages list ₹19,000. The table does not expose a guessed or selected fee.
6. Comparison selection exists only in React component state. It is not written to local/session storage, sent to an API, or included in analytics.
7. Added responsive comparison styling, horizontal table scrolling on small screens, visible keyboard focus, selected-state attributes and a live selection-count announcement.
8. Added `scripts/validate-course-compare.mjs` and wired it into `npm run check:offline`. Accessibility, UX and release-configuration validators now check the new controls and privacy boundary.
9. Refreshed the official AROUSH homepage, About, Gallery, Courses, Contact, CCNA, CCNA DevNet and Agentic AI course pages. Refreshed competitor UX research for Apna College, i-Medita and PyNet Labs.
10. Updated the README, beginner developer guide, source register and project status.

## Validation

`npm run check:offline` passed all 19 dependency-free validators, including:

- Content and route coverage
- Privacy and GA4 consent policy
- Brand and external-link security
- UX and accessibility source checks
- Internal navigation and public-claims checks
- Learning paths and searchable FAQs
- Natural course sorting
- New course comparison helper and UI checks
- 47 chatbot intent-routing cases
- JavaScript syntax and TypeScript/TSX syntax parsing
- Release configuration

The new comparison tests cover add/remove, the three-course limit, custom limits, immutable input arrays, accessible controls, published-only comparison fields, fee-conflict handling, local-only behavior and mobile table layout.

## Production blockers

- Available runtime: Node.js 22.16.0; project requirement: Node.js 24.x.
- npm registry lookup failed with `EAI_AGAIN registry.npmjs.org` during this run.
- No `package-lock.json` or `node_modules/` is present.
- `npm run typecheck` cannot resolve Next.js/React modules and JSX declarations without installed dependencies.
- `npm run lint` is blocked because ESLint is not installed.
- `npm run build` is blocked because Next.js is not installed.
- `npm run audit` is blocked with `ENOLOCK` because there is no lockfile.
- Real Android and desktop browser QA remains pending a successful build or staging environment.

The TypeScript syntax parser passed; that is not a semantic typecheck or production build.

## Current source findings

- Homepage: 20+ course/free-demo message and six course-category themes remain visible; featured course prices remain displayed.
- Courses: 20 public catalogue entries remain visible.
- CCNA and CCNA DevNet: catalogue price ₹19,999 versus individual-page price ₹19,000; rebuild continues to withhold both numeric fees.
- About: published mission/vision and three team profiles remain visible.
- Gallery: training and corporate-training photographs remain visible.
- Contact: `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses remain visible; the page also refers to a J.P. Nagar training centre without a complete visitor-ready address.
- Homepage still exposes three zero-value counters and 16 unrelated gambling/betting footer links. The rebuild excludes them; an authorised WordPress/hosting administrator must investigate. Their presence does not prove the precise compromise mechanism.
- Agentic AI course pages still expose a third-party checkout destination on `demosites.royal-elementor-addons.com`; it remains blocked in the rebuild.

## Privacy and release boundaries

- GA4 Measurement ID remains blank; analytics remains disabled until owner setup and explicit visitor opt-in.
- Course search, sorting and comparison remain browser-local; comparison selections are not persisted or transmitted.
- The contact form remains a voluntary email-draft workflow; no server-side lead database or CRM was added.
- No live website, WordPress, DNS, hosting account, GitHub repository, analytics property or deployment was changed.
