# Competitor UX review — Session 40

Date: 7 November 2026

This review covers public interface and information-discovery patterns only. No competitor prices, discounts, student counts, ratings, testimonials, placement statistics, credentials, schedules, guarantees or marketing claims are copied into AROUSH content.

## Apna College

Official reference: https://www.apnacollege.in/

The current homepage highlights several distinct programme families, including SigmaX, Prime 3.0, Alpha Plus, Sigma 12 and Delta. The useful pattern is a clear course-family hierarchy and a direct route from the home page to a specific learning goal. AROUSH already exposes six course-category themes, a searchable 20-course catalogue, course detail pages and goal-based learning paths. No programme outcomes, prices, discounts or performance claims are imported.

## i-Medita

Official references:
- https://www.imedita.com/
- https://www.imedita.com/frequently-asked-questions/

The FAQ content is organised around practical visitor questions such as location, schedule, language and training arrangements. The useful pattern is to answer decision-stage questions in a dedicated FAQ area and make human contact easy to find. AROUSH's searchable grouped FAQs and separate learner/business/general enquiry routes provide the equivalent path without copying i-Medita's fees, lab-access claims, enrolment counts, trainer claims or schedules.

## PyNet Labs

Official references:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

The course catalogue combines technical subject filters, career-path groupings and course cards. The useful pattern is layered discovery: visitors can start from a technology, a role or a specific course. AROUSH already supports category filters, keyword search, natural A–Z/Z–A sorting, learning-path collections and course comparison; Session 40 adds an outline-availability filter so visitors can distinguish courses with migrated source-published topics from courses needing AROUSH confirmation.

## Applied direction

- Keep AROUSH's catalogue order as the default.
- Preserve category and keyword discovery.
- Add outline availability as a separate filter, without inferring course details.
- Keep the comparison table limited to published category, outline status, duration and fee/confirmation state.
- Maintain visible human enquiry routes when the source information is incomplete.

No competitor marketing figures or commercial terms were copied.
