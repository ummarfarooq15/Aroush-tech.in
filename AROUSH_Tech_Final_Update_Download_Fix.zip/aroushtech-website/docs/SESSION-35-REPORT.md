# Session 35 — Course catalogue sorting and source refresh

Date: 7 November 2026

## Changes made

1. Added `lib/course-sort.mjs` and its TypeScript declaration. The small helper sorts a filtered course list by title A–Z or Z–A without mutating the source records; the default preserves AROUSH's published catalogue order.
2. Added a labelled sort control to `components/course-catalogue.tsx`. It works together with the existing search and category filters.
3. Updated the reset action so it clears the search, category filter and sort selection together.
4. Added responsive CSS for the search/sort row. The controls sit together on wider screens and stack on narrow mobile layouts; the select has visible keyboard focus.
5. Added `scripts/validate-course-sort.mjs` and `npm run validate:course-sort`, including tests for source order, A–Z, Z–A, unknown sort values, source immutability, accessibility markers and mobile styles.
6. Added the new check to `npm run check:offline`, release configuration validation, UX validation and accessibility source validation.
7. Reopened the current official AROUSH homepage, Courses, About, Contact, Gallery, AI & ML, CCNA and CCNA DevNet pages. The source review records current featured course prices, the 20-course catalogue and the two unresolved CCNA fee conflicts.
8. Refreshed competitor UX notes for Apna College, i-Medita and PyNet Labs. The catalogue sort is a simple, source-preserving discovery aid; no competitor commercial content was copied.
9. Updated the beginner developer guide, README, source register and project status.

## Validation

- `npm run check:offline`: all 18 dependency-free validators passed.
- Course sort tests: 5 direct behavior assertions plus component/accessibility/mobile integration checks passed.
- Existing FAQ search tests passed.
- Chatbot routing: 47 intent-routing cases passed; chatbot facts and rules were not changed in this session.
- TypeScript/TSX syntax: 34 files parsed with global TypeScript 5.8.3. This is syntax validation only, not semantic typechecking.
- JavaScript syntax: 25 `.mjs` files passed.
- Accessibility source scan: 25 TSX files checked, including the labelled course sort control and result relationship.
- Internal routes: 31 paths checked; 20 course slugs and redirects inspected.
- External-link security: 39 source files scanned and 9 HTTPS hosts reviewed; no unapproved host, HTTP URL or known spam domain found.
- Public-claims guard: 37 public source files scanned; no unapproved guarantee/comparative claim found.
- CSS/PostCSS: 563 rules, 24 at-rules and 1,848 declarations parsed successfully.
- Privacy: GA4 remains opt-in only, Measurement ID blank, reject/withdrawal available, phone voluntary, and no server-side lead database or CRM present.
- ZIP integrity and fresh extraction were checked after packaging.

## Production blockers

- Available Node.js: 22.16.0; project requires Node.js 24.x.
- No Node 24 runtime or nvm installation is available in this execution environment.
- `registry.npmjs.org` does not resolve (`EAI_AGAIN`); network access to the npm registry is unavailable.
- `node_modules/` and `package-lock.json` are absent.
- `npm run typecheck` is blocked by missing Next.js/React packages and type declarations. The global TypeScript parser passed syntax only.
- `npm run lint` is blocked because ESLint is not installed.
- `npm run build` is blocked because Next.js is not installed.
- `npm run audit` is blocked because no lockfile exists (`ENOLOCK`).
- Real Android/desktop browser QA remains pending a working build or staging environment.

## Privacy, approval and deployment

- GA4 Measurement ID remains blank; analytics remains disabled until owner configuration and explicit visitor opt-in.
- Course sorting runs locally in the visitor's browser and does not send search or sort selections to a server or analytics.
- The enquiry form still prepares an email draft on the visitor's device. No server-side lead database or CRM was added.
- No live website, WordPress installation, DNS, hosting account, GitHub repository, analytics property or production deployment was changed.
