# Competitor UX review — Session 36

Review date: **7 November 2026**

This review compares information architecture and visitor navigation only. Competitor prices, ratings, testimonials, statistics, credentials, schedules, placement figures, guarantees and marketing claims are not copied or used as AROUSH facts.

## Apna College

Reference: https://www.apnacollege.in/prime

Observed UX patterns:
- Gives separate entry points to engineering students, working professionals and non-CS learners.
- Presents curriculum as scannable topic groups.
- Places relevant calls to action near programme information.

AROUSH application:
- Keep goal-based learning paths and course categories easy to scan.
- Continue distinguishing published AROUSH course information from details that require direct confirmation.

## i-Medita

Reference: https://www.imedita.com/frequently-asked-questions/

Observed UX patterns:
- Organises FAQs around visitor decisions such as location, schedule, prerequisites, fees and payment.
- Makes operational details discoverable without forcing visitors to read every course page.
- Provides a route to a human team for programme-specific questions.

AROUSH application:
- Retain the searchable FAQ browser and three existing topic groups.
- Keep current fees, schedules, prerequisites, venue and service availability subject to direct confirmation where AROUSH's own source is incomplete or conflicting.

## PyNet Labs

Reference: https://www.pynetlabs.com/courses/

Observed UX patterns:
- Provides a broad course catalogue with technical categories.
- Places course discovery and groupings near the catalogue.
- Uses technology and learning-path groupings to help visitors narrow a large list.

AROUSH application:
- Retain AROUSH's own search and category filters.
- Refined AROUSH's A–Z/Z–A sorting to use natural numeric ordering, so numbered titles sort in human order.
- Corrected visible course numbers to follow the currently filtered/sorted results and announce the active sort to assistive technology.
- No competitor course level, duration, fee, rating, review, schedule, placement or guarantee data was imported.

## Boundaries

The only changes informed by competitor research are general navigation/discovery patterns. All AROUSH facts remain grounded in its own public pages or approved company material. Unresolved details remain on the owner-approval checklist.
