# Session 44 — accessible breadcrumbs and page hierarchy

Date: 7 November 2026

## Changes made

1. Added a reusable `components/breadcrumbs.tsx` component for all content pages except the homepage.
2. Added visible breadcrumb trails to About, Contact, Courses, course details, FAQs, Gallery, Learning Paths, Privacy, Services, Team and Corporate Training.
3. Added `BreadcrumbList` JSON-LD from the same breadcrumb data used for the visible trail. Course detail pages now use the shared component instead of maintaining a separate breadcrumb schema block.
4. Added a light-on-dark style for page heroes and a dark-on-light style for the privacy page. Mobile wrapping, keyboard focus and `aria-current="page"` are included.
5. Added `scripts/validate-breadcrumbs.mjs`, registered it in `npm run check:offline` and the release configuration validator, and extended the accessibility/content checks to recognise the shared component.
6. Updated the course detail eyebrow to show the course category without repeating the Courses breadcrumb label.
7. Reopened current official AROUSH pages and refreshed competitor UX research for Apna College, i-Medita and PyNet Labs.

## Why this change

The project already had a primary navigation menu and a breadcrumb JSON-LD block on course details, but most interior pages did not show a consistent visible path back to the parent page. The shared component improves orientation for visitors arriving from search engines, copied course links or the course comparison feature. It also reduces the chance that visible navigation and structured data drift apart.

## Validation performed

- `npm run check:offline` passed all 24 dependency-free validators in the working project.
- Dedicated breadcrumb validation passed for 11 content routes.
- TypeScript/TSX syntax validation passed for 39 files using TypeScript 5.8.3. This is syntax parsing only, not semantic typechecking.
- Accessibility source validation passed for 26 TSX files.
- Internal route validation passed for 31 routes and 20 course slugs.
- External-link security validation passed for 48 source files and 9 reviewed HTTPS hosts.
- Public-claims validation passed for 46 public source files.
- Fresh ZIP extraction and revalidation are recorded in the Session 44 validation report after packaging.

## Production limitations

- Runtime is Node.js 22.16.0, while the project requires Node.js 24.x.
- No `node_modules` or reviewed `package-lock.json` is present.
- npm registry access is still blocked by DNS resolution (`EAI_AGAIN registry.npmjs.org`).
- Full semantic TypeScript typecheck, ESLint, Next.js production build and npm audit remain blocked until Node.js 24 and npm registry access are available.
- Android and desktop browser QA, including visual breadcrumb checks and screen-reader testing, remain pending.

## Current source review findings

- The live homepage still advertises 20+ courses and a free demo, presents six course themes and features Agentic AI with LangChain & Hugging Face (₹35,000), CCNP Security (₹45,000) and CEH (₹25,000).
- The live homepage still displays zero-value counters and 16 unrelated gambling/betting footer links. The rebuild excludes them. An authorised WordPress/hosting investigation is still required; the crawl does not establish the exact injection mechanism.
- The public catalogue lists 20 courses. CCNA and CCNA DevNet remain inconsistent at ₹19,999 in the catalogue versus ₹19,000 on their individual pages. Both numeric fees remain withheld pending owner confirmation.
- The About page continues to publish the mission, vision and three team names/role titles.
- The Gallery continues to show training and corporate-training images. The rebuild retains ten training photographs and excludes the separate third-party logo collage pending approval.
- Contact continues to publish `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses. The J.P. Nagar training-centre reference still lacks a complete visitor-ready address.

## Privacy and deployment boundary

- GA4 Measurement ID remains blank and analytics remains disabled until owner setup and explicit visitor opt-in.
- No CRM, server-side lead database, payment integration or visitor-identification feature was added.
- No GitHub push, WordPress edit, DNS change, hosting change or deployment was performed.

## Files changed

- `components/breadcrumbs.tsx` — shared visible breadcrumb and JSON-LD component.
- `app/about/page.tsx`
- `app/contact/page.tsx`
- `app/courses/page.tsx`
- `app/courses/[slug]/page.tsx`
- `app/faqs/page.tsx`
- `app/gallery/page.tsx`
- `app/learning-paths/page.tsx`
- `app/privacy/page.tsx`
- `app/services/page.tsx`
- `app/team/page.tsx`
- `app/training/page.tsx`
- `app/globals.css` — breadcrumb variants, focus and mobile rules.
- `scripts/validate-breadcrumbs.mjs`
- `scripts/validate-accessibility.mjs`
- `scripts/validate-content.mjs`
- `scripts/validate-release-config.mjs`
- `package.json`
- `README.md`
- `docs/BEGINNER-DEVELOPER-GUIDE.md`
- `docs/SOURCE-REGISTER.md`
- `docs/PROJECT-STATUS.md`
- `docs/SESSION-44-REPORT.md`
- `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION44.md`
- `docs/COMPETITOR-REVIEW-2026-11-07-SESSION44.md`
- `docs/VALIDATION-REPORT-2026-11-07-SESSION44.md`

## Release archive

- ZIP: `AROUSH_Tech_Website_Session44_Accessible_Breadcrumbs_2026-11-07.zip`
- Archive entries: 215
- Uncompressed content: 8,565,959 bytes
- ZIP integrity check passed; the extracted archive passed the full `npm run check:offline` suite again.
