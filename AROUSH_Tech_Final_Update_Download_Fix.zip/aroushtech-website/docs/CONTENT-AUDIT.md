# Aroush Tech content audit — 6 November 2026

## Source hierarchy used

1. `https://aroushtech.in` — primary source for currently published public pages, course names and fees, published email/phone, logo, gallery imagery and existing customer-facing content. The live site was rechecked on 6 November 2026.
2. `AROUSH SOLUTIONS Company-Profile.pdf` — supporting 2026 company material for the expanded ten-service portfolio, leadership education/experience, company identity, address, delivery approach and SOC/SIEM scope.
3. `Aroush_Company_Brochure.pdf` — supporting 2026 summary of the service and training portfolio, values and SOC/SIEM limitations. Conflicts between the live site and 2026 documents are flagged for owner approval rather than silently resolved.

## Key facts migrated

- Brand: Aroush Tech / AROUSH Solutions.
- Legal entity: AROUSH SOLUTIONS (OPC) PRIVATE LIMITED.
- CIN: U72900KA2022OPC162189.
- Email: taj@aroushtech.in.
- Phone: +91 88676 92074.
- The supporting 2026 company profile lists a JP Nagar address; the live Contact page currently publishes two different office addresses, which are used in the public website build.
- LinkedIn: https://www.linkedin.com/company/103663927.
- Leadership: Abdul Aleem Khan, Tajuddin and Mohammed Khalid; the public build uses the names and role titles from the current live About page. Education and experience claims from the 2026 profile are held for owner approval because the profile and live-site titles differ.
- Ten service verticals migrated with deliverables, intended audiences and scope limitations.
- Eight target-industry profiles added from the 2026 company profile; they are explicitly described as intended customer segments, not existing clients.
- About page includes the company-stated mission, vision, core values, approach and brochure-listed reasons organizations choose AROUSH.
- 20 public courses migrated from the live course catalogue; six SOC/SIEM learning paths migrated from the 2026 profile. The course page supports text search and category filtering and includes the current homepage free-demo message with availability confirmation.

## Deliberately excluded pending confirmation

- Unsupported placement and job-assistance claims from the older website. Published course fees are included with a clear confirmation note.
- Old homepage counters displaying zero.
- Unverified vendor partnerships, vendor accreditations, exam vouchers and certification claims.
- Any 24×7 SOC monitoring or guaranteed incident response claim.
- Client logos from an old collage. A logo collage is not treated as proof of current clients or partnerships. The collage image remains excluded pending explicit approval.

## Discrepancies requiring owner approval

- The live contact page lists Corporate Office: #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029; and Registered Office: AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078. The supporting 2026 company profile lists a different JP Nagar address. The public build uses the two addresses published on the live Contact page; both should be reconfirmed before production.
- The live site lists course fees; these are copied into the redesign as website-listed amounts. Confirm current fees, availability and payment terms directly before payment.
- Confirm the approved corporate training photographs and whether the existing WordPress image URLs may be reused or should be replaced with original files.

## 6 November 2026 improvements

- Rechecked the live homepage, About, Courses, Gallery and Contact pages. The live course catalogue exposes 20 named public courses with displayed original/current fee pairs; all 20 pairs are copied as website-listed fees and accompanied by a confirmation note.
- Added two additional training photographs from the live Gallery page (10 photo references total). The client-logo collage is intentionally not used.
- Added course search and category filters with a live result count and an empty-results reset state.
- Added `/training` to the navigation, footer and sitemap; added unique anchors and enquiry actions for the six SOC/SIEM learning paths.
- Updated the homepage service preview to show representative examples from Connect, Secure, Support and Train.
- Added the eight target-industry profiles to Services and the four-point Aroush approach plus six brochure-listed strengths to About.
- Added page-specific canonical URLs, page descriptions and Open Graph metadata. Removed the inherited root canonical from the global layout so each route can identify its own canonical URL.
- Added a keyboard skip link and visible focus styles.
- Updated the sitemap to avoid publishing an unverified last-modified timestamp.
- Strengthened content validation for the ten services, 20 public courses, six SOC/SIEM learning paths, three leaders and ten gallery photographs.

## Current live-site observations

- The live contact page still lists two office addresses that differ from the supporting 2026 company profile address. The redesign now uses the two addresses currently published on the live Contact page; reconfirm them before launch.
- The live contact FAQ still claims 100% job assistance, certification and 24/7 lab access; these claims are not carried forward because the 2026 company materials do not substantiate them. The 2026 profile explicitly says placement outcomes, vendor accreditation and exam vouchers are not implied.
- The live homepage crawl continues to expose unrelated gambling/promotion links in the footer. This is a suspected SEO-spam injection; it must be investigated at the WordPress/hosting level. The live “Meet Our Team” navigation target also resolves to the About page; the rebuild provides a separate `/team` page.


## 6 November follow-up recheck

The live website is the primary source of truth for public-facing content in this build. The contact page currently lists two office addresses: the Corporate Office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029; and the Registered Office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078. Both are now shown in the new contact page and footer, with the linked map coordinates from the source page.

The mission and vision have been aligned with the current About page. Team profiles now show only the three names and role titles published there; supporting-document education and experience claims are not presented as live-site facts. The homepage now uses the two student testimonials shown on the current live homepage. Course descriptions and all 20 published fee pairs are aligned with the current Courses page. This was the status at the time of that initial follow-up. It was superseded by the later session 6 migration: 19 course pages now have source-backed outline summaries, while Fortinet remains an owner-review note.

The current live website does not publish the full ten-service vertical list as a dedicated Services page. The expanded ten-service portfolio and eight target-industry descriptions in the rebuild are therefore identified as supporting 2026 company-material content, not as content verified on the current live site. Confirm current service availability and wording with AROUSH before production.


## 6 November 2026 — current-source and course-detail review

- Rechecked the live homepage, Courses, About, Gallery and Contact pages on 6 November 2026. The live Courses page lists 20 course cards and their current displayed fee pairs; the new catalogue matches those pairs.
- The live About page currently spells the mission as: “To help your welfare and inspire people to realize their full potential through our revolutionary and superior training programs.” The new content data now preserves that wording exactly rather than silently polishing it.
- The live course catalogue labels the entries “Cybersys” and “Pentest (Penetration Testing)”; the new catalogue now matches those visible names.
- Added local detail pages for all 20 catalogue entries. Nineteen have source-backed outline summaries migrated, including ISE from its linked detail page. Fortinet has an explicit owner-review note because its legacy detail page mixes AROUSH wording with course and delivery copy attributed to I-Medita; that material is not reproduced.
- Where legacy detail pages show a different course fee from the live `/courses/` listing, the new website uses the current listing pair and asks visitors to confirm the current commercial terms.
- The new course-detail routes do not expose the legacy “Buy Course” links because the current crawl resolves those purchase links to a third-party demo-site domain.
- The current live Contact page still contains job-assistance and 24/7 lab-access statements in its FAQ. These remain excluded from the new site pending written confirmation because the 2026 supporting company material does not substantiate those promises.
- The live Gallery page contains ten training/learner photographs plus a client-logo collage. The new gallery retains ten training photographs and excludes the collage; it does not present the collage as evidence of current clients or partnerships.


## 6 November 2026 — session 6 live-source correction

A fresh live crawl of the homepage, Courses, About, Gallery and Contact pages was completed. The live catalogue still lists 20 courses and its fee pairs match the 20 records in `lib/content.ts`. The homepage's three featured courses are Agentic AI with LangChain & Hugging Face, CCNP Security and CEH; the rebuilt homepage now features those same three courses rather than the earlier four-course selection.

The ISE course has a linked detail page at `https://aroushtech.in/ciscoise/`. Its outline, prerequisites, one-month duration and online-weekend delivery notes have been migrated into the local `/courses/ise-identity-services-engine` page. This raises the number of source-backed course outlines from 18 to 19. Fortinet remains intentionally excluded from the migrated detail outlines because its live page contains extensive I-Medita-branded copy; the AROUSH catalogue card and fee are retained, but the detailed syllabus needs owner-approved replacement copy.

The live homepage still displays three zero-value counters and a footer containing unrelated gambling/promotion links to unrelated domains. The redesign does not copy those links or counters. This is an observable live-site issue, not proof of the insertion method; a WordPress, plugin, theme, administrator-account and hosting review is required.

The live Contact FAQ still contains claims about certification, 100% job assistance and 24/7 lab access. These are not repeated in the rebuild pending written confirmation. The live About page repeats the three leadership names and role titles; the new `/team` page remains a separate, cleaner destination because the legacy menu's “Meet Our Team” link resolves to the About page.

The live Gallery page contains ten training/learner photographs and text naming corporate-training examples. The new gallery keeps the ten photo references but does not add client names or logos as endorsement claims.


## Session 30 — 7 November 2026

The live catalogue and individual detail pages were compared for CCNA and CCNA DevNet. Both individual pages list ₹19,000 while the catalogue lists ₹19,999. The rebuild now withholds numeric fees for these two courses and routes fee questions to the AROUSH team until the owner confirms the correct amount. A shared `CoursePrice` component keeps the homepage, catalogue and detail pages consistent.

The CEH detail page attributes its instructor to UniNets. Its long-form syllabus, duration and trainer claims are now withheld pending AROUSH-approved content. This is in addition to the Fortinet/I-Medita content hold. The public catalogue still lists all 20 courses; 18 have source-backed outline summaries and two have explicit owner-review notes.

Office map links now search the published street addresses rather than using unverified coordinate pins. The Contact page makes clear that these are office-address searches, not confirmation of the J.P. Nagar training-centre venue or a precise entrance.
