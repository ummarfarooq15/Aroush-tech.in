# AROUSH website — release checklist

Use this checklist before any public launch. Do not treat a green content check as approval to deploy.

## Company approval

- [ ] Company owner approves the homepage and all public page copy.
- [ ] Corporate and registered office addresses and map pins are confirmed.
- [ ] Phone, email and LinkedIn details are confirmed.
- [ ] All ten service areas and delivery capabilities are approved.
- [ ] Course titles, current fees, prerequisites, schedules and availability are approved.
- [ ] Fortinet course detail is replaced with AROUSH-approved material.
- [ ] Team names, titles and portraits are approved for publication.
- [ ] Gallery photographs and testimonials have reuse permission.
- [ ] Job assistance, certification, lab access and trainer-experience claims are approved or omitted.

## Technical checks

- [ ] `node --version` reports Node.js 24.x.
- [ ] `npm install` completes successfully and creates a reviewed `package-lock.json`.
- [ ] `npm run validate:content` passes.
- [ ] `npm run typecheck` passes.
- [ ] `npm run lint` passes.
- [ ] `npm run build` passes.
- [ ] `npm run audit` reports no unresolved production dependency advisories.
- [ ] All pages are checked on phone, tablet and desktop widths.
- [ ] Keyboard navigation and visible focus are tested.
- [ ] Contact links, map links, course filters and mobile navigation are tested.
- [ ] All images load or show a deliberate fallback.
- [ ] All internal links and legacy redirects are tested.
- [ ] Metadata, sitemap, robots file and structured data are reviewed.
- [ ] A staging deployment is tested before production.

## Security and operations

- [ ] Hosting administrator investigates the unrelated promotional links seen in the old WordPress footer.
- [ ] WordPress administrators, plugins, themes, database content, scheduled tasks and hosting files are reviewed before migration.
- [ ] Production credentials and secrets are stored outside the repository.
- [ ] Backup and rollback plans are prepared.
- [ ] Enquiry form destination, consent wording and privacy process are approved.
- [ ] Owner explicitly authorizes the production deployment and DNS changes.
