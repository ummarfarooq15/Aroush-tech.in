# Session 28 development report — 7 November 2026

## Scope and release boundary

Continued the AROUSH Tech rebuild from Session 27. Work was performed only in the extracted project copy. The live WordPress site, hosting, DNS, GitHub repository and deployment were not changed.

## Fresh official-source review

Reopened the current public AROUSH homepage, About, Courses, Gallery and Contact pages, plus the AI & ML, CCNA, Agentic AI with LangGraph and LangChain, Agentic AI with LangChain and Hugging Face, and Fortinet course-detail pages.

- The homepage still advertises 20+ courses and a free demo, six course families, three featured courses, two testimonials and an instructor introduction. The zero-value counters remain excluded from the rebuild.
- The homepage still exposes 16 unrelated gambling/betting footer links to unrelated external domains. This remains a suspicious SEO-spam symptom requiring authorised WordPress/hosting investigation; it does not prove the entry point or a full server compromise.
- The Courses page still lists 20 course cards with descriptions and fee pairs. The rebuilt catalogue retains the same 20 records and clearly labels amounts as website-listed references requiring confirmation before payment.
- About still lists the current mission, vision and three team profiles. The rebuilt team-role wording follows the live About page.
- Gallery still shows training/learner and corporate-training imagery, plus a separate third-party logo collage and placement-related copy. The rebuild retains the ten training/learner photographs and excludes the collage and unapproved placement claims.
- Contact still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a J.P. Nagar training-centre reference. The rebuild keeps the two complete published office addresses distinct from the incomplete training-centre reference.
- The AI & ML page confirms 40 hours and seven modules. The two Agentic AI pages publish detailed outlines but no course duration; the chatbot now summarises their published topics without inventing a duration.
- The Fortinet detail page includes course text explicitly attributed to I-Medita. Its long-form content remains withheld; the rebuild retains only the AROUSH catalogue entry and requests an AROUSH-approved syllabus.
- The reviewed AI & ML and Agentic AI course-detail pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`. This destination was not opened or copied. The owner should verify whether it is an approved checkout destination before using it in any new site or campaign.

## Code changes

### Rule-based chatbot

- Added source-grounded answers for the Agentic AI with LangGraph and LangChain outline.
- Added source-grounded answers for the Generative AI with LangChain and Hugging Face outline.
- Explicitly state that those two public course pages do not publish a duration and direct visitors to the team for schedule confirmation.
- Added two matching quick replies to the mobile-friendly chatbot.
- Expanded chatbot regression checks to verify the route, key source topics, visible quick replies and unknown-question handoff.
- Chatbot remains a local rules-based helper. No live AI, CRM, backend enquiry or human-chat integration is claimed.

## Competitor UX review

Refreshed official public references for Apna College Prime, i-Medita FAQs/course pages and PyNet Labs course catalogue/contact. Retained only transferable patterns: ordered curriculum sections, course-level FAQs, technology/category discovery and clear human enquiry paths. No competitor pricing, statistics, ratings, testimonials, credentials, schedules, partners or guarantees were copied.

## Validation

`npm run check:offline` passed all 15 dependency-free validators:

1. Company/course content
2. Privacy and lead safeguards
3. Analytics consent policy
4. Brand assets
5. UX and enquiry flow
6. Accessibility source scan
7. Internal links and redirects
8. External-link policy tests
9. External-link security scan
10. Public marketing-claims guard
11. Learning paths
12. Chatbot intent routing and deep links
13. JavaScript syntax
14. TypeScript/TSX syntax
15. Release configuration

Additional targeted checks:

- Chatbot: 42 routing cases including the two new Agentic AI course intents, outline-topic assertions, quick replies and unknown-question handoff.
- TypeScript/TSX syntax: 29 files parsed with global TypeScript 5.8.3; syntax only, not semantic typechecking.
- JavaScript: 20 `.mjs` files passed syntax checks.
- External-link security: 32 source/config/static files scanned; no known spam domains, unsafe HTTP links or unapproved external hosts found in the rebuild.
- CSS/PostCSS parsing: 518 rules and 20 at-rules parsed successfully; the stylesheet was not changed in this session.

## Production blockers

The environment still runs Node.js 22.16.0 while the project requires Node.js 24.x. No `nvm`, `fnm` or `node24` executable is available in this runtime. The package has no `package-lock.json`, and local Next.js, React, TypeScript and ESLint dependencies are not installed. `npm ping` was retried and failed with `EAI_AGAIN` resolving `registry.npmjs.org`.

Therefore:

- Full TypeScript typecheck: blocked by missing dependencies/types.
- ESLint: blocked because ESLint is not installed.
- Next.js production build: blocked because Next.js is not installed.
- npm audit: blocked because no lockfile exists (`ENOLOCK`).
- Real Android and desktop browser QA: pending a successful staging build.

Do not treat syntax validation as a substitute for typechecking, linting, production build or browser testing. Do not fabricate a lockfile.

## Privacy and approvals

- GA4 Measurement ID remains blank.
- Analytics remains disabled until owner configuration and explicit visitor opt-in.
- Reject and withdrawal controls remain available.
- Phone number remains optional and visitor-supplied.
- No server-side lead database, CRM, SMS integration or analytics identity enrichment was added.

## Release decision

Not ready for deployment. The authorised WordPress/hosting administrator must investigate the 16 unrelated footer links and verify the third-party course checkout destination. Install Node.js 24 and dependencies in a supported Codespaces/staging environment, create and review a real lockfile, then complete semantic typecheck, lint, production build and real-device QA.
