# AROUSH website — beginner-friendly developer guide

The main marketing website is intentionally kept small and readable. It uses Next.js 15.5.29, React 19.3.1, standard React components and ordinary CSS. The root website has no database, CMS, authentication system, payment gateway or hidden content service. A separate, owner-approved development-only visitor-intelligence app lives under `apps/visitor-intelligence/`; it has its own Node 24 runtime, Supabase database, OTP providers and admin dashboard. It is not connected to the live website or deployed.

## 1. Main folders

| Folder or file | What it is for |
|---|---|
| `app/` | Website pages and shared page layout. Each folder with a `page.tsx` file creates a route. The dedicated FAQ page is `app/faqs/page.tsx`. |
| `components/` | Reusable pieces such as the header, footer, navigation, course list and enquiry form. |
| `lib/content.ts` | Main company, service, course, team, FAQ and gallery content. Start here when text needs updating. |
| `lib/course-details.ts` | The longer outline and detail information for individual courses. |
| `lib/course-compare.mjs` | A small browser-side helper that adds/removes up to three course slugs for comparison. |
| `lib/course-catalogue-url.mjs` | Reads and updates shareable course search/filter parameters without sending them to a server. |
| `lib/enquiry-path.mjs` | Normalizes learner/business/general enquiry routes and prepares the local email subject/body; it does not send or store data. |
| `lib/learning-paths.ts` | Goal-based collections built from existing public course slugs. |
| `lib/analytics-policy.mjs` | Small privacy rules for optional GA4: consent gating, safe page paths and referrer handling. |
| `lib/chatbot-rules.mjs` | Rule-based answers and routing for the website assistant. Each answer should link to a real page or send the visitor to Contact. |
| `app/globals.css` | Site-wide colours, typography, spacing, layout and responsive rules. |
| `public/` | Local images, icons and other static files. Approved source images can be moved here later. |
| `docs/` | Content review, decisions, deployment notes and checklists. |
| `scripts/` | Small Node.js checks that help catch missing or inconsistent content. |

## 2. Run the website

Use Node.js 24 LTS. As of 7 November 2026, the official Node.js site lists v24.22.2 as the latest 24.x maintenance-LTS release. The App Router pages use asynchronous `params` and `searchParams`, as required by Next.js 15.

```bash
nvm install 24
nvm use 24
node --version
npm install
npm run preflight:release
npm run check:offline
npm run typecheck
npm run lint
npm run build
npm run dev
```

Open the local preview shown by Next.js (normally `http://localhost:3000`). In GitHub Codespaces, open the **Ports** tab and use the forwarded port link.

### If you are using an Android phone with Codespaces

1. Open your GitHub repository in the browser and start its Codespace.
2. In the Codespaces file explorer, upload this ZIP and extract it into the repository workspace.
3. Open the terminal panel and enter the commands above from the project folder.
4. When Next.js starts, open the **Ports** tab, find port `3000`, and tap its forwarded address to preview the site.
5. Keep the Codespaces tab open while testing. You can edit `.tsx`, `.ts` and `.css` files directly in the browser editor.

## 3. Make common content edits

### Change a phone number or email

1. Open `lib/content.ts`.
2. Find the `company` object near the top.
3. Update `email`, `phone` and `phoneHref` together.
4. Update the contact page only if the layout or wording also needs to change.
5. Run `npm run validate:content`.

### Change a service

1. Open `lib/content.ts`.
2. Find the `services` array.
3. Edit the matching service's `title`, `summary`, `bullets`, `deliverable`, `audience` or `note`.
4. Keep claims within the scope AROUSH has approved.
5. Run `npm run validate:content`.

### Change a course

1. Open `lib/content.ts` and find the `courses` array.
2. Update the course title, category or summary there.
3. Open `lib/course-details.ts` to update its longer description or outline.
4. If the course belongs in a learning-goal collection, update `lib/learning-paths.ts` using its existing catalogue slug.
5. Do not guess a fee, duration, certification, exam voucher or schedule. Confirm it with AROUSH first.
6. Run `npm run validate:content`, `npm run validate:learning-paths` and `npm run typecheck`.
### Change a team member

1. Open `lib/content.ts` and find the `team` array.
2. Update the name, role, portrait path and initials only from approved company information.
3. Confirm permission to publish the portrait.

### Add or edit a page

1. Open the relevant folder in `app/`.
2. Edit its `page.tsx` file.
3. Use the shared components in `components/` where possible.
4. Add the page to `components/site-header.tsx` if it belongs in the main navigation.
5. Add it to `components/site-footer.tsx` and `app/sitemap.ts` when appropriate.
6. Add metadata and a useful page description.
7. Add the route to `app/sitemap.ts` and the appropriate navigation/footer links.


### Compare courses

1. `components/course-catalogue.tsx` renders the Add to comparison control on each public course card.
2. The visitor can select up to three courses. The selected list is held only in React state while the catalogue page is open.
3. `lib/course-compare.mjs` contains the add/remove/limit helper. Keep it small and free of browser storage, analytics or network calls.
4. The comparison table may use only source-backed fields already present in `lib/content.ts` and `lib/course-details.ts`: category, outline availability, published duration and the catalogue fee or a confirmation note.
5. Never infer a prerequisite, schedule, credential, delivery format or outcome for the comparison table. If a fee conflicts across official pages, keep the fee-confirmation note.
6. Run `npm run validate:course-compare`, `npm run validate:accessibility` and `npm run check:offline` after changing the feature.

## 4. Update learner and business enquiry paths

1. `app/contact/page.tsx` contains the three entry cards: individual learner, business/institution and general enquiry.
2. `components/contact-form.tsx` changes its optional fields and message guidance based on the selected path.
3. Course pages and learning paths should use `/contact?type=learner`; corporate training and service pages should use `/contact?type=business`.
4. `lib/enquiry-path.mjs` keeps route defaults and email-draft formatting in a small testable helper. Its TypeScript declaration is `lib/enquiry-path.d.ts`. The form shows the generated recipient, subject and message in a review panel before the visitor chooses to open their email app.
5. The visitor's email application is the only place where the draft is sent. Do not add `fetch`, `/api`, local storage, a database or CRM unless the owner separately approves that work.
6. Phone is always optional. Organisation, team size and course name are optional context fields; do not make them mandatory without owner approval.
7. Query-driven path cards update the form while it remains mounted. Keep the `useEffect` synchronisation in `components/contact-form.tsx` so the selected type/interest follows the URL without clearing unrelated fields. Course and message fields follow course query changes.
8. The form clears an old prepared-email fallback when a visitor edits the form or changes route/course, so it cannot reopen stale details.
9. `lib/enquiry-path.mjs` sanitises subject and single-line values before constructing the local email draft. Preserve those CR/LF/control-character protections and the field-length limits when editing it.
10. The review panel is React component state only. It does not write the draft to local storage, cookies, an API or a database. Editing any form field clears the preview so it cannot become stale.
11. The visitor must explicitly choose **Open email app** before the `mailto:` link is followed; the website does not launch the mail app automatically on form submission. The visitor still has to send the message from their email application.
12. Run `npm run validate:enquiry-paths`, `npm run validate:enquiry-safety`, `npm run validate:accessibility` and `npm run check:offline` after changing this flow.

## 5. Keep the code easy to maintain

- Use clear names such as `navigationLinks`, `course` and `office`.
- Keep repeated site sections in `components/` instead of copying the same markup everywhere.
- Keep business facts in `lib/content.ts`, not scattered across page files.
- Prefer plain CSS classes in `app/globals.css` over complicated styling systems.
- Add comments when the reason for a decision is not obvious.
- Do not add a new library for a small task that can be solved with existing code.
- Never commit passwords, API keys, private customer information or production credentials.

## 6. Checks before sharing a preview

```bash
npm run validate:content
npm run validate:accessibility
npm run validate:typescript-syntax
npm run validate:chatbot
npm run validate:analytics-policy
npm run test:external-link-policy
npm run preflight:release
npm run typecheck
npm run lint
npm run build
npm run audit
```

Then open each page on a phone-sized screen and a desktop-sized screen. Test the navigation, course search, contact links, map links, image fallbacks and all buttons. A successful content check is not the same as a successful production build or full browser test.

## 7. Update and search the FAQs

1. Edit the verified question and answer records in the `faqs` array in `lib/content.ts`.
2. Keep the existing categories unless the owner approves a new information group: `Courses & learning`, `Location & enquiries`, or `Services & business enquiries`.
3. `components/faq-browser.tsx` renders the search field, topic filters, result count and no-results contact path.
4. `lib/faq-search.mjs` contains the small, testable filter function. It searches question, answer and category text in the browser; it does not send the search term to a server.
5. Use only current AROUSH-published or owner-approved facts. Explain when fees, schedules, prerequisites, venues or service availability need direct confirmation.
6. Run `npm run validate:faqs`, `npm run validate:faq-search`, `npm run validate:links` and `npm run check:offline` after changing FAQ content or behavior.

## 8. Edit and test the website assistant

1. Edit `lib/chatbot-rules.mjs` to change a rule or add a verified answer.
2. Keep the response grounded in AROUSH-published or owner-approved information.
3. Link to an existing local page. Send unknown or uncertain questions to `/contact`.
4. Edit `quickQuestions` in `components/site-chatbot.tsx` to change the suggested questions.
5. Run `npm run validate:chatbot` to test common intents, including CCNA, AI & ML, both Agentic AI outlines, course-versus-service routing, SOC/SIEM, fees, privacy and unknown questions.

The chatbot does not call a live AI service, CRM or enquiry API. On mobile, opening the panel does not force the on-screen keyboard to appear; the visitor can tap the question field when ready.

## 9. Important current limitations

- The contact form opens the visitor's email application. It does not store or submit a lead to a server.
- Logo, team and gallery images still reference the current AROUSH website. Obtain approval and move approved files into `public/` before relying on the old WordPress host being available.
- Course fees are copied from the public catalogue snapshot and can change. Confirm current fees and availability before accepting payment.
- Course cards show whether source-published outline topics are available. The Fortinet syllabus remains pending AROUSH confirmation; do not copy material attributed to another provider.
- A course duration appears in the catalogue only when the AROUSH course-detail source publishes one. Do not infer a duration from a competitor or from a typical industry course.
- Fortinet's long syllabus is on hold because the old page contains material attributed to another training provider.
- No production deployment, WordPress replacement, DNS change or GitHub push has been performed.

## 10. Before production

Review `SOURCE-REGISTER.md` and complete `OWNER-APPROVAL-CHECKLIST.md`, investigate the unrelated links observed in the old WordPress footer, test the full site in a staging environment, and obtain written approval from the website owner before changing the live domain.

## 11. Public content safety checks

Run `npm run check:offline` for the full dependency-free source-validation suite. It includes content, privacy, analytics, brand, UX, accessibility, links, external-link security, public-claims, learning-path, FAQ, course sorting, outline-availability filtering and comparison, chatbot, JavaScript, TypeScript-syntax and release-configuration checks. Run `npm run validate:public-claims` before changing marketing copy or course prices. This validator prevents unapproved placement, hiring, top-rated, high-paying and 24×7 service promises from entering public application code; explicit disclaimers are allowed. If you add a course price, keep the visible notice that visitors must confirm the current fee before payment. Run `npm run test:external-link-policy` when changing the external-host security rules. The external-link scanner rejects HTTP links, protocol-relative unreviewed hosts, known spam domains and gambling anchor text. Run `npm run preflight:release` before a full build to see whether Node.js 24, a package lockfile and required dependencies are available.


## 12. Accessibility source check

Run `npm run validate:accessibility` after editing images, links, buttons, forms or shared layout. It checks that images have alternative-text attributes, new-tab links declare a safe `rel` value, buttons have accessible names, form controls have labels, and the shared layout keeps its skip link, main landmark, keyboard-focus styling, reduced-motion support and live announcements. This is a source-level safeguard; still test keyboard and screen-reader behavior in a real browser before release.


## 12. TypeScript and TSX syntax check

Run `npm run validate:typescript-syntax` after editing any `.ts`, `.tsx` or `.mts` file. It parses the source with the project TypeScript package when installed, or a global TypeScript installation when available. It catches malformed TypeScript/JSX syntax but does **not** check types, import resolution, React props or Next.js build behavior. Those still require `npm run typecheck` and `npm run build` after dependencies are installed.


## 13. Before adding an online payment link

The current rebuild has no online checkout. Do not copy the legacy third-party “Buy Course” link into a new page. The external-link validator blocks the unverified checkout host. Ask the owner to confirm the merchant, payment processor, privacy handling, refund terms and approval first. Run `npm run test:external-link-policy` and `npm run validate:external-links` after any external-link change.

## 14. Sort the course catalogue

1. Open `components/course-catalogue.tsx` to see the search, category filters and sort dropdown.
2. The default option, `AROUSH catalogue order`, preserves the order in `lib/content.ts`.
3. The A–Z and Z–A options use `lib/course-sort.mjs` with natural numeric ordering (for example, “Course 2” sorts before “Course 10”); the helper only rearranges existing course records and does not change their content.
4. Keep the sort options in `CourseSortOrder` in `lib/course-sort.d.ts` and `CourseSortOrder` state in the component aligned if a new sort option is ever approved.
5. Course-card numbers follow the current visible result order, and the live result message announces the active sort to assistive technology.
6. Run `npm run validate:course-sort`, `npm run validate:ux`, `npm run validate:accessibility` and `npm run check:offline` after changing the sort behavior.


## 15. Filter courses by outline availability

1. Open `components/course-catalogue.tsx` to see the `Outline availability` select beside the search and sort controls.
2. `All outline statuses` keeps every course visible. `Published outline topics` shows courses with a migrated source-backed outline. `Ask AROUSH to confirm` shows courses without a verified outline in this rebuild.
3. The classification lives in `lib/course-outline-filter.mjs`; the TypeScript declaration is in `lib/course-outline-filter.d.ts`.
4. A course with a `sourceNote` is not treated as having an approved outline, even if a legacy page contains material attributed to another provider. Do not remove this safeguard without written AROUSH approval.
5. Search, category, outline and sort controls combine. The reset button restores all controls to their defaults.
6. Run `npm run validate:course-outline-filter`, `npm run validate:ux`, `npm run validate:accessibility` and `npm run check:offline` after changing this behavior.



## Companion visitor-intelligence app (separate runtime)

1. Open `apps/visitor-intelligence/README.md` before editing the companion app. It explains the Supabase schema, email/SMS OTP providers, Cloudflare Turnstile, privacy controls and staging plan.
2. The companion app is a separate Next.js project. Do not move its `app/api` routes into the root marketing app or merge the two `package.json` files.
3. Use Node.js 24.x inside `apps/visitor-intelligence/`; its `.nvmrc` and `package.json` declare Node 24. The root project also uses Node 24.
4. Never add secrets to code, `.env.example`, screenshots or GitHub. Configure Supabase, Resend, MSG91, Turnstile and HMAC secrets only in a private local environment or approved hosting secret manager.
5. The tracker is aggregate-only and does nothing before consent. It uses a temporary tab-scoped token, not a persistent visitor ID. The dashboard must never expose session keys, individual visitor lists or visitor journeys.
6. Lead contact details are stored only after explicit contact consent and successful email and mobile OTP verification. Phone is entered voluntarily in the clearly described enquiry form and is never inferred from analytics.
7. Run `npm run validate:visitor-intelligence` and `npm run check:offline` after changes. Full typecheck/build, Supabase RLS/RPC tests, provider delivery tests and browser QA are still required before production.
8. The owner approved the development scope on 7 November 2026. Deployment, GitHub push, DNS changes, live WordPress edits and production provider-account changes still require separate explicit approval.

## 16. Share a filtered course catalogue view

1. Open `/courses` and use the search, category, sort and outline-availability controls.
2. The selected values appear in the page URL: `q` for search, `category` for the category, `sort` for ordering and `outline` for outline availability. Default values are omitted.
3. Select **Share filtered link**. Supported mobile browsers open the native share sheet; browsers without Web Share support fall back to clipboard copy.
4. If the visitor cancels the native share sheet, the page reports the cancellation and does not copy the link unexpectedly.
5. Search text is limited to 100 characters. `lib/course-catalogue-url.mjs` contains the parse/serialize helpers and the limit; its TypeScript declaration is `lib/course-catalogue-url.d.ts`.
6. Unrelated query parameters are preserved. Do not put personal information in the course search because the search term appears in the URL and may be shared.
7. The feature uses only browser history and component state. Do not add local storage, a server endpoint, analytics events or a database for this feature.
8. Run `npm run validate:course-catalogue-url`, `npm run validate:ux` and `npm run check:offline` after changing it.


## 17. Share a selected course comparison

1. Add two or three courses to the comparison tray on `/courses`.
2. Select **Share course view**. The share URL includes a `compare` parameter containing only the selected course slugs, for example `?compare=ccna,ai-ml`.
3. Opening a valid comparison link restores the selected courses and opens the comparison table automatically.
4. The parser accepts only slugs that exist in the current course catalogue, removes duplicates and keeps at most three courses. Unknown slugs are ignored, and the comparison parameter is capped at 128 characters before parsing.
5. Search, category, sort and outline filters can be shared with the comparison at the same time.
6. The URL does not contain names, phone numbers, email addresses or enquiry text. Search terms and comparison slugs appear in the URL and may be present in browser history, copied links and routine web-server logs. Do not add personal data to any catalogue parameter.
7. The comparison remains browser-side. No storage, API, database, CRM or analytics event is used.
8. Run `npm run validate:course-catalogue-url`, `npm run validate:ux` and `npm run check:offline` after changing this behavior.


## 18. Maintain page breadcrumbs

1. Open `components/breadcrumbs.tsx` to understand the shared breadcrumb component. It renders a visible navigation trail and matching `BreadcrumbList` JSON-LD from the same `items` array.
2. Each interior page passes its own final label and local path. For example, About passes `[{ label: "About", href: "/about" }]`; a course detail passes Courses followed by the current course title and slug. The component adds Home automatically.
3. The last item is shown as the current page with `aria-current="page"`; earlier items are normal internal links. Use only real internal routes and do not pass query strings, visitor input or external URLs.
4. Use `variant="dark"` only on a light page background, as on `/privacy`. The default `light` variant is for dark page heroes.
5. Styles are in the Session 44 section near the end of `app/globals.css`. Keep the focus outline and small-screen wrapping.
6. Run `npm run validate:breadcrumbs`, `npm run validate:accessibility`, `npm run validate:content` and `npm run check:offline` after changing route labels or breadcrumb behavior.


## Social preview cards

- `components/social-card.tsx` contains the shared AROUSH-branded preview layout.
- `app/opengraph-image.tsx` and `app/twitter-image.tsx` create the default site previews.
- `app/courses/[slug]/opengraph-image.tsx` and `twitter-image.tsx` create course-specific previews using the approved course catalogue.
- Keep social cards factual: do not add prices, placement promises, ratings, testimonials or competitor claims.
- Run `npm run validate:social-cards` after changing these files.
