# Session 27 development report — 7 November 2026

## Scope

Continue the AROUSH Tech rebuild from Session 26. The live WordPress site, DNS, GitHub repository and deployment were not changed.

## Source review

Reopened the official AROUSH homepage, About, Courses, Gallery, Contact, CCNA course and AI & ML course pages on 7 November 2026.

- Homepage: 20+ course positioning, free-demo message, six discovery families, featured courses and two published testimonials remain visible.
- About: mission, vision and three published team profiles remain visible.
- Courses: 20 public course cards and displayed fee pairs remain visible. Fees are catalogue references and require confirmation before payment.
- Gallery: training and corporate-training photographs remain available; the separate third-party logo collage remains excluded.
- Contact: `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a J.P. Nagar training-centre reference remain published. Visitors are told to confirm the exact training venue before travelling.
- CCNA: source page describes Cisco CCNA 200-301 topics and prerequisites.
- AI & ML: source page states 40 hours of live, intensive training and lists seven modules covering AI/ML, Python, network data, machine learning, predictive AI, language models and generative AI.

The homepage still exposes 16 unrelated gambling/betting footer links to unrelated domains. This is consistent with possible SEO-spam injection but does not establish the source or prove a full server compromise. The authorised WordPress/hosting administrator must investigate and confirm cleanup before migration. No live changes were attempted.

## Code changes

### Course discovery

- Added a visible outline-status label to each course card.
- Cards with source-published topics show “Published outline topics”.
- Fortinet shows “AROUSH syllabus to confirm”; its third-party-attributed legacy detail copy remains withheld.
- Published duration is displayed only where the AROUSH course-detail page supplies one.
- The live result count now includes the number of filtered results with published outline topics.

### Chatbot

- Added specific, source-grounded service answers for DPO-as-a-Service, CyberArk PAM, VAPT, OT/ICS, security awareness, network infrastructure, network security and technical support.
- Added stable service anchors (`/services#service-01` through `/services#service-08`, with the existing SOC/SIEM anchor retained).
- Added an AI & ML answer that states the AROUSH-published 40-hour duration and summarises the published subject areas.
- Routed named SIEM platforms (Sentinel, Splunk, Elastic, Wazuh and QRadar) to the SOC/SIEM information.
- Clarified that CyberArk/PAM consulting is listed, but a separate CyberArk/PAM course is not present in the public catalogue; visitors are directed to confirm tailored training with the team.
- Added a matching quick reply.
- Unknown questions continue to route to the human team. The chatbot remains rule-based and is not described as live AI or CRM-connected.

### Research and documentation

- Added `docs/COMPETITOR-REVIEW-2026-11-07.md` with current official Apna College, i-Medita and PyNet Labs UX references and the patterns applied.
- Updated the live-source review, source register, beginner developer guide and project status.

## Validation

`npm run check:offline` passed all 15 dependency-free validators after the changes:

- Company and course content
- Privacy and analytics consent
- GA4 analytics policy
- Brand assets
- UX and enquiry flow
- Accessibility source checks
- Internal routes and redirects
- External-link policy tests
- External-link security scan
- Public-claims guard
- Learning-path validation
- Chatbot intent and deep-link tests (38 cases, including unknown-question handoff)
- JavaScript syntax
- TypeScript/TSX syntax
- Release configuration

Additional checks:
- TypeScript/TSX syntax parser: 29 files, zero syntax diagnostics.
- JavaScript syntax: 20 `.mjs` files passed.
- CSS/PostCSS parsing: 518 rules and 20 at-rules parsed successfully.
- External-link security scan: 32 source files and 9 approved HTTPS hosts checked.
- ZIP integrity: passed after packaging.

## Production blockers

The runtime still has Node.js 22.16.0; the project requires Node.js 24.x. The current official Node.js 24 LTS release is v24.21.0 (published 8 September 2026; official release page last updated 27 October 2026). The package has no `package-lock.json`, and local Next.js, React, TypeScript and ESLint dependencies are not installed. The runtime cannot resolve `nodejs.org` or `registry.npmjs.org` (`Could not resolve host` / prior `EAI_AGAIN`). The existing Next.js 15.5.29 line was retained rather than attempting an untested major-version upgrade; upstream Next.js lists 15.5.29 as a 3 November 2026 security-fix release, and React 19.3.1 was released 14 October 2026.

Consequently:
- Full TypeScript typecheck: not run successfully.
- ESLint: blocked (`eslint: not found`).
- Next.js production build: blocked (`next: not found`).
- npm audit: blocked because no lockfile exists (`ENOLOCK`).
- Real Android and desktop browser QA: pending a successful build/staging environment.

Do not treat syntax checks as a substitute for full typechecking or a production build. Do not generate a fabricated lockfile.

## Privacy and approvals

- GA4 Measurement ID remains blank.
- Analytics remains disabled until owner setup and explicit visitor opt-in.
- Reject and withdrawal controls remain available.
- Phone remains optional and voluntarily entered.
- The contact form remains a local `mailto:` handoff; no server-side lead database or CRM exists.
- No charts or invented statistics were added.

## Release decision

Not ready for deployment. Resolve the live WordPress SEO-spam investigation, install Node.js 24 and project dependencies in GitHub Codespaces or another supported environment, generate and review a real lockfile, then complete typecheck, lint, production build and real-device browser QA.
