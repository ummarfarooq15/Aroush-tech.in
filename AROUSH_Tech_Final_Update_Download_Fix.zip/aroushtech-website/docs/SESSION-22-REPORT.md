# Session 22 — live-source security review and external-link guard

Date: 6 November 2026

## Main finding

A fresh public crawl of the live AROUSH homepage exposed 16 unrelated gambling/betting footer anchors pointing to 16 unrelated domains. This is consistent with possible SEO-spam injection. A public crawl cannot establish the exact injection source or prove a full WordPress/hosting compromise. The new incident review records the anchor phrases, domains, evidence limits and owner/hosting response plan.

The rebuilt website source does not contain those links. No live WordPress, hosting, DNS, Search Console, GitHub repository or production deployment changes were made.

## Code and documentation changes

- Added `scripts/validate-external-links.mjs`.
- The validator scans `app/`, `components/` and `lib/` source files for the observed gambling anchor phrases and 16 known unrelated domains.
- Added a small explicit external-host allowlist. Any new HTTPS host requires review and an allowlist entry; this is intended to prevent accidental copy/paste of injected footer links.
- Added `npm run validate:external-links` to `package.json` and `npm run check:offline`.
- Updated `scripts/validate-release-config.mjs` so the external-link validator is required and checked for existence.
- Added `docs/WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md` with preservation, investigation, containment and verification steps for the authorised owner/hosting administrator.
- Updated the README, security review, owner approval checklist, source register, competitor review and project status.

## Source and competitor review

Reopened the live AROUSH homepage, About, Courses, Gallery and Contact pages. The current homepage still advertises 20+ courses and a free demo, still features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH, still contains zero-value counters, and exposes the unrelated footer links. The new rebuild continues to omit zero-value counters and spam links.

The Courses page still lists 20 catalogue entries with displayed fee pairs. The About page still lists three team profiles. The Gallery page still shows training/corporate-training photographs. The Contact page still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses, and unconfirmed claims about 100% job assistance and 24/7 lab access. Those claims remain excluded pending written owner confirmation.

Competitor pages reviewed:

- Apna College SigmaX: programme comparison and visible curriculum sections.
- i-Medita Courses: technology/vendor groupings and course-specific destinations.
- PyNet Labs Courses: technology and career-path groupings with catalogue navigation.

Only general UX patterns were retained. No competitor claims, prices, ratings, testimonials, statistics, schedules, credentials or guarantees were copied.

## Validation

- `npm run check:offline` — passed all 11 dependency-free validators, including the new external-link check.
- External-link check — 31 source files scanned; 9 HTTPS hosts reviewed; no known spam domains, spam anchor phrases or unapproved hosts found.
- TypeScript/TSX syntax transpilation — passed for 27 source files with zero syntax diagnostics. This is a syntax check, not a semantic typecheck.
- CSS/PostCSS parse — passed for 534 top-level rules/at-rules in `app/globals.css`.
- External-link validator negative tests — correctly failed for both an unapproved test host and a known spam domain/anchor phrase; the temporary fixtures were removed and the clean scan passed again.
- Full TypeScript typecheck — blocked because `next`, React and their type declarations are not installed; `tsc --noEmit` reports unresolved framework modules and JSX types.
- ESLint — blocked because the `eslint` executable is not installed.
- Next.js production build — blocked because the `next` executable is not installed.
- npm audit — blocked because there is no package lockfile (`ENOLOCK`).
- Node.js 22.16.0 is available; the project requires Node.js 24.x. No Node 24 installation is present in this environment.
- Real Android and desktop browser QA — pending a successful staging build.

## Owner actions / blockers

1. The authorised WordPress/hosting administrator must investigate the live footer links and document cleanup before any migration or domain cutover.
2. Node.js 24 and the project's dependencies/lockfile are still needed for semantic typechecking, lint, build and dependency audit.
3. Real-device browser tests remain pending.
4. Owner approval is still needed for commercial details, legacy claims, training venue, image rights and GA4 setup/legal review.

## Privacy and deployment status

- GA4 Measurement ID remains blank and analytics remains disabled until owner setup plus explicit visitor opt-in.
- No server-side lead database or CRM was added.
- Phone numbers remain optional and voluntarily supplied.
- No live website, WordPress, DNS, GitHub repository, hosting, Search Console or production deployment was changed.

## Follow-up — Session 23

The live homepage was reopened again on 6 November 2026 and the same 16 unrelated gambling/betting footer anchors remained visible. The observed anchor spelling `casinomuhub` was added to the source guard. This confirms the public symptom persisted at the time of the recheck but does not prove the injection source or the scope of any WordPress/hosting compromise.
