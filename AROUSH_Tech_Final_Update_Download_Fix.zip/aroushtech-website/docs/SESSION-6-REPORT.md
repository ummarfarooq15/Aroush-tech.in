# Aroush Tech website — session 6 report

**Review date:** 6 November 2026
**Primary source:** https://aroushtech.in
**Project:** Next.js 14 + TypeScript public-site rebuild

## Work completed

1. Re-crawled the live homepage, About, Courses, Gallery and Contact pages, plus the ISE and Fortinet course detail pages.
2. Confirmed that the live catalogue still contains 20 course entries and that the package's 20 previous/current fee pairs match the current catalogue.
3. Found and corrected an earlier audit error: Cisco ISE has a linked live detail page at `/ciscoise/`. Migrated its outline, prerequisites, one-month duration and online-weekend delivery notes into the local ISE course detail page.
4. Updated the course migration tracker and content validator. The project now expects 19 source-backed course outlines; Fortinet remains intentionally held because its detail page contains third-party I-Medita-branded content.
5. Aligned the rebuilt homepage's featured course cards with the three courses featured on the live homepage: Agentic AI with LangChain & Hugging Face, CCNP Security and CEH.
6. Added a dated live-source review log with source URLs, observed issues and owner decisions required.
7. Confirmed the redesign omits the live site's zero-value counters, unrelated gambling/promotion footer links, unsupported job-assistance/24×7 lab claims, and third-party purchase links.

## Validation completed

- `node scripts/validate-content.mjs` — passed.
- The validator confirms 10 service records, 20 public course records, 19 source-backed course outlines, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery photo references, 8 target-industry profiles, 2 office addresses and 2 live-site testimonials.

## Not completed / blocked

- No `node_modules` or cached Next.js dependencies are available in this environment. Full `npm install`, `tsc --noEmit`, `next build` and browser QA have not been completed.
- No GitHub repository write, Codespaces session, DNS, hosting, WordPress or production deployment access is available in this run.
- Image assets still use the official site's WordPress URLs; local hosting requires approved image files and a download/upload workflow.

## Owner decisions and next steps

1. In GitHub Codespaces, run `npm install`, `npm run validate:content`, `npm run build` and `npm run dev`.
2. Review all 28 routes (8 main routes plus 20 course-detail routes) on mobile and desktop.
3. Obtain owner-approved Fortinet course copy and confirm the Contact FAQ promises before publication.
4. Confirm current fees, course availability, schedules, prerequisites, delivery mode and image reuse rights.
5. Investigate the suspicious WordPress footer links before any production migration.
6. Build a secure server-side enquiry endpoint, admin workflow and data-retention policy before collecting personal data.
