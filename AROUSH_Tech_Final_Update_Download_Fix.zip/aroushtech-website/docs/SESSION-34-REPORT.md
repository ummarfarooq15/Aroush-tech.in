# Session 34 — Searchable FAQ discovery and source refresh

Date: 7 November 2026

## Changes made

1. Added `components/faq-browser.tsx` as a small client-side FAQ discovery component. It searches existing question, answer and category text; it does not add, rewrite or generate company facts.
2. Added `lib/faq-search.mjs` and its TypeScript declaration. The helper preserves source order and supports case-insensitive search, category filtering, combined filters and empty results.
3. Replaced the static FAQ list in `app/faqs/page.tsx` with the searchable browser while keeping the same twelve verified FAQ records in `lib/content.ts`.
4. Added accessible category controls (`aria-pressed`), a labelled search field, a polite result-count status, a clear-filters action and a no-results state that routes visitors to Contact.
5. Added responsive CSS for search, category chips, empty-state recovery and touch-sized controls.
6. Added `scripts/validate-faq-search.mjs` with direct tests for default results, case-insensitive matching, searching answer text, category-only filtering, combined filters, no-match behavior and source immutability.
7. Integrated the new test into `npm run check:offline`, release-configuration validation, UX validation and accessibility source validation.
8. Updated the beginner developer guide, README, source register and competitor review notes.
9. Rechecked the live AROUSH homepage, course catalogue, About, Contact, Gallery, CCNA, CCNA DevNet and two Agentic AI course pages. Recorded the current source facts and unresolved discrepancies in `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION34.md`.
10. Refreshed the Apna College, i-Medita and PyNet Labs UX comparison. The searchable FAQ applies general information-discovery patterns without copying competitor claims or commercial content.

## Validation

- `npm run check:offline`: all 17 dependency-free validators passed.
- FAQ search behavior: 7 direct behavior assertions passed, plus source integration and responsive/accessibility markers.
- FAQ content/navigation: 12 unique source questions across 3 categories; route, navigation, footer, contact, sitemap and chatbot connections remain present.
- Chatbot: 47 intent-routing tests passed; no chatbot facts or answer rules were changed in this session.
- Accessibility source scan: 25 TSX files checked; labelled FAQ search, category state, live result count, empty-state contact recovery and native disclosure controls are present.
- TypeScript/TSX syntax: 33 `.ts`/`.tsx` files parsed with global TypeScript 5.8.3. This is syntax validation only, not semantic typechecking.
- JavaScript syntax: 23 `.mjs` files passed.
- Internal routes: 31 paths checked; 20 course slugs and redirects inspected.
- External-link security: 37 source files scanned and 9 HTTPS hosts reviewed; no unapproved host, HTTP URL or known spam domain found.
- Public-claims guard: 35 public source files scanned; no unapproved guarantee/comparative claim found.
- Privacy: GA4 remains opt-in only, Measurement ID blank, reject/withdrawal available, phone voluntary, and no server-side lead/CRM integration.
- CSS: parsed with the globally available PostCSS parser; detailed counts are recorded in the validation report.
- ZIP integrity and fresh extraction were checked after packaging.

## Production blockers

- Available Node.js: 22.16.0; project requires Node.js 24.x.
- npm registry ping failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- `node_modules/` and `package-lock.json` are absent.
- Full `npm run typecheck` is blocked by missing Next.js/React packages and type declarations.
- `npm run lint` is blocked because ESLint is not installed.
- `npm run build` is blocked because Next.js is not installed.
- `npm run audit` is blocked because no lockfile exists (`ENOLOCK`).
- Real Android/desktop browser testing remains pending a working build or staging environment.

## Privacy, approval and deployment

- GA4 Measurement ID remains blank; analytics remains disabled until owner configuration and explicit visitor opt-in.
- The FAQ browser only filters static verified FAQ records in the visitor's browser; it does not send search terms to a server or analytics.
- The contact form still prepares an email draft on the visitor's device. No server-side lead database or CRM was added.
- No live website, WordPress installation, DNS, GitHub repository, analytics property or production deployment was changed.
