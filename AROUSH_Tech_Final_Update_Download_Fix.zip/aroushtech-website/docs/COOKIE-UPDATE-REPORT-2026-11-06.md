# Privacy preference update report — 6 November 2026

## Implemented

- Explicit **Allow analytics** and **Reject** visitor choices.
- Persistent **Privacy settings** control for changing or withdrawing a choice.
- GA4 script loading requires both a valid owner-configured Measurement ID and explicit opt-in.
- The Measurement ID remains blank in `.env.example`; no GA4 property was created by this project.
- Withdrawal disables GA collection for the property, removes the saved choice and attempts to clear GA cookies.
- Privacy notice names Google Analytics 4 and Google LLC, describes the intended aggregate reporting, pseudonymous event processing, approximate geography, retention and owner/legal review requirements.
- Phone number remains optional and is clearly described as voluntary.
- No server-side lead database, API route or CRM integration was added.

## Validation

- `node scripts/validate-privacy.mjs`: source-level privacy safeguards.
- `node scripts/validate-ux.mjs`: chatbot, contact-form and course-discovery safeguards.
- `node scripts/validate-brand.mjs`: approved logo placement, responsive styles and favicon.
- `node scripts/validate-content.mjs`: AROUSH content and route coverage.
- Browser network testing is still required to prove no GA request before consent and correct withdrawal behaviour.

## Owner action before production

- Approve the GA4 property and Measurement ID, provider setup, retention, access and integrations.
- Confirm privacy contact and enquiry-email retention.
- Obtain legal review of the notice and consent flow.
- Complete staging browser tests before deployment.
