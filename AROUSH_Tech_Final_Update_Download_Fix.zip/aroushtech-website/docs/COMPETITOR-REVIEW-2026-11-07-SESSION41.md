# Competitor UX review — Session 41

Date: 7 November 2026

This review is limited to public information architecture and interaction patterns. No competitor prices, discounts, ratings, student counts, testimonials, credentials, placement statistics, schedules or guarantees are copied into AROUSH content.

## Apna College

Official references:
- https://www.apnacollege.in/
- https://www.apnacollege.in/prime

Current programme pages present distinct course families and learning goals, then expose curriculum sections and topic groupings. The useful pattern is to let visitors identify a goal before reading the full curriculum. AROUSH already uses course categories and goal-based learning paths; the catalogue now also lets visitors share a selected search/filter view.

## i-Medita

Official reference:
- https://www.imedita.com/frequently-asked-questions/

The FAQ is organised around practical visitor questions, including training location, schedules, language and travel arrangements. The transferable pattern is to organise FAQs around decisions visitors need to make, then provide a direct route to a human contact. AROUSH retains its own searchable FAQ groups and learner/business/general enquiry routes.

## PyNet Labs

Official references:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

The catalogue groups technical courses by technology and career-path families. The useful pattern is layered discovery: a visitor can begin with a domain, role or specific course. AROUSH retains its own category filters, keyword search, natural sorting, outline-availability filter and three-course comparison.

## Applied direction

- Keep AROUSH's published catalogue order as the default.
- Preserve keyword and category filtering.
- Keep outline availability separate from course category.
- Allow the current filtered catalogue to be copied as a shareable URL.
- Keep all course content and commercial information tied to AROUSH's own public sources or written owner approval.

No competitor marketing figures, commercial terms or guarantees were imported.
