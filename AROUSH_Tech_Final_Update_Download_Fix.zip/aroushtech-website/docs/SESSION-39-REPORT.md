# Session 39 — Enquiry state synchronisation and email-draft safety

Date: 7 November 2026

## Changes made

1. Fixed query-driven contact-form state synchronisation. When a visitor selects another learner, business/institution or general enquiry card while `/contact` remains mounted, the form now updates its selected enquiry type and interest instead of retaining the previous route's React state.
2. Kept the visitor's already-entered name, email and other unrelated fields when the enquiry path changes. Course name and the course-specific message are controlled fields and update only when the course query parameter changes.
3. Cleared an old prepared `mailto:` fallback whenever the visitor edits the form or the route/course query changes, so the fallback cannot silently point to an earlier version of the enquiry.
4. Hardened `lib/enquiry-path.mjs` before constructing a local email draft:
   - Subject and single-line fields strip control characters and collapse CR/LF into spaces.
   - Subject is capped at 180 characters.
   - Name, email, phone, organisation, team-size, course and interest fields have explicit helper-side limits.
   - Message text retains ordinary line breaks but strips non-printing control characters and is capped at 3,000 characters.
   - Empty fields receive clear placeholders.
5. Added `scripts/validate-enquiry-safety.mjs` with tests for subject/header line breaks, field-label injection, message handling, length limits and the local-only email handoff.
6. Expanded enquiry-path validation to assert route-query synchronisation, controlled course/message fields and stale-draft clearing.
7. Added the new safety validator to `npm run check:offline` and release-configuration validation.
8. Refreshed the official AROUSH homepage, Courses, About, Gallery, Contact, CCNA, CCNA DevNet, AI & ML and Agentic AI with LangGraph/LangChain pages. Refreshed Apna College, i-Medita and PyNet Labs UX references.

## Validation

- `npm run check:offline`: all 21 dependency-free validators passed.
- Enquiry route tests: 33 assertions passed.
- Enquiry email-draft safety tests: 19 assertions passed.
- Chatbot rule tests remain at 47 intent-routing cases.
- TypeScript/TSX syntax parser passed for 36 `.ts`/`.tsx` files using globally available TypeScript 5.8.3. This is syntax parsing only, not semantic typechecking.
- JavaScript syntax validation passed for 30 `.mjs` files using Node.js 22.16.0.
- Internal route validation: 31 paths; 20 course slugs and 23 redirects inspected.
- External-link policy and security checks passed; 43 source files and 9 HTTPS hosts reviewed.
- Privacy, analytics, public-claim, accessibility, course sort/comparison, FAQ, chatbot, content and release-config validators passed.

## Current source findings

- Homepage: the official site still advertises 20+ courses, a free-demo message and six course-category themes. It also still shows three zero-value counters and 16 unrelated gambling/betting footer destinations; the rebuild excludes these items. The public homepage currently features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH with listed amounts.
- Courses: the official catalogue still lists 20 courses. CCNA and CCNA DevNet are each listed at ₹19,999 in the catalogue, while their individual pages list ₹19,000. The rebuild continues to withhold those conflicting numeric fees.
- About: the page still lists the published vision/mission and three profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid. Three zero-value counters remain visible on the live About page and are excluded from the rebuild.
- Gallery: the public gallery continues to show training and corporate-training photographs and refers to corporate sessions in Bengaluru, including named organisations. The rebuild retains only its approved AROUSH gallery assets and does not add new client claims.
- Contact: the page still publishes `taj@aroushtech.in`, `+91 88676 92074`, the corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029, and registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru 560078. It separately refers to a J.P. Nagar training centre without a complete visitor-ready address.
- CCNA and CCNA DevNet individual pages still list ₹19,000; catalogue lists ₹19,999. The mismatch remains an owner decision.
- AI & ML still publishes a 40-hour duration. The Agentic AI with LangGraph/LangChain page publishes an outline but no duration and still exposes an unverified third-party checkout host. The rebuild does not enable that checkout.
- The homepage crawl still exposes 16 unrelated gambling/betting footer links. Their presence warrants an authorised WordPress/hosting investigation but does not prove the entry point or precise compromise mechanism.
- The Contact FAQ still contains certification, 100% job-assistance and 24/7 lab-access claims. These remain owner-review items and are not restated as guarantees in the rebuild.

## Competitor UX review

- Apna College Prime currently separates audience groups (engineering students, working professionals and non-CS learners) and provides a scannable curriculum. This reinforces the rebuild's separate learner and business/institution entry points; no competitor outcomes, offers or programme claims were copied.
- i-Medita's FAQ page exposes a large course taxonomy and a visible trainer/contact context. This supports topic-grouped FAQs and human handoff rather than guessing current batch/payment details.
- PyNet Labs' course catalogue exposes subject filters, career-path groupings and sorting. The AROUSH rebuild already provides course search, category filtering, natural A–Z/Z–A sorting, goal-based learning-path collections and local comparison.
- No competitor prices, discounts, ratings, testimonials, student counts, placements, credentials, schedules or guarantees were copied.

## Production blockers

- Runtime is Node.js 22.16.0; project requires Node.js 24.x. The official Node.js release post records v24.22.2 LTS on 28 October 2026: https://github.com/nodejs/nodejs.org/blob/main/apps/site/pages/en/blog/release/v24.22.2.md.
- A fresh `npm ping --fetch-retries=0` failed with `EAI_AGAIN` while resolving `registry.npmjs.org`.
- No `package-lock.json` or `node_modules/` is present.
- Full semantic TypeScript typecheck, ESLint, Next.js production build and npm audit remain blocked by missing dependencies/lockfile and unavailable registry access.
- Android and desktop browser QA remains pending a successful dependency install/build or staging environment.

## Privacy and release boundaries

- The contact form still prepares an email draft on the visitor's device. It does not POST to a server, save to a database or connect to a CRM.
- Phone remains optional and is included only when the visitor provides it.
- No analytics event or third-party script was added.
- GA4 Measurement ID remains blank; analytics remains disabled until owner configuration and explicit visitor opt-in.
- No production deployment, GitHub push, WordPress edit, DNS change, hosting change, analytics-property change or CRM/database integration was performed.
