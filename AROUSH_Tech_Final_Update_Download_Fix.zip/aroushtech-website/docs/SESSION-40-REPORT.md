# Session 40 — Course outline availability filter and source refresh

Date: 7 November 2026

## Changes made

1. Added a course-catalogue filter with three options: all outline statuses, published outline topics, and courses whose outline needs confirmation from AROUSH.
2. The filter is driven only by the migrated AROUSH course-detail records. It does not infer a syllabus from the course title or description.
3. Provider-attribution review notes remain in the confirmation group. CEH and Fortinet copy attributed to other training providers is not presented as an AROUSH-approved outline.
4. Search, category filters, natural A–Z/Z–A sorting and the new outline filter combine. The existing reset control now clears all four controls.
5. Added accessible label/select relationships, a live result announcement that includes the outline filter state, visible keyboard focus and a narrow-screen stacked layout.
6. Added `lib/course-outline-filter.mjs` and its TypeScript declaration so the classification can be tested without React or Next.js dependencies.
7. Added `scripts/validate-course-outline-filter.mjs` with 17 assertions and included it in `npm run check:offline` and release-configuration validation.
8. Reopened the official AROUSH homepage, About, Courses, Gallery, Contact, CCNA, CCNA DevNet and team information. Refreshed the Apna College, i-Medita and PyNet Labs interface review.
9. Updated the source register and beginner-facing README to describe the new filter and the current gallery evidence.

## Validation

- `npm run check:offline`: all 22 dependency-free validators passed.
- Course-outline filter: 17 assertions passed, including published-outline classification, provider-attribution guard, confirmation grouping, unknown-filter fallback, immutable input and mobile/accessibility source checks.
- Existing chatbot tests: 47 cases passed.
- Enquiry path tests: 33 assertions passed.
- Enquiry email-draft safety: 19 assertions passed.
- TypeScript/TSX syntax parser: 37 files passed. This is syntax validation only, not semantic typechecking.
- JavaScript syntax validator: 32 `.mjs` files passed.
- Internal routes: 31 checked; 20 course slugs and 23 redirects remain registered.
- External-link policy/security, privacy, GA4 consent, public-claims, accessibility, FAQ, learning-path, course-sort and course-comparison validators passed.

## Production blockers

- Runtime is Node.js 22.16.0; project requires Node.js 24.x.
- `registry.npmjs.org` does not resolve in the current environment. Package-lock generation failed with `EAI_AGAIN` while requesting `@types/node` metadata.
- No `node_modules` directory or reviewed `package-lock.json` is available.
- Full TypeScript typecheck cannot resolve Next.js/React modules and JSX types.
- ESLint binary is unavailable (`eslint: not found`).
- Next.js production build is unavailable (`next: not found`).
- `npm audit` cannot run without a lockfile (`ENOLOCK`).
- Real Android/desktop browser QA remains pending.

The syntax parser and dependency-free validators are not substitutes for a successful production build or semantic typecheck.

## Current source and owner-review findings

- The live catalogue lists 20 courses. Eighteen have migrated source-backed outlines; two long-form pages remain flagged for provider-attribution review.
- CCNA and CCNA DevNet still show ₹19,999 in the catalogue and ₹19,000 on their individual detail pages. Both numeric fees remain withheld in the rebuild.
- The live homepage still shows zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes them. An authorised WordPress/hosting investigation remains necessary; the public crawl does not establish the injection path.
- The live Contact page publishes `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses. It separately refers to a J.P. Nagar training centre without a complete visitor-ready address.
- The live gallery exposes ten training photographs plus a separate collage of third-party logos. The rebuild retains ten training photographs and excludes the logo collage so it is not mistaken for a verified current customer/partner list.
- Contact-page statements about certification, 100% job assistance and 24/7 lab access remain owner-review items and are not repeated as rebuild guarantees.
- The unverified third-party course checkout host remains blocked; the rebuild has no online payment flow.

## Privacy and deployment boundary

- GA4 Measurement ID remains blank; analytics remains disabled until owner setup and explicit visitor opt-in.
- No server-side lead database, CRM, payment processor or visitor-identification feature was added.
- Phone remains optional and voluntarily supplied through the enquiry form.
- No GitHub push, WordPress edit, DNS change or deployment was performed.

## Files changed

- `components/course-catalogue.tsx`
- `lib/course-outline-filter.mjs`
- `lib/course-outline-filter.d.ts`
- `app/globals.css`
- `scripts/validate-course-outline-filter.mjs`
- `scripts/validate-ux.mjs`
- `scripts/validate-course-sort.mjs`
- `scripts/validate-release-config.mjs`
- `package.json`
- `README.md`
- `docs/PROJECT-STATUS.md`
- `docs/SOURCE-REGISTER.md`
- `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION40.md`
- `docs/COMPETITOR-REVIEW-2026-11-07-SESSION40.md`
- `docs/VALIDATION-REPORT-2026-11-07-SESSION40.md`
