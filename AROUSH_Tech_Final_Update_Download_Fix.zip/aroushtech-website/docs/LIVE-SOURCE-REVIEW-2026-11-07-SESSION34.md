# Live AROUSH source review — Session 34

Review date: **7 November 2026**

Primary source: https://aroushtech.in/ and its current public pages. This is a point-in-time public crawl, not an owner confirmation of current commercial terms.

## Current public facts checked

| Area | Current public source observation | Rebuild treatment |
|---|---|---|
| Homepage | Advertises 20+ job-ready courses and a free demo; lists six course category themes. | Keeps course discovery and free-demo enquiry wording, with availability confirmed per course. |
| Course catalogue | Lists 20 individual courses, including CCNA and CCNA DevNet. | Keeps 20 course records and links to individual detail pages. |
| About | Publishes a vision, mission and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid with role titles. | Keeps only the public names/roles already recorded in the source register; does not import unapproved biography claims. |
| Contact | Publishes `taj@aroushtech.in`, `+91 88676 92074`, a corporate office address and a registered office address. | Uses the published contact details and address-search map links. The J.P. Nagar training-centre reference still lacks a complete visitor address. |
| Gallery | Shows training/learner photographs and a corporate-training section. | Uses the ten training/learner photographs already represented in the rebuild; the separate third-party logo collage remains excluded. |
| Course details | CCNA and CCNA DevNet individual pages each currently show ₹19,000. | Numeric fee remains withheld because the catalogue shows ₹19,999 for both. |
| Agentic AI pages | Both Agentic AI pages still display a Buy Course link to `demosites.royal-elementor-addons.com`. | The unverified host remains blocked and no checkout link is added to the rebuild. |

## Live-site issues observed again

1. The homepage currently displays zero-value counters (`0k+`, `0+`, `0%`). These are not copied into the rebuild because they do not provide useful, approved performance data.
2. The same homepage crawl exposes 16 unrelated gambling/betting footer links on unrelated domains. This is a suspicious SEO-spam indicator and is consistent with possible injected content, but the crawl alone does not establish the entry point or full compromise. An authorised WordPress/hosting administrator must investigate.
3. The public Contact page continues to state certification, 100% job assistance and 24/7 lab access. Those claims remain excluded from the rebuild pending written owner approval.
4. The Contact page refers to a J.P. Nagar training centre but does not provide a complete visitor address. Visitors should confirm the exact session venue before travelling.
5. The catalogue lists CCNA and CCNA DevNet at ₹19,999 while their individual pages list ₹19,000. Both numeric amounts remain withheld from those two rebuilt course cards pending owner confirmation.
6. The two Agentic AI detail pages continue to expose the unverified third-party checkout host. The destination was not opened or used.

## Content boundaries

- The public site remains the primary source for published courses, team names/roles, gallery context and contact details.
- The ten-service portfolio and SOC/SIEM learning-path material in the rebuild are supported by the supplied 2026 company profile and brochure, not a complete dedicated services catalogue on the current public website. Owner approval is still needed before those service details are treated as current commitments.
- The current public site uses some broad marketing language (including job-readiness, high-paying-career and certification wording). The rebuild avoids converting that language into guarantees or measurable outcomes.
- No charts or statistics were added; no counters were inferred or fabricated.

## Public source URLs

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Course catalogue: https://aroushtech.in/courses/
- Contact: https://aroushtech.in/contact-us/
- Gallery: https://aroushtech.in/gallery/
- CCNA detail: https://aroushtech.in/ccna/
- CCNA DevNet detail: https://aroushtech.in/ccna-devnet/
- Agentic AI with LangChain & Hugging Face: https://aroushtech.in/agentic-ai-with-langchain-hugging-face/
- Agentic AI with LangGraph & LangChain: https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/

## Change control

This review only informed the offline rebuild. No WordPress, live website, DNS, hosting account, GitHub repository, analytics property or deployment was changed.
