# AROUSH website assistant

The site includes a small responsive FAQ assistant in `components/site-chatbot.tsx`. Its source-backed answer rules live in `lib/chatbot-rules.mjs` so they can be tested without installing the website dependencies.

- It answers common questions about courses, the CCNA outline, the published AI & ML 40-hour duration and topic areas, both Agentic AI course outlines (LangGraph/LangChain and LangChain/Hugging Face), fees, batches, training formats, corporate training, SOC/SIEM learning and services. SIEM platform names such as Sentinel, Splunk, Elastic, Wazuh and QRadar route to the relevant SOC/SIEM information.
- It offers quick questions for course discovery (including both Agentic AI outlines), accepts typed questions and adds a relevant link to the next website page. The two Agentic AI pages do not state a duration, so the assistant directs visitors to confirm schedules rather than guessing.
- Service-intent questions can link directly to numbered service sections: DPO-as-a-Service, CyberArk PAM, VAPT, OT/ICS, security awareness, network infrastructure, network security and technical support. SOC/SIEM retains its dedicated anchor. Corporate training routes to `/training`.
- It treats fees as catalogue references and directs visitors to confirm current prices, dates, availability and programme terms with the AROUSH team. If a visitor asks for a CyberArk/PAM course, it explains that the public catalogue does not list a separate course and directs them to ask about a tailored option rather than implying one exists.
- It does not promise placement, certification, 24×7 lab access or managed SOC monitoring unless the company confirms the exact written terms.
- Unknown questions go to `/contact` instead of being guessed.
- It is a local rule-based FAQ helper, not a live AI model, CRM integration, enquiry submission service or human support channel.

To expand it, edit `lib/chatbot-rules.mjs` and `quickQuestions` in `components/site-chatbot.tsx`. Keep every answer source-backed, link to an existing route or stable service anchor, and direct uncertain questions to the Contact page. The service anchors are created by `app/services/page.tsx`; update the chatbot and tests together if those IDs change. Run `npm run validate:chatbot` after changes.

On mobile, opening the assistant does not force the on-screen keyboard to appear. Quick replies also leave the keyboard closed; visitors tap the question field when they want to type. The close button, quick replies and send controls use larger touch targets.
