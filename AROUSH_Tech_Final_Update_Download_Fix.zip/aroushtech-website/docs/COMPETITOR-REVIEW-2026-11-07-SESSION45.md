# Competitor UX review — Session 45

Date: 7 November 2026

This review considers navigation, content structure and user interaction only. Competitor commercial claims, prices, discounts, ratings, testimonials, credentials, learner counts, placement outcomes and guarantees must not be copied.

## Apna College

Official reference: https://www.apnacollege.in/prime

The current Prime page separates learner audiences (engineering students, working professionals and non-CS learners) and provides scannable curriculum sections. Useful pattern: help visitors identify the most relevant learning route before asking them to inspect a long curriculum. AROUSH already provides individual learner/business enquiry paths and goal-based learning collections; those remain grounded in AROUSH's own course information.

## i-Medita

Official reference: https://www.imedita.com/frequently-asked-questions/

The FAQ page exposes practical information such as training location, schedule, course language and payment questions. Useful pattern: group FAQs around decisions a visitor needs to make and provide a human contact path for details that change. AROUSH retains its own searchable FAQ groups and routes unknown chatbot questions to the team.

## PyNet Labs

Official reference: https://www.pynetlabs.com/courses/

The course catalogue uses technical category groups including automation, routing/switching, network security, cloud, data centre, cybersecurity and AI. Useful pattern: combine a quick search with understandable category navigation. AROUSH retains its own six published homepage themes and existing catalogue filters, comparison and shareable links.

## Applied direction in Session 45

- Added AROUSH-branded social preview images for the site and individual course pages.
- Course previews resolve the title, category and description from the existing AROUSH course catalogue.
- No competitor visual identity, claims, commercial data, course details or testimonials were imported.
