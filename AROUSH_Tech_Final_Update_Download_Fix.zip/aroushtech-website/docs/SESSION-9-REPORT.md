# Session 9 — structured data and live-source reconciliation

Date: 6 November 2026

## Live-source review

Reviewed the live homepage, About page, Courses page and Contact page again.

- The homepage currently lists three featured courses: Agentic AI with LangChain & Hugging Face (₹35,000 website-listed, previous amount ₹45,000), CCNP Security (₹45,000, previous amount ₹55,000), and CEH (₹25,000, previous amount ₹35,000).
- The live Courses page lists 20 public courses. All 20 title/fee pairs in `lib/content.ts` match the current catalogue snapshot reviewed in this session.
- The live homepage still exposes zero-value counters and unrelated gambling/promotion links in the footer. Neither is copied into the rebuild.
- The live Contact FAQ still claims course completion certification with “100% job assistance” and “24/7 lab access”. These claims remain excluded from the rebuilt FAQ until AROUSH confirms the exact terms in writing.
- The live Contact page publishes two office addresses and a phone/email contact. The linked map pins are retained as source URLs, but the registered-office address link and embedded map coordinates differ slightly; owner confirmation is required before launch.
- The live About page continues to list Abdul Aleem Khan, Tajuddin and Mohammed Khalid with their published role titles. Trainer qualifications and prior-company experience claims remain subject to approval before reuse.
- The homepage exposes three certificate images, but their contents and reuse permissions have not been verified. They remain excluded.
- The homepage contains a newsletter subscription block, but the public crawl does not establish a verified subscription destination, consent handling or data-retention policy. It is not reproduced in the new site.

## Code changes

- Added Schema.org `Organization` structured data to the root layout using the legal name, public brand, canonical website, published logo URL, public email and phone, LinkedIn destination, and both published office addresses.
- Added Schema.org `WebSite` structured data to the root layout.
- Added Schema.org `Course` and `BreadcrumbList` structured data to each generated course-detail page.
- Course structured data deliberately excludes prices, offers, reviews, aggregate ratings, durations and certification claims because those items are either changeable or not sufficiently verified for structured commercial claims.
- Extended `scripts/validate-content.mjs` to require Organization, WebSite, Course and BreadcrumbList structured data and to reject AggregateRating/Offer markup on course pages.

## Validation performed

- `npm run validate:content`: passed.
- `node --check next.config.mjs`: passed.
- `node --check scripts/validate-content.mjs`: passed.
- ZIP/package source inspection: passed.
- Full Next.js production build and browser QA: not run; the project has no installed dependencies in this environment and the previous install attempts failed on package-registry DNS (`EAI_AGAIN`).

## Remaining owner / hosting decisions

1. Confirm current course fees, schedules, availability, delivery format and payment terms before launch.
2. Confirm the registered-office map pin: the address link and embedded map use slightly different coordinates.
3. Approve the Fortinet syllabus; the old page contains mixed-provider material and is not reproduced.
4. Confirm whether certification, job assistance, 24/7 lab access and trainer experience claims are accurate and authorized.
5. Approve local reuse of the logo, team portraits and ten training photos; they currently reference the old WordPress media host.
6. Inspect and approve the three homepage certificate images before publishing any certificate section.
7. Confirm the intended newsletter provider, consent wording and privacy/retention process before implementing subscriptions.
8. Have the hosting administrator investigate the unrelated footer links in the current WordPress installation before migration.
9. Confirm the preferred enquiry destination and privacy/consent wording before implementing server-side lead storage.

## Next technical steps

1. Install dependencies in the user's GitHub Codespace.
2. Run `npm run validate:content`, `npm run typecheck`, `npm run lint` and `npm run build`.
3. Test all 28 public routes, 23 legacy redirects and mobile-menu keyboard interactions in a real browser.
4. Validate JSON-LD with Google's Rich Results Test / Schema Markup Validator after preview deployment.
5. Migrate approved media into local assets and test image loading without the WordPress host.
6. Configure a preview deployment; do not replace the production domain until content, contact workflow and WordPress security issues are resolved.

No GitHub push, WordPress modification, DNS change or production deployment was performed in this session.
