# Live AROUSH source review — Session 38

Date: 7 November 2026

## Pages reopened

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Courses: https://aroushtech.in/courses/
- Contact: https://aroushtech.in/contact-us/
- CCNA: https://aroushtech.in/ccna/
- AI & ML: https://aroushtech.in/ai-ml/
- Agentic AI with LangGraph and LangChain: https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/

## Confirmed public details

- Homepage continues to advertise 20+ job-ready courses and a free-demo message, with six course-category themes: cybersecurity essentials, advanced networking, cloud/DevOps, Agentic AI/ML, Linux/cybersecurity and web application penetration testing.
- Homepage currently features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH with website-listed amounts. These amounts are treated as changeable catalogue references, not final quotations.
- About page continues to publish the company vision/mission and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid, with the role titles as published.
- Gallery page continues to show training and corporate-training photographs. The rebuild retains ten training/gallery image references and does not import the unrelated client-logo collage.
- Contact page continues to publish `taj@aroushtech.in`, `+91 88676 92074`, the corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029, and registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru 560078.
- Contact page also refers to a J.P. Nagar training centre but does not provide a complete visitor-ready training venue address. The rebuild distinguishes the two office addresses from the training venue and advises visitors to confirm the exact session location.
- The public course catalogue continues to contain 20 course entries.
- CCNA and CCNA DevNet still show ₹19,999 in the catalogue and ₹19,000 on individual pages. The rebuild continues to withhold both numeric fees pending owner confirmation.
- AI & ML public course page still publishes a 40-hour training duration. Agentic AI with LangGraph and LangChain publishes course outline topics but no duration.

## Security and content cautions

- The homepage crawl continues to expose unrelated gambling/betting footer links and zero-value counters. The rebuild excludes both. Their presence is a reason for an authorised WordPress/hosting investigation, but it does not prove the entry point or exact compromise mechanism.
- Legacy Contact-page claims about certification, 100% job assistance and 24/7 lab access remain owner-review items. They are not presented as guarantees in the rebuild.
- Agentic AI course pages continue to expose an unverified third-party checkout destination. It remains blocked in the rebuild.
- Service detail copy in the rebuild continues to rely on the supplied AROUSH company profile and brochure where the public website does not provide a full dedicated service page. Availability, platform rights, delivery resources and scope remain subject to written owner confirmation.

## Changes informed by this review

The public source review did not require changing company facts in this session. The main change was to make enquiry routing clearer while retaining the source-backed distinctions between individual learning enquiries and business/campus requirements.
