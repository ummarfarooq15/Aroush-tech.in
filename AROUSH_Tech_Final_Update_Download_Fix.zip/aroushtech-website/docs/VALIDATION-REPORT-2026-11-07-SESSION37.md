# Validation report — Session 37

Date: 7 November 2026

## Passed

`npm run check:offline` completed successfully. It ran 19 dependency-free validation steps:

1. Content and route validation
2. Privacy validation
3. Analytics policy tests
4. Brand validation
5. UX validation
6. Accessibility source validation
7. Internal link validation
8. External-link policy tests
9. External-link security validation
10. Public-claims validation
11. Learning-path validation
12. FAQ content validation
13. FAQ search tests
14. Course sorting tests
15. Course comparison tests
16. Chatbot routing tests (47 cases)
17. JavaScript syntax validation (27 `.mjs` files)
18. TypeScript/TSX syntax parsing (35 files; syntax only)
19. Release-configuration validation

Course comparison-specific assertions passed for add/remove behavior, three-course limit, custom limit, immutable source selection, accessible state, semantic comparison table, fee-conflict guard, local-only behavior and responsive table styling.

Other checks report 20 public course records, 31 public routes, 23 legacy redirects, 10 service areas, 3 team profiles, 10 gallery references, 2 published office addresses and 6 SOC/SIEM learning-path records.

## Blocked / not run successfully

| Check | Result | Reason |
|---|---|---|
| Node.js 24 | Blocked | Runtime is Node.js 22.16.0 |
| npm install / lockfile | Blocked | npm registry DNS failure: `EAI_AGAIN registry.npmjs.org` |
| Full TypeScript typecheck | Blocked | Next.js/React packages and declarations are not installed |
| ESLint | Blocked | `eslint` binary is not installed |
| Next.js production build | Blocked | `next` binary is not installed |
| npm audit | Blocked | No `package-lock.json`; npm reports `ENOLOCK` |
| Android/desktop browser QA | Pending | Requires successful build or staging environment |

The TypeScript syntax parser passed using TypeScript 5.8.3, but semantic typechecking and module resolution did not pass. No production build success is claimed.

## Privacy and change-control

- GA4 Measurement ID remains blank.
- GA4 remains opt-in only; reject and withdrawal controls remain in place.
- Course comparison uses in-memory React state only; no local/session storage, API, database or analytics event was added.
- Contact form remains a local email-draft workflow.
- No CRM or server-side lead database was introduced.
- No live website, WordPress, DNS, GitHub repository, analytics property or deployment was changed.
