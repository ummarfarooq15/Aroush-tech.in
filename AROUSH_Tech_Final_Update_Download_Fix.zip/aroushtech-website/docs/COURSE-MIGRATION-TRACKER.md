# Course-detail migration tracker — updated 7 November 2026

The live Courses page lists 20 public courses. The rebuild carries all 20 names and catalogue descriptions. Eighteen courses have source-backed outline summaries; CEH and Fortinet are represented by owner-review notes because their legacy pages include trainer/course material attributed to other providers. The rebuild withholds numeric fees for CCNA and CCNA DevNet because the catalogue lists ₹19,999 while each individual course page lists ₹19,000. Prerequisites, durations, instructors, schedules and delivery formats remain subject to current owner confirmation before production.

Do not link visitors to these legacy pages from the new site until the WordPress footer/security issue has been investigated. These URLs are retained here as internal migration references only.

| Course | Current source page | Migration status |
|---|---|---|
| CCNA | https://aroushtech.in/ccna/ | Source-backed outline summary migrated. Fee withheld because the Courses catalogue lists ₹19,999 while this detail page lists ₹19,000; owner confirmation required. |
| CCNA DevNet | https://aroushtech.in/ccna-devnet/ | Source-backed outline summary migrated. Fee withheld because the Courses catalogue lists ₹19,999 while this detail page lists ₹19,000; owner confirmation required. |
| CCNP Enterprise | https://aroushtech.in/ccnp-enterprise/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| CCNP Security | https://aroushtech.in/ccnp-security/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| ISE (Identity Services Engine) | https://aroushtech.in/ciscoise/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Ansible & Terraform | https://aroushtech.in/ansible-and-terraform/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Checkpoint Firewall | https://aroushtech.in/checkpoint-firewall/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Fortinet Certified Engineer | https://aroushtech.in/fortinet-certified-engineer/ | Mixed-provider page; third-party-attributed syllabus and delivery copy withheld. Owner-approved AROUSH syllabus required. |
| Palo Alto Firewall Certified Engineer | https://aroushtech.in/palo-alto-firewall/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| CEH (Certified Ethical Hacker) | https://aroushtech.in/ceh-certified-ethical-hacker/ | Legacy page attributes the instructor to UniNets. Syllabus, duration and trainer claims withheld pending AROUSH-approved content. |
| CyberSys | https://aroushtech.in/cybersys/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Linux + Basic Cyber Security | https://aroushtech.in/linux-basic-cyber-security/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Linux + Advanced Cyber Security | https://aroushtech.in/linux-advanced-cyber-security/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| PenTest (Penetration Testing) | https://aroushtech.in/pentester/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Web App Pen Tester | https://aroushtech.in/web-app-pen-tester/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| AWS Solutions Architect Associate | https://aroushtech.in/aws-solutions-architect-associate/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| AI & ML | https://aroushtech.in/ai-ml/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Agentic AI with LangGraph & LangChain | https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| Agentic AI with LangChain & Hugging Face | https://aroushtech.in/agentic-ai-with-langchain-hugging-face/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |
| CCNP Data Center | https://aroushtech.in/ccnp-data-center/ | Source-backed outline summary migrated to local course route; confirm current schedule, delivery and fee before publication. |

## Migration acceptance checklist

- Preserve the source syllabus and prerequisites without silently adding certification guarantees.
- Reconfirm course title, duration, language, delivery mode, instructor, fee and availability with AROUSH before publication.
- Normalize spelling and formatting without changing technical meaning.
- Do not copy payment buttons or third-party checkout links until their destination and ownership are verified.
- Link every migrated course to a first-party enquiry form with the course name prefilled.
