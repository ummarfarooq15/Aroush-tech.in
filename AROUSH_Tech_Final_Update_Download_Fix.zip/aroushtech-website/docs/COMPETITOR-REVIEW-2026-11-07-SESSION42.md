# Competitor UX review — Session 42

Date: 7 November 2026

This review covers public information architecture and interaction patterns only. No competitor prices, discounts, ratings, student counts, testimonials, credentials, placements, schedules or guarantees are copied into AROUSH content.

## Apna College

Official references:
- https://www.apnacollege.in/
- https://www.apnacollege.in/prime

Current programme pages make course families and curriculum topics easy to scan. The transferable pattern is to let a visitor identify a learning goal and then inspect the relevant curriculum. AROUSH keeps its own categories, course records and goal-based learning paths.

## i-Medita

Official references:
- https://www.imedita.com/
- https://www.imedita.com/frequently-asked-questions/

The FAQ structure surfaces practical questions about training locations, schedules, languages and enrolment. AROUSH keeps its own decision-oriented searchable FAQs and directs unanswered or time-sensitive questions to the human team.

## PyNet Labs

Official references:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

The current catalogue uses domain and career-path groupings across networking, automation, security, cloud, data and AI. AROUSH retains its own course categories, keyword search, natural sort, outline-availability filter and comparison tray.

## Applied direction

- Keep AROUSH's published catalogue order as the default.
- Keep search, category, sort and outline availability as separate controls.
- Make the filtered view easier to share on phones by using the native Web Share API where supported.
- Use clipboard copy as a fallback on browsers without native sharing.
- Treat a visitor-cancelled share as a cancellation; do not copy without consent.
- Keep search terms bounded to 100 characters and warn that they appear in the URL.

No competitor marketing claims, commercial terms or guarantees were imported.
