# Session 21 — release workflow and source review

Date: 6 November 2026

## Changes made

- Added `npm run check:offline`. It runs the project's content, privacy, analytics-policy, brand, UX, internal-link, learning-path, chatbot, JavaScript syntax and release-configuration validators without requiring installed Next.js/React dependencies.
- Updated `npm run check` to run the offline suite first, then the full TypeScript typecheck. This makes it clear which checks can run in a lightweight environment and which require the full dependency tree.
- Added `scripts/validate-javascript.mjs` to run Node's syntax checker over project `.mjs` files while skipping generated/dependency directories.
- Added `scripts/validate-release-config.mjs` to check that `package.json` and `.nvmrc` agree on Node 24, the ESLint command is the direct CLI, required validators are registered, and the example GA4 Measurement ID remains blank.
- Changed the lint command from `next lint` to `eslint .`. Next.js 15.5 deprecated the wrapper and recommends invoking the linter directly; this avoids carrying a command that is removed in Next.js 16. Official reference: https://nextjs.org/blog/next-15-5.
- Updated the README, project status, source register and competitor review.

## Current public-source review

- Reopened https://aroushtech.in/ and confirmed the current homepage still advertises 20+ courses and a free demo, with six course discovery categories. Zero-value counters remain excluded from the rebuild.
- Reopened https://aroushtech.in/courses/ and confirmed the public catalogue remains the source for the existing course cards and fee pairs. Commercial amounts still require owner reconfirmation before payment.
- Reopened https://aroushtech.in/contact-us/ and confirmed the published email, phone and two office addresses. The legacy page still states 100% job assistance and 24/7 lab access; these claims remain excluded pending written owner confirmation.
- Reopened Apna College Prime, i-Medita CCNA and PyNet Labs homepage/catalogue pages. Only general UX lessons were retained: audience-oriented discovery, course-specific curriculum/FAQ placement, and searchable technology categories. No competitor marketing claims or commercial data were copied.

## Validation results

All ten dependency-free validators passed:

1. `validate:content`
2. `validate:privacy`
3. `validate:analytics-policy`
4. `validate:brand`
5. `validate:ux`
6. `validate:links`
7. `validate:learning-paths`
8. `validate:chatbot`
9. `validate:javascript`
10. `validate:release-config`

The existing eight project validators all passed. The two new validators also passed: all project `.mjs` files passed `node --check`, and the Node version/lint/validation/GA4 configuration is consistent.

## Blockers

- Node.js 22.16.0 is available in this environment; the project pins Node.js 24.x.
- Local dependencies are not installed. The npm registry previously returned `EAI_AGAIN` resolving `registry.npmjs.org`.
- Full TypeScript typechecking, ESLint, Next.js production build and `npm audit` could not be completed here. The project has no package lockfile yet, so a reproducible dependency audit remains unavailable.
- Real Android and desktop browser QA remains pending a successful staging build.
- Owner review is still needed for legacy claims, course fee freshness, team biography details, training venue, image reuse rights and GA4 setup/legal review.

## Safety and deployment status

- GA4 Measurement ID remains blank; analytics remains opt-in only and disabled by default.
- No server-side lead database or CRM was added.
- Phone details remain voluntary in the enquiry flow.
- No GitHub repository, live WordPress site, DNS, hosting or production deployment was changed.
