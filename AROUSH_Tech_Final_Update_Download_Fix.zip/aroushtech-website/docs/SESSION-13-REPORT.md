# Session 13 — Privacy controls and visitor-insight safeguards

Date: 6 November 2026

## Implemented

- Reworked the optional GA4 consent component so a valid Measurement ID is required before any analytics script can load.
- Kept the `.env.example` Measurement ID blank. This project package has no configured GA4 Measurement ID, GA4 property or owner credentials.
- Added explicit Allow analytics and Reject actions. Analytics loads only after an explicit opt-in.
- Added a persistent Privacy settings control. Reopening settings withdraws the current opt-in and disables collection until the visitor chooses again.
- Added a GA disable flag, consent update and best-effort removal of GA cookies set on this site when a visitor rejects or withdraws consent after previously accepting.
- Disabled Google Signals and advertising personalisation in the GA4 configuration. Added manual initial and client-side route pageviews while stripping query strings from analytics page URLs; owner setup notes require disabling GA4's automatic browser-history page-change event to avoid duplicates. No user ID, phone number, name, email address or enquiry message is sent to analytics by this code.
- Expanded `/privacy` to identify Google Analytics 4 and Google LLC, explain approximate geography and pseudonymous event processing, describe opt-in/reject/withdrawal, and disclose the current unconfigured status dynamically.
- Added owner setup requirements for GA4 property ownership, data retention, enhanced measurement, data processing terms, access control, international processing and privacy/legal review.
- Added a plain-language note beside the optional phone field. It explains that visitors should provide a number only if they want the team to contact them by phone.
- Kept the enquiry form as a visitor-controlled `mailto:` draft. No server-side API, visitor database, lead database or CRM was added.
- Added `scripts/validate-privacy.mjs` and included it in `npm run check`.
- Rechecked competitor UX and refreshed the research notes for Apna College, i-Medita and PyNet Labs without copying competitor claims or statistics.

## Validation performed

- `node scripts/validate-content.mjs`: passed — 10 services, 20 public courses, 19 source outlines plus one owner-review note, six SOC/SIEM learning paths, three team profiles, ten gallery photographs, eight target-industry profiles, two published office addresses, two live-site testimonials, 29 routes and 23 redirects.
- `node scripts/validate-privacy.mjs`: passed — opt-in-only GA4, blank Measurement ID by default, reject and withdrawal support, persistent settings, Google Signals/ad personalisation disabled, voluntary phone field and no server-side lead/CRM integration.
- Full TypeScript typecheck, Next.js build, ESLint, npm audit and browser/device testing remain pending because dependencies are not installed, the current environment is Node.js 22.16.0 rather than the required Node.js 24.x, and package-registry access previously failed. The source checks do not substitute for those release gates.

## Owner actions before analytics activation

1. Supply a GA4 Measurement ID from an AROUSH-owned property and configure it only in the intended staging/hosting environment.
2. Set the shortest suitable GA4 user-level retention period, review event collection and keep Google Signals/advertising features disabled.
3. Confirm the privacy contact, email-enquiry retention, data deletion process and the owner responsible for the GA4 property.
4. Obtain legal review of the privacy notice and consent flow against the requirements in force on launch date.
5. Verify no GA network request occurs before opt-in; test allow, reject, withdrawal, re-acceptance and the persistent settings control in a staging browser.

No GitHub repository, live website, WordPress, DNS or production deployment was changed.
