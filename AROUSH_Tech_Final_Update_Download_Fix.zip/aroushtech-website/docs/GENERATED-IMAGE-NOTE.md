# Generated website image

- File: `public/images/aroush-cybersecurity-training.webp`
- Use: homepage hero visual.
- Created specifically for the AROUSH website refresh on 6 November 2026.
- Subject: illustrative modern cybersecurity training room with an instructor and learners reviewing security dashboards.
- Format: WebP, 1536 × 1024 pixels.
- Optimized file size: approximately 110 KB.
- The image is illustrative, not a photograph of AROUSH staff, premises, students or a real training session. The homepage alt text says so.
- Do not use it as evidence of a real facility, class size, lab inventory or service capability.
