# Competitor UX review — Session 39

Date: 7 November 2026

This is a review of public interface patterns only. No competitor claims, commercial details, testimonials, ratings, schedules, credentials, placement figures or guarantees are copied into AROUSH content.

## Apna College

Official reference: https://www.apnacollege.in/prime

The current Prime page separates engineering students, working professionals and non-CS learners, then presents a scannable AI/ML curriculum. The useful pattern is audience-aware entry points and clear curriculum grouping. AROUSH already uses distinct learner and business/institution enquiry routes and course-specific pages. Do not import Apna College's eligibility claims, project outcomes, discounts, batch dates or programme promises.

## i-Medita

Official reference: https://www.imedita.com/frequently-asked-questions/

The FAQ page exposes a broad subject/course taxonomy and trainer/contact context. The useful pattern is making practical questions and human contact discoverable rather than forcing visitors through a single generic sales form. AROUSH's grouped searchable FAQs and three enquiry paths address this without copying i-Medita's fees, voucher offers, credentials, trainer profiles or availability claims.

## PyNet Labs

Official reference: https://www.pynetlabs.com/courses/

The course catalogue exposes subject filters, career-path groupings, sort controls and a fallback list of course links. The useful pattern is layered discovery with more than one way to browse. AROUSH's course search, category filters, natural sorting, learning-path collections and browser-local comparison follow the same broad usability principle without copying catalogue size, ratings, reviews, pricing or placement statistics.

## Applied direction

Session 39 concentrated on enquiry-form reliability rather than adding another discovery widget. It fixed query-driven route synchronisation so learner/business/general cards stay aligned with the selected form path, and hardened local email-draft formatting. Existing course search, filtering, sorting, comparison, FAQ search and human handoff remain the applied UX features.
