# AROUSH website rebuild — source register

Review date: **7 November 2026** (latest official-page recheck recorded in `LIVE-SOURCE-REVIEW-2026-11-07-SESSION44.md`)

The live public website is the primary source for information it currently publishes. The supplied 2026 AROUSH company profile and brochure are supporting sources for expanded service, corporate-training and SOC/SIEM information. If two sources conflict, do not silently choose a version; flag the difference for owner approval.

## Public website sources

| Source page | Used for |
|---|---|
| https://aroushtech.in/ | Current homepage positioning, free-demo message, featured courses, promotional amounts, testimonials and instructor introduction. |
| https://aroushtech.in/aboutus/ | Published mission, vision and the three team names and role titles. |
| https://aroushtech.in/courses/ | The 20-course catalogue, descriptions and published previous/current fee pairs. |
| https://aroushtech.in/gallery/ | Ten training/learner photographs and the corporate-training gallery context. The separate client-logo collage is excluded. |
| https://aroushtech.in/contact-us/ | Public email, phone, corporate and registered office addresses, map links and published FAQ wording. |

The homepage, About, Courses, Gallery and Contact pages were re-opened on 6 November 2026. The current root homepage still displays zero-value counters and unrelated promotional footer links; neither is copied into the rebuild. The current Contact page still publishes certification, 100% job-assistance and 24/7 lab-access wording; those claims remain excluded pending written owner confirmation.
| https://aroushtech.in/ai-ml/ | AI & ML course duration (40 hours), seven-module outline, instructor and course-page fee. |
| https://aroushtech.in/ccna/ | CCNA course description, prerequisites, learning outcomes, devices, tools and curriculum. |
| https://aroushtech.in/ciscoise/ | Cisco ISE course outline, prerequisites and published delivery notes. |
| https://aroushtech.in/fortinet-certified-engineer/ | Catalogue identity only. Long-form detail is withheld because the legacy page includes content attributed to I-Medita. |

The individual source URL for each migrated course is stored in `lib/course-details.ts`.

## Supporting company documents

- The 2026 AROUSH company profile supports the expanded service portfolio, team/leadership detail and SOC/SIEM learning paths.
- The 2026 AROUSH brochure supports the corporate-training, curriculum/lab-guide and train-the-trainer content.
- These documents do not override the live public website for contact details or current catalogue amounts. Conflicts are listed in `OWNER-APPROVAL-CHECKLIST.md`.

## Source decisions and safeguards

- The course catalogue currently has 20 entries. All 20 title and fee pairs in `lib/content.ts` were checked against the public catalogue during this review.
- The homepage featured course amounts and catalogue amounts are changeable commercial information. Reconfirm them before publishing a campaign or accepting payment.
- The main homepage and About page use “Tajuddin”; the alternate `/home/` page crawl uses “Taluqdar”. The rebuild follows the root homepage/About spelling and leaves the discrepancy for owner confirmation.
- The gallery has ten training/learner photographs plus a separate collage of third-party company logos. The ten photographs are represented; the logo collage is excluded to avoid implying unverified client relationships.
- The homepage certificate images are not reproduced because their contents and reuse approval were not verified.
- The current Contact FAQ contains certification, “100% job assistance” and “24/7 lab access” claims. These are not repeated in the rebuild until AROUSH confirms the exact current terms in writing.
- The old WordPress footer exposed unrelated promotional links. This observation does not prove the site is compromised; a hosting administrator must investigate before migration.

## Company-profile details held for approval

The supplied 2026 company profile lists additional education and experience details for the three team members: Abdul Aleem Khan (B.E. Electronics & Communication Engineering; 35+ years), Tajuddin (MCA; 20+ years) and Mohammed Khalid (B.Sc. Computer Science; 15 years). These details are not currently published in the rebuild; obtain owner confirmation before adding personal qualifications or experience claims.

The profile also lists a JP Nagar/SMS Layout company address that differs from the two addresses on the live Contact page. The rebuild follows the current live Contact page and leaves the profile address as an owner-confirmation item.

The live About page lists Tajuddin as “Technical Head Networking & Cyber Security”; the 2026 company profile lists him as “Director & Vertical Head Cyber Security”. The rebuild currently uses the live website title. Confirm the approved public title before launch.

The Contact page describes a physical training center in Bengaluru (J.P. Nagar) but does not establish a complete visitor address. The rebuild explains that visitors should confirm the exact venue and distinguishes it from the two office addresses.

## Session 20 source recheck — 6 November 2026

The following public pages were re-opened during the latest maintenance pass:

- Homepage: https://aroushtech.in/ — 20+ course message, free-demo message, six course families, three featured courses, two testimonials and instructor introduction. Zero-value counters and unrelated third-party promotional footer links remain excluded from the rebuild.
- About: https://aroushtech.in/aboutus/ — current mission/vision wording and three published team names/role titles. Zero-value counters remain excluded.
- Courses: https://aroushtech.in/courses/ — 20 course entries and current displayed fee pairs; amounts remain subject to owner reconfirmation.
- Gallery: https://aroushtech.in/gallery/ — training and corporate-training photographs/context; third-party client-logo collage remains excluded pending approval.
- Contact: https://aroushtech.in/contact-us/ — public email, phone, two office addresses and FAQs. Certification, 100% job-assistance and 24/7 lab-access claims remain owner-review items.

Competitor pages re-opened for UX-only comparison: Apna College homepage/Prime, i-Medita homepage/Cyber Security Bootcamp, and PyNet Labs course catalogue. See `docs/COMPETITOR-REVIEW-2026-11-06.md` for the patterns retained and the claims deliberately not copied.


## Session 21 source recheck — 6 November 2026

The public source pages were reopened for this maintenance pass:

- Homepage: https://aroushtech.in/ — still advertises 20+ job-ready courses and a free demo, and presents six discovery categories: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing. The homepage still contains zero-value counters; these remain excluded.
- Courses: https://aroushtech.in/courses/ — the public catalogue still exposes the existing course cards and displayed fee pairs. The rebuild retains the previously audited 20 catalogue entries; all amounts remain subject to owner reconfirmation before payment.
- Contact: https://aroushtech.in/contact-us/ — currently publishes `taj@aroushtech.in`, `+91 88676 92074`, the corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029, and the registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru 560078. The page also continues to publish 100% job-assistance and 24/7 lab-access statements; the rebuild does not repeat those claims pending written owner confirmation.

Competitor pages reopened for UX-only review:

- Apna College Prime: https://www.apnacollege.in/prime — separates information for engineering students, working professionals and non-CS learners, then exposes curriculum sections. The transferable lesson is to help visitors find a relevant starting point; no programme claims, durations, schedules or outcomes were copied.
- i-Medita CCNA course: https://www.imedita.com/courses/ccna-training/ — places course curriculum, trainer information, FAQs and demo enquiry on the course page. AROUSH keeps its own course detail and contact paths; no i-Medita credentials, fees, partner counts, ratings or placement statements were copied.
- PyNet Labs homepage and catalogue: https://www.pynetlabs.com/ and https://www.pynetlabs.com/courses/ — provide searchable course discovery and technology/category groupings. AROUSH retains its own search, filters and four learning-goal collections; no third-party course counts, ratings, prices, guarantees or testimonials were copied.



## Session 22 live-source security note — 6 November 2026

A fresh crawl of `https://aroushtech.in/` exposed 16 unrelated gambling/betting footer anchors to 16 unrelated external domains. The rebuild does not copy these links. This is consistent with possible SEO-spam injection but does not prove the WordPress database/server entry point or full compromise. The authorised owner/hosting administrator must investigate before migration. See `WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md` and `SECURITY-REVIEW.md`.

## Session 24 source recheck — 6 November 2026

Reopened the current public pages:

- Homepage: https://aroushtech.in/ — 20+ course/free-demo positioning, six course families, three featured course cards, zero-value counters and the 16 unrelated footer destinations remain visible. Only the course positioning and legitimate AROUSH content are used; zero counters and unrelated footer destinations are excluded.
- About: https://aroushtech.in/aboutus/ — vision, mission and three public team names/role titles remain visible.
- Courses: https://aroushtech.in/courses/ — 20 course cards and fee pairs remain visible. The rebuild's catalogue title/fee snapshot remains aligned with this page; amounts are not represented as final quotations.
- Gallery: https://aroushtech.in/gallery/ — training photographs remain visible; client-logo and placement-related material remains excluded pending owner confirmation.
- Contact: https://aroushtech.in/contact-us/ — `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and the online/offline/hybrid training FAQ remain visible. Certification, 100% job-assistance and 24/7 lab-access statements remain owner-approval items.

Competitor UX references reopened:

- Apna College Prime: https://www.apnacollege.in/prime — audience-specific entry points and structured curriculum presentation.
- i-Medita homepage and CCIE Bootcamp: https://www.imedita.com/ and https://www.imedita.com/ccie-bootcamp/ — course/trainer detail and demo enquiry paths.
- PyNet Labs course catalogue: https://www.pynetlabs.com/courses/ — technology categories, search and career-path navigation.

These competitor pages are UX references only. No third-party claims, prices, schedules, credentials, testimonials, ratings or guarantees are imported.

The homepage's 16 unrelated gambling/betting footer links remain visible in the public crawl. This is a public-page observation only and does not prove the WordPress database/server entry point or full compromise. The authorised owner/hosting administrator must investigate before migration.

## Session 26 source recheck — 7 November 2026

Reopened the official AROUSH homepage, About, Courses, Gallery and Contact pages. The homepage still shows the 20+ course/free-demo message, six discovery families, three featured courses, two learner testimonials, zero-value counters and 16 unrelated gambling/betting footer links. The rebuild keeps source-backed course/demo/testimonial content but excludes the counters and suspicious links. The Courses page still lists 20 course cards and fee pairs. The About page still lists Abdul Aleem Khan, Tajuddin and Mohammed Khalid; the rebuild now reflects Mohammed Khalid's published role as “Technical Head for Networking Security”. The Gallery includes ten training/learner photographs and a separate third-party client-logo collage, which remains excluded. Contact still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses, a J.P. Nagar training-centre reference and online/offline/hybrid formats. Its certification, 100% job-assistance and 24/7 lab-access claims remain owner-review items.

Competitor UX recheck: Apna College Prime curriculum, i-Medita FAQ/CCNA pages, and PyNet Labs course catalogue/contact pages. Retain only transferable information-architecture patterns; do not copy competitor claims, prices, ratings, testimonials, credentials, schedules or guarantees. Full notes are in `COMPETITOR-REVIEW-2026-11-06.md` and `LIVE-SOURCE-REVIEW-2026-11-07.md`.

## Session 27 source recheck — 7 November 2026

Reopened the current public AROUSH homepage, About, Courses, Gallery and Contact pages, plus the individual CCNA and AI & ML course pages:

- Homepage: https://aroushtech.in/ — still advertises 20+ job-ready courses and a free demo, six discovery families, featured courses and two testimonials. Sixteen unrelated gambling/betting footer links remain visible; all are excluded from the rebuild and documented for authorised WordPress/hosting investigation.
- About: https://aroushtech.in/aboutus/ — mission, vision and three public team names/roles remain visible.
- Courses: https://aroushtech.in/courses/ — 20 course cards and public fee pairs remain visible; all fees are labelled as catalogue references and require confirmation before payment.
- Gallery: https://aroushtech.in/gallery/ — training photographs remain available; third-party logo collage remains excluded.
- Contact: https://aroushtech.in/contact-us/ — public email, phone, corporate/registered office addresses and a J.P. Nagar training-centre reference remain visible. The published certification, 100% job-assistance and 24/7 lab-access claims remain excluded pending written owner approval.
- CCNA: https://aroushtech.in/ccna/ — course description, prerequisites, outcomes, tools and curriculum reviewed.
- AI & ML: https://aroushtech.in/ai-ml/ — source page states 40 hours of live and intensive training and publishes a seven-module outline. The rebuilt chatbot now answers course-content and duration questions with this qualification.

The course catalogue now exposes whether source-published outline topics are available. Nineteen course records have outline topics; the Fortinet long-form content remains withheld because the live detail page includes material attributed to another provider. No replacement syllabus has been invented.

Competitor UX references refreshed: Apna College home/Prime/Delta pages; i-Medita homepage/FAQ/CCNA course page; PyNet Labs homepage/course catalogue. See `COMPETITOR-REVIEW-2026-11-07.md`. UX patterns only; competitor claims, prices, figures, ratings, testimonials, schedules, credentials and guarantees were not copied.


## Session 28 source recheck — 7 November 2026

Reopened the official homepage, About, Courses, Gallery, Contact, AI & ML, CCNA, both Agentic AI course pages and Fortinet Certified Engineer. The root homepage still shows 20+ courses, a free-demo message, six course families, featured courses, two testimonials, zero-value counters and 16 unrelated gambling/betting footer links. The catalogue still lists 20 course cards and fee pairs. About retains the three public team profiles; Contact retains the published email, phone and two Bengaluru office addresses plus an incomplete J.P. Nagar training-centre reference.

The AI & ML page publishes a 40-hour duration and seven modules. The Agentic AI with LangGraph and LangChain page publishes a 15-topic outline; the LangChain and Hugging Face page publishes a 46-item outline. Neither Agentic AI page publishes a duration, so the rebuild does not infer one. The chatbot now answers outline questions for both courses and links to their local detail pages.

The Fortinet detail page explicitly attributes the training to I-Medita in its long-form copy. That content remains withheld from the rebuild; only the AROUSH catalogue listing is retained pending an approved AROUSH syllabus. The reviewed AI & ML and Agentic AI detail pages also expose a “Buy Course” link to `demosites.royal-elementor-addons.com`; it was not opened or copied and requires owner verification before any new checkout link is used.

Fresh competitor UX review: Apna College Prime curriculum sections, i-Medita FAQ/course detail and PyNet Labs technology/category catalogue plus contact guidance. Only UX patterns were applied. See `COMPETITOR-REVIEW-2026-11-07.md` and `LIVE-SOURCE-REVIEW-2026-11-07-SESSION28.md`.

## Session 29 source review — 7 November 2026

Reopened the official homepage, About, Courses, Gallery, Contact and both Agentic AI course pages. The homepage still shows the 20+ course/free-demo message, six course discovery families, featured courses, two testimonials, instructor introduction, zero-value counters and 16 unrelated gambling/betting footer links. The rebuild retains source-backed course/demo/testimonial/instructor information and excludes zero counters and unrelated footer links. Courses still lists 20 course cards and fee pairs. About still lists Abdul Aleem Khan, Tajuddin and Mohammed Khalid. Gallery still contains training photographs and a separate image/logo area; the rebuild retains ten selected training/learner photographs and excludes the client-logo collage. Contact still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and online/offline/hybrid FAQ wording. Its certification, 100% job-assistance and 24/7 lab-access statements remain owner-approval items.

Both reviewed Agentic AI course-detail pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`. The destination was not opened or verified. The rebuild does not link to it, does not implement online checkout and directs visitors to confirm payment instructions through AROUSH's published contact channels. The external-link policy now explicitly blocks this host and has a regression test.

Competitor UX refresh: Apna College Prime curriculum; i-Medita FAQ and CCNA pages; PyNet Labs course catalogue and contact page. Only information hierarchy, curriculum grouping, course filters and visible human-help patterns were retained. No competitor metrics, prices, testimonials, credentials, schedules or guarantees were copied. See `COMPETITOR-REVIEW-2026-11-07.md`.


## Session 30 source review — 7 November 2026

Reopened the official homepage and course catalogue, Contact page, CCNA, CCNA DevNet, ISE, CEH, AI & ML, both Agentic AI courses, AWS Solutions Architect Associate, CyberSys, PenTest, Linux + Basic Cyber Security, Linux + Advanced Cyber Security, Web App Pen Tester, CCNP Data Center, Ansible & Terraform, CCNP Enterprise, Checkpoint Firewall, CCNP Security, Fortinet and Palo Alto course pages. The homepage continues to show 20+ courses, a free-demo message, six course families, featured course prices, two testimonials, zero-value counters and 16 unrelated gambling/betting footer links. The rebuild continues to exclude zero counters and unrelated footer links.

The live Courses catalogue lists CCNA and CCNA DevNet at ₹19,999, while the individual CCNA and CCNA DevNet detail pages list ₹19,000. The rebuild now withholds numeric fees for both until AROUSH confirms the correct current amount. The other catalogue amounts remain visibly labelled as website-listed references and require confirmation before payment.

The live CEH detail page says the course is conducted by an instructor of UniNets and includes provider-specific instructor/course copy. The rebuild now withholds the CEH syllabus, duration and trainer claims pending an AROUSH-approved version. This joins the existing Fortinet hold for I-Medita-attributed content. Eighteen course outlines remain source-backed; two courses have provider-attribution review notes.

Multiple reviewed live course pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`, including AI & ML, both Agentic AI courses, CCNA, CCNA DevNet, ISE, CEH, CyberSys, PenTest, both Linux security courses, Web App Pen Tester, CCNP Data Center, Ansible & Terraform, CCNP Enterprise, Checkpoint Firewall, CCNP Security, Fortinet, AWS and Palo Alto. The destination was not opened or used. The rebuild blocks the host and has no online checkout. Owner verification of merchant ownership, processor, privacy/data handling, refund terms and authorisation remains required.

The live Contact page publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a J.P. Nagar training-centre reference. The rebuild now uses Google Maps address-search URLs built from the two published street addresses instead of unverified latitude/longitude pins. A visible note clarifies that the office addresses do not confirm the training venue or precise entrance.

Competitor UX recheck: Apna College Prime curriculum hierarchy, i-Medita FAQ/course detail and PyNet Labs searchable technology/category catalogue. Retain only curriculum grouping, course discovery and visible human enquiry patterns. Do not copy competitor pricing, statistics, ratings, testimonials, credentials, schedules or guarantees.


## Session 31 source recheck — 7 November 2026

Reopened the current public homepage, About, Gallery, Courses and Contact pages:

- Homepage: https://aroushtech.in/ — the page still advertises 20+ courses and a free demo, lists six course discovery families, displays featured course prices and two testimonials, and includes an instructor introduction. It also renders zero-value counters (0k+ course students, 0+ courses, 0% satisfaction) and 16 unrelated gambling/betting footer links. The rebuild does not reproduce the zero-value counters or unrelated links. The live footer links remain an authorised WordPress/hosting investigation item; their presence does not establish the precise cause or full compromise.
- About: https://aroushtech.in/aboutus/ — mission and vision plus three public team profiles remain visible: Abdul Aleem Khan, Tajuddin and Mohammed Khalid. Mohammed Khalid's live role wording is “Technical Head For Networking Security”; preserve that source wording in content validation.
- Courses: https://aroushtech.in/courses/ — 20 public course cards and catalogue fee pairs remain visible. The two CCNA-related individual-page fee conflicts remain withheld in the rebuild. CEH and Fortinet long-form syllabus attribution review notes remain in place.
- Gallery: https://aroushtech.in/gallery/ — training and corporate-training photographs remain visible. The third-party client-logo collage is not imported into the rebuild.
- Contact: https://aroushtech.in/contact-us/ — published email, phone and two Bengaluru office addresses remain visible. The page separately refers to a J.P. Nagar training centre. Confirm the exact venue before travel. Certification, 100% job-assistance and 24/7 lab-access statements remain owner-review items rather than rebuild guarantees.

The homepage's current counters and unrelated external footer links are excluded from the rebuild. No charts or analytics dashboards are shown without approved real data.


## Session 32 source recheck — 7 November 2026

Reopened the public homepage, About, Courses, Gallery, Contact, CCNA, CCNA DevNet and AI & ML pages. The homepage still advertises 20+ courses and a free demo, six course families, three featured courses, two testimonials and an instructor introduction. It still shows three zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes them.

The public About page still lists Abdul Aleem Khan, Tajuddin and Mohammed Khalid with the published role wording. The catalogue still lists 20 course entries. CCNA and CCNA DevNet catalogue amounts still differ from their individual detail pages; the rebuild withholds both numeric fees. The AI & ML page still publishes a 40-hour duration and seven-module outline.

The Gallery remains focused on training and corporate-training photographs. Contact still publishes `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses; the J.P. Nagar training-centre reference still lacks a complete visitor-ready address.

The public navigation exposes an “IT Consultation” label but does not provide a complete public service detail page for the rebuild's ten-service portfolio. Expanded service copy remains grounded in the supplied AROUSH company profile and brochure, and service availability must be confirmed by the owner. The live course pages still expose an unverified third-party checkout host; the rebuild blocks it.


## Session 33 source recheck — 7 November 2026

Reopened the official AROUSH homepage, About (`/aboutus/`), Courses, Gallery, Contact, AI & ML and both Agentic AI course pages. The homepage still advertises 20+ courses and a free demo and lists six course families; it also still shows three zero-value counters and 16 unrelated gambling/betting footer destinations. The About page still publishes the vision, mission and three team names/role titles. The Courses page currently lists 20 course entries; CCNA and CCNA DevNet catalogue/detail fees still conflict. The Contact page still publishes online/offline/hybrid training formats and a J.P. Nagar training-centre reference without a complete visitor address. Its certification/job-assistance/24×7 lab claims remain owner-review items. AI & ML still publishes a 40-hour duration; the two Agentic AI pages publish outlines without a duration.

Current references: https://aroushtech.in/ ; https://aroushtech.in/aboutus/ ; https://aroushtech.in/courses/ ; https://aroushtech.in/gallery/ ; https://aroushtech.in/contact-us/ ; https://aroushtech.in/ai-ml/ ; https://aroushtech.in/agentic-ai-with-langchain-hugging-face/ ; https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/ . Full detail and caveats are recorded in `LIVE-SOURCE-REVIEW-2026-11-07-SESSION33.md`.

Competitor UX review refreshed against Apna College Prime, i-Medita homepage/FAQ/course catalogue and PyNet Labs homepage/course catalogue. Applied audience-aware entry points, grouped FAQ discovery and searchable course/category patterns only. No competitor pricing, ratings, testimonials, schedules, credentials, student counts, placement statistics or guarantees were copied. See `COMPETITOR-REVIEW-2026-11-07-SESSION33.md`.


The Session 34 recheck again confirmed the 20-course catalogue and public About/Contact/Gallery content. It also reconfirmed the CCNA and CCNA DevNet fee discrepancy (catalogue ₹19,999; individual pages ₹19,000), the unverified third-party Agentic AI checkout host, the zero-value homepage counters and the unrelated gambling/betting footer links. See `LIVE-SOURCE-REVIEW-2026-11-07-SESSION34.md`.

## Session 35 source recheck — 7 November 2026

Reopened the current homepage, Courses, About, Contact, Gallery, AI & ML, CCNA and CCNA DevNet pages. The homepage still advertises 20+ courses and a free demo, six course families, and featured course prices: Agentic AI with LangChain & Hugging Face ₹35,000, CCNP Security ₹45,000 and CEH ₹25,000. These featured prices match the current catalogue snapshot. The catalogue lists 20 courses; CCNA and CCNA DevNet remain the only two fee conflicts (catalogue ₹19,999 vs individual page ₹19,000) and their numeric prices remain withheld in the rebuild. The other 18 catalogue fee pairs are retained as website-listed references requiring confirmation before payment.

The homepage still exposes zero-value counters and 16 unrelated gambling/betting footer links; both remain excluded from the rebuild. About still lists three public team profiles. Contact still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a J.P. Nagar training-centre reference without a complete visitor-ready address. The Contact FAQ's certification, 100% job-assistance and 24/7 lab-access statements remain owner approval items. Full details: `LIVE-SOURCE-REVIEW-2026-11-07-SESSION35.md`.

Competitor UX references refreshed: Apna College Prime, i-Medita FAQ and PyNet Labs course catalogue. A simple A–Z/Z–A course sort was added to the rebuild while preserving AROUSH's source order by default. No competitor claims, prices, ratings, testimonials, credentials, schedules or guarantees were copied. See `COMPETITOR-REVIEW-2026-11-07-SESSION35.md`.


## Session 36 source recheck — 7 November 2026

- Reopened the current homepage: https://aroushtech.in/ — it still advertises 20+ courses, a free-demo message and six course-category themes. The three featured course prices remain visible. The root page also still shows zero-value counters and unrelated gambling/betting footer links; the rebuild excludes both.
- Reopened Contact: https://aroushtech.in/contact-us/ — it currently publishes `taj@aroushtech.in`, `+91 88676 92074`, the corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029, and the registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru 560078. The page continues to make certification, 100% job-assistance and 24/7 lab-access claims; the rebuild does not present these as guarantees pending written owner approval.
- CCNA still has a visible individual-page fee of ₹19,000 while the public catalogue lists ₹19,999. The rebuild keeps the numeric fee withheld.
- The course catalogue still lists 20 course entries. Existing source-backed content and the two fee-conflict safeguards are unchanged in this session.
- Competitor UX pages rechecked: Apna College Prime (audience-specific learner entry points and scannable curriculum), i-Medita FAQ (decision-oriented FAQ topics and human contact paths), and PyNet Labs Courses (large catalogue with technical categories and course grouping). Only these information-discovery patterns inform the rebuild; no competitor commercial content is copied.


## Session 37 source recheck — 7 November 2026

Reopened the official homepage, About (`/aboutus/`), Gallery, Courses, Contact, CCNA, CCNA DevNet and both Agentic AI course detail pages. The homepage still advertises 20+ courses and a free demo, six category themes and featured course amounts. It still displays three zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes both. About still lists the published mission/vision and three team profiles. Gallery still contains training and corporate-training photographs. Contact still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a J.P. Nagar training-centre reference without a complete visitor-ready address.

The catalogue still lists 20 courses. CCNA and CCNA DevNet are listed at ₹19,999 in the catalogue while their individual pages show ₹19,000; the rebuild withholds both numeric fees. Both Agentic AI course pages still link to `demosites.royal-elementor-addons.com` for checkout; the destination remains unverified and blocked. The CEH page publishes a one-month duration and course topics, but provider/instructor attribution needs owner confirmation before the rebuild presents long-form content as AROUSH-authored.

Session 37 adds a browser-local comparison feature for up to three courses. It compares only AROUSH-published category, outline availability, published duration and catalogue fee/confirmation status. It does not store or transmit selection data.

Competitor UX references refreshed: https://www.apnacollege.in/prime ; https://www.imedita.com/frequently-asked-questions/ ; https://www.pynetlabs.com/courses/ . Only course grouping, FAQ discoverability and human-enquiry navigation patterns were retained. See `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION37.md` and `docs/COMPETITOR-REVIEW-2026-11-07-SESSION37.md`.


## Session 38 source recheck — 7 November 2026

Reopened https://aroushtech.in/, https://aroushtech.in/aboutus/, https://aroushtech.in/courses/, https://aroushtech.in/contact-us/, https://aroushtech.in/ccna/, https://aroushtech.in/ai-ml/ and https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/. The homepage continues to advertise 20+ courses, a free-demo message and six course-category themes. About continues to publish the mission/vision and three team profiles. Contact continues to publish the current email, phone and two Bengaluru office addresses, while referring separately to a J.P. Nagar training centre without a complete visitor-ready address. The course catalogue still has 20 entries. CCNA and CCNA DevNet fee conflicts remain unresolved and withheld. The homepage's unrelated gambling/betting footer links and zero-value counters remain excluded from the rebuild.

Competitor UX pages refreshed: https://www.apnacollege.in/, https://www.apnacollege.in/course/delta, https://www.apnacollege.in/course/sigma-batch, https://www.imedita.com/frequently-asked-questions/, https://www.imedita.com/contact/, https://www.pynetlabs.com/ and https://www.pynetlabs.com/courses/. Only curriculum grouping, topic-based FAQ organisation, course discovery and human-enquiry routing patterns were retained. No competitor commercial claims or statistics were copied.

Session 38 adds learner, business/institution and general enquiry paths to the rebuild. Individual course links preselect the learner route; corporate training and service links preselect the business route. The form prepares a local email draft only.


## Session 39 source recheck — 7 November 2026

Reopened the current homepage, About, Courses, Gallery, Contact, CCNA, CCNA DevNet, AI & ML and Agentic AI with LangGraph/LangChain pages. The 20-course catalogue, six homepage category themes, three team profiles, two office addresses and published email/phone remain unchanged. The homepage still shows three zero-value counters and 16 unrelated gambling/betting footer links; both remain excluded from the rebuild. CCNA and CCNA DevNet catalogue/detail fees still conflict (₹19,999 vs ₹19,000). The Agentic AI checkout destination remains unverified. Contact-page certification, job-assistance and 24/7 lab claims remain owner-review items.

Competitor UX review refreshed against Apna College Prime, i-Medita FAQ and PyNet Labs Courses. Only audience-specific entry points, topic-grouped FAQs, course category filters, career-path grouping and sorting patterns inform the AROUSH experience. See `LIVE-SOURCE-REVIEW-2026-11-07-SESSION39.md` and `COMPETITOR-REVIEW-2026-11-07-SESSION39.md`.


## Session 40 source recheck — 7 November 2026

Reopened the official homepage, About, Courses, Gallery, Contact, CCNA and CCNA DevNet pages. The homepage still advertises 20+ courses, a free-demo message and six category themes. The course catalogue still lists 20 entries. CCNA and CCNA DevNet remain fee conflicts (catalogue ₹19,999; individual pages ₹19,000) and their numeric fees remain withheld. The About page still publishes the vision/mission and three team role titles. Contact still publishes the current email, phone and two Bengaluru office addresses and separately references a J.P. Nagar training centre without a complete visitor-ready address.

The live gallery exposes ten training/corporate-training photographs plus a separate collage of third-party logos. The rebuild retains the ten training photographs and excludes the logo collage to avoid implying a verified current customer/partner list. The homepage's zero-value counters and 16 unrelated gambling/betting footer links remain excluded and require an authorised WordPress/hosting investigation. Contact-page certification, job-assistance and 24/7 lab claims remain owner-review items.

The catalogue now includes an outline-availability filter based on the 18 migrated source-backed outlines; CEH and Fortinet remain flagged for provider-attribution review and are grouped under "Ask AROUSH to confirm". Current competitor references: https://www.apnacollege.in/ ; https://www.imedita.com/frequently-asked-questions/ ; https://www.pynetlabs.com/courses/ . Only course-family hierarchy, decision-stage FAQs and layered catalogue discovery patterns were retained. See `LIVE-SOURCE-REVIEW-2026-11-07-SESSION40.md` and `COMPETITOR-REVIEW-2026-11-07-SESSION40.md`.


## Session 41 source recheck — 7 November 2026

- Homepage: https://aroushtech.in/ — still advertises 20+ courses and a free demo, presents six course families and features three course offers. The public crawl still exposes three zero-value counters and 16 unrelated gambling/betting footer destinations; the rebuild excludes them.
- About: https://aroushtech.in/aboutus/ — current vision/mission and three published team names/role titles remain visible.
- Courses: https://aroushtech.in/courses/ — 20 catalogue entries remain visible. CCNA and CCNA DevNet show ₹19,999 in the catalogue while their individual pages show ₹19,000; the rebuild continues to withhold both numeric fees.
- Gallery: https://aroushtech.in/gallery/ — training and corporate-training photographs remain visible. Ten training photographs are retained; the separate third-party logo collage remains excluded pending approval.
- Contact: https://aroushtech.in/contact-us/ — current public email, phone and two office addresses remain visible. J.P. Nagar training-centre wording still lacks a complete visitor-ready address. Certification, 100% job-assistance and 24/7 lab-access wording remains owner review.
- Individual fee checks: https://aroushtech.in/ccna/ and https://aroushtech.in/ccna-devnet/ — each individual page displays ₹19,000, conflicting with the catalogue's ₹19,999.

Competitor UX-only references reopened: Apna College Prime (https://www.apnacollege.in/prime), i-Medita FAQ (https://www.imedita.com/frequently-asked-questions/) and PyNet Labs Courses (https://www.pynetlabs.com/courses/). See `COMPETITOR-REVIEW-2026-11-07-SESSION41.md`.


## Session 42 source recheck — 7 November 2026

Reopened the current AROUSH homepage, About and Contact pages. Homepage still advertises 20+ courses and a free demo, presents six course-family themes and features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH offers. The same crawl exposes three zero-value counters and 16 unrelated gambling/betting footer destinations; the rebuild excludes both and the authorised WordPress/hosting investigation remains outstanding. About still lists the published mission/vision and three team roles. Contact still publishes `taj@aroushtech.in`, `+91 88676 92074`, the corporate/registered office addresses and a J.P. Nagar training-centre reference without a complete visitor-ready address. The course catalogue remains at 20 entries; CCNA and CCNA DevNet catalogue/detail fee conflicts remain withheld. Competitor UX references refreshed: https://www.apnacollege.in/prime, https://www.imedita.com/frequently-asked-questions/ and https://www.pynetlabs.com/courses/. Session 42 improves the mobile share path for filtered catalogue URLs and caps search terms at 100 characters. See `LIVE-SOURCE-REVIEW-2026-11-07-SESSION42.md` and `COMPETITOR-REVIEW-2026-11-07-SESSION42.md`.


## Session 43 source recheck — 7 November 2026

Reopened the current root homepage, About, Courses, Gallery, Contact, CCNA and CCNA DevNet pages. The homepage still advertises 20+ courses and a free demo, six course-family themes, and featured offers for Agentic AI with LangChain & Hugging Face (₹35,000), CCNP Security (₹45,000) and CEH (₹25,000). It still exposes three zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes both.

The About page continues to publish the vision/mission and three team profiles. The Courses page still contains 20 entries. CCNA and CCNA DevNet remain the two fee conflicts: catalogue ₹19,999 versus individual pages ₹19,000. The Gallery continues to show training and corporate-training photographs; ten training photographs remain in the rebuild and the separate third-party logo collage remains excluded pending approval. Contact continues to publish `taj@aroushtech.in`, `+91 88676 92074`, the corporate/registered Bengaluru office addresses and an incomplete J.P. Nagar training-centre reference. Certification, 100% job-assistance and 24/7 lab-access wording remains owner review.

Competitor UX-only references reopened: https://www.apnacollege.in/ (course-family entry points and curriculum resources), https://www.imedita.com/frequently-asked-questions/ (practical training FAQ grouping), and https://www.pynetlabs.com/courses/ (technical domain/category catalogue). Session 43 extends AROUSH's shareable catalogue to restore up to three selected courses in a shared comparison URL. No competitor claims, commercial information, statistics or guarantees were copied.


## Session 44 source recheck — 7 November 2026

Reopened the official homepage, About, Courses, Gallery and Contact pages. The homepage still advertises 20+ courses and a free demo, lists six course themes, features Agentic AI with LangChain & Hugging Face (₹35,000), CCNP Security (₹45,000) and CEH (₹25,000), and shows zero-value counters plus 16 unrelated gambling/betting footer destinations. The rebuild excludes the counters and unrelated links.

The current About page still publishes the mission, vision and three team profiles. The Course catalogue lists 20 entries; CCNA and CCNA DevNet remain inconsistent at ₹19,999 in the catalogue versus ₹19,000 on their individual pages, so both amounts remain withheld. Gallery training photographs remain represented without the third-party logo collage. Contact continues to publish `taj@aroushtech.in`, `+91 88676 92074` and the corporate/registered office addresses. The J.P. Nagar training-centre reference remains incomplete as a visitor address. See `LIVE-SOURCE-REVIEW-2026-11-07-SESSION44.md`.

Competitor UX references re-opened: Apna College Prime course page, i-Medita FAQ page and PyNet Labs course catalogue. Only curriculum scanning, decision-stage FAQ grouping and search/category navigation patterns were retained. See `COMPETITOR-REVIEW-2026-11-07-SESSION44.md`.


## Session 45 source recheck — 7 November 2026

- Reopened the live homepage, Contact page and AI & ML course page. The homepage still advertises 20+ courses, a free-demo option and six course themes. Featured amounts remain Agentic AI with LangChain & Hugging Face ₹35,000, CCNP Security ₹45,000 and CEH ₹25,000. Three counters still show zero and 16 unrelated gambling/betting footer links remain visible; both are excluded from the rebuild and require an authorised WordPress/hosting investigation.
- The AI & ML page still states 40 hours of live/intensive training and publishes seven modules across AI/ML, Python, network data, machine learning, predictive AI, language models and generative AI. It lists Mr. Tajuddin, English and ₹45,000; the third-party checkout host remains unapproved. The rebuild already carries the source-backed 40-hour outline.
- Contact still publishes `taj@aroushtech.in`, `+91 88676 92074` and the corporate/registered Bengaluru addresses. The J.P. Nagar training-centre reference remains incomplete. CCNA and CCNA DevNet fee conflicts remain unresolved and withheld.
- Competitor UX pages refreshed: Apna College Prime 3.0 (audience-specific course entry points and curriculum sections), i-Medita FAQ (practical location/schedule/training questions), and PyNet Labs Courses (technical category groups). Only transferable information architecture was used.
- Session 45 adds branded social preview images for the site and individual course routes, generated from approved AROUSH and course catalogue data. No competitor content or unapproved commercial claim was copied.
