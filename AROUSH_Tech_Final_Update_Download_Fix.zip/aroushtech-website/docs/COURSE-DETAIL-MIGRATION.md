# Course detail migration — 6 November 2026

Primary listing source: https://aroushtech.in/courses/

The course catalogue and fee pairs are taken from the current public listing. Where a legacy detail page shows a different fee, the catalogue fee remains the display value and the visitor is told to reconfirm the current amount before payment.

## Local routes and source outline status

| Local course route | Legacy detail source | Migration status |
|---|---|---|
| `/courses/ccna` | https://aroushtech.in/ccna/ | Outline, prerequisites and training notes migrated |
| `/courses/ccna-devnet` | https://aroushtech.in/ccna-devnet/ | Outline migrated |
| `/courses/ccnp-enterprise` | https://aroushtech.in/ccnp-enterprise/ | Outline, prerequisites, duration and delivery notes migrated |
| `/courses/ccnp-security` | https://aroushtech.in/ccnp-security/ | Outline, prerequisites, duration and delivery notes migrated |
| `/courses/ise-identity-services-engine` | https://aroushtech.in/ciscoise/ | Full outline, prerequisites, one-month duration and online-weekend delivery notes migrated |
| `/courses/ansible-terraform` | https://aroushtech.in/ansible-and-terraform/ | Outline migrated |
| `/courses/checkpoint-firewall` | https://aroushtech.in/checkpoint-firewall/ | Outline, duration and delivery notes migrated |
| `/courses/fortinet-certified-engineer` | https://aroushtech.in/fortinet-certified-engineer/ | Detail page contains third-party I-Medita wording; full outline withheld pending owner review |
| `/courses/palo-alto-firewall-certified-engineer` | https://aroushtech.in/palo-alto-firewall/ | Outline, prerequisites and duration migrated |
| `/courses/ceh-certified-ethical-hacker` | https://aroushtech.in/ceh-certified-ethical-hacker/ | Outline, duration and delivery notes migrated |
| `/courses/cybersys` | https://aroushtech.in/cybersys/ | Outline migrated |
| `/courses/linux-basic-cyber-security` | https://aroushtech.in/linux-basic-cyber-security/ | Outline migrated |
| `/courses/linux-advanced-cyber-security` | https://aroushtech.in/linux-advanced-cyber-security/ | Outline migrated |
| `/courses/pentest-penetration-testing` | https://aroushtech.in/pentester/ | Outline migrated |
| `/courses/web-app-pen-tester` | https://aroushtech.in/web-app-pen-tester/ | Outline and stated duration migrated |
| `/courses/aws-solutions-architect-associate` | https://aroushtech.in/aws-solutions-architect-associate/ | Outline migrated |
| `/courses/ai-ml` | https://aroushtech.in/ai-ml/ | Outline and stated duration migrated |
| `/courses/agentic-ai-langgraph-langchain` | https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/ | Outline migrated |
| `/courses/agentic-ai-langchain-hugging-face` | https://aroushtech.in/agentic-ai-with-langchain-hugging-face/ | Outline migrated |
| `/courses/ccnp-data-center` | https://aroushtech.in/ccnp-data-center/ | Outline, prerequisites, duration and delivery notes migrated |

## Important notes

- The source pages are legacy WordPress pages and are not linked directly from the new course cards while the suspicious footer links on the live site are being investigated.
- The new detail pages do not reproduce legacy “Buy Course” links because those links point to a third-party demo-site domain in the current crawl.
- The catalogue fee pair is copied from `/courses/`; a few individual detail pages show different amounts. The new site therefore displays the listing amount with a confirmation notice.
- Course availability, current schedule, delivery mode, prerequisites and commercial terms must be reconfirmed with AROUSH before enrolment.
- The ISE detail page is linked from the current live course catalogue and its published outline, prerequisites, one-month duration and online-weekend delivery notes have now been migrated. The Fortinet detail-page copy contains third-party I-Medita wording, so only the live catalogue summary is used until AROUSH confirms its own course content.
