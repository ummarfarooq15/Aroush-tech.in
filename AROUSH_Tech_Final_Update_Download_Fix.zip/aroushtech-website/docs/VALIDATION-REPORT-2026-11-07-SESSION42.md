# Validation report — Session 42

Date: 7 November 2026

## Passed

- Final archive integrity: `unzip -t` reported no errors; fresh extraction completed and the complete 23-validator offline suite passed from the extracted project.

- `npm run check:offline`: all 23 dependency-free validators passed in the working project and again after extracting the final ZIP into a fresh directory.
- Content validation: 10 services, 20 public courses, 18 source outlines, two provider-attribution review notes, 18 consistent fee pairs, two withheld fee conflicts, six SOC/SIEM learning paths, three team profiles, ten gallery photographs, eight target-industry profiles, two office addresses, two public testimonials, 31 public routes and 23 redirects.
- Privacy and analytics checks: GA4 remains opt-in only, Measurement ID blank by default, reject/withdrawal/settings controls present, Google Signals and ad personalisation disabled, phone voluntary, no server-side lead database or CRM.
- UX and accessibility source validators passed.
- Internal route checks: 31 paths, 20 course slugs and 23 redirects inspected.
- External-link security: 47 source files scanned; nine HTTPS hosts reviewed; no unapproved external host, known spam domain or HTTP link found.
- Public-claims validator: 45 public source files scanned; no unapproved guarantees/comparative claims found.
- Course catalogue URL/share tests passed for URL parsing and serialization, invalid-value fallback, campaign parameter preservation, reset behavior, native-share source branch, clipboard fallback, share cancellation, 100-character query limit and accessibility associations.
- Course sorting, outline filtering, comparison, enquiry, email-draft safety, FAQ and chatbot checks passed.
- Chatbot: 47 intent-routing cases passed.
- Enquiry paths: 33 checks passed.
- Email-draft safety: 19 checks passed.
- Course outline filter: 17 checks passed.
- TypeScript/TSX syntax: 38 files parsed with TypeScript 5.8.3. Syntax only; not a semantic typecheck.
- JavaScript syntax: 34 `.mjs` files checked.
- CSS parsed with PostCSS: 612 rules, 28 at-rules and 2,033 declarations; zero parse errors.

## Blocked / pending

- Runtime: Node.js 22.16.0; project requires 24.x.
- npm registry: `EAI_AGAIN` while resolving `registry.npmjs.org`.
- Release preflight: no `package-lock.json`; missing `next`, `react`, `react-dom`, `typescript`, `eslint` and `eslint-config-next` packages.
- `npm run typecheck`: blocked by missing Next.js/React modules and type declarations; resulting JSX type errors are dependency-environment errors, not a verified application typecheck.
- `npm run lint`: blocked because `eslint` is not installed.
- `npm run build`: blocked because `next` is not installed.
- `npm audit`: blocked until a reviewed lockfile can be generated.
- Android/desktop browser QA and actual Web Share API testing: pending.

Offline source validation must not be described as a successful production build or device test.
