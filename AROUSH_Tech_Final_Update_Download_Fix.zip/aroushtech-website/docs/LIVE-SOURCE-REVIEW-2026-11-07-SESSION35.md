# Live AROUSH source review — Session 35

Review date: **7 November 2026**

Primary source: the public AROUSH website. This is a point-in-time public review, not an owner approval of commercial terms or delivery commitments.

## Pages reopened

- Homepage: https://aroushtech.in/
- Courses: https://aroushtech.in/courses/
- About: https://aroushtech.in/aboutus/
- Contact: https://aroushtech.in/contact-us/
- Gallery: https://aroushtech.in/gallery/
- AI & ML: https://aroushtech.in/ai-ml/
- CCNA: https://aroushtech.in/ccna/
- CCNA DevNet: https://aroushtech.in/ccna-devnet/

## Current public facts observed

| Area | Public source observation | Rebuild treatment |
|---|---|---|
| Homepage | Advertises 20+ courses and a free demo; presents six course-category themes. | Keeps the course-discovery structure and describes demo availability as subject to confirmation for the chosen course. |
| Featured courses | Homepage lists Agentic AI with LangChain & Hugging Face at ₹35,000 (previously ₹45,000), CCNP Security at ₹45,000 (previously ₹55,000), and CEH at ₹25,000 (previously ₹35,000). | These are consistent with the current public catalogue entries and remain labelled as website-listed references, not final quotations. |
| Course catalogue | Lists 20 public course entries with price pairs. CCNA and CCNA DevNet each show ₹19,999 in the catalogue. | Keeps all 20 records. Numeric fees remain withheld for CCNA and CCNA DevNet because each individual page shows ₹19,000. The other 18 current catalogue fee pairs are retained with confirmation wording. |
| About | Publishes mission, vision and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid, with role titles. | Keeps public names/roles only; no additional qualifications or experience claims are inferred. |
| Contact | Publishes `taj@aroushtech.in`, `+91 88676 92074`, corporate and registered office addresses, and a J.P. Nagar training-centre reference. | Uses the published email, phone and two office addresses. The training-centre reference remains separate because it does not include a complete visitor address. |
| Contact FAQs | Describes online/offline/hybrid formats, certification, “100% job assistance” and “24/7 lab access”. | The formats are described as source-published but subject to programme confirmation. Certification, job-assistance and 24/7 access claims are not turned into rebuild guarantees pending owner approval. |
| Gallery | Shows training and corporate-training photographs. | Retains the ten selected training/learner image references already in the rebuild; the client-logo collage remains excluded pending permissions. |
| Homepage integrity | The current crawl still shows zero-value counters (`0k+`, `0+`, `0%`) and 16 unrelated gambling/betting footer links. | Excludes both from the rebuild. The external links remain an authorised WordPress/hosting investigation item; the crawl does not prove the precise compromise mechanism. |

## Course fee reconciliation

- CCNA: catalogue ₹19,999; individual page ₹19,000 — rebuild withholds the numeric fee.
- CCNA DevNet: catalogue ₹19,999; individual page ₹19,000 — rebuild withholds the numeric fee.
- The current catalogue's other 18 fee pairs remain consistent in this snapshot. They are still labelled as website-listed references and require confirmation before payment.
- Homepage featured prices for Agentic AI with LangChain & Hugging Face, CCNP Security and CEH match their current catalogue values in this crawl.

## Unresolved source and owner items

1. The legacy course pages still expose an unverified third-party checkout destination, `demosites.royal-elementor-addons.com`. It was not opened, used or copied into the rebuild.
2. The homepage still exposes 16 unrelated gambling/betting footer destinations. An authorised administrator should preserve backups/logs and inspect WordPress users, plugins, themes, widgets, database content, scheduled tasks, files and Search Console before migration.
3. The public Contact page describes a J.P. Nagar training centre without a complete visitor-ready address. Confirm the exact session venue before travel.
4. The public Contact FAQ's certification, job-assistance and 24/7 lab-access statements need written owner approval before reuse as commitments.
5. The 2026 company profile/brochure remains the supporting source for the expanded ten-service portfolio and SOC/SIEM material. The public site does not yet provide complete dedicated detail pages for every service; the owner must confirm current availability and delivery capability.
6. Team portrait, gallery-photo and testimonial reuse permissions remain owner approval items.

## Change control

This review informed only the offline rebuild. No live website, WordPress installation, DNS, hosting account, GitHub repository, analytics property or production deployment was changed.
