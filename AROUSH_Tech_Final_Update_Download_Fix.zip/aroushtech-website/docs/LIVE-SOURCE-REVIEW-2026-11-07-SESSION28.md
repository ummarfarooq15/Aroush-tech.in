# Live AROUSH source review — Session 28 — 7 November 2026

This is a public-page review only. It does not authorise edits to WordPress, hosting, DNS or the production site.

## Pages reviewed

| Page | Fresh observation | Rebuild decision |
|---|---|---|
| Homepage — https://aroushtech.in/ | 20+ course/free-demo message; six course families; featured Agentic AI with LangChain & Hugging Face, CCNP Security and CEH cards; two testimonials; Tajuddin instructor introduction; zero-value counters; 16 unrelated gambling/betting footer anchors. | Keep genuine course/demo positioning and source-approved content. Exclude zero counters and unrelated external links. |
| About — https://aroushtech.in/aboutus/ | Vision, mission and three profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid. | Keep public role wording; do not import unconfirmed profile qualifications or experience. |
| Courses — https://aroushtech.in/courses/ | Twenty course cards, descriptions and previous/current amount pairs. | Keep 20 course records; label all amounts as changeable website references and require confirmation before payment. |
| Gallery — https://aroushtech.in/gallery/ | Training/learner photos, corporate training context, third-party logo collage and placement-related wording. | Keep ten training/learner photos. Exclude logo collage and unapproved placement outcomes. |
| Contact — https://aroushtech.in/contact-us/ | `taj@aroushtech.in`, `+91 88676 92074`, corporate and registered Bengaluru office addresses, J.P. Nagar training-centre reference and online/offline/hybrid FAQ. Contact FAQ also publishes certification, 100% job-assistance and 24/7 lab-access claims. | Keep verified contact data. Distinguish office addresses from the incomplete training-centre reference. Do not repeat job-assistance or 24/7 claims until written owner approval. |
| AI & ML — https://aroushtech.in/ai-ml/ | 40-hour live/intensive course, seven modules, instructor and published course amount. | Keep the 40-hour duration and seven-module outline with a current-schedule caveat. |
| CCNA — https://aroushtech.in/ccna/ | CCNA 200-301 description, intended audience, basic prerequisites, tools, learning outcomes and curriculum. | Keep only the source-published topics and prerequisite wording. |
| Agentic AI with LangGraph and LangChain — https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/ | Fifteen outline topics: Python/Pydantic, LangChain, OpenAI/Ollama, LCEL, agents, LangGraph, LangSmith, workflows, human-in-the-loop and RAG. No duration stated. | Keep outline; do not infer a duration. Added a chatbot summary and direct course link. |
| Agentic AI with LangChain and Hugging Face — https://aroushtech.in/agentic-ai-with-langchain-hugging-face/ | Forty-six outline items covering Python, Streamlit, NLP, neural networks, Transformers, LangChain, RAG, SQL, Hugging Face, vector/graph databases, fine-tuning and multi-agent workflows. No duration stated. | Keep outline; do not infer a duration. Added a chatbot summary and direct course link. |
| Fortinet Certified Engineer — https://aroushtech.in/fortinet-certified-engineer/ | Long-form page text explicitly states that I-Medita conducts the Fortinet training and includes extensive third-party course material. | Do not reproduce the long-form syllabus, schedule, batch-size or provider claims as AROUSH-authored content. Keep the AROUSH catalogue listing only and request an approved AROUSH syllabus. |

## New checkout-link verification item

The reviewed AI & ML and Agentic AI course pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`. The destination was not opened and is not used in the rebuild. The owner should confirm the domain, merchant identity, payment processor, data handling, refund terms and approval before any checkout link is promoted.

## WordPress security observation

The root homepage still exposes 16 unrelated gambling/betting links to unrelated external domains. This is consistent with possible SEO-spam injection or an unapproved integration, but a public crawl cannot identify the injection point or prove a full server compromise. Preserve backups and logs; have the authorised WordPress/hosting administrator inspect users, plugins, themes, database content/options, widgets, custom code, uploads, scheduled tasks, hosting configuration and Search Console before migration.

## Competitor UX references

- Apna College Prime: https://www.apnacollege.in/prime — curriculum grouped into foundations, data preparation and machine-learning concepts. Retain the scannable curriculum pattern only.
- i-Medita FAQ and course pages: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ccna-training/ — make course, schedule, language, location and enquiry information easy to locate. Retain the information hierarchy only.
- PyNet Labs catalogue and contact: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — technology filters, career-path grouping and visible human guidance. Retain the discovery pattern only.

No competitor metrics, prices, testimonials, credentials, ratings, partners, schedules or guarantees are copied.

## Privacy and release

GA4 remains unconfigured and disabled until owner approval and explicit visitor consent. The contact form remains a visitor-controlled `mailto:` handoff; phone is optional. No CRM, server-side lead database or visitor identification was added. Source validators pass; full build and browser QA remain blocked by the unavailable Node.js 24/dependency environment.
