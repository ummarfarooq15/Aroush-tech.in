# Live AROUSH source review — 7 November 2026

Review scope: public company, course, team, gallery, contact and homepage content. The live site remains the primary source for facts it currently publishes. This review does not authorise any WordPress, hosting, DNS or deployment change.

## Public AROUSH pages reopened

| Page | Current public facts observed | Rebuild treatment |
|---|---|---|
| Homepage — https://aroushtech.in/ | “20+ Job-Ready Courses” and free-demo message; six course discovery families; three featured courses; two learner testimonials; instructor introduction; zero-value counters; 16 unrelated gambling/betting footer links. | Keep the genuine course/demo positioning, featured course records, published testimonials and instructor introduction. Exclude zero-value counters and all unrelated footer links. |
| About — https://aroushtech.in/aboutus/ | Mission and vision; Abdul Aleem Khan (Vertical Head Cyber Security & Cloud Security), Tajuddin (Technical Head Networking & Cyber Security), Mohammed Khalid (Technical Head For Networking Security). | Keep the three public profiles and published role wording. Corrected the rebuild's Mohammed Khalid role to “Technical Head for Networking Security”. Do not add qualifications or experience from supporting material without approval. |
| Courses — https://aroushtech.in/courses/ | 20 catalogue cards with descriptions and previous/current fee pairs. Featured listings include CCNA, CCNA DevNet, CCNP Enterprise, CCNP Security, CEH, AI/ML and two Agentic AI programmes. | The rebuild retains 20 course records and the public fee snapshot. Every amount is labelled as a website-listed reference and must be reconfirmed before payment. One Fortinet long-form outline remains withheld for source review. |
| Gallery — https://aroushtech.in/gallery/ | Training and corporate-training photographs, learner groups, one separate collage of third-party company logos and placement-related copy. | Keep ten descriptive training/learner photographs. Exclude the third-party logo collage and do not turn placement-related copy into a new endorsement or outcome claim. |
| Contact — https://aroushtech.in/contact-us/ | `taj@aroushtech.in`, `+91 88676 92074`, corporate and registered Bengaluru office addresses, a J.P. Nagar training-centre reference, online/offline/hybrid formats, and FAQs containing certification, “100% job assistance” and “24/7 lab access” claims. | Keep the published contact details and distinguish office addresses from the training-centre reference. Ask visitors to confirm the exact venue and current programme details. Do not repeat certification, placement or 24/7 access promises until AROUSH approves current written terms. |

## Specific content correction

The live About page spells Mohammed Khalid's role as “Technical Head For Networking Security”. The rebuild previously shortened it to “Technical Head – Networking Security”. The public role is now represented as “Technical Head for Networking Security”, preserving the meaning and wording while using normal sentence case. The content validator now checks for this role text.

## Homepage security observation

The current public homepage still exposes 16 unrelated gambling/betting footer anchors to 16 unrelated external domains. Visible terms include `bettilt`, `pinup`, `pinco`, `bahsegel`, `paribahis`, `casinomuhub`, `rokubet`, `slotbey`, `casino siteleri` and `bahis siteleri`. The homepage also continues to show zero-value counters. The rebuilt website excludes both.

This rendered-page symptom is consistent with possible SEO-spam injection or an unapproved third-party/footer integration. A public crawl cannot determine whether the source is WordPress content, a theme/widget, plugin, account, cache/CDN or third-party script, and it does not prove a full server compromise. The authorised WordPress/hosting administrator must preserve backups and logs, inspect the underlying installation and confirm cleanup before any migration or domain cutover. No suspicious destinations were opened and no live changes were made.

## Competitor UX review — official public pages

- Apna College Prime: https://www.apnacollege.in/prime — the page groups its AI/ML curriculum into Python/data foundations, mathematics, machine-learning topics and next-step information. Transferable lesson: keep AROUSH course outlines scannable and ordered, but only publish stages, prerequisites and practical outcomes supported by AROUSH course sources.
- i-Medita FAQ and CCNA course: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ccna-training/ — the pages make location, schedule, language, course details, trainer information and enquiry routes discoverable. Transferable lesson: keep AROUSH FAQs and human enquiry paths close to the relevant course; do not copy i-Medita credentials, partner counts, fees, ratings or placement claims.
- PyNet Labs catalogue and contact: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — the catalogue offers technology/category and career-path discovery, while the contact page exposes human counselling routes. Transferable lesson: retain AROUSH search and filters, and surface course level, duration, delivery mode or prerequisites only when AROUSH verifies each field.

No competitor prices, discounts, learner totals, ratings, testimonials, credentials, schedules, hiring partners, placement statistics or guarantees were copied.

## Privacy and analytics review

- GA4 Measurement ID remains blank in `.env.example` and no valid ID is configured in this package.
- The analytics component loads GA4 only after a valid owner-configured Measurement ID and explicit visitor opt-in.
- Reject, withdrawal and persistent privacy settings remain available.
- Query strings and hashes are excluded from page-view paths; Google Signals and advertising personalisation remain disabled.
- The contact form remains a visitor-controlled `mailto:` draft. Phone number is optional and is included only when voluntarily entered.
- No server-side lead database, CRM, SMS/WhatsApp automation or live AI chatbot integration was added.

## Release status

Dependency-free source checks pass. Full TypeScript typechecking, ESLint, Next.js production build, dependency audit and real Android/desktop browser QA remain blocked or pending because this runtime has Node.js 22.16.0 rather than the project's Node.js 24.x requirement, no package lockfile, missing local dependencies and npm registry DNS failure (`EAI_AGAIN`). See `SESSION-26-REPORT.md` for the exact checks.

## Session 27 follow-up — 7 November 2026

The official homepage, About, Courses, Gallery and Contact pages were reopened, along with the CCNA and AI & ML detail pages. The homepage still exposes the same 16 unrelated gambling/betting footer links. The live About page still publishes the same three team names and roles. The public catalogue still contains 20 courses and fee pairs. The AI & ML detail page explicitly states 40 hours of live, intensive training; the rebuilt chatbot now answers duration/content questions with that qualification and links to the migrated course detail page.

The course catalogue now marks whether source-published outline topics are available. Nineteen of the twenty course records have migrated outline topics; the Fortinet detail remains withheld because the live long-form page contains material attributed to another provider. The catalogue does not invent a replacement syllabus.

Service detail sections now expose stable anchors for the eight numbered service families and the existing SOC/SIEM anchor. This supports direct chatbot links without changing the service scope or adding new claims.
