# Competitor UX review — Session 46

Date checked: 7 November 2026

This review considers information architecture, navigation and user experience only. Do not copy competitor prices, discounts, ratings, testimonials, learner counts, placement outcomes, credentials, guarantees or marketing claims.

## Apna College

Reference: https://www.apnacollege.in/prime

The current Prime page separates engineering students, working professionals and non-CS learners, then provides a scannable curriculum. Useful pattern: help visitors select a relevant audience/goal path before presenting a long syllabus. AROUSH's learner/business enquiry routes and learning-path collections remain based on AROUSH's own published catalogue and service content.

## i-Medita

Reference: https://www.imedita.com/frequently-asked-questions/

The FAQ page groups practical visitor questions such as training location, schedules, language and payments. Useful pattern: organise FAQs around decisions a prospective learner needs to make, and route time-sensitive or account-specific questions to a human contact. AROUSH retains its own verified FAQ content and contact handoff.

## PyNet Labs

Reference: https://www.pynetlabs.com/courses/

The catalogue groups courses by technical areas such as automation, AI, SD-WAN, routing/switching, network security, cloud, data centre and cybersecurity. Useful pattern: combine a broad catalogue with understandable technical category navigation. AROUSH retains its own six public course themes and its existing search, filters, comparison and shareable catalogue state.

## Applied direction

- Keep course discovery audience-aware without inventing AROUSH prerequisites or outcomes.
- Keep practical FAQs searchable and linked to the human team.
- Keep AROUSH category labels and course records grounded in AROUSH source material.
- Session 46's main user-facing improvement is the review-before-send enquiry flow; it is not a copy of a competitor feature.
