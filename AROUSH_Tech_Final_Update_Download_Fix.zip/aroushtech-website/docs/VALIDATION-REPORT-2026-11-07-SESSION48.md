# Validation report — Session 48

**Date:** 7 November 2026  
**Project:** AROUSH Tech public website + separately approved visitor-intelligence companion app  
**Runtime available:** Node.js 22.16.0 / npm 10.9.2  
**Runtime required:** Node.js 24.x

## Result

**Offline source validation: PASS. Full build and runtime validation: BLOCKED.**

## Passed checks

- `npm run check:offline` — PASS after Session 48 changes.
- Content validation — PASS: 10 services, 20 public courses, 18 source outlines, 2 provider-attribution review notes, 18 consistent fee pairs, 2 conflicting fees withheld, 6 SOC/SIEM paths, 3 team profiles, 10 gallery photos, 8 target-industry profiles, 2 office addresses, 2 testimonials, 31 routes, 23 redirects and structured data.
- Privacy validation — PASS: root GA4 disabled by default and opt-in only; reject/withdrawal remains available; no root-site server-side lead API; owner-approved companion lead app remains separate; no CRM integration.
- Visitor-intelligence source checks — PASS: 54 checks covering aggregate analytics, consent, OTP, Turnstile, database controls and deployment boundaries.
- Analytics policy — PASS: valid Measurement ID gating, explicit opt-in, stored choice, safe referrers, query/hash removal and minimal page-view payload.
- Brand and UX validation — PASS.
- Accessibility source validation — PASS: 31 TSX files checked.
- Internal links and breadcrumbs — PASS: 31 internal paths, 20 course slugs, redirects and 11 breadcrumb routes.
- Social cards — PASS: root and course Open Graph/X cards use 1200 × 630 output.
- External link policy/security — PASS: HTTPS allowlist, spam host and phrase checks; 46 source files scanned and 9 HTTPS hosts reviewed.
- Public claims — PASS: 44 public source files scanned; no unapproved guarantees or comparative claims found.
- Learning paths, FAQs, FAQ search, course sorting, outline filter, shareable catalogue URLs and comparison — PASS.
- Enquiry paths and safety — PASS: 37 route/flow checks and 22 privacy/sanitisation checks.
- Chatbot — PASS: 52 intent-routing cases, including team, vision/mission, office, gallery, service, course, privacy and unknown-question handoff.
- JavaScript syntax — PASS: 38 `.js`/`.mjs` files.
- TypeScript syntax — PASS: 70 `.ts`/`.tsx`/`.mts`/`.cts` files parsed. This is syntax validation only, not semantic typechecking.
- Release configuration — PASS: Node 24 pin, scripts, blank GA4 Measurement ID and release settings are consistent.

## Blocked checks

### Release preflight

`npm run preflight:release` reports:

- Node.js 22.16.0 is available; Node.js 24.x is required.
- No root `package-lock.json` is present.
- Project dependencies are not installed: Next.js, React, React DOM, TypeScript, ESLint and `eslint-config-next`.

### TypeScript semantic check

`npm run typecheck` is blocked because `next`, `next/link`, `next/image` and `react` declarations are unavailable. The resulting missing JSX intrinsic-element errors are dependency-resolution cascades and must not be treated as confirmed source-code type defects.

### Production build

`npm run build` stops with `next: not found` because dependencies are not installed.

### Remaining external/runtime checks

- ESLint and dependency audit require a reviewed lockfile and installed dependencies.
- Supabase RLS/RPC behaviour and atomic OTP/lead creation require a non-production Supabase project.
- Resend email, MSG91 SMS and Cloudflare Turnstile require owner-owned accounts and test credentials.
- Browser, Android, tablet and desktop QA require a runnable staging environment.
- Retention/deletion periods, official privacy contact, named admin access and legal review require owner approval.

## Privacy and deployment status

- `NEXT_PUBLIC_GA_MEASUREMENT_ID` remains blank in `.env.example`; root GA4 is disabled until the owner supplies a valid AROUSH-owned Measurement ID and visitors explicitly opt in.
- The root marketing-site enquiry form remains a review-first email handoff and is not connected to the Supabase lead database.
- The separately owner-approved visitor-intelligence app remains isolated under `apps/visitor-intelligence`; no production provider accounts were configured.
- No live WordPress, DNS, GitHub repository, hosting project, GA4 property, Supabase project, Resend account, MSG91 account or Cloudflare account was changed. No deployment was performed.
