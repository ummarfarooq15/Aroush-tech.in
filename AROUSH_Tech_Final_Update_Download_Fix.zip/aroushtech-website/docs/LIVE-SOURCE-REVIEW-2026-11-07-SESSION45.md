# Live AROUSH source review — Session 45

Date: 7 November 2026

## Pages reopened

- https://aroushtech.in/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/ai-ml/

## Current published details observed

### Homepage

- The page advertises 20+ job-ready courses and a free-demo option.
- Six public course themes are visible: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing.
- Featured course amounts shown on the page are Agentic AI with LangChain & Hugging Face ₹35,000, CCNP Security ₹45,000, and CEH ₹25,000.
- Three counters still render as zero (`0 k+`, `0 +`, `0 %`).
- Sixteen unrelated gambling/betting footer links are still visible in the public crawl. The rebuild excludes them. An authorised WordPress/hosting investigation is required; the crawl does not establish the entry point or full compromise mechanism.
- The homepage includes two testimonials and an instructor introduction for Tajuddin. The rebuild uses only the existing source-backed testimonial and instructor content already recorded in the content audit.

### AI & ML course page

- The page states 40 hours of live and intensive training.
- It publishes seven modules covering AI/ML foundations, Python, network data handling, machine learning, predictive AI, language models and generative AI for network engineering.
- It identifies Mr. Tajuddin as instructor and lists English as the language.
- It displays ₹45,000 and links to a third-party checkout host. The checkout destination remains unapproved and is not used by the rebuild.
- The rebuild already includes the 40-hour duration and the public outline. Any course fee is still shown only under the project's catalogue/detail consistency safeguards.

### Contact page

- Email: `taj@aroushtech.in`
- Phone: `+91 88676 92074`
- Corporate office: `#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029`.
- Registered office: `AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078`.
- The page separately refers to a Bengaluru J.P. Nagar training centre but does not provide a complete visitor-ready address.
- The page continues to state certification, 100% job assistance and 24/7 lab access. These are not presented as guarantees in the rebuild pending written owner confirmation.

### Outstanding course discrepancy

CCNA and CCNA DevNet remain listed at ₹19,999 in the catalogue and ₹19,000 on their individual pages. The rebuild continues to withhold both numeric amounts until the owner confirms the correct fee.

## Use in the rebuild

No new company fact or price was added in this source pass. The current source was used to confirm existing course duration/outline data and to refresh the owner-action list. The rebuild continues to exclude the unrelated footer links, zero counters, unverified checkout destination and unapproved guarantees.
