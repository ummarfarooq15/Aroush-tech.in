# Session 38 — Learner and business enquiry paths

Date: 7 November 2026

## Changes made

1. Added three explicit enquiry routes to `/contact`: individual learner, business/institution and general enquiry. Each route is selectable from a dedicated card and from the form itself.
2. Added query-aware deep links. Course detail pages, course catalogue CTAs, learning paths and SOC/SIEM learning-path enquiries open the learner route. Corporate/campus training and service discussion links open the business route.
3. Made the enquiry form adapt to the selected path:
   - Learners can optionally identify a course and describe their learning goal.
   - Businesses/institutions can optionally provide an organisation and approximate team size.
   - General enquiries retain a simple message path.
   - Name and email are required to prepare the visitor's email; phone, organisation, team size and course name remain optional where applicable.
4. Added `lib/enquiry-path.mjs` and its declaration file. The helper normalizes route choices and prepares a clear email subject/body without network access or persistence.
5. Updated the email draft to include the enquiry type and only the optional details the visitor voluntarily provides. The visitor's email application remains the final send action.
6. Added responsive enquiry-path cards, visible keyboard focus, selected-route styling and an in-page anchor with scroll offset.
7. Updated the privacy notice to disclose the enquiry type and optional course, organisation and approximate team-size fields.
8. Added `scripts/validate-enquiry-paths.mjs` with tests for route defaults, learner/business email contents, optional phone, deep links, privacy boundaries, accessibility and responsive styling. Wired it into `npm run check:offline` and release configuration.
9. Updated accessibility and UX source validators, the beginner developer guide, README, project status and source register.
10. Refreshed official AROUSH source pages and competitor UX research. No competitor claims or commercial information were copied.

## Validation

- `npm run check:offline` passes all 20 dependency-free validators.
- The new enquiry-path test passes 30 assertions.
- Existing chatbot tests remain at 47 intent-routing cases.
- TypeScript/TSX syntax parsing passes for 36 files; JavaScript syntax checks pass for 29 `.mjs` files.
- Link validation confirms the new `/contact` query paths and `#enquiry-form` anchor.
- Accessibility source checks cover 25 TSX files, including the enquiry type selector, labelled path cards, in-page form target and optional phone control.
- Global PostCSS parsed 604 CSS rules, 27 at-rules and 2,001 declarations without syntax errors.

These are source-level checks, not a full production build or real browser test.

## Production blockers

- Runtime is Node.js 22.16.0; project requires Node.js 24.x. The official archive lists v24.22.2 as the latest 24.x maintenance-LTS release on 7 November 2026: https://nodejs.org/en/download/archive/v24.22.2.
- npm registry DNS resolution failed with `EAI_AGAIN registry.npmjs.org`.
- No `package-lock.json` or installed `node_modules/` is available.
- Full TypeScript semantic typecheck, ESLint, Next.js production build and npm audit remain blocked by missing dependencies/lockfile and registry connectivity.
- Android and desktop browser QA remains pending a working build or staging environment.

## Current source findings

- Official homepage still advertises 20+ courses and a free-demo message, and presents six course-category themes.
- Official About page continues to publish its mission/vision and three team profiles.
- Official Contact page publishes `taj@aroushtech.in`, `+91 88676 92074`, and two Bengaluru office addresses. It separately refers to a J.P. Nagar training centre without a complete visitor-ready address; the rebuild continues to advise confirming the session venue before travel.
- The live WordPress homepage crawl still exposes unrelated gambling/betting footer links and zero-value counters. They remain excluded; the crawl does not establish the precise compromise mechanism.
- CCNA and CCNA DevNet catalogue/detail fee conflicts remain withheld. The unverified third-party checkout host remains blocked.

## Privacy and release boundaries

- The enquiry form still prepares a local email draft; no website server receives or stores the details.
- Phone remains voluntary. Organisation, team size and course name are optional.
- No CRM, lead database, enquiry API, analytics event or additional third-party script was added.
- GA4 Measurement ID remains blank and analytics remains disabled until owner configuration and explicit visitor opt-in.
- No live site, WordPress, DNS, hosting, GitHub repository, analytics property or deployment was changed.
