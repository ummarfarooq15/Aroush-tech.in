# Live AROUSH source review — Session 41

Date: 7 November 2026

Primary source: https://aroushtech.in/

## Homepage

The current homepage advertises 20+ job-ready courses and a free-demo option. It presents six course families: Cybersecurity Essentials, Advanced Networking, Cloud & DevOps, Agentic AI & Machine Learning, Linux & Cybersecurity, and Web Application Pen Testing. It features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH with published promotional amounts.

The homepage also exposes three counters with zero values and 16 unrelated gambling/betting footer destinations. The rebuild excludes those elements. Their presence warrants an authorised WordPress and hosting investigation, but the public crawl alone does not identify the injection mechanism or prove full compromise.

## About and team

The About page publishes the company's vision and mission and lists three team members with role titles:

- Abdul Aleem Khan — Vertical Head Cyber Security & Cloud Security.
- Tajuddin — Technical Head Networking & Cyber Security.
- Mohammed Khalid — Technical Head for Networking Security.

The rebuild follows these public titles and does not add personal qualifications or experience claims that require separate approval.

## Courses

The public catalogue lists 20 courses across networking, network automation, network security, cybersecurity, Linux/security, cloud, AI/ML and data-centre subjects. The catalogue currently shows ₹19,999 for CCNA and CCNA DevNet. Their individual pages each show ₹19,000. The rebuild continues to withhold these two conflicting amounts and directs visitors to confirm the current fee with AROUSH.

The catalogue also exposes a third-party course checkout link on individual pages. The rebuild does not copy the link and does not provide online checkout.

## Gallery

The public Gallery page is titled “Successful Training Gallery” and describes training and corporate-training photographs. Its page text references corporate sessions in Bengaluru and names Larsen & Toubro Infotech, Capgemini and NTT Level 1/Level 2. The rebuild retains ten training photographs but excludes the separate third-party logo collage. The public wording is not treated as permission to use logos as current endorsements.

## Contact

The current Contact page publishes:

- Email: `taj@aroushtech.in`
- Phone: `+91 88676 92074`
- Corporate office: #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bengaluru 560029.
- Registered office: AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bengaluru, Karnataka 560078.

The page separately refers to a Bengaluru/J.P. Nagar training centre but does not provide a complete visitor-ready address. The rebuild tells visitors to confirm the exact session venue rather than treating either office address as the training location.

The Contact FAQ includes certification, “100% job assistance” and “24/7 lab access” statements. These remain owner-review claims and are not repeated as guarantees in the rebuild.

## Sources reopened

- https://aroushtech.in/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/courses/
- https://aroushtech.in/gallery/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/ccna/
- https://aroushtech.in/ccna-devnet/

This review records public-page observations only. It does not alter the live website or establish the integrity of the WordPress installation.
