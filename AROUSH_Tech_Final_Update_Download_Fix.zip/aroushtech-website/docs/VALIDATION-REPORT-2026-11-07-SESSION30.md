# Validation report — Session 30

Date: 7 November 2026

## Passed

| Check | Result |
|---|---|
| Content | 10 services; 20 courses; 18 source-backed outlines; CEH/Fortinet review notes; 18 consistent fee pairs; 2 fee conflicts withheld |
| Privacy | GA4 opt-in only; Measurement ID blank; reject/withdrawal; voluntary phone; no CRM/database |
| Analytics policy | Consent gating, Measurement ID validation and safe page-view payloads passed |
| Brand | Approved logo and derivatives passed |
| UX | Chatbot, navigation, filters and voluntary enquiry flow passed |
| Accessibility | 23 TSX files scanned; shared keyboard, landmark, focus and reduced-motion checks passed |
| Internal links | 30 routes, 20 course slugs and redirects passed |
| External-link policy | HTTPS allowlist, HTTP rejection, known spam domains and unverified checkout host tests passed |
| External-link scan | 33 files, 9 hosts; no unsafe or unapproved external links in rebuild |
| Public claims | 31 source files; no unapproved guarantees/comparative claims |
| Learning paths | 4 collections, 20 course links and 6 SOC/SIEM options passed |
| Chatbot | 45 intent-routing cases passed |
| JavaScript | 20 `.mjs` files parsed |
| TypeScript syntax | 30 `.ts`/`.tsx` files parsed using TypeScript 5.8.3; syntax only |
| Release config | Node 24 pin, scripts and blank GA4 Measurement ID consistent |
| CSS | 521 rules and 20 at-rules parsed using global PostCSS |

## Blocked

- Runtime is Node.js 22.16.0; project requires 24.x.
- No `nvm`, `fnm` or `node24` executable is available in this environment.
- `npm ping --fetch-retries=0` failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- `package-lock.json` is missing.
- `npm run typecheck` fails because Next.js and React type declarations are not installed; this is not a meaningful semantic typecheck of the project.
- `npm run lint` fails because ESLint is not installed.
- `npm run build` fails because Next.js is not installed.
- `npm audit --offline` fails with `ENOLOCK` because no lockfile exists.
- Real Android/desktop browser QA remains pending a successful staging build.

Do not treat source/syntax validators as a production build, semantic typecheck, lint run or browser test.
