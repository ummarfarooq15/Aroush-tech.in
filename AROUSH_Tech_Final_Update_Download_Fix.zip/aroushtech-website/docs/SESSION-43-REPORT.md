# Session 43 — shareable course comparisons

Date: 7 November 2026

## Changes made

1. Extended the shareable course-catalogue URL state with a `compare` parameter containing up to three selected course slugs.
2. Opening a valid comparison URL restores the selected courses in the same order and automatically opens the comparison table when at least two valid courses are present.
3. Added a strict allowlist based on the current 20-course catalogue. Unknown slugs are ignored, duplicates are removed and the selection is capped at three courses in both URL parsing and serialization. The incoming comparison parameter is capped at 128 characters before parsing.
4. Kept search, category, sort and outline-availability filters shareable alongside the selected comparison.
5. Updated the share action title/message for comparison links and changed the action label to “Share course view”.
6. Updated the catalogue note to explain that search terms and comparison slugs appear in the URL and may be present in browser history, copied links and routine server logs. Visitors are told not to enter personal information in course search.
7. Updated the beginner developer guide, privacy/analytics note, README and project status.
8. Added URL tests for restoring a comparison, unknown/duplicate slug handling, the three-course limit, serializer allowlisting, and clearing comparison state. Updated UX validation to require the new disclosure and URL behavior.
9. Reopened current official AROUSH pages and refreshed competitor UX research for Apna College, i-Medita and PyNet Labs.

## Validation performed

- Course catalogue URL/share validator passed after the changes.
- UX source validator passed.
- Release configuration validator passed.
- The full dependency-free `npm run check:offline` suite passed all 23 validators in the working project and again after extracting the final ZIP into a fresh directory. Details are recorded in `VALIDATION-REPORT-2026-11-07-SESSION43.md`.
- TypeScript/TSX syntax validation is source syntax only; it is not a semantic typecheck or Next.js build.

## Production limitations

- Current runtime: Node.js 22.16.0; project requirement: Node.js 24.x (`.nvmrc` and `package.json` engines).
- No `node_modules` directory and no `package-lock.json` are present in the working project.
- npm registry DNS resolution has previously returned `EAI_AGAIN` for `registry.npmjs.org`; package installation and lockfile generation remain blocked until registry access is restored.
- Full semantic TypeScript, ESLint, Next.js production build, npm audit and real Android/desktop browser testing remain pending.

## Current source review findings

- Official homepage continues to advertise 20+ courses, a free demo and six course families. It features Agentic AI with LangChain & Hugging Face (₹35,000), CCNP Security (₹45,000) and CEH (₹25,000).
- The official catalogue lists 20 courses. CCNA and CCNA DevNet remain inconsistent: catalogue ₹19,999 versus individual course pages ₹19,000. Both amounts remain withheld in the rebuild pending owner confirmation.
- About continues to publish the company vision/mission and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid.
- Gallery continues to show training and corporate-training photographs. The rebuild keeps ten training photographs and excludes the separate third-party logo collage pending approval.
- Contact continues to publish `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses. The J.P. Nagar training-centre reference still lacks a complete visitor-ready address.
- Homepage still exposes three zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes them. An authorised WordPress/hosting investigation is required; the public crawl does not establish the injection mechanism or full compromise.
- Contact-page certification, 100% job-assistance and 24/7 lab-access statements remain owner-review items and are not presented as guarantees in the rebuild.

## Competitor UX research

- Apna College: its current homepage separates several programme families and links visitors to curriculum/results resources. AROUSH retains its own course catalogue and uses the general lesson of clearer programme entry points. The current promotional discount and all third-party claims are excluded.
- i-Medita: its current FAQ page surfaces practical questions such as training location and schedules. AROUSH retains grouped searchable FAQs and human handoff for unconfirmed details.
- PyNet Labs: its current catalogue groups courses by domains such as automation, AI, SD-WAN, data, data centre, routing/switching, network security, cloud and cybersecurity. AROUSH retains its own categories and adds shareable comparisons; no third-party commercial data or claims are copied.

## Privacy and deployment boundary

- GA4 Measurement ID remains blank and analytics remains disabled until owner setup and explicit visitor opt-in.
- No CRM, server-side lead database, analytics event, payment integration or visitor-identification feature was added.
- The comparison URL contains course slugs only. Search terms are limited to 100 characters and may appear in normal URL/browser/server logs; the UI warns visitors not to enter personal information.
- No GitHub push, WordPress edit, DNS change, hosting change or deployment was performed.

## Files changed

- `components/course-catalogue.tsx`
- `lib/course-catalogue-url.mjs`
- `lib/course-catalogue-url.d.ts`
- `scripts/validate-course-catalogue-url.mjs`
- `scripts/validate-ux.mjs`
- `docs/BEGINNER-DEVELOPER-GUIDE.md`
- `docs/VISITOR-ANALYTICS-AND-LEADS.md`
- `docs/PROJECT-STATUS.md`
- `docs/SOURCE-REGISTER.md`
- `README.md`
- `docs/SESSION-43-REPORT.md`
- `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION43.md`
- `docs/COMPETITOR-REVIEW-2026-11-07-SESSION43.md`
- `docs/VALIDATION-REPORT-2026-11-07-SESSION43.md`
