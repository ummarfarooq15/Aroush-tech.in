# Live AROUSH source review — Session 46

Date checked: 7 November 2026

The public AROUSH website remains the source of truth for currently published company and course information. This review is a content snapshot, not owner confirmation of commercial terms.

## Pages reviewed

- Homepage: https://aroushtech.in/
- Courses: https://aroushtech.in/courses/
- About: https://aroushtech.in/aboutus/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/
- CCNA: https://aroushtech.in/ccna/
- CCNA DevNet: https://aroushtech.in/ccna-devnet/

## Current published content

- Homepage: 20+ courses, free-demo message, six course-category themes.
- Featured homepage course amounts: Agentic AI with LangChain & Hugging Face ₹35,000; CCNP Security ₹45,000; CEH ₹25,000.
- Course catalogue: 20 listed entries, including CCNA, CCNA DevNet, CCNP Enterprise, CCNP Security, ISE, Ansible & Terraform, Check Point Firewall, Fortinet Certified Engineer, Palo Alto Firewall Certified Engineer, CEH, Cybersys, Linux + Basic Cyber Security, Linux + Advanced Cyber Security, Pentest, Web App Pen Tester, AWS Solutions Architect Associate, AI & ML, two Agentic AI courses and CCNP Data Center.
- About: published vision and mission; team profiles for Abdul Aleem Khan, Tajuddin and Mohammed Khalid.
- Gallery: training-gallery and corporate-training sections, including a caption referencing training in Bengaluru.
- Contact: `taj@aroushtech.in`, `+91 88676 92074`, corporate office at #47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029; registered office at #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078.
- Training-centre location: J.P. Nagar is named, but a complete visitor-ready address is not published on the reviewed Contact page.

## Conflicts and exclusions

- CCNA: catalogue ₹19,999; individual page ₹19,000.
- CCNA DevNet: catalogue ₹19,999; individual page ₹19,000.
- Both conflicting course amounts remain withheld in the rebuilt website pending written owner confirmation.
- Homepage zero-value counters and unrelated gambling/betting footer links remain visible on the live WordPress crawl. The rebuild excludes these elements. Their presence warrants an authorised WordPress/hosting investigation; the public crawl does not establish the exact compromise mechanism.
- The rebuilt Gallery retains ten training photographs and excludes the separate third-party logo collage pending approval.
- The rebuild does not copy unverified checkout destinations or treat marketing statements about placement, certification or lab access as guarantees.

## Primary source URLs

- https://aroushtech.in/
- https://aroushtech.in/courses/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/gallery/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/ccna/
- https://aroushtech.in/ccna-devnet/
