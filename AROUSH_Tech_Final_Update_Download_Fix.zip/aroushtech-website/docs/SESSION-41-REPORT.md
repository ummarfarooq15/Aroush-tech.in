# Session 41 — shareable course catalogue views

Date: 7 November 2026

## Changes made

1. Added URL-backed course-catalogue state for keyword search, category, natural sort order and outline availability.
2. A visitor can now copy a filtered catalogue link. Opening that link restores the same search and filter selection.
3. The catalogue updates only its own query parameters and preserves unrelated query parameters such as campaign tags.
4. Invalid category, sort and outline values safely fall back to the default view. Reset removes only the catalogue parameters and keeps unrelated URL values.
5. Browser `popstate` handling restores the catalogue controls when a visitor returns to a previously filtered course list.
6. Added an accessible copy-result announcement, a clipboard-unavailable fallback, mobile-sized action controls and a visible reminder not to enter personal information in the course search.
7. The feature uses the browser address bar and React state only. It does not add local/session storage, network calls, analytics events, a server endpoint or a database.
8. Added `lib/course-catalogue-url.mjs` and its TypeScript declaration, plus a dependency-free validator. Included it in the offline and release-configuration checks.
9. Reopened the official AROUSH homepage, About, Courses, Gallery, Contact, CCNA and CCNA DevNet pages. Refreshed competitor UX notes for Apna College, i-Medita and PyNet Labs.

## Validation

- `npm run check:offline`: all 23 dependency-free validators passed.
- Course catalogue URL helper: parse/serialize, default handling, URL encoding, unrelated-parameter preservation, reset behavior and safe invalid-value handling passed.
- Course catalogue integration: browser-history restore, URL synchronisation, clipboard copy/fallback, accessible status and privacy note source checks passed.
- Existing chatbot tests: 47 cases passed.
- Enquiry path tests: 33 assertions passed.
- Email-draft safety tests: 19 checks passed.
- Course outline filter tests: 17 checks passed.
- TypeScript/TSX syntax parser: 38 files passed. This is syntax validation only, not semantic typechecking.
- JavaScript syntax validator: 34 `.mjs` files passed.
- Accessibility source checks: 25 TSX files checked.
- Internal route validator: 31 paths, 20 course slugs and 23 redirects inspected.
- External-link security validator: 47 source files scanned; nine HTTPS hosts reviewed.
- CSS parsed with the installed global PostCSS parser; no parse errors.

## Production blockers rechecked

- Runtime is Node.js 22.16.0; the project requires Node.js 24.x.
- `registry.npmjs.org` lookup still fails with `EAI_AGAIN`.
- No `package-lock.json` or `node_modules` directory is available.
- Full TypeScript typecheck fails because Next.js, React and their type declarations are not installed; the output is dominated by missing-module/JSX-type errors.
- ESLint is unavailable (`eslint: not found`).
- Next.js production build is unavailable (`next: not found`).
- `npm audit` is blocked because no lockfile exists (`ENOLOCK`).
- Real Android/desktop browser QA remains pending.

The successful offline validators and syntax parser do not establish a successful production build or semantic typecheck.

## Current source and owner-review findings

- The live homepage advertises 20+ courses and a free demo, presents six course families and features three course offers. It also still exposes three zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes the zero counters and unrelated destinations. This public crawl does not prove the injection path or full compromise.
- The live Courses page lists 20 entries. CCNA and CCNA DevNet each show ₹19,999 in the catalogue, while their individual pages show ₹19,000. Both amounts remain withheld in the rebuild pending owner confirmation.
- The live About page publishes the mission/vision and three team names/role titles. The rebuild uses those public titles and does not add unapproved profile credentials.
- The Gallery page describes training and corporate-training sessions. The rebuild retains ten training photographs and excludes the separate third-party logo collage pending relationship/usage approval.
- The Contact page publishes `taj@aroushtech.in`, `+91 88676 92074` and the corporate/registered office addresses. It also refers to a J.P. Nagar training centre without a complete visitor-ready address. Certification, 100% job-assistance and 24/7 lab-access wording remains owner-review content and is not presented as a rebuild guarantee.
- The unverified third-party course checkout host remains blocked; no online payment flow was added.

## Competitor UX research

- Apna College: current programme pages separate course families and learning goals, then expose curriculum sections. AROUSH keeps its own categories and course records; no competitor outcomes, claims or commercial terms were copied.
- i-Medita: its FAQ groups practical visitor questions such as location, schedules and language. AROUSH retains grouped searchable FAQs and direct human contact routes.
- PyNet Labs: its catalogue groups courses by technology and career path. AROUSH retains its own category, search, sort, outline-availability and comparison controls.

## Privacy and deployment boundary

- GA4 Measurement ID remains blank; analytics remains disabled until owner setup and explicit visitor opt-in.
- No CRM, server-side lead database, payment processor or visitor-identification feature was added.
- Phone remains optional and voluntarily supplied through the enquiry form.
- Catalogue search terms appear in the page URL so a view can be shared; the page warns visitors not to enter personal information in the search field. The search is performed locally and is not sent to a server.
- No GitHub push, WordPress edit, DNS change or deployment was performed.

## Files changed

- `components/course-catalogue.tsx`
- `app/courses/page.tsx`
- `app/globals.css`
- `lib/course-catalogue-url.mjs`
- `lib/course-catalogue-url.d.ts`
- `scripts/validate-course-catalogue-url.mjs`
- `scripts/validate-ux.mjs`
- `scripts/validate-release-config.mjs`
- `package.json`
- `README.md`
- `docs/BEGINNER-DEVELOPER-GUIDE.md`
- `docs/PROJECT-STATUS.md`
- `docs/SOURCE-REGISTER.md`
- `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION41.md`
- `docs/COMPETITOR-REVIEW-2026-11-07-SESSION41.md`
- `docs/VALIDATION-REPORT-2026-11-07-SESSION41.md`
