## Latest session 45 — 7 November 2026

- Added a shared AROUSH-branded social-card component and generated 1200 × 630 PNG Open Graph and X/Twitter previews for the site and individual course pages.
- Course-specific cards resolve only approved titles, categories and descriptions from the course catalogue; unknown slugs use a neutral fallback. Prices, testimonials, ratings, learner counts, guarantees and competitor claims are excluded.
- Added `validate:social-cards` to the offline and release validation sequences.
- Reopened the official homepage, Contact and AI & ML course pages. The homepage still advertises 20+ courses, a free demo and six course themes; it still shows three zero-value counters and 16 unrelated gambling/betting footer links. The rebuild excludes those elements. The AI & ML page still publishes a 40-hour outline and a ₹45,000 price; the contact page still lists the published email, phone and two office addresses while the J.P. Nagar training-centre address remains incomplete. CCNA/CCNA DevNet fee conflicts remain unresolved and withheld.
- Refreshed Apna College, i-Medita and PyNet Labs UX research. Only learner-path navigation, practical FAQ grouping and technical course-category patterns were applied.
- `npm run check:offline` passed all 25 dependency-free validators; chatbot 47 cases; enquiry paths 33 checks; email safety 19 checks; TypeScript/TSX syntax 44 files; JavaScript syntax 36 files; social-card validation passed. Fresh ZIP extraction and revalidation passed.
- Production remains blocked: Node.js 22.16.0 instead of 24.x, npm registry DNS `EAI_AGAIN`, empty npm cache, missing dependencies and no lockfile. Full semantic typecheck, ESLint, Next.js build, npm audit and generated-image rendering remain unverified; Android/desktop QA is pending.
- GA4 remains disabled with a blank Measurement ID. No CRM, server-side lead database, live WordPress edit, DNS change, GitHub push, analytics-property change or deployment was performed.

## Latest session 44 — 7 November 2026

- Added a reusable breadcrumb component to all 11 interior content routes (including dynamic course details) while leaving the homepage as the root entry point.
- Breadcrumbs provide a visible Home → section → current-page trail, accessible navigation naming, `aria-current="page"`, keyboard focus styling and mobile wrapping. The same data generates `BreadcrumbList` JSON-LD; course detail pages no longer maintain a separate breadcrumb schema block.
- Added a dedicated breadcrumb validator to `npm run check:offline` and the release configuration. Extended content and accessibility checks for the shared structured-data/navigation component.
- Reopened current AROUSH homepage, About, Courses, Gallery and Contact pages. The homepage still exposes zero-value counters and 16 unrelated gambling/betting footer destinations; the rebuild excludes them and owner/hosting investigation remains required. CCNA/CCNA DevNet fee conflicts and the incomplete J.P. Nagar training-centre address remain unresolved.
- Refreshed UX-only research for Apna College, i-Medita and PyNet Labs. No competitor commercial claims or statistics were copied.
- `npm run check:offline` passed all 24 dependency-free validators. Breadcrumb validation passed for 11 content routes; accessibility checked 26 TSX files; TypeScript/TSX syntax passed for 39 files; JavaScript syntax passed for 35 `.mjs` files.
- Production typecheck, ESLint, Next.js build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x, missing dependencies/lockfile and npm registry DNS `EAI_AGAIN`. Android/desktop browser QA remains pending.
- GA4 remains disabled with a blank Measurement ID. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change, hosting change or deployment was made.
- Exact findings and validation details are in `SESSION-44-REPORT.md`, `LIVE-SOURCE-REVIEW-2026-11-07-SESSION44.md`, `COMPETITOR-REVIEW-2026-11-07-SESSION44.md` and `VALIDATION-REPORT-2026-11-07-SESSION44.md`.

## Latest session 43 — 7 November 2026

- Extended shareable course-catalogue URLs to include a comparison of up to three known course slugs. Opening a valid link restores the selected courses and automatically opens the comparison table.
- Added a catalogue slug allowlist, duplicate removal and a three-course limit in both URL parsing and serialization. Unknown slugs are ignored, and the incoming comparison parameter is capped at 128 characters before parsing.
- Search, category, sort and outline-availability filters can be shared together with the comparison. The share action now uses comparison-specific copy when appropriate.
- Clarified that search terms and comparison slugs appear in the URL and may be present in browser history, copied links and routine server logs. The UI warns visitors not to enter personal information.
- Reopened the current official AROUSH homepage, About, Courses, Gallery, Contact, CCNA and CCNA DevNet pages. The 20-course catalogue, current featured prices, three team profiles, ten training photographs and two office addresses remain represented with existing conflict/approval safeguards.
- Refreshed UX-only research for Apna College, i-Medita and PyNet Labs. No competitor claims, prices, statistics, ratings, testimonials or guarantees were copied.
- The exact Session 43 checks and blockers are in `SESSION-43-REPORT.md`, `LIVE-SOURCE-REVIEW-2026-11-07-SESSION43.md`, `COMPETITOR-REVIEW-2026-11-07-SESSION43.md` and `VALIDATION-REPORT-2026-11-07-SESSION43.md`.
- Production typecheck/build/lint/audit and real-device QA remain blocked or pending until Node.js 24, npm registry access, dependencies and a reviewed lockfile are available.
- GA4 remains blank and disabled. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 42 — 7 November 2026

- Improved the shareable course catalogue for phones: use the native Web Share API when available, fall back to clipboard copy otherwise, and treat a visitor-cancelled share as a cancellation without copying unexpectedly.
- Capped course search at 100 characters in the input and URL parser/serializer. The search help now associates the input with both the result count and the reminder that search text appears in the URL.
- Expanded catalogue URL and UX regression checks. `npm run check:offline` passes all 23 dependency-free validators; chatbot: 47 cases; enquiry paths: 33 checks; email-draft safety: 19 checks; outline filter: 17 checks; TypeScript/TSX syntax: 38 files; JavaScript syntax: 34 files.
- Reopened the official AROUSH homepage, About, Contact and public course pages. The live homepage still has three zero-value counters and 16 unrelated gambling/betting footer links; rebuild excludes them and the authorised WordPress/hosting investigation remains outstanding. CCNA/CCNA DevNet fee conflicts and the incomplete J.P. Nagar training-centre address remain unresolved.
- Refreshed UX-only research for Apna College, i-Medita and PyNet Labs. No competitor claims, prices, ratings, testimonials or guarantees were copied.
- Production typecheck, ESLint and Next.js build remain blocked: Node.js 22.16.0 vs required 24.x, npm registry DNS `EAI_AGAIN`, no lockfile and no installed dependencies. Real Android/desktop testing, including Web Share API behavior, remains pending.
- GA4 remains disabled and unconfigured. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made. See `SESSION-42-REPORT.md` and the Session 42 source/competitor/validation reports.

## Latest session 41 — 7 November 2026

- Added shareable course-catalogue URL state for keyword search, category, sort order and outline availability. A filtered view can be copied and restored when opened by another visitor.
- URL updates preserve unrelated query parameters and handle browser `popstate`; invalid category/sort/outline values fall back to safe defaults. Reset removes only catalogue parameters.
- Added a clipboard copy action, accessible success/fallback announcement and a visible warning not to enter personal information in the search field because the query appears in the URL.
- Added a small URL helper and declaration plus dedicated tests. The feature is local-only and introduces no storage, analytics event, server endpoint or database.
- `npm run check:offline` passes all 23 dependency-free validators. TypeScript/TSX syntax: 38 files; JavaScript syntax: 34 `.mjs` files; CSS parsed with PostCSS.
- Production typecheck, ESLint, Next.js build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x, missing dependencies/lockfile and npm registry DNS failure (`EAI_AGAIN`). Real Android/desktop browser QA remains pending.
- Reopened the official homepage, About, Courses, Gallery, Contact, CCNA and CCNA DevNet; refreshed competitor UX reviews for Apna College, i-Medita and PyNet Labs.
- GA4 remains disabled and unconfigured; no CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 40 — 7 November 2026

- Added a course-catalogue outline-availability filter: all courses, courses with published outline topics, and courses whose syllabus needs AROUSH confirmation. Search, category filters, natural sorting and reset behavior work together.
- The filter uses only migrated source-backed outline records. CEH and Fortinet remain in the confirmation group because their legacy pages include provider-attributed material.
- Added a dependency-free outline-filter helper, TypeScript declaration and 17-assertion validator; wired it into the offline and release checks.
- Rechecked the official homepage, About, Courses, Gallery, Contact, CCNA and CCNA DevNet. The gallery shows ten training photographs plus a separate logo collage; the rebuild keeps the ten training photographs and excludes the collage.
- Refreshed competitor UX research for Apna College's course-family hierarchy, i-Medita's decision-stage FAQs and PyNet Labs' layered technical/career-path catalogue. No competitor claims or commercial figures were copied.
- `npm run check:offline` passes all 22 dependency-free validators. Chatbot: 47 cases; enquiry paths: 33 assertions; email-draft safety: 19 assertions; outline filter: 17 assertions; TypeScript/TSX syntax: 37 files; JavaScript syntax: 32 files.
- Production typecheck, ESLint, Next.js build and npm audit remain blocked: Node.js 22.16.0 instead of required 24.x, npm registry DNS `EAI_AGAIN`, no installed dependencies and no lockfile. Android/desktop browser QA remains pending.
- GA4 remains disabled and unconfigured. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made. See `SESSION-40-REPORT.md` and the Session 40 source/competitor/validation reports.

## Latest session 39 — 7 November 2026

- Fixed query-driven enquiry form state so changing learner/business/general path cards updates the form without losing unrelated visitor-entered fields. Course and course-message fields now follow changed course query parameters.
- Cleared stale prepared-email fallback links after edits or route/course changes.
- Hardened the local `mailto:` helper against CR/LF/control-character injection in subject and single-line fields; added length limits and safe multiline message handling.
- Added a dedicated enquiry-safety validator with 19 checks and expanded enquiry-path validation to 33 assertions. All 21 offline validators pass; chatbot remains at 47 cases; TypeScript/TSX syntax passes for 36 files and JavaScript syntax for 30 files.
- Refreshed official AROUSH homepage, About, Courses, Gallery, Contact, CCNA, CCNA DevNet, AI & ML and Agentic AI source review. Refreshed Apna College Prime, i-Medita FAQ and PyNet Labs course catalogue UX research.
- Production typecheck, ESLint, Next.js build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x, absent dependencies/lockfile and npm registry DNS failure (`EAI_AGAIN`). Android/desktop browser QA remains pending.
- GA4 remains disabled and unconfigured. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 38 — 7 November 2026

- Added separate individual learner, business/institution and general enquiry paths to `/contact`, with query-aware links from course details, learning paths, corporate training and service pages.
- The form adapts its optional fields to the selected path: course interest for learners; organisation and approximate team size for business/institution enquiries; a simple message path for general enquiries. Phone remains optional. The privacy notice now lists these optional fields.
- Added a small local email-draft helper and 27 assertions. The visitor's email app remains the only send action; no server endpoint, database, CRM, analytics event or persistence was introduced.
- Refreshed official AROUSH homepage, About, Courses, Contact, CCNA, AI & ML and Agentic AI pages. Refreshed Apna College, i-Medita and PyNet Labs UX research.
- `npm run check:offline` passes all 20 dependency-free validators; chatbot remains at 47 routing cases. TypeScript/TSX syntax passed for 36 files, JavaScript syntax passed for 29 files, and PostCSS parsed 604 rules/27 at-rules/2,001 declarations.
- Full typecheck, ESLint, Next.js production build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x (latest 24.x maintenance-LTS: 24.22.2), missing dependencies/lockfile and npm registry DNS failure (`EAI_AGAIN`). Android/desktop browser QA remains pending.
- GA4 remains disabled and unconfigured. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 37 — 7 November 2026

- Added an accessible in-browser course comparison feature for up to three courses. The comparison table shows only AROUSH-published category, outline availability, published duration and catalogue fee/confirmation status.
- Comparison selections stay in component memory only; no local/session storage, server endpoint, analytics event, database or CRM was added.
- Added the immutable `toggleComparedCourse` helper, TypeScript declaration, mobile-responsive comparison table, selected-state controls, live count and dedicated tests. Added the comparison validator to `npm run check:offline` and the release-config check.
- Reopened the official homepage, About, Gallery, Courses, Contact, CCNA, CCNA DevNet and both Agentic AI course pages. CCNA and CCNA DevNet remain fee conflicts (catalogue ₹19,999; individual pages ₹19,000). The homepage still has zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes them. The Agentic AI checkout destination remains unverified and blocked.
- Refreshed UX-only reviews of Apna College Prime, i-Medita FAQ and PyNet Labs course catalogue. No competitor prices, statistics, ratings, testimonials, credentials, schedules or guarantees were copied.
- `npm run check:offline` passes all 19 dependency-free validators. Course comparison tests cover add/remove, max-three selection, custom limits, immutable arrays, accessibility, published-only fields, fee conflict and local-only behavior. TypeScript/TSX syntax parsing passed for 35 files; JavaScript syntax checks passed for 27 `.mjs` files.
- Production preflight remains blocked: Node.js 22.16.0 instead of 24.x, no lockfile or installed dependencies, and npm registry DNS failure (`EAI_AGAIN`). Full typecheck reports missing Next.js/React modules, ESLint and Next.js binaries are unavailable, and npm audit reports `ENOLOCK`. Real browser QA remains pending.
- GA4 remains disabled and unconfigured. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 36 — 7 November 2026

- Refined the course catalogue sorting introduced in Session 35. A–Z and Z–A now use `Intl.Collator` natural numeric ordering, so numbered titles sort in human order (for example, 2 before 10).
- Corrected course-card sequence numbers so they follow the currently visible filtered/sorted list rather than the original catalogue index. The accessible live result message now announces whether the list is in AROUSH catalogue order, A–Z or Z–A.
- Expanded course-sort tests for numeric titles, empty results, visible result numbering, sort announcements and source immutability. Updated UX and accessibility source validators.
- Reopened the live AROUSH homepage and Contact page. The homepage still advertises 20+ courses/free demo and six course families; the Contact page still publishes the current email, phone and two office addresses. Zero-value counters, unrelated gambling/betting footer links and unapproved certification/job-assistance/24×7 claims remain excluded from the rebuild.
- Refreshed UX-only reviews of Apna College Prime, i-Medita FAQ and PyNet Labs Courses. No competitor prices, ratings, testimonials, claims, schedules or guarantees were copied.
- Offline source validation and the new natural-sort tests passed. Full typecheck, ESLint, Next.js build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x, absent dependencies/lockfile and npm registry DNS failure. Android/desktop browser QA remains pending.
- GA4 remains disabled and unconfigured. No CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 31 — 7 November 2026

- Reopened the current official AROUSH homepage, About, Courses, Gallery and Contact pages. The homepage still advertises 20+ courses/free demo and six course families, while also showing zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes those counters and links.
- Confirmed the About page still lists three team profiles and the Gallery still contains training/corporate-training photographs. Current office/contact details remain in the source register; the J.P. Nagar training-centre reference remains separate from the two published office addresses.
- Improved the enquiry experience: added a clear warning not to include passwords, API keys, access tokens, personal records or sensitive production logs; added mobile-friendly telephone/email input hints; added a FAQ and chatbot answer explaining that the form prepares an email draft and does not send/store details on the website.
- Expanded chatbot regression coverage to 46 intent-routing cases.
- Refreshed Apna College Prime, i-Medita FAQ/CCNA and PyNet Labs catalogue/contact UX research. Only curriculum grouping, FAQ discoverability, course filtering and human-guidance patterns were retained.
- `npm run check:offline` passes all 15 dependency-free validators. TypeScript/TSX syntax passed for 30 files using TypeScript 5.8.3; 20 `.mjs` files passed syntax checks; CSS/PostCSS parsed 521 rules and 20 at-rules in the latest package source.
- Node runtime check: Node.js 22.16.0 / npm 10.9.2. A fresh `npm view next@15.5.29 version` attempt failed with `EAI_AGAIN` resolving `registry.npmjs.org`. No Node 24 runtime, dependency install or lockfile is available, so full typecheck, ESLint, Next.js build and npm audit remain blocked.
- GA4 remains disabled and unconfigured; no CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 28 — 7 November 2026

- Reopened the current official homepage, About, Courses, Gallery, Contact, AI & ML, CCNA, both Agentic AI course pages and Fortinet detail page. The 20-course catalogue and published fees remain visible; the homepage still contains 16 unrelated gambling/betting footer links.
- Added rule-based chatbot answers and quick replies for the Agentic AI with LangGraph/LangChain and LangChain/Hugging Face outlines. Neither source page publishes a duration, so the assistant explicitly directs visitors to confirm schedule details.
- Expanded chatbot tests to 42 intent-routing cases, including source-topic assertions, quick-reply presence and unknown-question handoff.
- Confirmed the Fortinet long-form source page explicitly attributes training to I-Medita; its syllabus remains withheld. Reviewed AI & ML and Agentic AI pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`; the destination was not opened or copied and is now an owner verification item.
- Refreshed competitor UX notes for Apna College Prime, i-Medita FAQs/course pages and PyNet Labs catalogue/contact.
- `npm run check:offline` passes all 15 dependency-free validators. TypeScript/TSX syntax passes for 29 files; 20 `.mjs` files pass syntax checks; PostCSS parsed 518 rules and 20 at-rules.
- Full typecheck, ESLint, production build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x, missing dependencies and lockfile, and unavailable npm registry DNS. Android/desktop browser QA remains pending.
- GA4 remains disabled and unconfigured; no CRM/server-side lead database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 26 — 7 November 2026

- Added a repeatable TypeScript/TSX parser check using local TypeScript when installed and a global TypeScript fallback when available; included it in `npm run check:offline` and release-config validation.
- Corrected Mohammed Khalid's published team-role wording against the current About page and added a content assertion.
- Reopened the live homepage, About, Courses, Gallery and Contact pages, and refreshed Apna College, i-Medita and PyNet Labs UX notes. The same 16 unrelated gambling/betting footer links remain visible on the live homepage; owner/hosting investigation remains required.
- All 15 offline/source validators pass. The TypeScript syntax parser checked 29 `.ts`/`.tsx` files with TypeScript 5.8.3; a temporary malformed TSX negative test failed as expected and was removed.
- Full semantic typecheck, ESLint, Next.js build and npm audit remain blocked by Node.js 22.16.0 vs required 24.x, missing local dependencies, no lockfile and npm registry DNS failure (`EAI_AGAIN`). Real browser QA remains pending.
- GA4 remains disabled and unconfigured; no CRM/database, GitHub push, WordPress edit, DNS change or deployment was made.

## Latest session 24 — 6 November 2026

- Reopened the live AROUSH homepage, About, Courses, Gallery and Contact pages. The 20-course catalogue, three public team profiles, current published contact details and gallery context remain visible. The homepage still exposes 16 unrelated gambling/betting footer links; this remains an owner/hosting investigation blocker and does not by itself prove full compromise.
- Hardened external-link scanning to detect and reject HTTP URLs, review protocol-relative URLs, and continue blocking known spam hosts/anchor phrases and unapproved external hosts. Added independent positive/negative tests for the policy.
- Added `npm run test:external-link-policy` to the offline validation chain and added `npm run preflight:release` to report the actual Node runtime, lockfile and installed dependency state before release work.
- All 13 dependency-free validators pass. The external-link scanner covers application, library, component, public SVG and Next.js configuration sources. TypeScript/TSX syntax transpilation passed for 27 files; PostCSS parsed 534 rules/at-rules; 18 `.mjs` files passed syntax checks.
- Release preflight confirms Node.js 22.16.0 instead of required 24.x, no `package-lock.json`, and missing Next.js/React/TypeScript/ESLint packages. `npm install --package-lock-only` timed out after `EAI_AGAIN` resolving `registry.npmjs.org`. Full typecheck, lint, build and npm audit remain blocked.
- No live WordPress, hosting, DNS, Search Console, GitHub repository or production deployment was changed.

## Session 22 — initial SEO-spam finding (6 November 2026)

- A fresh public crawl of the live AROUSH homepage exposed 16 unrelated gambling/betting footer links to 16 unrelated external domains. This is consistent with possible SEO-spam injection but does not prove the entry point or full WordPress/hosting compromise. The incident review and owner response checklist are documented in `docs/WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md`.
- Added `scripts/validate-external-links.mjs`, a fail-closed allowlist check that scans application/component/library source for the observed spam anchors/domains and for new external HTTPS hosts that have not been reviewed. Added it to `npm run check:offline` and the release-config validator.
- Reopened the current AROUSH homepage, About, Courses, Gallery and Contact pages. The 20-course catalogue, three team profiles, published contact details and two office addresses remain visible. Zero-value counters and unconfirmed job-assistance/24×7 lab claims remain excluded from the rebuild.
- Refreshed UX-only competitor review for Apna College SigmaX, i-Medita Courses and PyNet Labs Courses. Only programme comparison, technology grouping, visible curriculum and catalogue-discovery patterns were retained.
- All 13 dependency-free validators pass. The external-link validator scanned 32 source/config/static files and reviewed nine HTTPS hosts; no known spam domains, anchor phrases or unapproved external hosts were found in the rebuild source.
- Full TypeScript typecheck, ESLint, Next.js production build and dependency audit remain blocked by missing dependencies and the unavailable Node.js 24 runtime. Real Android/desktop browser QA remains pending.
- No live WordPress, hosting, DNS, Search Console, GitHub repository or production deployment was changed.

## Latest session 21 — 6 November 2026

- Added `npm run check:offline` so the complete dependency-free validation suite can be run separately from TypeScript's full semantic typecheck. The normal `npm run check` now runs the offline suite first and then `tsc --noEmit`.
- Added JavaScript syntax validation for every project `.mjs` file and release-configuration validation for the Node 24 pin, validation scripts, direct ESLint CLI command and blank GA4 Measurement ID.
- Migrated `npm run lint` from the deprecated `next lint` wrapper to `eslint .`, matching the Next.js 15.5 recommendation and avoiding a future Next.js 16 command break.
- Re-opened the AROUSH homepage, course catalogue and contact page, and refreshed Apna College Prime, i-Medita CCNA and PyNet Labs homepage/catalogue UX notes. Current AROUSH zero-value counters and unconfirmed job-assistance/24×7 lab claims remain excluded from the rebuild.
- All eight existing dependency-free validators plus the two new release/syntax validators pass. Full typecheck, lint, production build and dependency audit remain blocked by missing local dependencies; Node 22.16.0 is available instead of the project's Node 24 requirement, and npm registry DNS has returned `EAI_AGAIN`.
- No GitHub repository, live WordPress site, DNS, hosting or production deployment was changed.

## Latest session 20 — 6 November 2026

- Extracted the GA4 consent and page-view privacy rules into `lib/analytics-policy.mjs` so they can be tested without the Next.js runtime. The helper enforces valid Measurement ID + explicit visitor opt-in, normalises saved consent, strips query/hash values from page paths, reduces external referrers to their origin and builds a minimal page-view payload.
- Added `scripts/validate-analytics-policy.mjs` with dependency-free assertions and included it in `npm run check`. The privacy validator now checks that page metadata is not sent through the GA4 config call.
- Re-opened the current AROUSH homepage, About, Courses, Gallery and Contact pages, and refreshed UX-only research for Apna College, i-Medita and PyNet Labs. See `docs/SESSION-20-REPORT.md`, `docs/SOURCE-REGISTER.md` and `docs/COMPETITOR-REVIEW-2026-11-06.md`.
- All eight dependency-free validators pass. TypeScript/TSX syntax transpilation passed for 27 files (zero syntax diagnostics) and PostCSS parsed 430 top-level rules/at-rules. Full TypeScript typecheck reports missing Next.js/React/Node type packages; production build and lint return `next: not found`; dependency audit returns `ENOLOCK`. Node 22.16.0 is available instead of required Node 24.x, npm registry DNS fails with `EAI_AGAIN`, and dependencies/lockfile are absent.
- No GitHub repository, live WordPress site, DNS, hosting or production deployment was changed.

## Latest session 19 — 6 November 2026

- Improved the persistent analytics settings control: opening it now displays the saved preference without silently withdrawing consent. The visitor changes the choice only by explicitly selecting Allow or Reject; closing the panel keeps the current choice. Keyboard focus moves into the manually opened panel and returns to the trigger when it closes.
- Added a one-time GA4 bootstrap guard: first opt-in sends one initial pageview, and same-session re-acceptance sends one pageview only if GA4 was already bootstrapped. Client-side route changes remain handled separately.
- Updated the privacy notice and owner guide to explain the settings behavior and to require a staging check for one initial pageview after re-acceptance.
- Standardized the fee caution on homepage, catalogue and course-detail cards: “Website-listed amount; confirm current fee before payment.” This avoids presenting a changeable website amount as a final quotation.
- Rechecked the official AROUSH homepage, About, Contact and selected course pages, plus Apna College, i-Medita and PyNet Labs. The current AROUSH homepage lists 20+ courses, a free demo and featured course offers; Contact publishes the current email, phone and two office addresses. Legacy job-assistance/24×7-lab statements remain owner-review items.
- All seven dependency-free validators passed after the changes. Full TypeScript typecheck, Next.js production build, lint, dependency audit and real mobile browser tests remain blocked/pending because this environment has Node 22.16.0, no installed dependencies or lockfile, and npm registry DNS failure (`EAI_AGAIN`).
- No GitHub repository, live WordPress website, DNS, hosting or production deployment was changed.

## Latest session 17 — 6 November 2026

- Added a visible prepared-email fallback link after the contact form attempts to open the visitor's mail app; the form remains mailto-only and has no server endpoint or lead storage.
- Added a clear-all control whenever course search or category filters are active, not only when there are zero results.
- Added chatbot message auto-scroll and an explicit association between the question input and the rule-based support disclosure.
- Rechecked the live homepage, About, Courses, Gallery and Contact pages and refreshed competitor UX notes.
- Re-ran all six dependency-free project validators successfully. Full typecheck/build/lint/audit and real mobile tests remain blocked by Node 22 versus required Node 24, missing dependencies, and npm registry DNS failure (`EAI_AGAIN`).
- No live site, WordPress, DNS, GitHub repository or deployment changes were made.

# Project status — 7 November 2026

## Latest Session 46 — 7 November 2026

- Changed the contact form to show a complete email preview (recipient, subject and sanitised body) before opening the visitor's email app. The visitor must explicitly choose **Open email app** and then send the message themselves.
- Added a clear **Not sent** status, an **Edit enquiry** action and stale-preview clearing whenever the visitor edits any form field or changes the enquiry route.
- The preview exists only in React component state; no local storage, cookie, API, database, CRM, analytics event or server-side submission was added. Phone remains optional and the sensitive-data warning remains visible.
- Updated the FAQ and rule-based chatbot to describe the review-first flow. Corrected the cookie-consent implementation note so it accurately states that opening Privacy settings preserves the saved choice until the visitor explicitly selects Allow or Reject; added a validator to prevent that documentation mismatch from returning.
- `npm run check:offline` passed all 25 dependency-free validators. Enquiry-path checks: 37; email-safety checks: 22; chatbot: 47 cases; accessibility source scan: 31 TSX files; TypeScript/TSX syntax: 44 files; JavaScript syntax: 36 files.
- Reopened the live homepage, Courses, About, Gallery, Contact, CCNA and CCNA DevNet pages. The homepage still advertises 20+ courses and six themes; the catalogue lists 20 courses. CCNA/CCNA DevNet remain inconsistent at ₹19,999 in the catalogue versus ₹19,000 on their individual pages, so both numeric amounts remain withheld. The live homepage still shows three zero-value counters and 16 unrelated gambling/betting footer links; the rebuild excludes them and owner/hosting investigation remains required.
- Refreshed UX-only competitor research for Apna College, i-Medita and PyNet Labs. Only audience-first course discovery, practical FAQ grouping and technical category navigation were considered. No competitor commercial claims or statistics were copied.
- Production remains blocked: Node.js 22.16.0 instead of 24.x, missing dependencies and no reviewed lockfile. `npm run typecheck`, `npm run lint`, `npm run build` and `npm run audit` could not complete. Android/desktop browser QA and actual mail-app handoff remain pending.
- GA4 remains disabled with a blank Measurement ID. No CRM, server-side lead database, GitHub push, WordPress edit, DNS change, analytics-property change or deployment was performed.
- Details are in `SESSION-46-REPORT.md`, `LIVE-SOURCE-REVIEW-2026-11-07-SESSION46.md`, `COMPETITOR-REVIEW-2026-11-07-SESSION46.md` and `VALIDATION-REPORT-2026-11-07-SESSION46.md`.


## Latest Session 43 update

- Extended shareable course-catalogue URLs to include a selected comparison of up to three known course slugs. Opening a valid link restores the selected courses and automatically opens the comparison table.
- Added an allowlist based on the current catalogue, duplicate removal and a three-course maximum when parsing and serializing the `compare` URL parameter. Invalid or unknown slugs are ignored.
- The share action now uses a comparison-specific title and message when two or more courses are selected. Search/category/sort/outline filters can be shared with the comparison.
- The URL contains course slugs only; no personal data is added. The feature remains browser-side with no storage, API, database, CRM or analytics event.
- Current official-source review confirms the 20-course catalogue, published company mission/vision, three team profiles, ten training-gallery images, current homepage featured course amounts, and contact details. CCNA and CCNA DevNet fee conflicts remain unresolved.
- Refreshed competitor UX research for Apna College, i-Medita and PyNet Labs; only course-family navigation, practical FAQ grouping and category discovery patterns were considered. No competitor claims or commercial information were copied.
- Offline validation results and production blockers are recorded in `docs/SESSION-43-REPORT.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION43.md`.


## Latest session 7 update

- Added accessible stateful mobile navigation with `aria-expanded`, current-page state, Escape-to-close and close-after-navigation behaviour.
- Added a clear Fortinet syllabus review note and updated the catalogue/detail validator to require 20 detail records, 19 source-backed outlines and one owner-review note.
- Added baseline Next.js response headers for frame protection, MIME sniffing prevention, referrer policy, browser permissions and opener isolation.
- Revalidated all 20 public courses, ten service records, six SOC/SIEM learning paths, three team profiles, ten gallery references, eight target-industry profiles, two office addresses and two homepage testimonials.
- `npm run validate:content` passed; TypeScript/TSX syntax transpilation passed for 21 files; CSS brace structure passed; `next.config.mjs` syntax passed.
- Dependency installation is blocked in this environment by DNS resolution failure to `registry.npmjs.org` (`EAI_AGAIN`). Full production build and browser QA remain pending in Codespaces.
- No GitHub push, live WordPress change, DNS change or production deployment was performed.

## Completed in this work session

- Reviewed the live homepage, About, Courses, Gallery and Contact pages.
- Reviewed the current 2026 AROUSH company profile and brochure.
- Established a content hierarchy that uses the live website for currently published public information and the 2026 company documents as supporting material for expanded services, leadership and SOC/SIEM details; conflicts are flagged for approval.
- Built a responsive Next.js 14 + TypeScript public-site source package with eight primary routes: Home, About, Services, Courses, Corporate Training, Team, Gallery and Contact. The later course-detail migration adds 20 static course routes under `/courses/[slug]`.
- Migrated all ten service verticals with typical deliverables, intended audiences and scope notes.
- Migrated 20 named public courses from the live catalogue and six SOC/SIEM learning paths from the 2026 profile.
- Added current leadership profiles, company legal identity, CIN, contact details, FAQs and gallery references.
- Removed stale zero-value homepage counters, unverified vendor/placement claims and unsupported 24×7 SOC language. Copied all 20 live-site fee pairs with a clear website-listed/confirm-before-payment note.
- Added content audit, deployment plan and live-site security review notes.
- Content validation passed after expanding checks for ten services, 20 public courses and fee pairs, six SOC/SIEM paths, three leadership profiles, ten gallery references, eight target-industry profiles and the corporate training route.
- Added searchable/filterable course catalogue (search includes migrated outline topics), page-specific SEO metadata/canonicals, sitemap cleanup, skip-to-content link and visible keyboard focus styles.
- Expanded the gallery to ten live-site training photographs while excluding the unapproved client-logo collage.
- Added a dedicated `/training` landing page for corporate and campus learning, curriculum and lab-guide development, train-the-trainer engagements, delivery options and SOC/SIEM learning.
- Added eight target-industry profiles to Services and source-backed “Why choose AROUSH” and “The Aroush approach” sections to About.
- Added Training to the primary navigation, footer and sitemap.
- Added direct enquiry actions for each of the six SOC/SIEM learning paths.
- Improved the homepage service preview so it represents all four portfolio pillars (Connect, Secure, Support and Train).
- Expanded the enquiry form interest options and carry-through from training/course links, including the featured homepage courses.
- Corrected the legacy navigation issue: the current live “Meet Our Team” menu target resolves to the About page; the new site has a dedicated `/team` route.

## Not completed / blocked

- Full Next.js production build remains blocked: `npm install --no-audit --no-fund --prefer-offline` timed out in this environment and `node_modules` was not created. The content validation script runs successfully; full framework type/build checks still need to run in Codespaces.
- The source package has not yet been copied into the user's private GitHub repository/Codespace; no repository-write connector or authenticated Codespaces session is available in this run.
- Production domain is unchanged. No DNS, hosting, WordPress or Google Cloud deployment action has been taken.
- Logo and gallery images still load from the existing WordPress media URLs. Original assets should be downloaded and approved for local hosting before launch.
- Contact form currently prepares a mailto draft; a server-side lead API and CRM/email integration are not included.

## Owner decisions required before production

1. Confirm that both office addresses currently published on the live Contact page remain current. The supporting 2026 company profile lists a different JP Nagar address.
2. Confirm current fees, schedules and availability for the 20 public courses; the displayed amounts were copied from the live website and are not a final quote.
3. Approve the existing training photographs and logo for reuse on the new site.
4. Confirm the intended enquiry destination and whether the site needs a backend form, CRM integration or LMS.
5. Have the hosting/WordPress administrator investigate the unrelated gambling/promotion links observed in the live footer.

## Next technical steps

1. Upload `aroushtech-website-build-2026-11-06.zip` into the active `myPortfolio` Codespace.
2. Run `npm install`, `npm run validate:content` and `npm run dev`.
3. Preview on mobile and desktop; fix any runtime/build issues and verify every route.
4. Review owner decisions and approve production content.
5. Configure deployment, domain redirects, analytics, privacy/cookie requirements and secure enquiry handling.

## 6 November validation result

- `npm run validate:content`: passed after adding checks for the corporate training route, main-navigation link and unique SOC/SIEM course anchors.
- `npm install --no-audit --no-fund --prefer-offline`: timed out again; no dependency installation completed.
- TypeScript/TSX syntax transpilation passed for all 18 `.ts`/`.tsx` source files.
- Full `tsc --noEmit` and production build remain blocked by the unavailable Next.js/React dependencies after npm installation timed out.
- Browser-based mobile/desktop QA: not yet run. A standalone `tsc --noEmit` attempt also cannot complete without the missing Next.js/React dependencies; this is an environment dependency blocker, not a successful type-check.


## Follow-up source-of-truth corrections

- Rechecked the live homepage, About, Courses, Gallery and Contact pages on 6 November 2026.
- Corrected the public contact section to show both addresses exactly as currently published on the live Contact page (Corporate Office and Registered Office), with map links using the coordinates attached to those source-page links.
- Replaced the provisional JP Nagar profile address in the public contact UI and footer. The JP Nagar address is no longer presented as the website-published office address.
- Replaced mission and vision copy with the live About page wording (mission lightly edited for grammar without changing its meaning).
- Restricted team cards to the three names and role titles currently published on the live About page; education and experience claims from supporting documents are not displayed as live-site facts.
- Replaced the profile-only homepage quotation with the two student testimonials currently displayed on the live homepage.
- Rewrote public course descriptions to match the current live Courses page and retained all 20 currently published fee pairs with the confirm-before-payment notice.
- The current live site also displays 0-valued course/student/satisfaction counters; these remain excluded. Its homepage crawl exposes unrelated gambling/promotion links in the footer; this is flagged for WordPress/hosting investigation and no links from that footer are copied.

## Remaining source migration

- The 20 course catalogue summaries and fee pairs are migrated. Eighteen course-detail outline summaries are now included locally; ISE needs a source outline and Fortinet needs owner review because its legacy detail page contains a third-party provider reference.
- The new contact form still opens a prefilled email and does not store or submit leads to a server.
- Confirm that the two live-published office addresses remain current before production launch.

- Added the three team portrait image references from the live About page to both the Team and Corporate Training pages. These remain remote WordPress media references pending image-rights approval and local asset migration.


## 6 November 2026 — course-detail migration pass

- Rechecked the live homepage, Courses, About, Gallery and Contact pages. The live Courses page still lists 20 public courses with the fee pairs currently copied into the new catalogue.
- Added stable slugs to all 20 course records and created a dynamic local route at `/courses/[slug]` for each catalogue entry.
- Updated every catalogue card to open its own local course-detail page instead of sending visitors straight to the general contact form.
- Migrated source-backed outline summaries for 19 courses, including ISE from its linked live detail page. Fortinet has a dedicated owner-review note because its legacy detail page mixes AROUSH wording with content attributed to another provider; that material is not reproduced.
- Added course-specific metadata/canonicals, prerequisites and delivery notes only where those details were present on the source page.
- Kept the course fee pair from the live `/courses/` listing as the display source. Individual detail pages sometimes show older/different fee amounts; those were not copied over the current catalogue fee.
- Updated the mission statement to match the current live About page wording exactly.
- Made the contact form's interest field required.
- Updated the sitemap to include all 20 local course-detail pages.
- Content validation now checks 20 unique course slugs, the dynamic course-detail route and 18 source-backed outline records and matching catalogue slugs.

### Current validation

- `npm run validate:content`: passed (10 services, 20 public courses, 19 source-backed outlines plus 1 Fortinet owner-review note, 6 SOC/SIEM paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 office addresses and 2 testimonials).
- Full Next.js build and browser-based responsive QA remain pending because the package dependencies are not installed in this working environment.
- No changes have been pushed to GitHub or deployed to `aroushtech.in`.


## Latest session 8 update — 6 November 2026

- Rechecked the live homepage, About, Courses, Gallery and Contact pages. The public catalogue still contains 20 courses; the three homepage featured courses remain Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. The current homepage still shows zero-value counters and unrelated gambling/promotion footer links; neither is copied.
- Rechecked both office address links from the live Contact page. The published map destinations resolve to 12.9226818,77.6014636 for the corporate office and 12.902296,77.589056 for the registered office.
- Added 23 permanent redirects from legacy WordPress URLs: three old section paths and all 20 course-detail source paths.
- Added a reusable remote-image component with asynchronous decoding, eager/high-priority loading for the logo, and an accessible fallback when the existing WordPress media URL fails. Replaced direct `<img>` use across the logo, team, training and gallery surfaces.
- Moved the mobile-navigation breakpoint to 860px to avoid compressed tablet headers. The hidden mobile menu continues to respect its explicit hidden state.
- Updated the Services page wording so the ten expanded service areas are clearly identified as coming from the supporting 2026 company profile; specific capability, platform access, deliverables and availability remain proposal-confirmed.
- Added the source-published Tajuddin instructor introduction to the homepage using his existing team portrait.
- Added the AI & ML highlight from the live Courses page, clearly attributing the “Most Popular Course” label to the current AROUSH catalogue.
- Verified the official company LinkedIn page and replaced the previous numeric URL with its canonical company slug URL.
- Rechecked the Gallery page links: ten training/learner photographs are represented; a separate client-logo collage remains excluded. Three homepage company-certificate images could not be visually fetched and are pending inspection and reuse approval.
- `npm run validate:content`: passed, including 23 legacy redirects, 20 course-detail mappings, image fallback and responsive navigation checks.
- Global TypeScript 5.8.3 transpile syntax check passed for 22 `.ts`/`.tsx` files with zero diagnostics. `node --check` passed for `next.config.mjs` and the content validator.
- `npm install --no-audit --no-fund --fetch-retries=0 --fetch-timeout=25000` failed because DNS could not resolve `registry.npmjs.org` (`EAI_AGAIN`). Full framework type-check, production build and browser QA remain unverified.
- No GitHub push, live WordPress change, DNS change or production deployment was performed.

### Remaining owner / hosting decisions

1. Confirm current course fees, schedules and availability before launch; current amounts are copied from the live catalogue, not guaranteed quotes.
2. Approve the current logo, team portraits and gallery photos for local reuse; media URLs still point to the existing WordPress host.
3. Supply AROUSH-approved Fortinet syllabus content; the mixed-provider legacy page remains excluded.
4. Confirm whether the live FAQ claims about certificates, job assistance and 24/7 lab access remain accurate and authorized.
5. Have the hosting administrator investigate the unrelated footer links before migration; a public crawl cannot establish the cause or whether the WordPress environment is compromised.
6. Choose the secure enquiry destination (email service/CRM) and approve any privacy/consent wording before adding a server-side lead API.

### Next technical steps

1. Install dependencies in the user's GitHub Codespace, where package registry access may be available.
2. Run `npm run validate:content`, `npx tsc --noEmit`, `npm run lint` and `npm run build`.
3. Test all 28 public routes at mobile, tablet and desktop widths, including the 23 legacy redirects and the menu keyboard flow.
4. Migrate approved media into local assets and test image loading without the old WordPress host.
5. Configure the preview deployment and only then plan the production migration.

## Latest session 9 update — 6 November 2026

- Rechecked the live homepage, About, Courses and Contact pages. The 20 public course title/fee pairs in the local catalogue match the current Courses page snapshot.
- Confirmed the live homepage still contains zero-value counters and unrelated gambling/promotion footer links; neither is copied into the new site.
- Confirmed the live Contact FAQ still advertises certification, “100% job assistance” and “24/7 lab access”; these remain excluded pending written owner approval.
- Added Schema.org Organization and WebSite structured data using published company identity, contacts, LinkedIn and office details.
- Added Course and BreadcrumbList structured data to all course-detail routes; intentionally omitted offers, ratings, reviews, schedules and certification claims.
- Extended content validation to check structured-data coverage and prevent unsupported Offer/AggregateRating markup.
- `npm run validate:content`, `node --check next.config.mjs` and `node --check scripts/validate-content.mjs` passed.
- Full Next.js build and browser QA remain pending because dependencies are not installed; previous npm installation attempts failed on package-registry DNS (`EAI_AGAIN`).
- No GitHub push, live WordPress change, DNS change or production deployment was performed.

### New owner confirmation item

- The registered-office address link and the embedded map on the live Contact page use slightly different coordinates. Confirm the correct public pin before launch.
- The homepage newsletter block has no verifiable subscription endpoint, consent flow or retention information in the public crawl; it is not reproduced until a provider and privacy process are approved.


## Session 10 update — 6 November 2026

### Maintainability improvements

- Reworked the shared site layout, header, footer and contact form into expanded, consistently indented JSX with descriptive names and comments.
- Reformatted the global stylesheet into readable multi-line CSS while preserving its existing selectors and declarations.
- Added `.editorconfig` and `.nvmrc` to make indentation and the recommended Node.js version consistent across developer environments.
- Added `docs/BEGINNER-DEVELOPER-GUIDE.md` with beginner-friendly instructions for running the site and updating company details, services, courses, team profiles and pages.
- Updated the README with the page map, simple setup commands, source rules and production limitations.
- Added `npm run check` as a shortcut for content validation and TypeScript checking.
- Darkened the primary blue slightly after a contrast calculation showed the previous shade was just below the WCAG AA 4.5:1 target for white normal-size text; the revised shade measures approximately 5.19:1 on white.
- Expanded the AI & ML detail page from a short summary into 18 source-based outline items covering all seven modules visible on the current public course page.
- Added the live homepage’s free-demo message to the course page with wording that asks visitors to confirm availability for their selected course and schedule.

### Validation performed in this session

- `node scripts/validate-content.mjs`: passed — 10 services, 20 public courses, 19 source-backed course outlines, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery references, 8 target-industry profiles, 2 office addresses, 2 testimonials, 28 public routes and 23 legacy redirects.
- `node --check next.config.mjs`: passed.
- `node --check scripts/validate-content.mjs`: passed.
- TypeScript/TSX syntax transpilation: 22 files, zero syntax diagnostics.
- CSS parsed successfully with PostCSS after formatting.
- Dependency installation was attempted again but failed because this environment could not resolve `registry.npmjs.org` (`EAI_AGAIN`). Therefore the complete framework type-check, ESLint run, production build and real browser QA are still not verified.

### Still required

- Run `npm install`, `npm run check`, `npm run lint` and `npm run build` in GitHub Codespaces or another network-enabled environment.
- Test all 28 routes and all 23 legacy redirects in a browser at mobile, tablet and desktop widths.
- Confirm current course fees and availability, approved Fortinet syllabus, office/map details, service delivery scope and marketing claims with the company owner.
- Approve and locally host the logo, team and gallery images.
- Configure an approved enquiry backend only if AROUSH wants leads stored instead of using the current email-app workflow.
- Obtain owner and hosting-admin approval before any live website or DNS migration.

No GitHub push, live WordPress edit, DNS change or production deployment was performed.


## Dependency security update — 6 November 2026

- Replaced the previous Next.js 14.2.35 / React 18.3.1 baseline with Next.js 15.5.29 / React 19.3.1 and matching React type packages. The Next.js 14.2.35 package has published security advisories; the 15.5.28+ release line includes fixes for the listed 2026 issues.
- Updated the course-detail route's `params` and the contact page's `searchParams` to the asynchronous Promise-based App Router API required by Next.js 15.
- Moved the runtime baseline to Node.js 24 LTS and matching Node 24 type definitions; Node 20 is end-of-life, while Node 24 remains an LTS line.
- Kept the framework change limited to the minimum needed for the patched release line; no new UI library or application dependency was added.
- The package versions are pinned. A lockfile has not yet been generated because npm registry DNS failed in this environment. Run `npm install` in a network-enabled Codespace, review the generated lockfile and run the full build and audit before production.
- The source-level syntax and content checks can run without dependencies, but they do not prove the upgraded framework build or deployment is valid.

### Environment limitation after the dependency upgrade

The latest `npm install` attempt on 6 November 2026 failed before downloading packages with `EAI_AGAIN` while resolving `registry.npmjs.org`. This execution environment currently runs Node.js 22.16.0, while the project now correctly requests Node.js 24.x; therefore the upgraded dependency installation, `npm run typecheck`, `npm run lint`, `npm run build` and `npm run audit` have not been run here. The 22-file TS/TSX transpilation check is a syntax check only, not a substitute for those commands.


## Session 11 update — 6 November 2026

- Expanded the rule-based website assistant with contextual answers and links for course discovery, CCNA, fees, batch dates, training formats, corporate training, SOC/SIEM, services and contact details.
- Added caution around unverified prices, schedules, placement/certification promises, 24×7 lab access and managed SOC monitoring.
- Improved keyboard focus, live announcements, button states and added the missing SOC/SIEM section anchor.
- `npm run validate:content`, Node config/script syntax checks and CSS brace balance passed.
- Full framework type-check, ESLint, production build, dependency audit and browser QA remain blocked by Node 22.16.0 in this environment and missing `node_modules`; the project requires Node 24.x.
- No GitHub push, live website edit, WordPress change, DNS update or production deployment was performed.

## Latest session 13 update — 6 November 2026

- Hardened the optional GA4 integration: a valid owner-supplied Measurement ID and explicit visitor opt-in are both required before the analytics scripts load.
- Kept the Measurement ID blank in `.env.example`; the current project package does not contain a configured GA4 ID.
- Added reject, withdrawal and re-acceptance behavior. Opening the persistent Privacy settings control withdraws the current choice and disables GA collection until the visitor chooses again.
- Disabled Google Signals and advertising personalisation in the GA4 configuration; no visitor user ID, phone, name, email or enquiry text is sent by this integration.
- Expanded `/privacy` with the provider, reporting scope, pseudonymous event-data disclosure, approximate geography limitations, optional phone handling, owner retention/setup actions and legal-review requirements. The page dynamically reflects whether a GA4 Measurement ID is configured for the build.
- Clarified the optional phone field so visitors know to supply a number only if they want a phone response. The form remains a local `mailto:` draft.
- Added a dependency-free privacy validator and included it in `npm run check`.
- Rechecked Apna College, i-Medita and PyNet Labs UX patterns; documented current lessons without importing competitor claims, prices, ratings, testimonials, schedules or statistics.
- `node scripts/validate-content.mjs`: passed (29 routes and 23 redirects, including the privacy route).
- `node scripts/validate-privacy.mjs`: passed (opt-in only, blank ID by default, reject/withdrawal, persistent settings, no user ID/phone fields in analytics, voluntary phone form and no server-side lead/CRM integration).
- Full TypeScript typecheck, ESLint, production build, dependency audit and browser/device tests remain unverified because dependencies are absent, the available runtime is Node 22.16.0 instead of the required Node 24.x, and npm registry access has previously failed.
- No GitHub repository, live WordPress site, DNS or production deployment was changed.

### Analytics activation is still an owner decision

No GA4 property or Measurement ID was created. Before activation, the owner must supply the ID, confirm the GA4 property is company-controlled, choose the shortest suitable retention period, review Enhanced Measurement and Google Signals/advertising settings, approve the privacy contact and enquiry retention policy, and obtain legal review. See `docs/VISITOR-ANALYTICS-AND-LEADS.md`.

## Session 14 update — 6 November 2026

- Combined the owner-approved 3D AROUSH Solutions logo with the latest privacy-first analytics implementation. The original 4096 × 4096 PNG remains unchanged; a transparent 1000 × 915 WebP derivative is now used in the header, homepage, footer, chatbot and Organization structured data.
- Kept the readable wordmark and favicon and added `scripts/validate-brand.mjs` for asset presence, placements, accessible text and responsive brand styles.
- Improved the rule-based chatbot's keyboard flow: focus moves to the question field when opened, Escape closes it, focus returns to the launcher, new messages are announced and typed questions are capped at 500 characters.
- Reworked the contact form for readability, validated incoming enquiry categories, added a General enquiry fallback, capped field lengths and kept phone voluntary.
- Added `scripts/validate-ux.mjs` to check chatbot, course discovery, contact privacy and the absence of unapproved lead/CRM functionality.
- Updated cookie/privacy documentation to match the actual Allow/Reject and persistent Privacy settings implementation.
- Rechecked Apna College's audience-segmented learning path, i-Medita's category/instructor/demo discovery and PyNet Labs' course-category/career-path navigation. Only UX patterns were used; competitor marketing claims were not copied.
- `node scripts/validate-content.mjs`, `node scripts/validate-privacy.mjs`, `node scripts/validate-brand.mjs` and `node scripts/validate-ux.mjs` passed after the updates.
- Global TypeScript 5.8.3 transpilation passed for 25 `.ts`/`.tsx` files with zero syntax diagnostics. Global PostCSS parsed the stylesheet (396 top-level rules/at-rules). Node syntax checks passed for the Next config and all validation scripts.
- Full `npm run typecheck` remains blocked by missing `next` and React type packages. `npm run build` and `npm run lint` return `next: not found`; `npm run audit` requires a lockfile. A fresh dependency install again failed with `EAI_AGAIN` resolving `registry.npmjs.org`. Available Node is 22.16.0; the project requires Node 24.x.
- No GitHub repository, live WordPress site, DNS or production deployment was changed.

## Session 15 — 6 November 2026

- Switched compact brand placements to an emblem-only derivative and retained the complete approved lockup in the footer and structured data. The owner-supplied original 4096 × 4096 PNG was verified byte-for-byte against the uploaded source.
- Added a homepage free-demo enquiry callout and matching rule-based chatbot answers for demo and privacy questions.
- Improved mobile navigation focus when opening the menu.
- Strengthened the GA4 owner setup and public privacy notice with a strict Enhanced Measurement event allowlist.
- Added an internal-link/redirect validator to the project's `npm run check` sequence.
- All five dependency-free content, privacy, brand, UX and link validators passed.
- Full typecheck, build, lint, audit and real browser/device tests remain blocked/pending because dependencies are absent, Node.js 24 is unavailable in this environment and npm registry access is restricted.
- No live site, WordPress, DNS, GitHub repository or deployment changes were made.

## Session 16 update — 6 November 2026

- Added `/learning-paths`, a goal-based discovery page using only the 20 existing public catalogue course slugs. Four collections cover networking/infrastructure, network security, cybersecurity/penetration testing, and cloud/automation/AI.
- Added the six SOC/SIEM learning options from the company-profile source, retaining their recorded durations and clear scope caveats.
- Explicitly stated that collections are browsing aids, not prerequisite sequences, formal certification paths or career guarantees.
- Linked the new page from the homepage learning section, course catalogue, footer and sitemap.
- Added `npm run validate:learning-paths` to verify all course slugs exist and no prerequisite claim is introduced.
- Refreshed public competitor UX research for Apna College, i-Medita and PyNet Labs; applied goal-based catalogue grouping without copying competitor claims or metrics.
- Content, privacy, brand, UX, link and learning-path validators passed. TypeScript/TSX syntax transpilation passed for 27 files; CSS parsing passed for 502 rules; Node syntax checks passed.
- Full TypeScript typecheck, Next.js build, lint and dependency audit remain blocked by missing dependencies, Node 22.16.0 versus required Node 24.x, no lockfile, and npm registry DNS failure (`EAI_AGAIN`). Real mobile/browser testing remains pending a working staging build.
- No GitHub push, WordPress edit, DNS update, hosting change or production deployment was performed.

## Session 23 update — 6 November 2026

- Reopened the current AROUSH homepage, About, Courses, Gallery and Contact pages. The same 16 unrelated gambling/betting footer links remained visible in the live homepage crawl; the finding is still an owner/hosting investigation blocker, not proof of the injection source.
- Added `scripts/validate-public-claims.mjs` and `npm run validate:public-claims` to block unapproved placement, hiring, top-rated, high-paying and unqualified 24×7 promises from public application source. The validator also checks that rendered course-price components retain the current-fee confirmation notice.
- Expanded the external-link anchor guard to catch the latest observed `casinomuhub` spelling.
- Improved course catalogue accessibility with explicit search/filter relationships to a stable results region and an association between the search field and live result count.
- Updated the live-source, competitor and WordPress incident reports with this pass's evidence and limits.
- `npm run check:offline` passed all 12 dependency-free validators. External-link and public-claims negative tests both correctly rejected temporary unsafe fixtures; fixtures were removed and clean scans passed.
- JavaScript syntax passed for 15 `.mjs` files; TypeScript/TSX syntax transpilation passed for 27 files with zero diagnostics; PostCSS parsed 430 top-level rules/at-rules.
- Full typecheck, ESLint, Next.js build and npm audit remain blocked because dependencies and a lockfile are missing. A fresh npm install timed out after `EAI_AGAIN` resolving the registry. The environment has Node.js 22.16.0; the project requires Node.js 24.x.
- No live WordPress, DNS, GitHub repository, hosting or production deployment was changed.

## Session 27 update — 7 November 2026

- Rechecked the official AROUSH homepage, About, Courses, Gallery, Contact, CCNA and AI & ML pages. The homepage's 16 unrelated gambling/betting footer links remain visible and require authorised WordPress/hosting investigation before migration.
- Improved the course catalogue with outline-status labels, source-published durations where available, and a live count of filtered courses with published outline topics. The Fortinet detail remains marked for AROUSH syllabus confirmation.
- Added stable anchors to all numbered service sections and expanded the rule-based chatbot with direct links and source-grounded answers for eight specific service areas.
- Added a chatbot answer for the published AI & ML 40-hour course duration and topic outline, plus a quick reply. Unknown questions still route to the human team.
- Added `docs/COMPETITOR-REVIEW-2026-11-07.md` and updated source and developer documentation.
- `npm run check:offline` passed after the changes. Full typecheck, ESLint, production build and npm audit remain blocked by Node.js 22.16.0, missing dependencies and lockfile, and unavailable network/DNS. Real mobile/desktop browser QA remains pending.
- GA4 remains disabled with a blank Measurement ID; phone is voluntary; no CRM or server-side lead database was added.
- No live site, WordPress, DNS, GitHub repository or deployment was changed.


## Session 30 — 7 November 2026

- Compared the live Courses catalogue with CCNA and CCNA DevNet individual pages; both fee values conflict (₹19,999 catalogue vs ₹19,000 detail page). The rebuild now withholds numeric fees for both and the chatbot routes fee questions to the human team.
- Withheld CEH syllabus, duration and trainer claims because the live page attributes the instructor to UniNets. Fortinet remains withheld because its page includes I-Medita-attributed material.
- Added a shared `CoursePrice` component, updated the course data type and expanded content/chatbot regression checks.
- Replaced office coordinate pins with Google Maps search URLs generated from the published office addresses and added a training-centre location caveat.
- Refreshed the official source and competitor UX reviews.
- `npm run check:offline`: passed all 15 dependency-free validators; chatbot 45 cases; 30 TypeScript/TSX syntax files; 20 JavaScript files; 33 external-link scan files; CSS 521 rules/20 at-rules.
- Production remains blocked: Node 22.16.0 instead of 24.x, npm registry `EAI_AGAIN`, missing lockfile/dependencies, and no browser QA.


## Session 32 update — 7 November 2026

- Kept a compact set of chatbot quick replies visible after each answer and added an accessible expand/collapse control for the remaining verified prompts.
- Added a bounded scroll area for expanded chatbot prompts on small screens.
- Returned keyboard focus to the mobile navigation toggle after an in-menu route change.
- Reworked the 404 page into a recovery path for courses, services and human contact.
- Reopened the current official homepage, About, Courses, Gallery, Contact, CCNA, CCNA DevNet and AI & ML sources; recorded current facts and unresolved discrepancies in `LIVE-SOURCE-REVIEW-2026-11-07-SESSION32.md`.
- Refreshed Apna College, i-Medita and PyNet Labs UX research. No competitor commercial claims were copied.
- All 15 dependency-free validators passed. Chatbot routing remains 46 cases; additional assertions cover persistent quick replies and expansion state.
- Runtime remains Node.js 22.16.0, not the required 24.x. npm registry DNS still fails with `EAI_AGAIN`; no dependencies or lockfile are available, so full typecheck, lint, production build and audit remain blocked. Browser/device QA is pending.
- GA4 remains disabled with a blank Measurement ID; no server-side lead database or CRM was added. No live WordPress, DNS, GitHub or deployment changes were made.


## Session 33 update — 7 November 2026

- Added a dedicated `/faqs` page with 12 verified questions grouped into Courses & learning, Location & enquiries, and Services & business enquiries.
- Added FAQ navigation in the header/footer, a contact-page FAQ shortlist and full-page link, sitemap registration, and a chatbot FAQ quick reply/answer.
- Added `validate:faqs` to the offline validation sequence and release checks.
- `npm run check:offline`: all 16 dependency-free validators passed; chatbot 47 cases; TypeScript/TSX syntax 31 files; JavaScript syntax 21 files; accessibility scan 24 TSX files; internal paths 31; external-link scan 34 files/9 HTTPS hosts; CSS 538 rules/22 at-rules/1,754 declarations.
- Fresh official source review covered homepage, About, Courses, Gallery, Contact, AI & ML and both Agentic AI pages. Current fee conflicts, unverified checkout links, incomplete training-centre address and suspicious homepage footer links remain documented for owner action.
- Competitor UX research refreshed for Apna College, i-Medita and PyNet Labs; only transferable navigation, FAQ and course-discovery patterns were used.
- Runtime remains Node.js 22.16.0, not required 24.x. npm registry ping returns `EAI_AGAIN`; no `node_modules` or lockfile exists. Full typecheck, ESLint, Next.js build and npm audit remain blocked; real browser/device QA is pending.
- GA4 Measurement ID remains blank and analytics disabled until owner configuration plus visitor opt-in. No CRM or server-side lead database was added. No live site, WordPress, DNS, GitHub repository, analytics property or deployment was changed.

## Latest session 35 — 7 November 2026

- Added A–Z and Z–A sorting to the course catalogue while preserving AROUSH's source order as the default. Search, category filters and sorting work together; reset clears all three.
- Added a pure, non-mutating `sortCourses` helper and five behavior assertions plus UI/accessibility/mobile integration checks.
- Added `npm run validate:course-sort` to the offline check and release validation.
- Reopened the official homepage, Courses, About, Contact, Gallery, AI & ML, CCNA and CCNA DevNet pages. Homepage featured course prices (Agentic AI with LangChain & Hugging Face ₹35,000; CCNP Security ₹45,000; CEH ₹25,000) match the current catalogue snapshot. CCNA and CCNA DevNet remain conflicting (catalogue ₹19,999 vs detail ₹19,000); numeric prices remain withheld.
- Refreshed Apna College, i-Medita and PyNet Labs UX research. No competitor commercial claims were copied.
- `npm run check:offline`: all 18 dependency-free validators passed; course-sort assertions passed; chatbot 47 cases; TypeScript/TSX syntax 34 files; JavaScript 25 files; accessibility scan 25 TSX files; internal routes 31; external-link scan 39 files/9 HTTPS hosts.
- Production remains blocked: Node 22.16.0 instead of 24.x, npm registry DNS `EAI_AGAIN`, missing dependencies and lockfile. Full typecheck, ESLint, Next.js build and npm audit cannot complete; Android/desktop browser QA remains pending.
- GA4 remains disabled with blank Measurement ID. No server-side lead database/CRM, live WordPress edit, DNS change, GitHub push, analytics property change or deployment was made.

## Session 47 — 7 November 2026: visitor-intelligence security hardening and competitor UX review

- Integrated the owner-approved visitor-intelligence companion app as a separate Next.js application under `apps/visitor-intelligence`; the root marketing website remains separate and unchanged at runtime.
- Reworked analytics to aggregate-only reporting: no persistent visitor ID, visitor profile table, raw/masked IP, device fingerprint, screen size, locale/timezone or individual visitor journey. A random tab-scoped token is HMAC-hashed server-side only to group page views within that temporary tab session and calculate approximate visit time. Consent is required before tracking; Reject and persistent Privacy settings are available.
- Hardened OTP and lead flows with atomic SQL RPCs for recipient send cooldowns, email OTP attempts/one-time success, single in-flight SMS verification and one-time lead creation. Added HMAC-keyed rate limits, bounded JSON bodies and server-side Cloudflare Turnstile Siteverify for admin login, OTP sends and final lead submission. Production fails closed when Turnstile is not configured.
- Added 54 dependency-free visitor-intelligence source checks. Full offline suite passes, including content, privacy, aggregate analytics, OTP, Turnstile, accessibility, navigation, course discovery, chatbot, JavaScript and TypeScript syntax checks.
- Completed fresh UX research for Apna College, i-Medita and PyNet Labs and documented transferable patterns in `docs/COMPETITOR-REVIEW-2026-11-07-SESSION-47.md`. Existing AROUSH search/filter/compare/share, learning paths, course outlines, team profiles, FAQs and grounded chatbot already cover most of the useful patterns; no competitor claims or numbers were copied.
- Updated the visitor-intelligence README, Android setup guide, dual-site integration plan, privacy notice draft and security review. The root website privacy notice now states that the companion app is not deployed or connected.
- Corrected four missing type-export errors by pairing `.mjs` modules with `.d.mts` declaration files and fixed the course-detail missing-course branch to narrow correctly. The remaining semantic check is still blocked by missing Next/React/Node dependencies.
- **Validation:** `npm run check:offline` passed. TypeScript syntax parser passed for 70 `.ts/.tsx/.mts` files; JavaScript syntax passed for 38 `.js/.mjs` files.
- **Release blockers:** runtime is Node.js 22.16.0 while both apps require Node.js 24.x; no package lockfile or local dependencies exist. Full semantic typecheck reports missing Next/React/Node modules, and both Next.js builds fail with `next: not found`. Provider credentials/accounts, Supabase RLS and RPC integration tests, Turnstile provider tests, real email/SMS delivery, retention approval/legal review and Android/desktop browser QA remain pending.
- No live website, WordPress, DNS, GitHub repository, hosting account, GA4 property, Supabase project, Resend account, MSG91 account or Cloudflare account was changed. No tracker was installed. No deployment was performed.
