# Competitor UX review — Session 43

Date: 7 November 2026

This is an information-architecture and interaction review only. Do not copy competitor prices, discounts, ratings, student counts, testimonials, credentials, placements, schedules or guarantees.

## Apna College

Official reference: https://www.apnacollege.in/

The current homepage exposes several distinct programme families (including Prime 3.0, SigmaX, Alpha Plus, Sigma 12 and Delta) and links visitors to curriculum and learning resources. The transferable pattern is clear programme-family entry points and easy access to curriculum. AROUSH keeps its own course names, categories, content and claims. A current time-limited promotion on the competitor site is not copied.

## i-Medita

Official reference: https://www.imedita.com/frequently-asked-questions/

The FAQ page surfaces practical questions about training location and schedules alongside course/training navigation. AROUSH keeps its own grouped, searchable FAQs and directs uncertain venue, timing and availability questions to the human team.

## PyNet Labs

Official references:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

The current catalogue groups technical programmes by domains and career directions, including automation, AI, SD-WAN, data, data centre, routing/switching, network security, cloud and cybersecurity. AROUSH keeps its own category taxonomy and course records. The shareable course-comparison URL is a site-specific improvement and does not import PyNet Labs' course details or marketing claims.

## Applied direction

- Keep AROUSH's own category names and featured order.
- Keep course search, category, sort and outline availability as separate controls.
- Let a visitor share a selected comparison of up to three AROUSH courses.
- Validate shared course slugs against the current AROUSH catalogue, remove duplicates and cap the selection at three.
- Open the comparison table automatically when a valid shared URL contains two or three courses.
- Keep unanswered questions and time-sensitive course details routed to the AROUSH human team.

No competitor claims, commercial terms, statistics or guarantees were imported.
