# Live source review — 6 November 2026

Primary source: https://aroushtech.in/
Review scope: homepage, About, Courses, Gallery, Contact, Cisco ISE detail, Fortinet detail, and the homepage's linked featured courses.

## Confirmed current public content

- Homepage: https://aroushtech.in/ — three featured courses are Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. The page also advertises a free course demo and contains two student testimonials and an instructor introduction.
- About: https://aroushtech.in/aboutus/ — vision, mission, three named team profiles and role titles. The “Meet Our Team” menu item resolves to this page rather than a dedicated team page.
- Course catalogue: https://aroushtech.in/courses/ — 20 public courses with published previous/current fee pairs. The new catalogue mirrors those 20 pairs and displays a reconfirmation notice.
- ISE detail: https://aroushtech.in/ciscoise/ — linked from the catalogue; includes a course outline, prerequisites, one-month duration and online-weekend format. This has now been migrated to the local ISE detail route.
- Fortinet detail: https://aroushtech.in/fortinet-certified-engineer/ — contains extensive I-Medita-branded text. Do not reproduce this as AROUSH-authored content. Retain only the AROUSH catalogue title/summary/fee until owner-approved copy is supplied.
- Gallery: https://aroushtech.in/gallery/ — ten training/learner photos and corporate-training narrative. The new site retains ten image references but avoids turning image captions into customer endorsements.
- Contact: https://aroushtech.in/contact-us/ — email `taj@aroushtech.in`, phone `+91 88676 92074`, corporate office and registered office addresses, and FAQ claims.

## Issues not copied into the redesign

1. Homepage counters display zero values. They are omitted rather than replaced with invented statistics.
2. Homepage footer exposes unrelated gambling/promotion links to unrelated domains. The redesign omits them. The live WordPress/hosting stack needs forensic review; the crawl alone does not identify the cause.
3. Contact FAQ claims certification, 100% job assistance and 24/7 lab access. The redesign does not repeat these claims pending written confirmation of current policy and actual delivery.
4. Legacy “Buy Course” links resolve to a third-party demo-site domain in the crawl. The redesign uses direct local course detail pages and contact enquiries instead.

## Current rebuild changes from this review

- Migrated the ISE detail syllabus, prerequisites, duration and delivery notes; 19 of 20 courses now have source-backed detail outlines.
- Kept Fortinet's detail outline on hold due to third-party-attributed course and delivery copy; the local course page now explains the reason and requests an AROUSH-approved syllabus.
- Aligned homepage featured courses to the three currently featured on the live homepage.
- Kept the 20 catalogue course records and listed fee pairs; visitors are told to confirm current fees and availability before payment.
- Preserved the two published office addresses, the three current team profiles and ten gallery photo references.

## Decisions still needed from AROUSH

- Supply approved original Fortinet syllabus copy or authorize a rewrite from an AROUSH-owned syllabus.
- Confirm whether the Contact FAQ promises about certification, placement assistance and 24/7 lab access are still accurate and authorized.
- Confirm current course prices, schedules, prerequisites, lab access and availability before launch.
- Confirm permission to reuse all current team and training photographs locally.
- Have the website/hosting administrator investigate the suspicious footer links and review administrator accounts, plugins, themes, database content, redirects, scheduled tasks and hosting files.


## Session 7 follow-up — 6 November 2026

- Re-opened the live homepage, About, Courses, Contact and Fortinet detail page. The live catalogue still lists 20 courses and the two office addresses remain as published.
- Reconfirmed that the Fortinet page includes AROUSH-branded introductory wording but also explicitly attributes course and delivery material to I-Medita. The new site does not reproduce that mixed-provider syllabus or schedule.
- Added an explicit Fortinet owner-review note to the local detail route, while retaining only the title, short catalogue description and current catalogue fee pair.
- Replaced the passive mobile `<details>` menu with an accessible stateful navigation component: expanded state, current-page indication, Escape-to-close, and automatic close after route selection.
- Updated the content validator to require all 20 course detail records, 19 migrated outlines, the Fortinet review note and mobile navigation accessibility hooks.

## Session 8 live-source recheck — 6 November 2026

- Homepage: https://aroushtech.in/ — current crawl still shows the three featured courses (Agentic AI with LangChain & Hugging Face, CCNP Security, CEH), two student testimonials, a Tajuddin instructor introduction, zero-value counters, and unrelated gambling/promotion footer links.
- About: https://aroushtech.in/aboutus/ — current vision and mission wording, three named team profiles and their published role titles remain visible.
- Courses: https://aroushtech.in/courses/ — 20 public course entries and all current displayed fee pairs were rechecked. The rebuild retains the 20 entries and asks visitors to confirm price and availability before payment.
- Gallery: https://aroushtech.in/gallery/ — the page links to ten training/learner photographs and a separate client-logo collage. The rebuild represents the ten photographs and excludes the collage so it does not imply unverified customer relationships. The page also contains a placement-outcome statement and names Larsen & Toubro Infotech Ltd, Capgemini and NTT Level 1 & Level 2 in its corporate-training narrative; those claims/references remain pending owner approval before reuse.
- Contact: https://aroushtech.in/contact-us/ — the email, phone and two office addresses remain published. The two address links resolve to map destinations 12.9226818,77.6014636 and 12.902296,77.589056 respectively.
- Homepage certificate area: three image links are present, but the images could not be visually fetched during this review. They are not copied into the rebuild until the certificate contents and permission to display them can be verified.
- About page trainer-certification/prior-company wording and Contact FAQ claims about certification, “100% job assistance” and “24/7 lab access” are present on the live source but are not carried into the new site until the owner confirms their current accuracy and approved wording.
- Added the current homepage's short Tajuddin instructor introduction to the new homepage. The text is attributed to the current source page and is not expanded into additional qualification claims.
- Added permanent redirects for all 20 legacy course-detail paths plus old About, Contact and team paths; see `ROUTE-MIGRATION.md`.

## Additional public-page check — 6 November 2026

- The current AI & ML detail page states a 40-hour live/intensive programme, lists a seven-module outline and names Mr. Tajuddin as instructor. The rebuild retains the 40-hour duration and now expands the visible seven modules into 18 readable outline items; the published course catalogue amount is shown separately with a reconfirmation notice.
- The root homepage currently names the networking/cybersecurity instructor as Tajuddin. The alternate `/home/` page crawl uses the spelling “Taluqdar” for its instructor introduction. The About page also lists Tajuddin. The rebuild uses the root homepage/About spelling and flags the alternate-page discrepancy for owner confirmation rather than creating a fourth team profile.
- The root homepage continues to publish three featured-course promotional amounts. The course catalogue and individual course pages should be checked together before each campaign or price update so promotional and catalogue amounts do not drift.

## Current maintenance pass — 6 November 2026

Reopened the official homepage, About, Gallery, Courses and Contact pages. The homepage still advertises a free course demo, the same three featured courses, and shows zero-value counters; the redesign retains the demo enquiry path and omits the zero counters. The About page continues to publish the three leadership names/roles; Gallery continues to expose ten training/learner photographs; Courses continues to list 20 public course entries and fee pairs; Contact continues to publish `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses.

The current redesign now surfaces the free-demo enquiry on the homepage as well as the catalogue and chatbot. It explicitly asks visitors to confirm eligibility and timing with the team. It does not turn the homepage's general free-demo message into an availability promise for every course.

The logo compact-placement review found that the full lockup was too small to read in the header and chatbot. A square emblem-only derivative is now used in compact positions; the full lockup remains in the footer and structured data. The owner-provided original PNG remains byte-for-byte unchanged.

## Session 17 live-source recheck — 6 November 2026

The official homepage, About page, course catalogue, Gallery and Contact page were reopened during this pass:

- Homepage: https://aroushtech.in/ — still promotes 20+ job-ready courses, a free demo, and the featured Agentic AI with LangChain & Hugging Face, CCNP Security and CEH courses. It still shows zero-value counters; the rebuild continues to omit them.
- About: https://aroushtech.in/aboutus/ — still lists the vision, mission and three team profiles/roles. Zero-value counters and broad trainer-experience claims remain excluded pending approval.
- Courses: https://aroushtech.in/courses/ — 20 course entries and their displayed fee pairs remain visible. The rebuild retains the 20 records with a clear note to reconfirm fees and availability before payment.
- Gallery: https://aroushtech.in/gallery/ — ten training/learner image references remain visible. Client-logo collage, placement outcome statement and named corporate-training claims remain excluded pending owner confirmation.
- Contact: https://aroushtech.in/contact-us/ — still lists `taj@aroushtech.in`, `+91 88676 92074`, the Corporate Office and Registered Office addresses, plus FAQ statements about certification, 100% job assistance and 24/7 lab access. The rebuild does not repeat the latter claims pending written confirmation.

The current live footer still contains an unrelated third-party promotional link. The rebuild omits it; the live WordPress installation has not been modified.

### Session 17 implementation refinements

- Contact enquiry now retains a visible `mailto:` fallback link if the visitor's device does not open an email app automatically. It still does not submit or store the form on a website server.
- Course search/filter results now expose a clear-all control whenever a filter is active, including when matches still exist. The empty-results recovery remains available.
- Chatbot message history now scrolls to the newest answer, and the question field is associated with its plain-language support disclosure.

No live website, WordPress, DNS, GitHub repository or deployment was changed.


## Session 18 source recheck — 6 November 2026

The following official AROUSH pages were reopened for this pass:

- Homepage: https://aroushtech.in/ — still shows the 20+ courses/free-demo message and features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. The zero-value counters remain omitted from the rebuild.
- About: https://aroushtech.in/aboutus/ — continues to list the vision, mission and three team profiles.
- Courses: https://aroushtech.in/courses/ — current catalogue still exposes 20 course entries and published fee pairs.
- Gallery: https://aroushtech.in/gallery/ — current public gallery continues to show training and corporate-learning photographs.
- Contact: https://aroushtech.in/contact-us/ — current email, phone and two office addresses remain published. The FAQ still contains certification, 100% job-assistance and 24/7 lab-access wording; these remain owner-confirmation items, not promises in the rebuild.

The current rebuild keeps its three featured course cards aligned with the live homepage, keeps the full catalogue searchable, and continues to omit unverified guarantees, zero-value counters and unrelated legacy footer links.

## Session 19 source check — 6 November 2026

Official AROUSH pages checked:

- Homepage: https://aroushtech.in/ — continues to present 20+ courses, a free-demo message, technology/course families and featured course offers. The rebuild keeps the public course discovery paths and labels fee amounts as website-listed, subject to confirmation before payment. Zero-value counters remain omitted.
- About: https://aroushtech.in/aboutus/ — mission, vision and three published team profiles/roles remain the source for the public About/Team pages.
- Contact: https://aroushtech.in/contact-us/ — continues to publish `taj@aroushtech.in`, `+91 88676 92074` and the Corporate Office and Registered Office addresses. FAQ statements about certification, 100% job assistance and 24/7 lab access remain owner-confirmation items rather than approved guarantees.
- CCNA course: https://aroushtech.in/ccna/ — the public outline covers network fundamentals, network access, IP connectivity, IP services, security fundamentals, automation and programmability. The rebuild should keep the course page outline tied to this source and send visitors to the team for current schedule, fees and availability.

The rebuild does not change the live WordPress pages or reproduce unconfirmed guarantees, zero-value counters or unrelated legacy footer promotions.

## Session 23 recheck — 6 November 2026

The current public pages were reopened again:

- Homepage: https://aroushtech.in/ — still advertises 20+ courses and a free demo, features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH, and still shows zero-value counters. The rendered footer still exposes the same 16 unrelated gambling/betting links documented in the WordPress SEO-spam incident review. The rebuild continues to omit the zero counters and suspicious footer links.
- About: https://aroushtech.in/aboutus/ — still publishes the stated vision and mission and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid. Zero-value counters and broad trainer-credential claims remain excluded pending owner approval.
- Courses: https://aroushtech.in/courses/ — still lists 20 public course entries with visible fee pairs. The rebuild keeps the 20 source-backed entries, labels amounts as website-listed references, and asks visitors to confirm current fees before payment.
- Gallery: https://aroushtech.in/gallery/ — still exposes ten training/learner photographs, a client-logo collage, placement-related wording and named corporate-training references. The rebuild keeps the ten training-photo references but excludes the logo collage and unconfirmed placement/client claims pending owner approval.
- Contact: https://aroushtech.in/contact-us/ — still publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a separate map coordinate. The FAQ still contains certification, 100% job-assistance and 24/7 lab-access wording; these remain owner-confirmation items rather than promises in the rebuild.

The source review is a public-page content check, not a WordPress database, hosting, account or filesystem inspection. The persistent unrelated footer links remain an owner/hosting investigation blocker.


## Session 24 recheck — 6 November 2026

Official pages reopened in the current maintenance pass:

- Homepage: https://aroushtech.in/ — the page still advertises 20+ courses and a free demo, shows the six course families and features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. Zero-value counters remain visible and are not copied. The rendered footer still exposes 16 unrelated gambling/betting anchors to 16 unrelated domains; the rebuild continues to exclude them.
- About: https://aroushtech.in/aboutus/ — the live page still publishes its mission, vision and three team profiles/role titles.
- Courses: https://aroushtech.in/courses/ — the live catalogue still contains 20 course entries and their visible fee pairs. The rebuild's 20 title/fee records remain aligned with this snapshot and keep the confirm-before-payment notice.
- Gallery: https://aroushtech.in/gallery/ — training and corporate-training photos remain visible alongside separate client/placement-related material. The rebuild retains the ten training-photo references and excludes the unapproved client-logo collage and unconfirmed outcome claims.
- Contact: https://aroushtech.in/contact-us/ — `taj@aroushtech.in`, `+91 88676 92074`, the two published Bengaluru office addresses and the training-format FAQ remain visible. Certification, 100% job-assistance and 24/7 lab-access statements remain owner-confirmation items.

This is a public-page review only. It does not inspect WordPress records, administrator accounts, plugin/theme files, server logs, hosting or CDN configuration. The repeated footer links remain an owner/hosting investigation blocker before migration.

## Session 25 source recheck — 6 November 2026

Fresh public pages reopened:

- Homepage: https://aroushtech.in/ — the page still promotes 20+ courses and a free demo, shows six course families and features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. It continues to render zero-value counters (`0 k+`, `0 +`, `0 %`) and 16 unrelated gambling/betting footer anchors to unrelated domains. The rebuild excludes those counters and anchors.
- About/team: https://aroushtech.in/aboutus/ — the published mission and vision remain visible, along with Abdul Aleem Khan (Vertical Head Cyber Security & Cloud Security), Tajuddin (Technical Head Networking & Cyber Security) and Mohammed Khalid (Technical Head For Networking Security).
- Courses: https://aroushtech.in/courses/ — 20 entries remain visible with their current page-listed fee pairs. The rebuild's 20 title/fee pairs match this public snapshot. The rebuild continues to label amounts as website-listed references and asks visitors to confirm current fees before payment.
- Gallery: https://aroushtech.in/gallery/ — the page still contains training and corporate-training photographs as well as separate client/placement-related statements. The rebuild retains the ten training-photo references and does not use the client-logo collage as an endorsement.
- Contact: https://aroushtech.in/contact-us/ — the published email, phone, two office addresses and a separate map coordinate remain visible. The FAQ still states 100% job assistance and 24/7 lab access; these remain excluded from the rebuild pending written owner approval.

This review covers public rendered pages only. It does not inspect the WordPress database, administrator accounts, theme/plugin files, server logs, hosting, CDN or Search Console. The suspicious footer links remain an owner/hosting investigation blocker before migration.
