# Session 23 — source recheck, public-claim guard and accessible course filters

Date: 6 November 2026

## Summary

This session concentrated on content integrity, the unresolved live WordPress SEO-spam symptom, and small accessibility improvements rather than adding another large feature.

## Live AROUSH source recheck

Reopened the official homepage, About, Courses, Gallery and Contact pages:

- Homepage: https://aroushtech.in/ — still advertises 20+ courses and a free demo; still features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH; still shows zero-value counters; and still exposes the same 16 unrelated gambling/betting footer links.
- About: https://aroushtech.in/aboutus/ — still publishes the vision, mission and three team profiles (Abdul Aleem Khan, Tajuddin and Mohammed Khalid).
- Courses: https://aroushtech.in/courses/ — still lists 20 public course entries and visible fee pairs.
- Gallery: https://aroushtech.in/gallery/ — still exposes ten training/learner photographs, a client-logo collage and placement/corporate-training statements. The rebuild keeps the ten photo references but does not reproduce the collage or unconfirmed client/placement claims.
- Contact: https://aroushtech.in/contact-us/ — still publishes `taj@aroushtech.in`, `+91 88676 92074` and two Bengaluru office addresses. Its FAQ still contains certification, 100% job-assistance and 24/7 lab-access wording; these remain owner-confirmation items.

The repeated footer finding confirms that the public-page symptom was still visible at the time of this recheck. It does not prove the injection source or the extent of any WordPress/hosting compromise. The live installation was not modified.

## Code changes

- Added `scripts/validate-public-claims.mjs`. It scans public application, component and library source for unapproved job/placement guarantees, top-rated/high-paying claims, fast-hiring claims and unqualified 24×7 lab/monitoring promises. It permits explicit disclaimers and checks that course-price components retain the visible instruction to confirm the current fee before payment.
- Added `npm run validate:public-claims` to `package.json`, the offline validation chain and the release-configuration validator.
- Expanded the known spam-anchor pattern to catch the latest visible `casinomuhub` spelling as well as earlier observed variants.
- Improved course catalogue relationships for assistive technology: search and category filters now identify the results region they control; the search field is associated with the live result count; and the results region exists in both populated and empty states.
- Updated the UX validator to check those relationships.
- Updated the README, beginner developer guide, live-source review, incident report and competitor review.

## Competitor UX research

Reopened current official pages:

- Apna College Prime: https://www.apnacollege.in/prime — current programme page makes its AI/ML curriculum and project sections easy to scan. AROUSH can keep its own course outlines structured and readable; no Apna programme claims, batch dates, support promises or certificates were copied.
- i-Medita CCIE Bootcamp and Ethical Hacking pages: https://www.imedita.com/ccie-bootcamp/ and https://www.imedita.com/courses/ethical-hacking-training/ — programme detail, delivery information, trainer sections, FAQs and demo enquiry are prominent. AROUSH retains its own outline, prerequisites and enquiry flow; no prices, durations, enrolment counts, ratings, schedules, credentials or placement claims were copied.
- PyNet Labs catalogue: https://www.pynetlabs.com/courses/ — broad technology-based grouping and course navigation remain clear. AROUSH retains its 20 published courses and four learning-goal collections; no PyNet course range or marketing claims were imported.

## Validation performed

- `npm run check:offline` — passed all 12 dependency-free validators.
- `npm run validate:external-links` — passed; 31 source files scanned and 9 HTTPS hosts reviewed, with no known spam domains/phrases or unapproved hosts in rebuilt application source.
- `npm run validate:public-claims` — passed; 30 public source files scanned, no unapproved guarantees/comparative claims found, and all course-price components retain the current-fee confirmation notice.
- `npm run validate:ux` — passed with new search/filter `aria-controls`, search/result-count association and stable results-region checks.
- Chatbot regression tests — passed 23 intent-routing cases.
- JavaScript syntax — passed for 15 `.mjs` files.
- TypeScript/TSX syntax transpilation — passed for 27 files with zero syntax diagnostics. This is syntax validation only, not semantic typechecking.
- CSS/PostCSS parse — passed for 430 top-level rules/at-rules.
- Negative tests for both new security guards — passed: temporary `100% job assistance`, `24/7 lab access`, and a known spam domain/anchor were rejected; an explicit `No 24×7 monitoring is included` disclaimer was accepted. Fixtures were removed and clean scans passed again.
- Full `npm run typecheck` — blocked by missing Next.js/React packages and declarations.
- `npm run lint` — blocked (`eslint: not found`).
- `npm run build` — blocked (`next: not found`).
- `npm run audit` — blocked because no lockfile exists (`ENOLOCK`).
- A fresh `npm install --ignore-scripts --no-audit --no-fund` attempt timed out after npm reported `EAI_AGAIN` resolving `registry.npmjs.org`; no lockfile or usable `node_modules` directory was created.

## Remaining blockers

- Node.js 24 is required; this environment currently has Node.js 22.16.0.
- Dependencies and `package-lock.json` are still absent because npm registry resolution previously failed with `EAI_AGAIN`.
- Full TypeScript typecheck, ESLint, Next.js production build and npm audit remain blocked until Node 24 and dependencies/lockfile are available.
- Real Android/desktop browser testing remains pending a successful staging build.
- The authorised WordPress/hosting administrator must investigate the live footer links and document cleanup before any migration or domain cutover.
- Owner approval remains required for course fees/availability, selected legacy marketing claims, image rights and analytics setup/legal review.

## Privacy and deployment

GA4 Measurement ID remains blank; analytics remains disabled until owner configuration and explicit visitor opt-in. Reject and withdrawal controls remain available. Phone remains optional and voluntarily supplied. No server-side lead database or CRM was added. No live website, WordPress, DNS, GitHub repository, hosting or production deployment was changed.
