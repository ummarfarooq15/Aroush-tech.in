# Session 31 — Enquiry privacy, mobile input and source review

Date: 7 November 2026

## Changes made

1. Updated `components/contact-form.tsx`:
   - Added mobile-friendly telephone input mode.
   - Disabled automatic capitalisation and correction for email entry.
   - Added an explicit warning not to include passwords, API keys, access tokens, personal records or sensitive production logs.
   - Directed visitors to share sensitive technical details only through a secure channel agreed with AROUSH.
2. Updated the Contact FAQ with a plain-language explanation of the enquiry form: it prepares an email draft on the visitor's device; the website does not send or store the details; the visitor must review and send the email themselves.
3. Added a chatbot quick reply and grounded answer for “Does the enquiry form send my details?”. The answer also repeats that the phone field is optional and sensitive credentials must not be sent.
4. Expanded chatbot regression coverage from 45 to 46 intent-routing cases.
5. Strengthened the privacy validator to require the sensitive-data warning.
6. Updated the source register, live-source review, competitor review, privacy implementation note, project status and README.

## Current source review

The official homepage still displays 20+ courses/free-demo messaging, six course families, featured courses, two testimonials and an instructor introduction. It also shows three zero-value counters and 16 unrelated gambling/betting footer links. The rebuild excludes the counters and unrelated links. About, Gallery, Courses and Contact continue to show the three team profiles, training photographs, 20 course cards, published contact details and two office addresses. See `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION31.md`.

## Competitor UX review

Refreshed Apna College Prime, i-Medita FAQ/CCNA and PyNet Labs course catalogue/contact pages. Retained only curriculum grouping, FAQ discoverability, category-based course discovery and visible human-help patterns. No competitor commercial claims or metrics were copied. See `docs/COMPETITOR-REVIEW-2026-11-07.md`.

## Validation

`npm run check:offline` passed all 15 dependency-free validators:

- Content and course catalogue checks.
- Privacy and analytics policy checks.
- Brand and UX checks.
- Accessibility source checks.
- Internal routes and external-link policy/security checks.
- Public-claims and learning-path checks.
- Chatbot tests: 46 intent-routing cases.
- JavaScript syntax: 20 `.mjs` files.
- TypeScript/TSX syntax: 30 files parsed with TypeScript 5.8.3 (syntax only, not semantic typechecking).
- Release configuration checks.

Additional checks:

- CSS parsed with PostCSS: 521 rules and 20 at-rules.
- Accessibility source scan: 23 TSX files.
- External-link scan: 33 source files and 9 reviewed HTTPS hosts.

## Blockers

- Runtime is Node.js 22.16.0 with npm 10.9.2; project requires Node.js 24.x.
- `npm view next@15.5.29 version --fetch-retries=0 --fetch-timeout=8000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- Dependencies are not installed and no package lockfile is present.
- `npm run typecheck` fails because Next.js/React and type declarations are missing.
- `npm run lint` fails with `eslint: not found`.
- `npm run build` fails with `next: not found`.
- `npm audit` fails with `ENOLOCK` because no lockfile exists.
- Real Android/desktop browser testing remains pending.

Do not fabricate a lockfile or treat source syntax checks as a production build.

## Approval and deployment status

No GA4 Measurement ID configured; analytics remains disabled until owner setup and visitor opt-in. No server-side lead database or CRM added. No live website, WordPress, DNS, GitHub repository, analytics property or production deployment changed.
