# Session 33 — Dedicated FAQ experience and source refresh

Date: 7 November 2026

## Changes made

1. Added `app/faqs/page.tsx`, a dedicated FAQ route grouped into Courses & learning, Location & enquiries, and Services & business enquiries.
2. Expanded the shared `faqs` data in `lib/content.ts` to 12 questions. Answers cover published course areas, the advertised free demo, online/offline/hybrid formats, schedule/prerequisite confirmation, fee discrepancies, vendor certification/exam-voucher caveats, the incomplete J.P. Nagar training-centre address, the email-draft enquiry workflow, payment safety, the supplied services portfolio and SOC/SIEM scope.
3. Added the FAQ route to the main navigation, footer and sitemap. The contact page shows six enquiry-focused questions and links to the full FAQ page.
4. Added a chatbot quick reply for common questions and a rule-based FAQ intent that links to `/faqs`. The assistant still routes unknown questions to the human team.
5. Added responsive grouped FAQ layout styles and a visible keyboard focus state for native `<summary>` controls.
6. Added `scripts/validate-faqs.mjs`, `npm run validate:faqs`, and included the check in `npm run check:offline` and release-configuration validation.
7. Updated the beginner developer guide and README with FAQ editing instructions and the new route.
8. Reopened the current AROUSH homepage, About, Courses, Gallery, Contact, AI & ML and both Agentic AI pages. Recorded current facts and unresolved issues in `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION33.md`.
9. Refreshed UX research for Apna College, i-Medita and PyNet Labs. Useful discovery and FAQ patterns were applied without copying competitor commercial claims.

## Validation

- `npm run check:offline`: all 16 dependency-free validators passed.
- FAQ validator: passed; confirms answer coverage, uncertainty notices, main navigation, footer, contact page, sitemap and chatbot route.
- Chatbot intent routing: 47 cases passed, including the FAQ route and unknown-question handoff.
- TypeScript/TSX syntax: 31 files parsed with global TypeScript 5.8.3; syntax only, not semantic typechecking.
- JavaScript syntax: 21 `.mjs` files passed.
- Accessibility source scan: 24 TSX files checked.
- Internal route validation: 31 internal paths checked; 20 course slugs and redirects inspected.
- External-link security: 34 source files scanned and 9 HTTPS hosts reviewed; no unapproved host, known spam domain or HTTP link found.
- CSS/PostCSS: 538 rules, 22 at-rules and 1,754 declarations parsed successfully.
- ZIP integrity and fresh extraction checked after packaging.

## Production blockers

- Available Node.js: 22.16.0; project requires Node.js 24.x. No Node 24 runtime or nvm installation was found in this environment.
- npm registry ping failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- `node_modules/` and `package-lock.json` are absent.
- Full `npm run typecheck` is blocked by missing Next.js/React packages and type declarations; the global TypeScript syntax parser passed but is not a typecheck.
- `npm run lint` is blocked because `eslint` is not installed.
- `npm run build` is blocked because `next` is not installed.
- `npm run audit` is blocked because no lockfile exists (`ENOLOCK`).
- Real Android/desktop browser testing remains pending a working build or staging environment.

## Privacy, approval and deployment

- GA4 Measurement ID remains blank; analytics remains disabled until owner configuration and explicit visitor opt-in.
- The enquiry form still prepares an email draft on the visitor's device. No server-side lead database or CRM was added.
- Phone number remains optional and voluntarily supplied.
- No live website, WordPress installation, DNS, GitHub repository, analytics property or production deployment was changed.
