# Validation report — Session 46

Date: 7 November 2026

## Passed

- `npm run check:offline`: all 25 dependency-free validators passed.
- Content: 10 services, 20 public courses, 18 source outlines, 2 provider-attribution review notes, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 office addresses, 31 public routes and 23 redirects.
- Enquiry paths: 37 checks passed.
- Enquiry safety: 22 checks passed.
- Chatbot: 47 intent/content checks passed.
- Privacy and analytics policy: passed, including consent documentation consistency, opt-in-only loading, blank GA4 ID, query-free page metadata, rejection/withdrawal and voluntary phone field.
- Accessibility source scan: 31 TSX files; the review panel has a labelled region, explicit not-sent status, keyboard-visible focus and responsive layout.
- TypeScript/TSX syntax: 44 files parsed with TypeScript 5.8.3; syntax only.
- JavaScript syntax: 36 `.mjs` files checked.
- Internal routes: 31 checked.
- Breadcrumbs: 11 content routes checked.
- Social-card source rules, public claims, external-link security, FAQ search, course sorting/filtering/comparison and release configuration: passed.

## Blocked or pending

- Runtime: Node.js 22.16.0; project requires 24.x.
- Release preflight: blocked by Node.js version, missing `package-lock.json` and missing dependencies.
- npm registry: package-lock-only installation attempt timed out; no lockfile was created.
- Full TypeScript typecheck: blocked because Next.js/React type declarations are not installed.
- ESLint: blocked (`eslint: not found`).
- Next.js build: blocked (`next: not found`).
- npm audit: blocked (`ENOLOCK`, no lockfile).
- Browser QA: pending on Android and desktop, including actual `mailto:` handoff and social-preview rendering.

## Release boundary

No deployment, live WordPress change, DNS change, GitHub push, analytics-property change, CRM or server-side lead database was performed. GA4 Measurement ID remains blank and analytics remains disabled.
