# Privacy preference implementation — 6 November 2026

## Visitor controls

- GA4 is disabled unless a valid owner-supplied Measurement ID is present **and** the visitor explicitly selects **Allow analytics**.
- Visitors can select **Reject** without losing access to the website.
- The choice is saved in first-party `localStorage` so it persists between visits.
- A persistent **Privacy settings** control remains available after a choice and can reopen the panel.
- Opening Privacy settings is informational and preserves the saved choice. The visitor can explicitly switch from Allow to Reject (which disables further GA collection and attempts to clear GA cookies) or from Reject to Allow. Closing the panel keeps the existing choice.
- If the owner has not configured a valid GA4 ID, no Google Analytics script is loaded. The persistent Privacy settings control explains that analytics is currently disabled.
- Google Signals and advertising personalisation are disabled in the GA4 configuration. No user ID, phone number, name, email or enquiry message is sent by the integration.

## Owner setup and release checks

1. Keep `NEXT_PUBLIC_GA_MEASUREMENT_ID` blank until AROUSH creates or selects a company-owned GA4 property and approves the provider configuration.
2. Configure the Measurement ID only in the intended staging/hosting environment after owner and legal review.
3. In a staging browser, verify that no GA request occurs before explicit opt-in; verify Reject, Privacy settings, withdrawal and re-acceptance.
4. Confirm the GA4 property owner, authorised report viewers, shortest suitable retention period, Enhanced Measurement settings, Google Signals and advertising integrations.
5. Review the privacy notice, privacy contact, enquiry-email retention and applicable Indian DPDP requirements with qualified counsel before production.
6. Test keyboard access, screen-reader announcements, zoom and small Android/iOS viewports.

## Important limitations

- The preference record is stored in `localStorage`; it is first-party browser storage, not a cookie itself.
- The consent UI and source validators are not a legal compliance certification.
- GA4 may process pseudonymous event-level data to produce aggregate reports. Do not describe this as fully anonymous processing.
- Rejection/withdrawal disables further GA collection and attempts to clear GA cookies set for the site. Browser-managed and third-party storage behaviour must still be checked in a real browser.
- Do not add advertising pixels, session replay, fingerprinting or marketing tags without a separate review and explicit implementation.
- No personal phone number or precise GPS location is discovered from a visit.
