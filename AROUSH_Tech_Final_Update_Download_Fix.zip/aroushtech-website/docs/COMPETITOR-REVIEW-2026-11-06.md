# Competitor website review — 6 November 2026

This is a public-facing UX and positioning review. It is not a claim that AROUSH is better or worse than another provider. Competitor claims (learner counts, ratings, placements, guarantees, trainer credentials, batch dates and lab access) belong to those providers and must not be copied into AROUSH content.

## Websites reviewed

- Apna College — https://www.apnacollege.in/ and https://www.apnacollege.in/all-courses
- i-Medita — https://www.imedita.com/ and https://www.imedita.com/courses/
- PyNet Labs — https://www.pynetlabs.com/ and https://www.pynetlabs.com/courses/
- AROUSH — https://aroushtech.in/

## What each site does well

### Apna College

- Very clear learner outcome and audience: software-development and placement preparation.
- Packages learning into named tracks/batches (DSA, web development, AI/ML and placement preparation).
- Strong community and social proof placement in the homepage journey.
- Course discovery is centred on a small number of recognisable programmes rather than a very long undifferentiated list.

**Useful lesson for AROUSH:** create clear learner pathways (for example, Networking Foundations → Enterprise Networking → Network Security; or Cybersecurity Foundations → Ethical Hacking → SOC Analyst). Keep the path factual and link every step to an actual AROUSH course. Add outcomes and proof only when approved and evidenced.

### i-Medita

- Broad technical catalogue with category discovery across Cisco, cybersecurity, Check Point, EC-Council, F5, Palo Alto, automation and AWS.
- Prominent instructor profiles, online certification, backup classes, placement support and lab-access propositions.
- Popular course cards show fee information; the site also displays upcoming batch schedules and learning modes.

**Useful lesson for AROUSH:** make instructor profiles and course details easy to reach; show upcoming batches only when AROUSH supplies confirmed dates, times, delivery mode and enrolment status. Do not copy i-Medita's placement, 24x7 lab or certification promises.

### PyNet Labs

- Rich course discovery with categories, skill levels, duration, delivery mode and course filters.
- Strong career-path navigation and clear course pages for networking, automation, cloud, cybersecurity and AI.
- Highlights instructor expertise, labs, upcoming batches, alumni stories and learner outcomes.

**Useful lesson for AROUSH:** improve the catalogue with level, duration, format and prerequisites wherever verified. Add career-path landing pages and real practical project/lab examples. Never copy PyNet's learner counts, star ratings, hiring partners, placement figures or job guarantees.

## AROUSH's own opportunity

AROUSH has a potentially distinctive combination: enterprise IT and infrastructure services, cybersecurity, technical support, corporate training and the new SOC/SIEM deployment-and-training line. The 2026 company brochure describes a practical engagement flow: assess, plan, authorized delivery, test, document and hand over. It also explicitly says SOC/SIEM is a new business line and that delivery depends on confirmed people, platform access and scope.

The website should therefore not imitate a pure mass-market coding academy or a networking-only training catalogue. It should make two journeys equally clear:

1. **For learners:** choose a course, understand its level/prerequisites/duration/format, see what practical work is included, and request a demo or course discussion.
2. **For organizations:** choose a service, understand the scope and deliverables, discuss the operating environment, and request a scoped proposal.

## Recommended improvements (prioritized)

### Do now

1. Keep the homepage hero image authentic to the training/technology theme and ensure the main headline remains HTML text, not baked into the image.
2. Put two distinct calls to action near the top: “Explore training” and “Discuss IT services”.
3. Keep course search and category filters, then add verified level, duration, prerequisites and learning mode to course cards.
4. Add a structured “Choose your learning path” page using existing approved courses only.
5. Make every course detail page answer: who it is for, prerequisites, topics, practical exercises, format, duration, certificate details (only if verified), and next step.
6. Give corporate training and SOC/SIEM its own clear enquiry flow. Explain scope, platform access and handover; do not imply 24x7 monitoring or vendor accreditation.
7. Keep real AROUSH instructors and approved student feedback visible. Do not invent ratings, student totals, hiring partners or placement results.

### Next iteration

8. Add a small resource centre: networking explainers, Linux command labs, cybersecurity awareness checklists, SOC triage examples and interview preparation. Each resource should be authored/reviewed by AROUSH and link to a relevant course or service.
9. Add upcoming batches only after the team provides an authoritative schedule and an owner for updates.
10. Add WhatsApp handoff only after confirming the company-owned number and approved response process. Keep an email/contact fallback.
11. Measure course search usage, course-detail views, demo requests, service enquiries and completed form submissions. Do not publish private analytics as marketing statistics.

## Guardrails

- Competitor prices, guarantees, ratings, certifications, trainer biographies, testimonials, logos, schedules and statistics must not be copied.
- Do not add “100% placement”, “job guarantee”, “24x7 labs”, “certified trainers”, “official partner” or similar claims unless AROUSH provides current written evidence and approval.
- Course fees already visible on the AROUSH public catalogue are a snapshot; reconfirm them before accepting payment.
- Keep the distinction between training courses and consulting services clear.

## Public pages checked

- Apna College homepage and course listing.
- i-Medita homepage and course listing.
- PyNet Labs homepage and course listing.
- AROUSH homepage and current course catalogue.

The pages can change; recheck before production release.


## Fresh public-page recheck — 6 November 2026

The official public pages were rechecked during this maintenance pass:

- Apna College homepage and its current AI/ML and placement-preparation programme pages: https://www.apnacollege.in/ and https://www.apnacollege.in/prime
- i-Medita homepage and cybersecurity demo page: https://www.imedita.com/ and https://www.imedita.com/cyber-security-bootcamp/
- PyNet Labs homepage and course catalogue: https://www.pynetlabs.com/ and https://www.pynetlabs.com/courses/

### Patterns worth retaining

- **Apna College:** its homepage puts a small number of flagship learning tracks near the top and gives each track a clear audience and next step. AROUSH can keep the homepage focused on a few representative areas while retaining the full catalogue for visitors who want detail. Do not import its learner totals, results, discounts, batch dates or job-outcome language.
- **i-Medita:** the homepage makes instructor profiles, practical training propositions and a demo enquiry easy to discover. AROUSH can keep its real team profiles and contact route visible, but should publish lab-access, backup-class, certification or placement terms only after written confirmation.
- **PyNet Labs:** the catalogue offers category and career-path navigation with course cards that surface useful decision details. AROUSH's current searchable category catalogue is a good base; add course level, delivery format, prerequisites and duration only when those fields are supported by the corresponding AROUSH course source or approved owner data.

### Additional AROUSH safeguards confirmed

- The current AROUSH homepage still shows zero-value counters and unrelated promotional links in the legacy footer. They are not reproduced.
- The current Contact FAQ still contains certification, 100% job-assistance and 24/7 lab-access wording. These are not treated as approved guarantees in the rebuild.
- The current course catalogue remains the source for public course names and listed fee pairs. Fees remain subject to owner reconfirmation before payment.

The review is limited to public website UX. Competitor marketing claims, prices, testimonials, ratings, credentials, schedules, learner counts and guarantees are not copied into AROUSH content.

## Maintenance recheck — 6 November 2026

The current public pages were rechecked during this maintenance pass:

- Apna College's current Prime programme page segments guidance for engineering students, working professionals and non-CS learners, then exposes a curriculum and next step. AROUSH can make its own audience and course fit easier to understand without importing Apna's durations, batch dates, job-preparation outcomes or claims.
- i-Medita's homepage continues to make top course categories, instructor profiles, practical-training propositions and course discovery prominent. AROUSH should keep its own team and enquiry routes visible, but publish lab-access, certification and placement terms only when the owner approves them.
- PyNet Labs' homepage and catalogue continue to surface categories, career paths and course detail links. AROUSH's existing search and category filters are a suitable base; add duration, level, delivery mode and prerequisites only where AROUSH sources verify those fields.
- The current AROUSH homepage continues to promote its public course areas and featured courses; the Contact page remains the source for current public email, phone and office-address text. Fees and promotional amounts remain subject to owner reconfirmation.

Public pages rechecked: https://www.apnacollege.in/prime, https://www.imedita.com/, https://www.pynetlabs.com/, https://www.pynetlabs.com/courses/, https://aroushtech.in/ and https://aroushtech.in/contact-us/.

No competitor prices, statistics, ratings, testimonials, credentials, schedules, guarantees or marketing claims were copied into AROUSH content.

## Current public-site UX recheck — 6 November 2026

The current official pages were opened again during this maintenance pass:

- Apna College homepage: https://www.apnacollege.in/ — the visible navigation prioritizes a small set of named flagship programmes (including SigmaX, Prime 3.0, DSA and web development), results/community destinations and a clear start-learning path.
- i-Medita homepage: https://www.imedita.com/ — the navigation organizes live training by technology/vendor families (Cisco, Palo Alto, Fortinet, Check Point, EC-Council, F5, AWS and network automation), with success stories, FAQs and contact paths.
- PyNet Labs homepage: https://www.pynetlabs.com/ — the current page presents a searchable course catalogue, featured programmes and grouped technology categories such as Network Automation, Routing & Switching, Network Security, Cyber Security, Cloud, Data Center, AI/ML and Data Science.
- AROUSH homepage: https://aroushtech.in/ — still presents the 20+ course message, six course families, a free-demo message, three featured courses, zero-value counters and two testimonials. The redesign keeps the verified course/demo paths and omits the zero counters.
- AROUSH About, Gallery, Courses and Contact pages: https://aroushtech.in/aboutus/, https://aroushtech.in/gallery/, https://aroushtech.in/courses/ and https://aroushtech.in/contact-us/ — the three published team profiles, ten training photographs, 20 course entries, contact mailbox/phone and two office addresses remain visible.

### Changes applied from this review

- Kept the AROUSH homepage focused on a few current featured courses while retaining search and category filters for the complete catalogue.
- Added a clearer homepage free-demo enquiry callout. The copy says the team must confirm eligibility and timing; it does not promise that every course has an available demo.
- Added chatbot answers for free-demo enquiries and the privacy notice, with links to the relevant AROUSH pages.
- Kept learner and organization journeys separate through course enquiries, corporate training and service proposal paths.
- Kept course level, prerequisites, delivery mode, fee, trainer and schedule claims tied to AROUSH source material or explicitly marked for confirmation.

No competitor prices, statistics, ratings, testimonials, credentials, schedules, guarantees, batch sizes or marketing claims were copied. This is a UX review only.

## Maintenance pass — goal-based course discovery

Public pages rechecked on 6 November 2026:

- Apna College homepage and Prime 3.0 programme: https://www.apnacollege.in/ and https://www.apnacollege.in/prime
- i-Medita homepage and Cyber Security Bootcamp demo page: https://www.imedita.com/ and https://www.imedita.com/cyber-security-bootcamp/
- PyNet Labs homepage and current course catalogue: https://www.pynetlabs.com/ and https://www.pynetlabs.com/courses/
- AROUSH homepage, contact page and course detail pages: https://aroushtech.in/, https://aroushtech.in/contact-us/, https://aroushtech.in/ccna/, https://aroushtech.in/ccnp-security/ and https://aroushtech.in/fortinet-certified-engineer/

### Fresh observations and decisions

- Apna College's current Prime page separates content for engineering students, working professionals and non-CS learners, then exposes a curriculum and programme next step. AROUSH now uses a lighter-weight goal-based catalogue page, but does not copy Apna's durations, batch dates, placement outcomes or programme promises.
- i-Medita's current site makes technical course categories and a free-demo enquiry visible. AROUSH's own live homepage also advertises a free demo; the rebuild asks visitors to confirm course eligibility and timing rather than promising universal availability.
- PyNet Labs' current catalogue exposes category and career-path navigation with course cards. AROUSH now groups only its existing public course slugs into four goal-based collections and separately presents its six SOC/SIEM learning options.
- The new AROUSH `/learning-paths` page describes these collections as discovery groupings only. It does not claim that the listed order is a prerequisite sequence, certification route or guaranteed career progression.
- The current live AROUSH homepage continues to advertise 20+ job-ready courses and a free demo. The live Contact page continues to list the published email, phone and two office addresses. Course fee amounts and availability remain subject to owner reconfirmation.

No competitor prices, ratings, testimonials, learner counts, credentials, guarantees, schedules or placement claims were copied.

## Session 17 public UX recheck — 6 November 2026

Official pages reviewed again:

- Apna College Prime page: https://www.apnacollege.in/prime — currently separates programme information for engineering students, working professionals and non-CS learners, and exposes curriculum sections and practical-project examples.
- i-Medita course pages: https://www.imedita.com/ccna-bootcamp/ and https://www.imedita.com/cyber-security-bootcamp/ — show course-specific facts, demo enquiry routes, trainer information and programme detail blocks.
- PyNet Labs course catalogue: https://www.pynetlabs.com/courses/ — groups offerings by technology and career path and provides searchable/filterable course cards.

### UX decisions retained for AROUSH

- Keep AROUSH's own four learning-goal collections and its searchable category catalogue. Do not copy competitor audience promises, curriculum, batch dates, durations or project claims.
- Keep the course-specific enquiry route and ask the team to confirm current schedule, prerequisites, delivery mode, fee and demo eligibility.
- Keep corporate/campus training separate from individual learner enquiries so organizational visitors do not have to search through the individual course catalogue.
- Keep the AROUSH FAQ and chatbot conservative: no guarantee, placement, certification, lab-access or continuous-monitoring promise unless the company confirms it in writing.

No competitor price, statistic, rating, testimonial, credential, guarantee or schedule was copied.


## Session 18 recheck — 6 November 2026

Official public pages re-opened during this pass:

- Apna College homepage: https://www.apnacollege.in/ — current navigation highlights a small set of flagship programmes and provides a clear route into programme information. Its Delta page exposes a course-specific curriculum and FAQ structure: https://www.apnacollege.in/course/delta.
- i-Medita homepage: https://www.imedita.com/ — organizes training around technology/vendor families and makes trainer, course and contact destinations easy to discover.
- PyNet Labs homepage: https://www.pynetlabs.com/ and catalogue: https://www.pynetlabs.com/courses/ — exposes a searchable catalogue, featured programmes and technology/career-path groupings.

### UX decisions reinforced

- Keep AROUSH's homepage focused on its three currently featured courses, while preserving the full 20-course catalogue for deeper browsing.
- Keep the four AROUSH learning-goal collections and category/search controls. They are discovery aids, not prerequisites or job pathways.
- Route service questions to Services and learner questions to Courses/Training; this pass adds explicit regression tests for that distinction.
- Keep the Contact and FAQ routes visible. Do not add competitor batch schedules, trainer credentials, course durations, placement outcomes, prices, ratings, testimonials, discounts or guarantees.

No competitor claims or commercial data were copied.

## Session 19 public course UX recheck — 6 November 2026

Official pages rechecked:

- Apna College Delta course page: https://www.apnacollege.in/course/delta-7 — exposes a course-specific curriculum and programme details. The UX lesson is to make curriculum and the next action easy to locate; its course outcomes, batch dates, project claims and other marketing copy are not imported.
- Apna College Prime page: https://www.apnacollege.in/prime — separates the programme by learner goal/audience and exposes curriculum sections. AROUSH's own course and learning-path groupings remain grounded only in AROUSH's catalogue.
- i-Medita CCNA course page: https://www.imedita.com/courses/ccna-training/ — presents curriculum, trainer information, FAQ and demo enquiry content in a course-specific layout. AROUSH can make its own verified course outline and enquiry path similarly easy to find, without copying i-Medita's trainer claims, rating, partner counts, fees or placement statements.
- PyNet Labs course catalogue: https://www.pynetlabs.com/courses/ — offers technology/category and career-path groupings with course detail links. AROUSH's existing search, category filters and four discovery collections remain the appropriate local pattern; no extra course levels, duration or prerequisites are added without AROUSH source support.

No competitor prices, statistics, ratings, testimonials, credentials, schedules, guarantees or placement claims were copied into AROUSH content.

## Session 20 public UX recheck — 6 November 2026

Pages re-opened during this maintenance pass:

- Apna College homepage and Prime programme: https://www.apnacollege.in/ and https://www.apnacollege.in/prime — the homepage keeps a small set of flagship programme entry points; Prime separates information by learner audience and exposes curriculum sections. AROUSH uses only the general discovery principle and does not copy learner outcomes, schedules, prices or claims.
- i-Medita homepage and Cyber Security Bootcamp: https://www.imedita.com/ and https://www.imedita.com/cyber-security-bootcamp/ — navigation groups offerings by technology/vendor family and the bootcamp page exposes course-specific information and a demo enquiry path. AROUSH keeps its own catalogue and asks the team to confirm current demo eligibility.
- PyNet Labs course catalogue: https://www.pynetlabs.com/courses/ — course navigation is grouped by technology and training path. AROUSH retains its own 20-course catalogue and four learning-goal collections.

No competitor price, statistic, rating, testimonial, trainer credential, schedule, placement outcome or guarantee was copied.


## Session 21 recheck — 6 November 2026

Official pages reopened:

- Apna College Prime: https://www.apnacollege.in/prime — currently distinguishes engineering students, working professionals and non-CS learners before presenting its curriculum. AROUSH's existing goal-based collections remain a lightweight discovery aid; no Apna course content, durations, batch dates, student counts or outcome claims are copied.
- i-Medita CCNA course: https://www.imedita.com/courses/ccna-training/ — uses a course-specific structure with curriculum, trainer information, FAQs and a demo enquiry route. AROUSH should keep its own source-backed syllabus and enquiry path easy to find, without importing i-Medita's credentials, fees, partner counts, ratings or placement claims.
- PyNet Labs homepage and catalogue: https://www.pynetlabs.com/ and https://www.pynetlabs.com/courses/ — provide searchable course discovery and technology groupings. AROUSH retains its existing catalogue filters and four goal-based collections rather than copying PyNet's course inventory, commercial data or marketing claims.

No competitor prices, ratings, learner counts, testimonials, credentials, schedules, placement outcomes, guarantees or batch claims were copied into AROUSH content.


## Session 22 recheck — 6 November 2026

Official pages reopened during this pass:

- Apna College SigmaX: https://www.apnacollege.in/course/sigmax — presents a small set of programme choices, a side-by-side comparison and visible curriculum sections. AROUSH can keep its own featured-course choices and make course outline/next steps easy to scan; no Apna curriculum, student figures, outcomes, schedules or promotional terms are copied.
- i-Medita Courses: https://www.imedita.com/courses/ — organizes the catalogue by vendor/technology family and exposes course links and upcoming event information. AROUSH retains its own category/search controls and avoids publishing unverified batch dates or delivery promises.
- PyNet Labs Courses: https://www.pynetlabs.com/courses/ — groups offerings by technology and career path and provides a catalogue entry point. AROUSH keeps its own 20 source-backed catalogue entries and four discovery collections; no additional courses or prerequisites are inferred.

### UX decisions

- Keep the homepage focused on the three featured AROUSH courses, with the full catalogue one click away.
- Keep search and category filtering, course-specific outlines, and clear enquiry actions.
- Keep individual learner enquiries separate from corporate/campus training and consulting requests.
- Keep current fees, schedules, availability, demo eligibility and prerequisites subject to confirmation by AROUSH.

No competitor prices, statistics, ratings, testimonials, credentials, schedules, placement claims or guarantees were copied.

## Session 23 recheck — 6 November 2026

Official pages reopened for this pass:

- Apna College Prime: https://www.apnacollege.in/prime — the current page presents a named AI/ML and Data Science programme, a curriculum broken into Python/data preparation, machine learning, deep learning/GenAI and project work, plus learner-support and completion information. UX lesson: make the curriculum structure and project expectations easy to scan. AROUSH must use only its own approved outline and must not import Apna's programme claims, batch dates, support promises or certificates.
- i-Medita course pages: https://www.imedita.com/ccie-bootcamp/ and https://www.imedita.com/courses/ethical-hacking-training/ — course pages expose programme-specific detail, delivery information, demo enquiry and trainer/course sections. UX lesson: keep the AROUSH course detail page structured around its own outline, prerequisites, delivery confirmation and a direct enquiry action. Do not copy i-Medita's prices, duration, enrolment counts, ratings, schedules, certifications or placement statements.
- PyNet Labs catalogue: https://www.pynetlabs.com/courses/ — the catalogue groups a large set of programmes into network automation, AI for network engineers, SD-WAN, data science, data centre, routing and switching, network security, cloud, segment routing and cybersecurity. UX lesson: keep category navigation prominent and use search to shorten discovery. AROUSH retains its own published categories and four learning-goal collections rather than importing PyNet's course range or marketing claims.

Changes applied in this pass are limited to accessible course-filter relationships and automated public-claim checks. No competitor prices, testimonials, ratings, learner counts, credentials, schedules, placement outcomes or guarantees were copied.


## Session 24 official-page refresh — 6 November 2026

- Apna College Prime: https://www.apnacollege.in/prime — the current page separates entry points for engineering students, working professionals and non-CS learners, and presents the AI/ML curriculum in scan-friendly topic groups. AROUSH retains its own programme content and uses only the audience-oriented discovery and curriculum-structure lesson.
- i-Medita: https://www.imedita.com/ and https://www.imedita.com/ccie-bootcamp/ — the current public pages make course discovery, trainer information, programme details and demo enquiry visible. AROUSH keeps its own published course facts and human enquiry route; no i-Medita prices, durations, enrolment counts, ratings, credentials, schedules or placement statements are copied.
- PyNet Labs: https://www.pynetlabs.com/courses/ — the current catalogue provides technology categories and career-path navigation alongside a searchable course catalogue. AROUSH retains its own 20 published courses and four learning-goal collections; no PyNet course counts, ratings, prices, hiring partners, placement figures or guarantees are copied.

No competitor claims, statistics, prices, testimonials, credentials, schedules, ratings or guarantees were copied into AROUSH content.

## Session 25 recheck — 6 November 2026

Fresh official pages checked:

- Apna College Prime: https://www.apnacollege.in/prime — the current page presents an AI/ML programme with a scannable sequence of Python/data preparation, machine-learning concepts, deep-learning/GenAI concepts, and project work. AROUSH should continue to make its own verified course outlines and learning-goal collections easy to compare. No Apna College start date, curriculum claim, project promise, support offer, price or outcome was copied.
- i-Medita FAQ and Ethical Hacking course: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ethical-hacking-training/ — the FAQ makes location, schedule and language questions easy to find; course pages place programme details, FAQs and trainer information near the enquiry path. AROUSH can continue improving its own FAQ and course-specific enquiry route, but must not import i-Medita's office details, dates, prices, language claims, credentials, ratings or placement statements.
- PyNet Labs catalogue and contact page: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — the catalogue groups offerings by technology and career path, while the contact page offers clear counselling and course-expert routes. AROUSH already has search, category filters, four goal-based collections and direct enquiry links; these patterns support retaining those controls and making human handoff clear. No PyNet Labs catalogue counts, hiring/placement figures, ratings, fees, batch dates or response-time claims were copied.

Only information architecture and UX patterns are used. Competitor marketing claims and numerical data remain excluded from AROUSH pages.

## Session 26 official-page recheck — 7 November 2026

- **Apna College Prime** (https://www.apnacollege.in/prime): its current page groups AI/ML curriculum into Python and data foundations, mathematics, machine-learning concepts and next-step information. AROUSH should keep its own course outlines scannable and ordered, but publish only AROUSH-verified prerequisites, modules and practical work.
- **i-Medita FAQ and CCNA course** (https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ccna-training/): the pages make training location, schedules, language, course detail, trainer information and enquiries discoverable. AROUSH should keep its own course FAQs and contact path near the relevant programme; no i-Medita credentials, partner counts, fees, ratings or placement claims are reused.
- **PyNet Labs catalogue and contact** (https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/): the catalogue uses technology/category and career-path discovery, and the contact page makes human counselling routes visible. AROUSH retains its own search and filters; course level, duration, delivery mode and prerequisites should be shown only when AROUSH has verified values.

No competitor prices, discounts, learner totals, ratings, testimonials, credentials, schedules, hiring partners, placement statistics or guarantees were copied. Current AROUSH source findings are recorded in `LIVE-SOURCE-REVIEW-2026-11-07.md`.
