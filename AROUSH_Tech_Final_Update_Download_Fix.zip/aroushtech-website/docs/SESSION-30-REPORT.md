# AROUSH Tech development report — Session 30

Date: 7 November 2026

## Scope and release boundary

Continued from Session 29 using the extracted project copy. No live WordPress, hosting, DNS, GitHub repository, analytics property or deployment was changed.

## Work completed

1. Reopened the live homepage, course catalogue, Contact page and all 20 individual course pages.
2. Found a fee conflict for CCNA and CCNA DevNet: the public Courses catalogue lists ₹19,999 for each, while the individual course pages list ₹19,000. The rebuilt site now withholds numeric fees for these two courses until AROUSH confirms the current amounts. The chatbot explains the conflict and routes visitors to the team.
3. Found that the live CEH course page attributes its instructor to UniNets and includes provider-specific training copy. The rebuilt site now withholds the CEH syllabus, duration and trainer claims pending an AROUSH-approved version. The existing Fortinet/I-Medita content hold remains. The catalogue still contains all 20 course entries; 18 course detail pages have source-backed outlines and two have owner-review notes.
4. Confirmed that multiple reviewed course pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`. The destination was not opened or copied. The rebuild continues to block the host and does not process payments.
5. Replaced the two hard-coded office map coordinate pins with Google Maps search URLs built from the exact street addresses published on the AROUSH Contact page. Added a visible caveat that the office address search does not confirm the precise entrance or the separate J.P. Nagar training venue.
6. Added a reusable `CoursePrice` component so homepage, catalogue and detail pages share the same fee display and conflict-withholding logic.
7. Added a chatbot quick reply and answers for CCNA and CCNA DevNet fee questions.
8. Added regression checks for the fee conflicts, CEH provider attribution, address-search links and shared price component.
9. Refreshed competitor UX notes for Apna College, i-Medita and PyNet Labs. Only curriculum hierarchy, course discovery and FAQ/enquiry patterns were retained.

## Fresh official-source findings

- Homepage: https://aroushtech.in/ — still advertises 20+ courses and a free demo, and still exposes zero-value counters and 16 unrelated gambling/betting footer links. The rebuild excludes the zero counters and unrelated links.
- Courses: https://aroushtech.in/courses/ — 20 catalogue entries. CCNA and CCNA DevNet each show ₹19,999 here.
- CCNA: https://aroushtech.in/ccna/ — individual detail page shows ₹19,000.
- CCNA DevNet: https://aroushtech.in/ccna-devnet/ — individual detail page shows ₹19,000.
- CEH: https://aroushtech.in/ceh-certified-ethical-hacker/ — the detail page says the course is conducted by a UniNets instructor; third-party-attributed content is withheld from the rebuild.
- Contact: https://aroushtech.in/contact-us/ — publishes the company email, phone, two Bengaluru office addresses and a J.P. Nagar training-centre reference.

The all-course-page review found the same unverified checkout host on multiple course detail pages. The finding is recorded in `docs/OWNER-APPROVAL-CHECKLIST.md`; the destination was not opened.

## Validation

`npm run check:offline` passed all 15 dependency-free validators. The final run reported:

- Content: 10 services, 20 courses, 18 source-backed outlines, 2 provider-attribution review notes, 18 consistent fee pairs and 2 withheld fee conflicts.
- Privacy/analytics: GA4 opt-in only, blank Measurement ID, reject/withdrawal and voluntary phone field.
- Accessibility: 23 TSX files scanned.
- Internal links: 30 paths and 20 course slugs checked.
- External-link security: 33 source files scanned; 9 HTTPS hosts reviewed.
- Chatbot: 45 intent-routing cases, including CCNA and CCNA DevNet fee-conflict handling.
- JavaScript: 20 files syntax-checked.
- TypeScript/TSX: 30 files parsed with global TypeScript 5.8.3; syntax only.
- CSS: 521 rules and 20 at-rules parsed with global PostCSS.

The dependency-free suite is run with:

```bash
npm run check:offline
```

The suite now includes checks for: 20 public course records; 18 consistent catalogue fee pairs; fee-review notes for CCNA and CCNA DevNet; 18 source-backed course outlines; CEH and Fortinet provider-attribution notes; two office-address search links; visible training-centre caveat; shared course-price rendering; chatbot fee-conflict responses; analytics consent; accessibility; internal routes; external-host policy; and syntax.

Do not describe syntax/source checks as a full semantic typecheck, ESLint run, production build or browser QA.

## Production blockers

- Node.js 24.x is required; this environment runs Node.js 22.16.0 and has no `nvm`, `fnm` or `node24` executable.
- A reviewed `package-lock.json` and installed dependencies are still required. `npm ping` failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- Full TypeScript typecheck currently fails because `next` and React type declarations are not installed; ESLint and Next.js build commands are unavailable; `npm audit` returns `ENOLOCK` because there is no lockfile. Complete all four in a working Node 24/npm environment.
- Android and desktop browser QA remain pending.
- AROUSH must resolve CCNA/CCNA DevNet fees and approve CEH/Fortinet syllabus details.
- The authorised WordPress/hosting administrator must investigate the 16 unrelated footer links and verify any third-party checkout destination before migration.

## Privacy and approvals

GA4 Measurement ID remains blank. Analytics is disabled until owner configuration and explicit visitor opt-in. Reject and withdrawal remain available. Phone number remains optional and visitor-supplied. No server-side lead database or CRM was added.

## Package verification

The 7.4 MB ZIP contains the complete project source, passes `unzip -t`, and was freshly extracted to a separate directory. The extracted copy passed the same `npm run check:offline` suite.

## Change control

No live site, WordPress installation, DNS, GitHub repository, analytics property or production deployment was changed.
