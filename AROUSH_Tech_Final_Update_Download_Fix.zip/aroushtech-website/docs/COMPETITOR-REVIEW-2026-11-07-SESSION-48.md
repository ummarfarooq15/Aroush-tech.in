# Competitor UX review — Session 48

**Reviewed:** 7 November 2026  
**Purpose:** Compare public information architecture and course-discovery patterns only. Do not copy competitor claims, statistics, ratings, testimonials, prices, trainer credentials, schedules, guarantees or proprietary wording into AROUSH content.

## Apna College

Official pages reviewed:
- https://www.apnacollege.in/
- https://dsa.apnacollege.in/
- https://www.apnacollege.in/notes

Observed UX patterns:
- The main page separates learning programmes by goal and presents a clear route to explore a programme.
- Course pages and study resources organise curriculum content into digestible topics.
- The DSA practice area uses a structured roadmap and lets learners see progress through a sequence of topics.
- A dedicated notes area makes supplementary learning material discoverable.

Useful AROUSH application:
- Keep goal-based learning paths above the full catalogue so visitors can start from a learning outcome rather than a long list.
- Keep course outlines and verified FAQs close to the course introduction.
- If AROUSH later publishes approved notes/lab guides, give them a dedicated resource library with clear ownership and update dates.

Already present in AROUSH:
- Six goal-based learning paths.
- Individual course detail pages with source-backed outline topics and explicit review notes where source material is not suitable to migrate.
- Searchable FAQs and a grounded website assistant.

## i-Medita

Official page reviewed:
- https://www.imedita.com/

Observed UX patterns:
- The main navigation groups a broad catalogue by technology/vendor.
- Trainer profiles and course categories are easy to discover.
- Course pages use a compact metadata block before longer descriptions and curriculum content.
- Visitors can move from course discovery to an enquiry or training-adviser contact route.

Useful AROUSH application:
- Keep category navigation, the team page and course enquiry actions easy to reach.
- Use a consistent metadata block only when AROUSH has verified the value (for example, duration or published outline status).
- Do not fill gaps in AROUSH course data with competitor formats, lab-access promises or schedules.

Already present in AROUSH:
- Category filters, goal-based learning paths, team profiles, course pages and separate learner/business enquiry paths.

## PyNet Labs

Official pages reviewed:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

Observed UX patterns:
- The homepage exposes technology families and featured programmes.
- The catalogue supports keyword search, category filters and career-path browsing.
- Course cards and detail pages make course metadata and curriculum routes easy to scan.
- FAQ content helps visitors understand the training model and next steps.

Useful AROUSH application:
- Keep search, category filtering, sorting and comparison accessible from the catalogue.
- Use consistent course cards and detail pages, but show only AROUSH-owned facts.
- Keep enquiry routes available when the visitor cannot determine the correct programme from the catalogue.

Already present in AROUSH:
- Search across course names and technologies, category filters, natural A–Z/Z–A sorting, outline-availability filtering, comparison of up to three courses, shareable catalogue URLs, searchable FAQs and a contact handoff.

## Session 48 priorities applied

The current AROUSH build already includes the main transferable course-discovery patterns. This session focused on making company information easier to discover through the chatbot: team profiles, vision/mission, gallery and office-location questions now have verified answers and relevant page links. No competitor statistics or claims were imported.

## Remaining opportunity

A resource/download centre could be useful if AROUSH supplies approved lab guides, notes, brochures or course handouts. Do not create placeholder resources or copy competitor material. Confirm copyright, version ownership and public access before adding such a section.
