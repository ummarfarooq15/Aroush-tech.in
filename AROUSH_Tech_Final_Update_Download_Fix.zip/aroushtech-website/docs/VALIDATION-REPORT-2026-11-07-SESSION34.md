# Validation report — Session 34

Date: 7 November 2026

## Offline validation

`npm run check:offline` completed successfully. All 17 dependency-free validation commands passed:

1. Content validation — 10 services, 20 public courses, 18 published course outlines, 2 provider-attribution review notes, 18 consistent catalogue fee pairs, 2 withheld fee conflicts, 6 SOC/SIEM learning paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 office addresses and 31 public routes.
2. Privacy validation — opt-in-only GA4, blank Measurement ID, reject/withdrawal, persistent settings, disabled Google Signals/ad personalisation, voluntary phone and no server-side lead/CRM storage.
3. Analytics policy tests — consent gating, Measurement ID validation, safe page paths/referrers and minimal page-view payload.
4. Brand validation — approved logo assets and favicon.
5. UX validation — chatbot, course discovery, FAQ search, navigation, 404 recovery and voluntary email enquiry workflow.
6. Accessibility source validation — 25 TSX files, labelled controls, native FAQ disclosures, keyboard focus, live status and reduced-motion markers.
7. Internal link validation — 31 paths and 20 course slugs checked.
8. External-link policy tests — HTTPS allowlist, HTTP/protocol-relative rejection, spam domains, unverified checkout host and mailto/tel handling.
9. External-link scan — 37 source files and 9 HTTPS hosts reviewed.
10. Public-claims guard — 35 public source files scanned.
11. Learning-path validation — 4 collections, 20 valid course links and 6 SOC/SIEM options.
12. FAQ content/navigation validation — 12 unique questions across 3 categories; links to navigation, footer, contact, sitemap and chatbot retained.
13. FAQ search tests — 7 direct behavioral assertions plus integration/accessibility/mobile markers.
14. Chatbot tests — 47 intent-routing cases passed.
15. JavaScript syntax — 23 `.mjs` files passed.
16. TypeScript/TSX syntax — 33 `.ts`/`.tsx` files parsed with TypeScript 5.8.3; syntax only.
17. Release configuration — Node 24 pin, scripts and blank GA4 default validated.

PostCSS parsed `app/globals.css` successfully after the Session 34 additions. The parser reported 557 CSS rules, 23 at-rules and 1,825 declarations.

## Production checks attempted

| Check | Result | Reason |
|---|---|---|
| Node runtime | Blocked | Environment has Node.js 22.16.0; project pins Node.js 24.x. |
| npm registry | Blocked | `npm ping` failed with `EAI_AGAIN` resolving `registry.npmjs.org`. |
| Dependency install | Not run to completion | Registry unavailable; `node_modules/` absent. |
| Package lockfile | Missing | No reviewed `package-lock.json` is present. |
| Full TypeScript typecheck | Blocked | Next.js/React packages and declarations are not installed. |
| ESLint | Blocked | ESLint package is not installed. |
| Next.js production build | Blocked | Next.js package is not installed. |
| npm audit | Blocked | No lockfile (`ENOLOCK`) and dependencies not installed. |
| Real Android/desktop browser QA | Pending | No working local build or staging environment is available. |

The source-level TypeScript syntax check must not be described as a full typecheck. Offline validators do not prove runtime rendering, browser behavior or production readiness.

## Release and privacy state

- `NEXT_PUBLIC_GA_MEASUREMENT_ID` remains blank.
- Analytics remains disabled until owner setup and explicit visitor opt-in.
- The FAQ search operates only on static in-memory FAQ content; it does not transmit search terms.
- The contact form remains a visitor-controlled email draft. No backend, lead database or CRM was added.
- No live site, WordPress, DNS, GitHub repository, analytics property or production deployment was changed.
