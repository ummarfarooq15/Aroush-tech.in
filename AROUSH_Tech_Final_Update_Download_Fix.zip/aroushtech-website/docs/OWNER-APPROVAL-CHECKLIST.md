# AROUSH owner approval checklist before production

This checklist separates information visible on the current public website from details that should be reconfirmed before the new site goes live.

## Urgent live WordPress security review — required before migration

- [ ] Investigate the 16 unrelated gambling/betting footer links still visible on the public homepage at the 7 November 2026 recheck (first documented 6 November 2026). Follow `WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md`; preserve filesystem/database backups and logs before cleanup.
- [ ] Have the authorised hosting/WordPress administrator inspect users, plugins, themes, widgets, database content/options, custom code, uploads, scheduled tasks, `.htaccess`, `wp-config.php`, hosting cron jobs and access logs.
- [ ] Confirm whether the links were stored in WordPress, injected by a plugin/theme/third party, or introduced elsewhere. Record the likely cause and remediation.
- [ ] Review Google Search Console security issues/manual actions and indexed spam pages. Confirm clean recrawls after remediation.
- [ ] Obtain written owner/host confirmation that the live site and hosting environment have been investigated and cleaned before migration, redirect or domain cutover.

## Contact and company identity

- [ ] Confirm that the Corporate Office and Registered Office addresses currently shown on the live Contact page are still current.
- [ ] Confirm that Google Maps address-search results resolve to the correct public entrance for both office addresses. The rebuild no longer uses unverified coordinate pins; the J.P. Nagar training-centre venue remains a separate confirmation item.
- [ ] Confirm the CIN and legal-name presentation for the footer and legal notice against current company records.
- [ ] Confirm the official LinkedIn company page link.

## Courses and commercial information
- [ ] Review and approve the new `/faqs` page wording, especially course fee conflicts, training-centre location caveat, enquiry email-draft behavior, payment safety and service-availability qualifications.

- [ ] Reconfirm all public catalogue fee pairs, including whether the previous/struck-through amounts should remain visible. The rebuild currently withholds numeric fees for CCNA and CCNA DevNet because the catalogue lists ₹19,999 while each individual course page lists ₹19,000.
- [ ] Confirm current course availability, schedule, duration, prerequisites, delivery format and lab access for each course.
- [ ] Provide an AROUSH-approved Fortinet Certified Engineer syllabus; the legacy detail page explicitly attributes its training to I-Medita and its long-form content is not reproduced.
- [ ] Provide an AROUSH-approved CEH syllabus, trainer allocation and duration. The legacy CEH page identifies the instructor as a UniNets trainer; its syllabus, duration and trainer claims are withheld from the rebuild pending AROUSH confirmation.
- [ ] Verify the “Buy Course” destination `demosites.royal-elementor-addons.com` shown on multiple reviewed course detail pages, including AI & ML, both Agentic AI courses, CCNA, CCNA DevNet, ISE, CEH, CyberSys, PenTest, both Linux security courses, CCNP Data Center, Ansible & Terraform, CCNP Enterprise, Checkpoint Firewall, CCNP Security, Fortinet, AWS and Palo Alto. Confirm merchant ownership, payment processing, privacy/data handling, refund terms and approval before any new checkout link is promoted; the rebuild does not use this destination.
- [ ] Confirm the exact completion certificate wording and whether any vendor-issued certification or exam voucher is included.

## Marketing claims that need written approval

- [ ] Confirm whether the current Contact FAQ's “100% job assistance” statement is accurate and authorized.
- [ ] Confirm whether the current Contact FAQ's “24/7 lab access” statement is accurate and authorized.
- [ ] Confirm the About page's trainer-certification and prior-company experience wording before it is reused.
- [ ] Confirm the Gallery page's placement-outcome statement before it is reused.
- [ ] Confirm permission and preferred wording for the Gallery page's references to Larsen & Toubro Infotech Ltd, Capgemini and NTT Level 1 & Level 2 corporate training.
- [ ] Confirm the newsletter provider, subscription destination, consent wording and data-retention process before adding a newsletter form to the new site.

## Images and brand assets

- [ ] Approve local reuse of the logo, three team portraits and ten training/learner photographs.
- [ ] Inspect the three certificate images linked in the live homepage and approve their contents and reuse before adding a certificate section.
- [ ] Keep the client-logo collage excluded unless each logo/customer reference is verified and permission is confirmed.

## Service portfolio and operations

- [ ] Confirm which of the ten expanded service areas are currently available for delivery and which should be labelled as planned or partner-supported.
- [ ] Confirm platform-specific capabilities, licensed access, delivery resources, support hours and acceptance criteria before publishing any detailed commitment.
- [ ] Confirm the preferred production enquiry destination and approve the final privacy/consent wording, administrator roles and deletion workflow. The owner approved a development-only Supabase lead database with voluntary email/SMS OTP verification on 7 November 2026; this does not approve production account setup or deployment.
- [ ] Name the hosting/WordPress security administrator who will own the investigation and provide written remediation confirmation before migration.
- [ ] Confirm the instructor name/spelling: the root homepage and About page say “Tajuddin”, while the alternate `/home/` page crawl says “Taluqdar”.
- [ ] Reconcile featured-course promotional prices on the homepage with the catalogue and individual course detail pages before each campaign.
- [ ] Confirm the 2026 profile's team qualification/experience claims before publication: Abdul Aleem Khan (B.E. Electronics & Communication Engineering; 35+ years), Tajuddin (MCA; 20+ years) and Mohammed Khalid (B.Sc. Computer Science; 15 years).
- [ ] Reconcile the company-profile address (#09, 19th Main, 20th Cross, SMS Layout, JP Nagar 5th Phase) with the two office addresses currently published on the live Contact page. The rebuild currently follows the live Contact page and does not replace it with the profile address.
- [ ] Confirm Tajuddin's public title: the live About page says “Technical Head Networking & Cyber Security”, while the 2026 company profile says “Director & Vertical Head Cyber Security”. The rebuild currently follows the live website's role title.
- [ ] Confirm permission to reuse the two publicly displayed student testimonials and their displayed names (Jamshed (tajakistan) and Sana (Jordan)).

- [ ] Confirm the exact public training-center venue in J.P. Nagar and whether it is different from the corporate and registered office addresses. The live Contact page describes a J.P. Nagar training center but does not establish a complete visitor address. The rebuild now uses Google Maps address-search links for the two published office addresses rather than unverified coordinate pins.
- [ ] Confirm which courses, dates and delivery modes are eligible for the free demo advertised on the live homepage.

## Privacy and visitor analytics

- [ ] Decide whether AROUSH wants optional Google Analytics 4. No GA4 property or Measurement ID has been created or supplied by this project.
- [ ] If approved, provide a Measurement ID from an AROUSH-owned Google Analytics property and configure it only in the intended staging/hosting environment. The visitor opt-in requirement must remain enabled.
- [ ] Confirm the company account that owns the GA4 property and name the staff who may access reports.
- [ ] Confirm the intended reporting scope: aggregate pages, visit/engagement time, device/browser categories, traffic source and approximate geography only.
- [ ] Keep Google Signals and advertising personalisation disabled. Turn off Enhanced Measurement for scrolls, outbound clicks, file downloads, video engagement, site search and form interactions; keep only page views and standard session/engagement metadata needed for aggregate visit-time, device/browser, traffic-source and approximate-geography reports. Google Ads linking, BigQuery export and other integrations require separate approval.
- [ ] Select the shortest suitable GA4 user-level retention period and record the chosen period in the privacy notice.
- [ ] Confirm the approved privacy contact, enquiry-email retention period, visitor request/complaint process and data deletion process.
- [ ] Obtain legal review of the privacy notice and consent flow against the requirements in force at production launch, including the DPDP Act/Rules where applicable.
- [ ] Test allow, reject, withdrawal, re-acceptance and the persistent privacy-settings control in a staging browser. Confirm no GA request is sent before explicit opt-in.
- [ ] Keep phone number optional in the root marketing website form. In the separate OTP enquiry app, the visitor must voluntarily enter a mobile number to complete that verified enquiry path. Do not infer phone numbers or exact addresses from analytics.
- [x] Development-only Supabase lead storage and voluntary email/SMS OTP were explicitly approved by the owner on 7 November 2026. Before production, approve the actual provider accounts, data fields, named administrator access, security controls, purpose, retention, deletion and legal wording. No CRM integration is included. Obtain separate explicit deployment approval.
- [ ] Confirm whether `demosites.royal-elementor-addons.com` is an authorised AROUSH checkout destination. The rebuild explicitly blocks it and does not accept payments until merchant ownership, payment processor, privacy/data handling, refund terms and owner authorisation are confirmed.
