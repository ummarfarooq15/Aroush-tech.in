# Session 24 — external-link hardening, release preflight and live-source recheck

Date: 6 November 2026

## Summary

This session strengthened the rebuild's external-link security checks and made the remaining release blockers easier to identify. It also re-opened the current AROUSH public pages and refreshed the competitor UX notes. No live system was modified.

## Live AROUSH source recheck

Official pages reopened during this pass:

- Homepage: https://aroushtech.in/ — still advertises 20+ courses and a free demo, presents six course families and features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH. The page still shows zero-value counters and 16 unrelated gambling/betting footer links. The rebuild continues to omit the counters and unrelated links.
- About: https://aroushtech.in/aboutus/ — still publishes the vision and mission and three team profiles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid, with their public role titles.
- Courses: https://aroushtech.in/courses/ — still lists 20 catalogue entries and their visible fee pairs. The local catalogue remains aligned with those 20 title/fee pairs; every displayed amount is labelled as a website-listed reference that must be confirmed before payment.
- Gallery: https://aroushtech.in/gallery/ — still shows training and corporate-training photographs, plus separate client/placement-related material. The rebuild keeps the ten training-photo references and excludes the client-logo collage and unconfirmed placement/client claims.
- Contact: https://aroushtech.in/contact-us/ — still publishes `taj@aroushtech.in`, `+91 88676 92074`, the Corporate Office and Registered Office addresses, and the training-format FAQ. Certification, 100% job-assistance and 24/7 lab-access wording remains excluded pending written owner confirmation.

The public footer links remain consistent with possible SEO-spam injection, but a public crawl does not prove the WordPress entry point or full hosting compromise. The authorised administrator must investigate before migration or domain cutover.

## Code changes

- Refactored the external-link checks into `scripts/external-link-policy.mjs` so the policy can be tested independently of the Next.js application.
- Expanded URL detection to include `http://` and protocol-relative (`//host`) destinations. Non-HTTPS destinations are rejected, unknown hosts require explicit review, and known spam domains/anchor phrases remain blocked.
- Added `scripts/test-external-link-policy.mjs` with positive and negative cases for approved HTTPS links, HTTP rejection, protocol-relative links, unknown hosts, known spam domains, spam anchor text, and non-web `mailto:`/`tel:` references.
- Added `npm run test:external-link-policy` to `npm run check:offline`.
- Added `scripts/validate-release-preflight.mjs` and `npm run preflight:release`. This reports the actual Node.js runtime, package-lock presence and installed build/lint dependencies before a developer starts the production checks. It exits non-zero when the environment is not ready.
- Updated `scripts/validate-release-config.mjs` to require the new scripts and ensure the external-link policy tests remain in the offline check chain.
- Updated README and beginner developer instructions with the new commands.

## Competitor UX research

Current official pages checked:

- Apna College Prime: https://www.apnacollege.in/prime — audience-specific learning entry points and a scannable AI/ML curriculum. AROUSH keeps its own course information and uses only the discovery/structure lesson.
- i-Medita: https://www.imedita.com/ and https://www.imedita.com/ccie-bootcamp/ — visible trainer discovery, programme detail and demo enquiry paths. AROUSH retains its own published details; no third-party claims or prices are copied.
- PyNet Labs catalogue: https://www.pynetlabs.com/courses/ — technology categories, searchable catalogue and career-path navigation. AROUSH retains its own 20-course catalogue and four learning-goal collections.

No competitor prices, statistics, ratings, testimonials, credentials, schedules, placement outcomes or guarantees were copied.

## Validation performed

- `npm run check:offline` — passed all 13 dependency-free validators, including the new external-link policy unit tests.
- External-link policy tests — passed for HTTPS allowlist, HTTP rejection, protocol-relative links, unknown hosts, known spam domains, spam anchor text, and `mailto:`/`tel:` handling.
- External-link validator — passed; 32 application/config/static source files scanned, nine HTTPS hosts reviewed, no HTTP links, known spam domains, spam phrases or unapproved external hosts found in the rebuild source.
- Content validator — passed: 10 services, 20 public courses (19 source outlines plus one owner-review note), six SOC/SIEM learning paths, three team profiles, ten gallery photographs, eight target-industry profiles, two published office addresses, two live-site testimonials, 30 public routes and 23 permanent redirects.
- Privacy, analytics policy, brand, UX, internal links, public claims, learning paths and chatbot regression validators — passed.
- Chatbot regression tests — passed 23 intent-routing cases.
- JavaScript syntax — passed for 18 `.mjs` files.
- TypeScript/TSX syntax transpilation — passed for 27 files with zero syntax diagnostics. This is syntax-only, not semantic typechecking.
- CSS/PostCSS parsing — passed for 534 top-level rules/at-rules.
- Release preflight — correctly reported blockers: Node.js 22.16.0 rather than 24.x, no package lockfile and missing Next.js/React/TypeScript/ESLint packages.

## Production blockers

- `npm run typecheck` remains blocked by missing Next.js, React and related type declarations.
- `npm run lint` remains blocked (`eslint: not found`).
- `npm run build` remains blocked (`next: not found`).
- `npm run audit` remains blocked because no lockfile exists (`ENOLOCK`).
- A fresh `npm install --ignore-scripts --no-audit --no-fund --package-lock-only` attempt timed out. The npm debug log records `EAI_AGAIN` while resolving `registry.npmjs.org`; no lockfile or usable `node_modules` directory was created.
- Real Android and desktop browser QA remains pending a successful staging build.
- The WordPress/hosting administrator must investigate and document cleanup of the unrelated live footer links before any migration or domain cutover.
- Owner approval remains required for current fees/availability, selected legacy claims, image rights and GA4 setup/legal wording.

## Privacy and deployment

GA4 Measurement ID remains blank. Analytics remains disabled until owner setup and explicit visitor opt-in. Reject and withdrawal controls remain available. Phone remains optional and voluntary. No server-side lead database or CRM was added. No GitHub push, WordPress edit, DNS change, hosting change or production deployment was performed.

- Added `*.tsbuildinfo` to `.gitignore` and removed the stale TypeScript incremental cache from the handoff package so it is regenerated by the next successful typecheck.
