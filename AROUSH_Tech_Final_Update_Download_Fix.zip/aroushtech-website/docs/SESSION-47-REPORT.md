# Session 47 report — 7 November 2026

## Scope completed

1. Continued the AROUSH Tech website maintenance and source/competitor review.
2. Integrated the owner-approved visitor-intelligence companion app as a separate application under `apps/visitor-intelligence` without changing the root marketing site's runtime or deployment.
3. Reworked analytics to aggregate-only reporting and removed persistent visitor-profile behaviour from the companion tracker/dashboard.
4. Hardened OTP verification and lead creation with atomic Supabase RPCs, HMAC-keyed rate limits, Turnstile server-side validation and bounded JSON parsing.
5. Updated privacy, security, Android setup, dual-site integration and beginner-developer documentation.
6. Added 54 offline checks for aggregate analytics, consent, OTP, Turnstile, database permissions and deployment boundaries.
7. Refreshed competitor UX research for Apna College, i-Medita and PyNet Labs.

## Code changes

- `apps/visitor-intelligence/public/aroush-tracker.js`: explicit opt-in/reject, persistent Privacy control, temporary tab-only session token, active page-time events, query-free paths, no persistent visitor ID.
- `apps/visitor-intelligence/app/api/track/route.ts`: HMAC session key, safe path/referrer/campaign handling, aggregate event storage, no IP or visitor profile storage.
- `apps/visitor-intelligence/app/api/admin/data/route.ts` and dashboard: aggregate-only sessions, pages, time, device/browser, source and approximate-geography breakdowns. No visitor list or individual journey view.
- `apps/visitor-intelligence/supabase/schema.sql`: no visitor profile table; RLS and server-only grants; atomic rate-limit, recipient cooldown, email OTP, SMS OTP and one-time lead creation functions. Added an explicit migration from the earlier visitor-profile draft that removes old visitor/session data while retaining lead records.
- Email/SMS OTP routes: atomic verification state, per-recipient caps and server-side Turnstile protection.
- Admin login: Turnstile validation and four-hour signed HTTP-only session.
- `apps/visitor-intelligence/lib/use-turnstile.ts` and `lib/turnstile.ts`: fresh single-use browser tokens and server-side Cloudflare Siteverify with hostname check; production fails closed when missing.
- Documentation: README, privacy draft, Android setup, dual-site integration, security review and owner retention/legal checklist.
- Root marketing website: clarified in its privacy notice that the companion app is development-only and is not connected to the live website.

## Competitor research

The updated review identifies useful patterns already reflected in the AROUSH site: goal-based learning paths, course outlines and FAQs, search/category filters, course comparison, team profiles, course enquiry routes and shareable catalogue views. Missing metadata such as level, format, schedules, lab entitlements or placement outcomes is not filled from competitors. See `docs/COMPETITOR-REVIEW-2026-11-07-SESSION-47.md`.

## Validation

- `npm run check:offline`: PASS.
- Visitor-intelligence source validator: 54 checks PASS.
- JavaScript syntax: 38 `.js`/`.mjs` files PASS.
- TypeScript syntax parser: 70 `.ts`/`.tsx`/`.mts` declaration/source files PASS (syntax only).
- Root content validator: PASS (10 services, 20 public courses, 6 learning paths, 3 team profiles, 10 gallery photos, 8 industry profiles, 2 office addresses, 2 testimonials, 31 routes, 23 redirects and structured data).

## Blockers

- Available runtime is Node.js 22.16.0; root and companion apps require Node.js 24.x.
- No package-lock files or `node_modules` are present.
- Full semantic TypeScript checks are blocked because Next.js, React, Supabase and Node type dependencies are absent; JSX/module/implicit-any errors cascade from missing dependencies, and `notFound()` cannot be typed without Next declarations. Four earlier TS2305 type-export errors were fixed by adding `.d.mts` declarations.
- ESLint is blocked (`eslint: not found`); dependency installation and a reviewed lockfile are required before linting.
- Next.js production builds fail with `next: not found` in both apps.
- Supabase, Resend, MSG91, Cloudflare Turnstile and Vercel accounts/credentials are not configured. Provider delivery, RLS and RPC integration tests are pending.
- Retention schedule, deletion workflow, official privacy contact and legal review are not approved.
- Real Android/desktop browser QA is pending a working staging deployment.

## Deployment boundary

No live website, WordPress installation, DNS record, GitHub repository, hosting account, GA4 property, Supabase project, Resend account, MSG91 account or Cloudflare account was changed. No tracker was installed on the live website. No deployment was performed.
