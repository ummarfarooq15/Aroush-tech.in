# Live AROUSH source review — Session 48

**Reviewed:** 7 November 2026  
**Primary source:** https://aroushtech.in/  
**Purpose:** Verify current public company, course, team, gallery and contact content before updating the rebuild. The live website remains untouched.

## Pages reviewed

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Courses: https://aroushtech.in/courses/
- CCNA detail: https://aroushtech.in/ccna/
- CCNA DevNet detail: https://aroushtech.in/ccna-devnet/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/

## Verified current content

### Homepage

- Public headline: “20+ Job-Ready Courses | Free Demo Available”.
- Current categories include cybersecurity, networking, cloud/DevOps, Agentic AI/machine learning, Linux/cybersecurity and web application penetration testing.
- Three featured course cards currently shown: Agentic AI with LangChain & Hugging Face, CCNP Security and CEH.
- Two student testimonials are visible.
- Three counters show zero values; do not reproduce them as statistics.
- The current page contains a cluster of unrelated gambling/betting footer links to unrelated domains. The rebuild excludes them. This is a suspected SEO-spam issue requiring a WordPress, plugin, theme, account, database, filesystem, log and Search Console investigation by the authorised administrator. A public crawl alone does not establish the injection point or full compromise.

### About and team

- Vision: AROUSH aims to be a preferred consulting and training services company providing solutions and training that empower people and businesses.
- Mission: The published mission focuses on supporting people's welfare and helping them realise their potential through training programmes.
- Three published profiles and roles:
  - Abdul Aleem Khan — Vertical Head Cyber Security & Cloud Security.
  - Tajuddin — Technical Head Networking & Cyber Security.
  - Mohammed Khalid — Technical Head for Networking Security.
- The page includes zero-value counters and broad trainer-experience statements; the rebuild does not use zero metrics or add unverified individual biographies/credentials.
- The legacy “Meet Our Team” navigation target resolves to the About page; the rebuild provides a separate `/team` page.

### Courses and course details

- The public catalogue currently lists 20 course cards.
- The catalogue shows CCNA at ₹19,999; the individual `/ccna/` page shows ₹19,000.
- The catalogue shows CCNA DevNet at ₹19,999; the individual `/ccna-devnet/` page shows ₹19,000.
- Both fee conflicts remain withheld from the rebuilt public display until AROUSH confirms the current amounts.
- The CCNA detail page contains a substantial curriculum and lab outline. The CCNA DevNet detail page contains a detailed DevNet outline.
- The CCNA DevNet “Buy Course” link resolves to a third-party demo-site domain; do not reproduce it as a trusted checkout destination.
- The rebuild continues to omit legacy checkout links and direct visitors to AROUSH for payment instructions.

### Gallery

- The public gallery shows training and corporate-training photographs and describes training activity in Bengaluru.
- The rebuild retains ten training/learner photo references and excludes the client-logo collage as proof of current partnerships or endorsements.
- Confirm image rights and move approved original assets to the new site's local public assets before production migration.

### Contact

- Published email: `taj@aroushtech.in`.
- Published phone: `+91 88676 92074`.
- Corporate Office: `#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029`.
- Registered Office: `AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078`.
- The Contact page separately refers to a physical training centre in Bengaluru (J.P. Nagar) but does not give a complete visitor address. Do not present either office address as the confirmed training venue.

## Implementation consequences

- The chatbot now answers verified questions about the team, mission/vision, gallery and office addresses, linking to `/team`, `/about`, `/gallery` and `/contact`.
- The office answer explicitly distinguishes the two published offices from the incomplete J.P. Nagar training-centre reference.
- The course catalogue continues to withhold the two conflicting fees.
- Zero counters, unsupported guarantees, unsupported vendor/placement claims and unverified checkout links remain excluded.
- The rebuilt site continues to use its review-first email handoff. The separately approved companion lead application remains development-only and is not connected to the live site.

## Owner actions before launch

1. Investigate and remediate the live WordPress SEO-spam footer links.
2. Confirm current CCNA and CCNA DevNet fees.
3. Confirm the complete J.P. Nagar training-centre visitor address and whether visitors may attend there.
4. Confirm image rights and provide approved original assets.
5. Review the final privacy notice, analytics configuration, retention/deletion process and applicable legal requirements.
6. Complete staging, device, database and provider tests before any production migration.
