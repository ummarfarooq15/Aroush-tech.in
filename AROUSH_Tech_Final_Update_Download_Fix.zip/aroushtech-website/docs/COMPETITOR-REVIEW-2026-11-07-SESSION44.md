# Competitor UX review — Session 44

Date: 7 November 2026

This is an information-architecture and interaction review only. Do not copy competitor pricing, promotions, student counts, ratings, testimonials, credentials, placements, schedules or guarantees.

## Apna College

Official reference: https://www.apnacollege.in/course/prime-2

The current Prime course page has a distinct programme navigation area and curriculum sections that let a visitor inspect subject groups and practical topics. The transferable lesson is to make programme information easier to scan and keep curriculum access close to the course overview. AROUSH retains its own course names, source-backed outlines and confirmation notes.

## i-Medita

Official reference: https://www.imedita.com/frequently-asked-questions/

The FAQ page is organised around practical visitor questions, including general information, schedules, pricing/payment and travel. The transferable lesson is to group FAQs by decision stage and provide a route to a human team when a detail is not clear. AROUSH keeps its own verified FAQ categories and contact details; no i-Medita prices, claims or policies were copied.

## PyNet Labs

Official reference: https://www.pynetlabs.com/courses/

The catalogue provides a search entry point and technical category groups such as network automation, routing/switching, AI for network engineers, network security, SD-WAN, cybersecurity, cloud and data centre. The transferable lesson is a layered catalogue: quick search plus understandable category navigation. AROUSH retains its own six public course themes and existing filters.

## Applied direction

- Session 44 adds visible breadcrumbs to interior pages so visitors can identify their location and return to the parent catalogue or page.
- The same breadcrumb data generates `BreadcrumbList` JSON-LD, reducing the risk that visible navigation and structured data disagree.
- The course detail breadcrumb exposes the path Home → Courses → Current course.
- Existing AROUSH course search, category, sorting, outline availability, comparison, share links and FAQ search remain unchanged.

No competitor commercial data or marketing claims were imported.
