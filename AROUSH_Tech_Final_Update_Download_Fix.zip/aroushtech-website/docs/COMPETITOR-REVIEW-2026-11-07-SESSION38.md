# Competitor UX review — Session 38

Date: 7 November 2026

This review records interface patterns only. Competitor claims, prices, ratings, testimonials, schedules, credentials, learner counts, placement figures and guarantees are not copied into AROUSH content.

## Apna College

Official pages reviewed:
- https://www.apnacollege.in/
- https://www.apnacollege.in/course/delta
- https://www.apnacollege.in/course/sigma-batch

Useful patterns:
- Programme pages make the learning subject and curriculum structure easy to scan.
- Learner questions are grouped around course fit, prerequisites, delivery and access.
- Distinct programme paths make it easier to understand which offer is intended for which learner goal.

Applied to AROUSH:
- Individual course links now open the learner enquiry path directly.
- The contact page offers a clear learner-specific route without importing Apna College course claims or offers.

## i-Medita

Official pages reviewed:
- https://www.imedita.com/frequently-asked-questions/
- https://www.imedita.com/contact/

Useful patterns:
- FAQs are grouped around practical decisions such as formats, location, schedules, pricing/payment and registration.
- Human contact options remain visible when a visitor needs a specific answer.

Applied to AROUSH:
- The Contact page now distinguishes learner, business/institution and general enquiry paths.
- The email-draft workflow is explained before the visitor submits, and no automated response or storage is implied.

## PyNet Labs

Official pages reviewed:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

Useful patterns:
- Large catalogues use topic categories and goal-based groupings to reduce browsing effort.
- Course detail pages provide a route to human guidance when visitors need current batch or programme information.

Applied to AROUSH:
- Course pages, learning paths and catalogue enquiries use a learner-specific contact route.
- Corporate training and service discussion links use the business/institution route.

## Boundaries

No competitor prices, promotions, testimonials, ratings, guarantees, statistics, credentials, course schedules or placement claims were copied. No competitor images or brand assets were reused. The new AROUSH enquiry routing is based on AROUSH's own published course catalogue, service portfolio and corporate/campus training information.
