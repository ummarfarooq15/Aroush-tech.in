# Validation report — Session 38

Date: 7 November 2026

## Passed

- `npm run check:offline`: all 20 dependency-free validators passed.
- `npm run validate:enquiry-paths`: 30 assertions passed.
- Content validation: 10 services, 20 public courses, 18 source outlines, 2 course fee conflicts withheld, 6 SOC/SIEM paths, 3 team profiles, 10 gallery photographs, 8 target-industry profiles, 2 published office addresses and 31 public routes.
- Privacy validation: GA4 opt-in only, blank Measurement ID, reject/withdrawal support, persistent settings, disabled Google Signals/ad personalisation, voluntary phone and no server-side lead/CRM.
- FAQ, course search, sort and comparison validators passed.
- Chatbot rule validation passed 47 intent-routing cases.
- Internal route/anchor validation passed.
- Accessibility source scan passed across all TSX pages/components, including the new enquiry path selector, cards and in-page form anchor.
- JavaScript syntax validation passed for all `.mjs` files.
- TypeScript/TSX syntax parsing passed for 36 files. This is not semantic typechecking.
- JavaScript syntax validation passed for 29 `.mjs` files.
- Global PostCSS parsed 604 CSS rules, 27 at-rules and 2,001 declarations without syntax errors.

## Blocked / pending

- Node.js runtime: 22.16.0; required: 24.x.
- npm registry lookup: `EAI_AGAIN registry.npmjs.org`.
- `package-lock.json`: absent.
- `node_modules/`: absent.
- Full TypeScript typecheck: blocked by unresolved Next.js/React modules and declarations.
- ESLint: blocked because the executable is not installed.
- Next.js production build: blocked because Next.js is not installed.
- npm audit: blocked because no package lockfile exists (`ENOLOCK`).
- Real Android and desktop browser testing: pending a successful install/build or staging environment.

## Scope safeguards

No production deployment, GitHub push, WordPress edit, DNS change, hosting change, analytics-property change or CRM/database integration was performed.
