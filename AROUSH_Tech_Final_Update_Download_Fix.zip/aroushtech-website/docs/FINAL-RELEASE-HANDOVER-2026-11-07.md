# AROUSH Tech website — final development handover

**Prepared:** 7 November 2026  
**Scope:** Public marketing website, course discovery, grounded FAQ chatbot, privacy-first analytics controls, and separately approved Visitor Intelligence companion app.  
**Status:** Development package ready for owner review; **not production-ready and not deployed**.

## What is in this package

- Responsive Next.js marketing website with Home, About, Services, Courses, Learning Paths, Training, Team, Gallery, FAQs, Contact and Privacy pages.
- Course catalogue with search, category and outline filters, sorting, shareable URL state, side-by-side comparison and fee-conflict safeguards.
- Learner, business and general enquiry paths. The public marketing-site form remains a review-first, voluntary email handoff; it does not write to a server-side lead database.
- Rule-based website FAQ assistant with quick replies, typed questions, verified AROUSH answers and links to relevant pages. It is not represented as live AI or CRM-connected.
- Accessibility, breadcrumbs, metadata, structured data, social cards, sitemap, redirects and external-link safeguards.
- Root-site GA4 consent integration, disabled by default until the owner supplies a valid GA4 Measurement ID and each visitor explicitly opts in. Reject and persistent preference controls are included.
- Separately located `apps/visitor-intelligence` companion app, included following the user's explicit approval for Supabase lead storage and voluntary email/phone OTP. It is not wired into the public marketing-site enquiry form and has not been connected to live provider accounts.

## Content and claims policy

The official AROUSH website is the source of truth for company, course, service, team, gallery and contact information. The current public catalogue has unresolved course-fee conflicts; affected prices are withheld rather than guessed. Incomplete training-centre directions, unconfirmed course details, unverified credentials, schedules, guarantees and commercial claims must remain unpublished until an authorised AROUSH owner confirms them. Zero-value counters and unrelated spam/betting footer links found on the live WordPress site are excluded from the rebuild and should be investigated by the authorised site administrator.

Competitor UX research is used only for general interaction patterns such as catalogue discovery, curriculum organisation, trainer discovery, FAQs and enquiry paths. No competitor statistics, prices, testimonials, guarantees or claims are reused.

## Privacy and security boundaries

- Root-site analytics is optional and must not load before explicit opt-in. A visitor can reject and later change their preference.
- Root-site analytics should be limited to aggregate page/time, device/browser, traffic source and approximate geography. No fingerprinting, covert identification, raw phone-number capture or exact-location claims.
- Phone numbers are collected only when a visitor voluntarily supplies one in a clearly described enquiry or verification flow.
- The visitor-intelligence app requires owner-managed Supabase, email, SMS and anti-bot credentials. Never commit `.env` files, service-role keys, OTP secrets or provider credentials.
- Before live use, verify database RLS and RPC permissions with a non-production project, test OTP delivery and expiry, abuse/rate limits, administrator access, deletion/retention procedures and provider costs.
- The privacy notice needs an approved contact address, retention periods, deletion procedure, processor/vendor list and legal review.

## Offline checks completed

`npm run check:offline` passed on the available Node.js 22.16.0 runtime. It covers content, privacy, visitor-intelligence source checks, analytics policy, brand, UX, accessibility source checks, internal links, breadcrumbs, social cards, external-link policy/security, public claims, learning paths, FAQs/search, course sorting/filtering/share/compare, enquiry paths/safety, chatbot rules, JavaScript syntax, TypeScript syntax and release configuration.

Important distinction: TypeScript syntax parsing is not semantic typechecking. Source checks are not a substitute for browser testing, live provider tests or a production build.

## Required release environment

This project pins Node.js 24.x in `package.json`, `.nvmrc` and `.node-version`.

From the `aroushtech-website` directory, in a clean Node.js 24 environment:

```bash
node --version
npm ci
npm run check:offline
npm run typecheck
npm run lint
npm run build
npm audit
```

If there is no reviewed `package-lock.json`, do not use `npm ci` yet. Generate the lockfile in a trusted Node.js 24 environment with network access, review the diff and dependency tree, then commit it through the owner's approved workflow. Run `npm audit` and resolve or document findings before staging.

## Staging and acceptance checklist

1. Use a staging hostname and non-production credentials; do not point the production domain at staging.
2. Complete semantic typecheck, lint, production build and dependency audit.
3. Test at 360px, 390px, 768px, 1024px and desktop widths, on Android Chrome and desktop Chromium/Firefox/Safari where available.
4. Keyboard-test navigation, chatbot, FAQ disclosures, course filters/comparison, consent banner/settings and enquiry review flow. Check focus visibility, screen-reader labels, reduced motion and zoom.
5. Test every internal route, redirects, sitemap, canonical metadata, social previews and 404 handling.
6. Verify chatbot answers only from approved content and routes unknown questions to the human team.
7. Confirm GA4 remains absent before consent, after rejection and when no Measurement ID is configured; confirm withdrawal stops further analytics collection.
8. In a non-production Supabase project, test RLS/RPC, OTP expiry/replay/attempt limits, concurrent verification, rate limits, Turnstile, lead validation, admin session expiry and deletion/retention.
9. Obtain written owner approval for privacy wording, retention, legal review, GA4 Measurement ID, provider credentials and administrator accounts.
10. Obtain a separate explicit deployment approval before any production change.

## Deployment boundary

No live WordPress content, DNS, GitHub repository, hosting project, GA4 property, Supabase project, Resend account, MSG91 account or Cloudflare account was modified as part of this development package. No deployment was performed. The user explicitly requested that this final update remain undeployed.
