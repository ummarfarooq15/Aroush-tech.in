# AROUSH Tech — Build, Security and Browser Validation

**Date:** 6 November 2026  
**Project:** Next.js 15.5.29 / React 19.3.1  
**Validation environment:** Node.js 22.16.0, npm 10.9.2, Chromium available  
**Required runtime:** Node.js 24.x (`.nvmrc`)

## Summary

The content and source-level syntax checks pass. A production build, dependency audit and runtime browser testing could not be completed in this environment because the project dependencies are not installed and package installation did not complete. The environment is also running Node 22 rather than the project's required Node 24. These are validation blockers, not evidence that the production build passes or fails on a correctly provisioned Node 24 environment.

## Results

| Check | Result | Evidence / reason |
|---|---|---|
| Content validation | **PASS** | `npm run validate:content` passed: 10 services, 20 public courses, 6 SOC/SIEM paths, 3 team profiles, 10 gallery photos, 8 industry profiles, 2 office addresses, 2 testimonials, 28 routes and 23 redirects. |
| TypeScript/TSX syntax transpilation | **PASS** | Global TypeScript 5.8.3 transpiled all 23 `.ts`/`.tsx` source files without syntax diagnostics. This is a syntax check, not a full typecheck. |
| CSS parse | **PASS** | Global PostCSS parsed `app/globals.css` successfully (359 top-level nodes). |
| Production build | **BLOCKED** | `npm run build` returned `next: not found`; `node_modules` is absent. |
| ESLint | **BLOCKED** | `npm run lint` requires the local Next.js executable, which is not installed (`next: not found`). |
| Full TypeScript typecheck | **BLOCKED** | `npm run typecheck` cannot resolve `next` or React JSX type declarations because dependencies are absent. |
| Dependency security audit | **BLOCKED** | `npm audit` returned `ENOLOCK`; there is no `package-lock.json`/other npm lockfile. An install attempt with retries/timeouts did not finish. No vulnerability-free claim is made. |
| Local runtime browser tests | **NOT RUN** | A working Next.js production/dev server cannot be started without installed dependencies. |
| Public-site browser smoke test | **BLOCKED BY NETWORK POLICY** | Chromium/Playwright navigation to `https://aroushtech.in/` returned `net::ERR_BLOCKED_BY_ADMINISTRATOR` for desktop, mobile-sized and tablet viewports. No page rendering or interaction result can be claimed. |
| Physical Android/iOS device test | **NOT PERFORMED** | No physical device or remote device lab is attached to this environment. Responsive emulation is not a substitute for a real-device test. |
| ZIP integrity | **PASS** | Final project archive passed `unzip -t` with no archive errors. |

## Environment blockers

1. The project pins Node 24.x in `.nvmrc`, but the available runtime is Node 22.16.0.
2. `node_modules` is not present.
3. `npm install --ignore-scripts --no-audit --no-fund` did not complete within the available execution window.
4. No npm lockfile is present, so `npm audit` cannot calculate a reproducible dependency tree.
5. Outbound Chromium navigation to the public site is blocked by the execution environment's administrator policy.

## Required next steps in GitHub Codespaces

Run these commands from the project root using Node 24.x:

```bash
node -v
npm install
npm run validate:content
npm run typecheck
npm run lint
npm run build
npm audit
```

Commit the generated `package-lock.json` after reviewing it, then use `npm ci` for reproducible CI builds. Resolve any reported findings before release.

After the app starts with `npm run dev` or `npm run start`, test at minimum:

- Desktop: 1365×900 and 1920×1080.
- Tablet: 768×1024.
- Android phone: 360×800 and 390×844 using Chrome on the actual phone.
- iPhone-sized viewport: 375×812, followed by Safari on a real iPhone if supported by the release audience.
- Navigation open/close, keyboard focus, chatbot open/close and quick replies, course filters, contact links, form validation, image loading, 404 route, horizontal overflow, zoom to 200%, and landscape orientation.
- Record screenshots, browser/OS versions, console errors, failed network requests and actual-device observations.

## Release decision

**Not production-ready for sign-off yet.** The source-level checks are useful, but the build, lockfile-backed dependency audit, local browser run and physical-device tests remain release gates. No production deployment or live-site modification was performed.

## Privacy and consent validation update — 6 November 2026

| Check | Result | Evidence / reason |
|---|---|---|
| Privacy/consent source validator | **PASS** | `node scripts/validate-privacy.mjs` confirms valid-ID gating, explicit opt-in, reject, withdrawal, persistent settings, disabled Google Signals/ad personalisation, blank default Measurement ID, voluntary phone field and absence of an approved server-side lead/CRM implementation. |
| GA4 activation status | **DISABLED** | `.env.example` has an empty `NEXT_PUBLIC_GA_MEASUREMENT_ID`; no GA4 property or ID was supplied. The integration does not load scripts until both a valid ID and explicit visitor opt-in are present. |
| Privacy notice | **SOURCE CHECK PASS** | `/privacy` identifies Google Analytics 4 and Google LLC, describes pseudonymous event processing, approximate geography, retention owner setup, voluntary phone handling and legal review. Owner/legal approval remains required. |
| Live consent/browser interaction test | **PENDING** | Must be run in a staging browser after the owner configures a GA4 ID. Verify no analytics network request before opt-in and verify reject, withdrawal and re-acceptance. |

## Session 13 source validation rerun — 6 November 2026

| Check | Result | Evidence / reason |
|---|---|---|
| Content validator | **PASS** | `node scripts/validate-content.mjs` passed: 10 services, 20 public courses, 19 source outlines plus one owner-review note, six SOC/SIEM paths, three team profiles, ten gallery photographs, eight target-industry profiles, two published offices, two live testimonials, 29 public routes and 23 redirects. |
| Privacy validator | **PASS** | `node scripts/validate-privacy.mjs` passed: opt-in-only GA4, blank ID by default, reject/withdrawal, persistent settings, cookie-clear attempt, disabled Google Signals/ad personalisation, voluntary phone field and no server-side lead/CRM integration. |
| TypeScript/TSX syntax transpilation | **PASS** | Global TypeScript 5.8.3 transpiled 25 `.ts`/`.tsx` source files with zero syntax diagnostics. This is not a semantic typecheck. |
| CSS parse | **PASS** | Global PostCSS parsed `app/globals.css` successfully (382 top-level rules/at-rules). |
| Node script/config syntax | **PASS** | `node --check` passed for `scripts/validate-content.mjs`, `scripts/validate-privacy.mjs` and `next.config.mjs`. |
| Full TypeScript typecheck | **BLOCKED** | `npm run typecheck` cannot resolve `next` or React JSX type declarations because dependencies are absent. The resulting missing-module/JSX errors are environment dependency errors; no full typecheck pass is claimed. |
| Production build | **BLOCKED** | `npm run build` returned `next: not found`; dependencies are not installed. |
| ESLint | **BLOCKED** | `npm run lint` returned `next: not found`; dependencies are not installed. |
| npm audit | **BLOCKED** | `npm audit` returned `ENOLOCK`; a lockfile has not been generated because package installation is unavailable. |
| Browser/device consent test | **PENDING** | Requires a running Node 24/Next.js staging build and a test GA4 Measurement ID. No live analytics property was supplied. |

The current runtime remains Node.js 22.16.0, while `.nvmrc` requires Node.js 24.x. No live site, WordPress, DNS, GitHub repository or deployment was changed.

A fresh dependency-install attempt during Session 13 (`npm install --ignore-scripts --no-audit --no-fund --fetch-retries=0 --fetch-timeout=15000`) failed with `EAI_AGAIN` while resolving `registry.npmjs.org`. No lockfile or `node_modules` directory was created.


## Session 14 maintenance validation — 6 November 2026

| Check | Result | Evidence / reason |
|---|---|---|
| Content validation | **PASS** | 10 services, 20 public courses (19 source outlines plus one owner-review note), six SOC/SIEM paths, three team profiles, ten gallery photographs, eight target-industry profiles, two offices, two testimonials, 29 public routes and 23 redirects. |
| Privacy validation | **PASS** | GA4 requires a valid owner ID and explicit opt-in; reject/withdrawal and persistent settings are present; ID remains blank; phone is voluntary; no lead database/CRM. |
| Brand validation | **PASS** | Original 4096 × 4096 logo retained; optimized transparent WebP used in header, homepage, footer, chatbot and structured data; favicon and responsive styles checked. |
| UX validation | **PASS** | Chatbot Escape/focus flow, live announcements, quick replies, typed input, course search/filter and voluntary phone disclosure checked. |
| TypeScript/TSX syntax transpilation | **PASS** | Global TypeScript 5.8.3 transpiled 25 source files with zero syntax diagnostics. Not a semantic typecheck. |
| CSS parse | **PASS** | Global PostCSS parsed `app/globals.css` (396 top-level rules/at-rules). |
| Node syntax checks | **PASS** | `next.config.mjs` and all four validation scripts passed `node --check`. |
| Full TypeScript typecheck | **BLOCKED** | Dependencies are absent; `next` and React type declarations cannot be resolved. |
| Production build / lint | **BLOCKED** | Both commands return `next: not found`. |
| Dependency audit | **BLOCKED** | No lockfile exists; `npm audit` returns `ENOLOCK`. |
| Dependency install | **BLOCKED** | `npm install --ignore-scripts --no-audit --no-fund --fetch-retries=0 --fetch-timeout=15000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`. |
| Real browser/mobile QA | **PENDING** | Requires Node.js 24, installed dependencies and a running staging build. |

Environment: Node.js 22.16.0 / npm 10.9.2; `.nvmrc` requires Node.js 24.x. No package lockfile or `node_modules` was generated. No GitHub, WordPress, DNS or deployment changes were made.

## Session 15 maintenance validation — 6 November 2026

| Check | Result | Evidence / reason |
|---|---|---|
| Content validator | **PASS** | 10 services, 20 public courses, six company-profile SOC/SIEM learning paths, three team profiles, ten gallery references, eight target-industry profiles, two offices, two testimonials, 29 routes and 23 redirects. |
| Privacy validator | **PASS** | Opt-in-only GA4, blank Measurement ID, reject/withdrawal, persistent settings, voluntary phone, no lead database/CRM, and explicit Enhanced Measurement exclusions. |
| Brand validator | **PASS** | Compact emblem derivative, full footer/structured-data lockup, favicon and original logo asset all present. |
| UX validator | **PASS** | Chatbot privacy/demo answers, quick replies, typed input, keyboard focus flow, course search/filter and voluntary phone handling. |
| Internal-link validator | **PASS** | 29 internal paths checked, 20 course slugs registered, redirects inspected, no broken internal routes or non-HTTPS external links found. |
| TypeScript/TSX syntax transpilation | **PASS** | Global TypeScript 5.8.3 transpiled 25 `.ts`/`.tsx` files with zero syntax diagnostics. This is not a semantic typecheck. |
| CSS parse | **PASS** | Global PostCSS parsed `app/globals.css` successfully (400 top-level rules/at-rules). |
| Node syntax checks | **PASS** | `node --check` passed for `next.config.mjs` and all five validation scripts. |
| Full TypeScript typecheck | **BLOCKED** | Missing `next` and React type dependencies cause module-resolution and JSX-type errors. |
| Production build / lint | **BLOCKED** | Both return `next: not found`; dependencies are not installed. |
| Dependency audit | **BLOCKED** | `npm audit` returns `ENOLOCK`; no lockfile exists. |
| Runtime browser/device tests | **PENDING** | Require Node.js 24, installed dependencies and a running staging build. |

The current environment still provides Node.js 22.16.0 rather than the project's required Node.js 24.x. Registry DNS lookup is unavailable, so dependency installation and lockfile generation could not be completed. No live website, WordPress, DNS, GitHub repository or deployment was changed.


## Session 17 validation rerun — 6 November 2026

| Check | Result | Evidence / reason |
|---|---|---|
| Content validator | **PASS** | 10 services, 20 public courses (19 source outlines plus one owner-review note), six SOC/SIEM options, three team profiles, ten gallery references, eight target industries, two offices, two testimonials, 30 public routes and 23 redirects. |
| Privacy validator | **PASS** | GA4 requires a valid owner ID and explicit opt-in; ID remains blank; reject/withdrawal and persistent settings are present; phone is voluntary; no server-side lead/CRM. |
| Brand validator | **PASS** | Approved 4096 × 4096 source PNG hash matches the user-supplied image exactly; full/emblem derivatives and favicon are present. |
| UX validator | **PASS** | Chatbot answer scope, keyboard focus, message auto-scroll, input disclosure, mobile navigation focus, course-filter recovery and email-app fallback are checked. |
| Link validator | **PASS** | 30 internal paths, 20 course slugs, 23 redirects and in-page anchors checked; no broken internal route or non-HTTPS external link found. |
| Learning-path validator | **PASS** | Four collections, 20 valid course links, six SOC/SIEM options and no prerequisite claims. |
| TypeScript/TSX syntax transpilation | **PASS** | Global TypeScript 5.8.3 transpiled 27 source files with zero syntax diagnostics. This is not a semantic typecheck. |
| CSS/PostCSS parsing | **PASS** | Global PostCSS parsed `app/globals.css` (426 top-level rules/at-rules). |
| Node config/script syntax | **PASS** | `node --check` passed for `next.config.mjs` and all six validation scripts. |
| Full TypeScript typecheck | **BLOCKED** | `npm run typecheck` reports missing `next/*`, `react` and JSX intrinsic declarations because dependencies are absent. |
| Production build | **BLOCKED** | `npm run build` returns `next: not found`. |
| ESLint | **BLOCKED** | `npm run lint` returns `next: not found`. |
| Dependency audit | **BLOCKED** | `npm audit --omit=dev` returns `ENOLOCK`; no lockfile exists. |
| Dependency installation | **BLOCKED** | `npm ping --fetch-retries=0 --fetch-timeout=10000` failed with `EAI_AGAIN` resolving `registry.npmjs.org`. |
| Real browser / Android test | **PENDING** | Requires Node.js 24, installed dependencies, a running staging build and physical/remote device testing. |

Environment: Node.js 22.16.0 / npm 10.9.2; `.nvmrc` requires Node.js 24.x. No GitHub, WordPress, DNS, hosting or production deployment changes were made.

## Session 19 validation update — 6 November 2026

- All seven dependency-free validators passed: content, privacy, brand, UX, internal links, learning paths and chatbot routing.
- Privacy validation now checks that opening the persistent settings panel preserves the current choice, the visitor must explicitly select Allow or Reject to change it, keyboard focus moves into the opened panel and returns to the trigger, and the first/re-acceptance pageview paths are guarded against duplicate events.
- Fee caution wording is validated consistently on the homepage, course catalogue and course-detail cards.
- TypeScript/TSX syntax transpilation passed for 27 files with zero syntax diagnostics; PostCSS parsed the global stylesheet successfully (430 top-level rules/at-rules).
- Node syntax checks passed for all `.mjs` scripts and `next.config.mjs`.
- Full semantic TypeScript check, Next.js production build and ESLint remain blocked because `node_modules` is absent and the environment is Node.js 22.16.0 rather than the project's Node.js 24 requirement. A fresh npm ping failed with `EAI_AGAIN` resolving `registry.npmjs.org`.
- Dependency audit remains blocked because no package lockfile exists (`ENOLOCK`). Real mobile/desktop browser testing remains pending a working staging build.
