# Live-site security review — 6 November 2026

## Session 22 — expanded SEO-spam finding

A fresh public crawl of the live homepage on 6 November 2026 exposed 16 unrelated gambling/betting footer anchors pointing to 16 unrelated domains. The observed terms included `bettilt`, `pinup`, `pinco`, `bahsegel`, `paribahis`, `casinomub`, `rokubet`, `slotbey`, `casino siteleri` and `bahis siteleri`. This strengthens the earlier possible SEO-spam finding, but a crawl still cannot establish the injection source or prove compromise of the underlying WordPress/hosting environment. The full domain list, evidence limits and owner/host response plan are recorded in [`WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md`](WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md).

The rebuild excludes the links and now runs `npm run validate:external-links` as part of `npm run check:offline`. No live WordPress, hosting, DNS, Search Console or production changes were made. Do not migrate/cut over the domain until the authorised owner/host documents investigation and cleanup.

The homepage crawl rechecked on 6 November 2026 exposed a sequence of unrelated gambling/promotion anchor texts and third-party domains in the page footer. This is consistent with possible SEO spam injection, but a crawl alone cannot establish the exact compromise or its persistence.

## Immediate owner/host actions

1. Take a full filesystem and database backup before making changes.
2. Review WordPress administrator accounts and remove unknown accounts after owner verification.
3. Update WordPress core, themes and plugins; remove unused or abandoned extensions.
4. Inspect theme footer/header files, widgets, database options/posts, custom HTML blocks, `.htaccess`, `wp-config.php`, scheduled tasks and hosting-level cron jobs for injected links or scripts.
5. Search the database and files for the unrelated domains observed in the live footer.
6. Rotate WordPress, hosting, SFTP/SSH, database and API credentials; enable MFA where available.
7. Run a reputable malware/integrity scan and review hosting access logs for the initial entry point.
8. Re-crawl the homepage, all page templates and search results after cleanup.

Do not claim the live site is clean until the hosting environment has been inspected and the injected links are gone from both rendered pages and stored content.


## Session 7 application-level headers

The Next.js configuration now adds baseline response headers: `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, a restrictive `Permissions-Policy` for camera/microphone/geolocation, and `Cross-Origin-Opener-Policy: same-origin`. These headers are a baseline only; they do not replace a hosting/WP investigation, a tailored Content Security Policy, dependency scanning, or server-side form security. HSTS is intentionally not added until the production host and all relevant subdomains are confirmed HTTPS-only.


## Dependency baseline review — 6 November 2026

The previous project used Next.js 14.2.35. Public vulnerability databases list security advisories affecting that version, with the 15.5.28+ release line listed as fixed for the relevant 2026 advisories. The project has therefore been moved to pinned Next.js 15.5.29 and React 19.3.1, with matching type packages, and Node.js 24 LTS as the runtime baseline. The App Router `params` and `searchParams` inputs have been converted to asynchronous access.

References reviewed:
- https://security.snyk.io/package/npm/next/14.2.35
- https://www.npmjs.com/package/next
- https://nextjs.org/docs/app/guides/upgrading/version-15
- https://nodejs.org/en/about/previous-releases

This is a dependency-baseline improvement, not a completed security audit. npm install, lockfile generation, `npm audit`, framework build, production configuration review and deployment testing remain outstanding because the package registry could not be resolved in this environment.

## Session 23 public-claim and external-link follow-up — 6 November 2026

The live homepage was rechecked and the same 16 unrelated gambling/betting footer links remained visible. The external-link source guard now includes the latest `casinomuhub` anchor spelling. A separate public-claims validator blocks unapproved placement/hiring guarantees, top-rated/high-paying claims and unqualified 24×7 lab/monitoring promises in public application source, and requires the course-price confirmation notice. Both guards were tested with temporary unsafe fixtures and correctly rejected them. The clean source scans pass. This is application-source protection only; it does not clean or inspect the live WordPress installation. Owner/hosting investigation remains mandatory before migration or domain cutover.


## Session 24 — external URL scheme hardening

The external-link policy now recognises `http://`, `https://` and protocol-relative (`//host`) URL forms. HTTP destinations are rejected even if the hostname is otherwise approved. Protocol-relative destinations are normalised as HTTPS for host review. Unknown hosts require explicit approval; known live-footer spam domains and anchor phrases remain blocked. The independent tests are in `scripts/test-external-link-policy.mjs`. Run `npm run test:external-link-policy` and `npm run validate:external-links` after changing external destinations.

`npm run preflight:release` reports the actual Node major, whether a package lockfile exists, and whether Next.js, React, TypeScript and ESLint dependencies are installed. It is intentionally separate from `check:offline` because a development machine may pass content/security checks while still being unable to build.

## Session 26 public recheck — 7 November 2026

The current public homepage still renders the same 16 unrelated gambling/betting footer links and zero-value counters. The rebuilt source continues to exclude them and passes its local external-link policy checks. This is not a determination of compromise or remediation status. The authorised WordPress/hosting administrator must inspect the underlying installation and confirm cleanup before migration. No live changes were made.


## Session 26 upstream framework version check — 7 November 2026

The project pins Next.js 15.5.29 and React 19.3.1. The official Next.js release history lists v15.5.29 (3 November 2026) with moderate security fixes for cross-client response injection/disclosure in self-hosted forwarded responses, SVG rejection bypass in image optimization, and HttpOnly cookie exposure through an internal Edge response header. The official React release history lists v19.3.1 (14 October 2026). The project retains the patched 15.5 maintenance line instead of making an untested major-version move to Next.js 16. This is a release-page review only; a lockfile-backed `npm audit` remains blocked until dependencies can be installed. References: https://github.com/vercel/next.js/releases and https://github.com/facebook/react/releases.


## Session 29 — unverified course checkout host

The current public Agentic AI detail pages expose a “Buy Course” link to `demosites.royal-elementor-addons.com`. The destination has not been opened or verified. The rebuild does not link to it and does not process online payments. The external-link policy explicitly rejects this host before checking the general HTTPS allowlist, and a regression test verifies the rejection. The course detail page tells visitors to confirm payment instructions directly with AROUSH. Owner verification of merchant identity, payment processor, privacy/data handling, refund terms and authorisation is required before any checkout is considered.
