# AROUSH live-source review — Session 33

Review date: 7 November 2026  
Primary source: https://aroushtech.in

## Pages reopened

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Courses: https://aroushtech.in/courses/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/
- AI & ML: https://aroushtech.in/ai-ml/
- Agentic AI with LangChain & Hugging Face: https://aroushtech.in/agentic-ai-with-langchain-hugging-face/
- Agentic AI with LangGraph and LangChain: https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/

## Current published facts observed

- Homepage continues to advertise 20+ job-ready courses and a free demo, and describes six course families: cybersecurity, networking, cloud/DevOps, Agentic AI and machine learning, Linux/security, and web-application penetration testing.
- The Courses page currently lists 20 individual course entries. Its general marketing copy still includes high-paying, top-rated and fast-hiring language; the rebuild does not repeat those unverified outcome claims.
- The About page publishes the company vision and mission and three team members: Abdul Aleem Khan (Vertical Head Cyber Security & Cloud Security), Tajuddin (Technical Head Networking & Cyber Security), and Mohammed Khalid (Technical Head For Networking Security).
- The About page still displays three zero-value counters (0k+, 0+, 0%). They remain excluded from the rebuild.
- The Gallery page presents training and corporate-training photographs and mentions corporate-training references. The rebuild does not turn those references into customer endorsements or add a client-logo collage without permission.
- The Contact page publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses, and a separate reference to a J.P. Nagar physical training centre. The J.P. Nagar reference still does not provide a complete visitor address; the two office addresses must not be presented as the training-centre address.
- The Contact page says online, offline and hybrid delivery formats are available. The rebuild asks visitors to confirm the format for the selected programme.
- The AI & ML detail page states 40 hours of live, intensive training and publishes a seven-module outline. The rebuild retains this duration with a course-specific confirmation caveat.
- The Agentic AI course pages publish detailed topic outlines but do not state a duration. The chatbot and FAQ do not invent one.

## Content and security discrepancies retained for owner review

1. The live Courses catalogue lists CCNA and CCNA DevNet at ₹19,999, while the individual pages list ₹19,000. The rebuild withholds numeric fees for both until the owner confirms the current amount.
2. Multiple live course pages link their Buy Course controls to `demosites.royal-elementor-addons.com`. This destination remains unverified and is blocked from the rebuild. Do not promote it until the owner verifies merchant ownership, payment processor, privacy/data handling, refund terms and authorisation.
3. The homepage crawl still exposes 16 unrelated gambling/betting footer links. This is consistent with possible SEO-spam injection but does not prove the entry point or the extent of compromise. An authorised WordPress/hosting administrator must inspect the database, theme, plugins, users, filesystem, scheduled tasks, logs and Search Console.
4. The public Contact FAQ contains broad certification, job-assistance and 24/7 lab-access claims. The rebuild does not reproduce those promises without written owner approval.
5. The public site identifies a J.P. Nagar training centre but does not give a complete address. Confirm the precise venue before publishing directions.
6. The About page's current team titles are retained as published; supporting company-profile role/experience claims are not substituted without owner approval.
7. The current public site lists an instructor introduction, but course-specific trainer allocation and provider-attributed CEH/Fortinet material remain subject to separate review.

## Session 33 website response

- Added a dedicated `/faqs` page grouped into Courses & learning, Location & enquiries, and Services & business enquiries.
- Answers explicitly flag current fee conflicts, unpublished schedules/prerequisites, incomplete training-centre address details, the email-draft enquiry flow and the absence of online checkout.
- Added the FAQ route to the main navigation, footer, contact page, sitemap and chatbot.
- The contact page now shows a shorter enquiry-focused FAQ subset and links to the complete FAQ page.
- No live WordPress, website, DNS, GitHub repository, analytics property or deployment was changed.
