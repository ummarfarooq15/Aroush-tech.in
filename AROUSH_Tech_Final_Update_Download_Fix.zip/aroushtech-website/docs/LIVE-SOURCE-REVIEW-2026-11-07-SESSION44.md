# Live AROUSH source review — Session 44

Review date: 7 November 2026

The official public website remains the source of truth for currently published company, course, gallery and contact details. The current crawl was re-opened for this session; conflicts and unverified claims remain flagged rather than silently resolved.

## Pages reviewed

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Course catalogue: https://aroushtech.in/courses/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/

## Current public information

### Homepage

- Advertises `20+ Job-Ready Courses | Free Demo Available`.
- Shows six categories: Cybersecurity Essentials; Advanced Networking; Cloud & DevOps; Agentic AI & Machine Learning; Linux & Cybersecurity; Web Application Pen Testing.
- Features Agentic AI with LangChain & Hugging Face at ₹35,000, CCNP Security at ₹45,000 and CEH at ₹25,000.
- Still displays counters as `0 k+`, `0 +` and `0 %`; these are not treated as valid statistics.
- Still exposes 16 unrelated gambling/betting footer destinations. These are excluded from the rebuild. This is a security finding requiring an authorised WordPress/hosting investigation, not proof of the exact compromise mechanism.

### About and team

- Publishes the vision and mission statements.
- Lists Abdul Aleem Khan (Vertical Head Cyber Security & Cloud Security), Tajuddin (Technical Head Networking & Cyber Security) and Mohammed Khalid (Technical Head For Networking Security).
- The rebuild retains the published names and titles; additional qualifications and years of experience from supporting company materials remain subject to owner approval.

### Course catalogue

- Lists 20 courses across the published technology categories.
- CCNA and CCNA DevNet each show ₹19,999 on the catalogue, while their individual course pages show ₹19,000. The rebuild withholds both numeric fees until the owner confirms the correct current amount.
- Other catalogue fees are changeable commercial information and remain labelled as website-listed amounts, not final quotations.
- CEH and Fortinet syllabus details remain subject to source-attribution/owner review in the rebuild.

### Gallery

- Continues to show training and corporate-training photographs.
- The rebuild retains ten training photographs and excludes a separate third-party logo collage pending approval to avoid implying unverified client/partner endorsements.

### Contact

- Email: `taj@aroushtech.in`
- Phone: `+91 88676 92074`
- Corporate office: `#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029`.
- Registered office: `AROUSH SOLUTIONS (OPC) PRIVATE LIMITED #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078`.
- The page refers to a J.P. Nagar training centre but does not provide a complete visitor-ready address. The rebuild tells visitors to confirm the exact venue before travelling.
- Published certification, 100% job-assistance and 24/7 lab-access statements remain owner/legal-review items and are not represented as guarantees in the rebuild.

## Applied to this session

No new company or commercial facts were invented. Session 44 adds only navigation and structured-data presentation based on existing internal page routes and labels. The shared breadcrumb component is used for all interior pages and course details; the homepage remains the root entry point.

## Source references

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Courses: https://aroushtech.in/courses/
- Gallery: https://aroushtech.in/gallery/
- Contact: https://aroushtech.in/contact-us/
