# AROUSH live-source review — Session 30

Date: 7 November 2026

## Pages reviewed

- Homepage: https://aroushtech.in/
- Courses catalogue: https://aroushtech.in/courses/
- Contact: https://aroushtech.in/contact-us/
- CCNA: https://aroushtech.in/ccna/
- CCNA DevNet: https://aroushtech.in/ccna-devnet/
- ISE: https://aroushtech.in/ciscoise/
- CEH: https://aroushtech.in/ceh-certified-ethical-hacker/
- AI & ML: https://aroushtech.in/ai-ml/
- Agentic AI with LangChain & Hugging Face: https://aroushtech.in/agentic-ai-with-langchain-hugging-face/
- Agentic AI with LangGraph & LangChain: https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/
- AWS Solutions Architect Associate: https://aroushtech.in/aws-solutions-architect-associate/
- CyberSys: https://aroushtech.in/cybersys/
- PenTest: https://aroushtech.in/pentester/
- Linux + Basic Cyber Security: https://aroushtech.in/linux-basic-cyber-security/
- Linux + Advanced Cyber Security: https://aroushtech.in/linux-advanced-cyber-security/
- Web App Pen Tester: https://aroushtech.in/web-app-pen-tester/
- CCNP Data Center: https://aroushtech.in/ccnp-data-center/
- Ansible & Terraform: https://aroushtech.in/ansible-and-terraform/
- CCNP Enterprise: https://aroushtech.in/ccnp-enterprise/
- Checkpoint Firewall: https://aroushtech.in/checkpoint-firewall/
- CCNP Security: https://aroushtech.in/ccnp-security/
- Fortinet Certified Engineer: https://aroushtech.in/fortinet-certified-engineer/
- Palo Alto Firewall: https://aroushtech.in/palo-alto-firewall/

## Material findings

All 20 individual course pages were compared against the current public Courses catalogue. The only fee conflicts found in this review were CCNA and CCNA DevNet. The other 18 published fee amounts matched the catalogue.

1. The homepage continues to show 20+ courses and a free-demo message. It also retains zero-value counters and 16 unrelated gambling/betting footer links. The rebuild excludes the counters and suspicious footer links.
2. The Courses catalogue lists CCNA and CCNA DevNet at ₹19,999 each. Their individual course detail pages list ₹19,000 each. The rebuild withholds numeric fees for both until owner confirmation.
3. The CEH page identifies its instructor as a UniNets trainer. The rebuild withholds the CEH syllabus, duration and trainer claims pending AROUSH-approved copy.
4. The Fortinet page includes I-Medita-attributed content; that material remains withheld.
5. Multiple reviewed course pages expose a Buy Course link to `demosites.royal-elementor-addons.com`. The destination was not opened or used. The rebuild blocks this host and provides only a first-party enquiry route.
6. The homepage continues to expose 16 unrelated external footer links, a suspicious SEO-spam symptom that requires authorised WordPress/hosting investigation. A public crawl does not establish the cause or prove a complete compromise.
7. Contact publishes `taj@aroushtech.in`, `+91 88676 92074`, two Bengaluru office addresses and a separate J.P. Nagar training-centre reference. The rebuild uses address-search map links rather than unverified coordinate pins and tells visitors to confirm the actual training venue.

## Competitor UX review

- Apna College Prime: curriculum hierarchy and scannable topic groups.
- i-Medita FAQ/course pages: easy-to-find programme questions and human enquiry routes.
- PyNet Labs catalogue: technology/category and career-path discovery.

These are UX references only. No competitor prices, ratings, testimonials, statistics, credentials, schedules or guarantees were copied.
