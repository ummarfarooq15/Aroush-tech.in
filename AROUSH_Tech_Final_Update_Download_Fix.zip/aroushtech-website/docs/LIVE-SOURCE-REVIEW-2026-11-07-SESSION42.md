# Live AROUSH source review — Session 42

Date: 7 November 2026

Official pages reopened:

- Homepage: https://aroushtech.in/
- About: https://aroushtech.in/aboutus/
- Contact: https://aroushtech.in/contact-us/
- Courses: https://aroushtech.in/courses/
- Gallery: https://aroushtech.in/gallery/

## Confirmed public information

- Homepage: advertises 20+ job-ready courses and a free demo; describes six course-category themes; features Agentic AI with LangChain & Hugging Face, CCNP Security and CEH offers.
- About: publishes the company vision and mission and names three team members with role titles: Abdul Aleem Khan, Tajuddin and Mohammed Khalid.
- Contact: publishes `taj@aroushtech.in`, `+91 88676 92074`, corporate office `#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029`, and registered office `AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078`.
- Contact: refers to a physical training centre in Bengaluru (J.P. Nagar) but does not publish a complete visitor-ready address. The two office addresses must not be presented as the training venue.
- Contact: continues to state certification, 100% job assistance and 24/7 lab access. These claims remain subject to owner approval and are not restated as guarantees in the rebuild.
- Homepage: displays three zero-value counters and 16 unrelated gambling/betting footer destinations. The rebuild excludes them. Their presence requires an authorised WordPress/hosting investigation; a public crawl alone does not establish the exact entry point or extent of compromise.
- Course catalogue: 20 entries remain represented in the rebuild. CCNA and CCNA DevNet catalogue/detail amounts remain inconsistent, so their numeric fees remain withheld.
- Gallery: the rebuild continues to use ten training photographs and excludes the separate third-party logo collage pending usage/relationship confirmation.

## Rebuild decisions

- Keep published company identity, public contact details, team roles, course records and training imagery tied to AROUSH sources.
- Do not invent a complete J.P. Nagar address, schedules, prices, credentials, service availability or job guarantees.
- Keep online course checkout disabled; direct visitors to confirm payment instructions through published AROUSH contact channels.
- Preserve privacy-first analytics: GA4 remains unconfigured and disabled until owner setup and explicit visitor opt-in.

## Source URLs

- https://aroushtech.in/
- https://aroushtech.in/aboutus/
- https://aroushtech.in/contact-us/
- https://aroushtech.in/courses/
- https://aroushtech.in/gallery/
- https://aroushtech.in/ccna/
- https://aroushtech.in/ccna-devnet/
