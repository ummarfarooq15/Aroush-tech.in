# Validation report — Session 31

Date: 7 November 2026

## Passed

| Check | Result |
|---|---|
| `npm run check:offline` | Passed, all 15 validators |
| Content validation | 20 public courses, 18 source outlines, 2 provider-attribution review notes; 18 consistent fee pairs and 2 fee conflicts withheld |
| Privacy validation | Passed; GA4 opt-in only, blank ID, reject/withdrawal, optional phone, no CRM/database |
| Analytics policy tests | Passed |
| Brand validation | Passed |
| UX validation | Passed |
| Accessibility source validation | Passed; 23 TSX files scanned |
| Internal route validation | Passed; 30 internal paths and 20 course slugs |
| External-link policy tests | Passed |
| External-link security | Passed; 33 source files scanned, 9 HTTPS hosts reviewed |
| Public-claims validation | Passed; no unapproved guarantees/comparative claims |
| Learning-path validation | Passed; 4 collections, 20 course links, 6 SOC/SIEM options |
| Chatbot tests | Passed; 46 intent-routing cases |
| JavaScript syntax | Passed; 20 `.mjs` files |
| TypeScript/TSX syntax | Passed; 30 files parsed using TypeScript 5.8.3; syntax only |
| Release configuration | Passed |
| CSS/PostCSS parse | Passed; 521 rules and 20 at-rules |

## Blocked / not run successfully

| Check | Result | Reason |
|---|---|---|
| Node.js 24 runtime | Blocked | Available runtime is Node.js 22.16.0 |
| npm registry access | Blocked | `EAI_AGAIN` resolving `registry.npmjs.org` |
| Package lockfile | Missing | No lockfile; registry unavailable to generate one |
| Full TypeScript typecheck | Blocked | Next.js, React and type declarations are not installed |
| ESLint | Blocked | `eslint` executable not installed |
| Next.js production build | Blocked | `next` executable not installed |
| npm audit | Blocked | `ENOLOCK`; audit requires a lockfile |
| Android/desktop browser QA | Pending | Requires a runnable build and browser/device test environment |

## Interpretation

Passing source validators does not prove runtime behavior, semantic type correctness, dependency security or production readiness. A real dependency install, reviewed lockfile, full typecheck, lint, build and browser QA remain release gates.
