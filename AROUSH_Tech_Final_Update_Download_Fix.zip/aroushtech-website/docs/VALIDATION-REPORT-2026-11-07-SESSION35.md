# Session 35 validation report

Date: 7 November 2026

## Passed

- Offline validation suite: **18/18 validators passed**.
- Course sort behavior: default source order, A–Z, Z–A, unknown-value fallback and non-mutating behavior passed.
- Course sort integration: labelled select, result-region relationship, reset behavior and mobile CSS markers passed.
- FAQ search behavior and integration passed.
- Chatbot routing: **47 cases passed**.
- TypeScript/TSX syntax: **34 files parsed** with TypeScript 5.8.3.
- JavaScript syntax: **25 `.mjs` files passed**.
- Accessibility source scan: **25 TSX files checked**.
- Internal route scan: **31 paths checked**, including 20 course slugs and redirect mappings.
- External-link security: **39 source files scanned**, 9 HTTPS hosts reviewed.
- Public-claims guard: **37 public source files scanned**.
- CSS/PostCSS: **563 rules, 24 at-rules and 1,848 declarations parsed**.
- Content, brand, privacy, analytics policy, learning paths, FAQs, chatbot, release configuration and CSS source checks passed.
- ZIP integrity and clean extraction passed.

## Blocked / not run successfully

- Runtime: Node.js **22.16.0**; required **24.x**.
- npm registry DNS: `EAI_AGAIN` resolving `registry.npmjs.org`.
- Release preflight: blocked by Node version, missing lockfile and missing dependencies (`next`, `react`, `react-dom`, `typescript`, `eslint`, `eslint-config-next`).
- Full TypeScript typecheck: failed because project dependencies and React/Next declarations are absent. Do not interpret the syntax parser as a full typecheck.
- ESLint: unavailable (`eslint: not found`).
- Next.js production build: unavailable (`next: not found`).
- npm audit: unavailable without a package lockfile (`ENOLOCK`).
- Actual Android/desktop browser testing: pending a runnable build/staging environment.

## Environment

- Node.js: `v22.16.0`
- npm: `10.9.2`
- `.nvmrc`: `24`
- npm cache: empty
- `node_modules/`: absent
- `package-lock.json`: absent

No lockfile was fabricated and no dependencies were guessed or downloaded from an unverified source.
