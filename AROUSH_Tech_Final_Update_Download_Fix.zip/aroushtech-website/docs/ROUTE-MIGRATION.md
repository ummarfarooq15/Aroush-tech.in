# Legacy URL migration map

Permanent redirects configured in `next.config.mjs`. Keep these redirects during the WordPress-to-Next.js migration so existing links and search results resolve to the new routes.

| Existing WordPress URL | New route |
|---|---|
| `/ai-ml` | `/courses/ai-ml` |
| `/agentic-ai-with-langchain-hugging-face` | `/courses/agentic-ai-langchain-hugging-face` |
| `/agentic-ai-with-langgraph-and-langchain` | `/courses/agentic-ai-langgraph-langchain` |
| `/aws-solutions-architect-associate` | `/courses/aws-solutions-architect-associate` |
| `/cybersys` | `/courses/cybersys` |
| `/ceh-certified-ethical-hacker` | `/courses/ceh-certified-ethical-hacker` |
| `/pentester` | `/courses/pentest-penetration-testing` |
| `/linux-advanced-cyber-security` | `/courses/linux-advanced-cyber-security` |
| `/linux-basic-cyber-security` | `/courses/linux-basic-cyber-security` |
| `/web-app-pen-tester` | `/courses/web-app-pen-tester` |
| `/ccna-devnet` | `/courses/ccna-devnet` |
| `/ccna` | `/courses/ccna` |
| `/ccnp-enterprise` | `/courses/ccnp-enterprise` |
| `/ccnp-security` | `/courses/ccnp-security` |
| `/ciscoise` | `/courses/ise-identity-services-engine` |
| `/checkpoint-firewall` | `/courses/checkpoint-firewall` |
| `/palo-alto-firewall` | `/courses/palo-alto-firewall-certified-engineer` |
| `/ccnp-data-center` | `/courses/ccnp-data-center` |
| `/ansible-and-terraform` | `/courses/ansible-terraform` |
| `/fortinet-certified-engineer` | `/courses/fortinet-certified-engineer` |

| `/aboutus` | `/about` |
| `/contact-us` | `/contact` |
| `/meet-our-team` | `/team` |

The old `/gallery` and `/courses` paths already match the new routes and do not need redirects. The former “Meet Our Team” navigation entry on the old site resolves to the About page; the rebuilt site provides a dedicated `/team` page.
