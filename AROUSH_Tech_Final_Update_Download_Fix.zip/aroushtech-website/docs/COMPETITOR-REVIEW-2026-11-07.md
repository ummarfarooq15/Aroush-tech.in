# Competitor UX review — 7 November 2026

Purpose: identify useful information-architecture and interaction patterns for AROUSH Tech. This is UX research only. Competitor claims, figures, pricing, ratings, testimonials, credentials, schedules, partner names and guarantees must not be copied into AROUSH content.

## Apna College

Official references:
- https://www.apnacollege.in/
- https://www.apnacollege.in/prime
- https://www.apnacollege.in/course/delta-7

Observed UX patterns:
- Programme pages make the curriculum visible as an ordered set of topics.
- Course pages separate learning areas and practical project descriptions.
- The main navigation exposes distinct programme families and a route to explore each one.

AROUSH application:
- Keep course detail pages structured around source-published outline topics.
- Make the availability of an AROUSH-published outline visible on each catalogue card.
- Keep the AI & ML course duration visible only because the AROUSH source page states 40 hours.

Not copied: Apna College course prices, discounts, student outcomes, employer names, batch dates, durations, certificates, testimonials or placement claims.

## i-Medita

Official references:
- https://www.imedita.com/
- https://www.imedita.com/frequently-asked-questions/
- https://www.imedita.com/courses/ccna-training/

Observed UX patterns:
- Course FAQs make location, schedule, language and enrolment questions easier to find.
- Course pages group programme information and enquiry actions together.
- The homepage surfaces upcoming-event information as a distinct content area.

AROUSH application:
- Keep the FAQ section near the enquiry route.
- Ask visitors to confirm current schedule, location, language, trainer and delivery details rather than publishing unverified values.
- Keep a clear human enquiry action on course detail pages.

Not copied: i-Medita trainers, partner relationships, credentials, prices, ratings, schedules, locations, testimonials or placement statements.

## PyNet Labs

Official references:
- https://www.pynetlabs.com/
- https://www.pynetlabs.com/courses/

Observed UX patterns:
- The catalogue exposes technology categories and career-path groupings.
- Course cards show structured information such as level, delivery mode and duration when available.
- Human guidance is presented as an alternative to browsing alone.

AROUSH application:
- Retain the searchable catalogue and category filters.
- Display only verified course metadata. Where AROUSH has not published a detailed outline, show a clear request-for-confirmation state instead of implying that a syllabus is available.
- Keep course enquiry links visible.

Not copied: PyNet Labs course counts, learner totals, ratings, prices, discounts, placement outcomes, hiring partners, guarantees, trainers or schedules.

## Changes made in Session 27

1. Course cards now distinguish source-published outline topics from the Fortinet course whose detailed syllabus remains withheld pending AROUSH approval.
2. Course cards display a duration only when the AROUSH course-detail source explicitly publishes one.
3. The course result announcement reports how many currently visible results have published outline topics.
4. Service detail sections now have stable numbered anchors so chatbot answers can link directly to the relevant service.
5. The rule-based chatbot now has specific, source-grounded answers for the ten-service portfolio's principal service families and the published AI & ML course duration.

These changes use the competitor UX patterns without importing competitor content or claims.


## Session 28 refresh — 7 November 2026

Official references reopened:
- Apna College Prime: https://www.apnacollege.in/prime — current AI/ML curriculum sections remain grouped into Python/data foundations, mathematics and machine-learning concepts. AROUSH keeps its own source-backed topic lists and avoids adding competitor-only prerequisites or outcomes.
- i-Medita FAQ and course pages: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ccnp-training/ — current pages expose practical learner questions such as location, language, schedule, fees and demo information near the course context. AROUSH keeps those questions in its own FAQ/contact flow and requires the team to confirm current availability.
- PyNet Labs course catalogue and contact: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — current catalogue continues to use technology filters and career-path groupings; contact page presents human counselling as a route when visitors are unsure. AROUSH retains its own search, category filters, goal collections and human contact path.

No competitor course counts, learner/placement statistics, ratings, prices, discounts, partner names, testimonials, credentials, schedules or guarantees were copied.

## Session 29 refresh — 7 November 2026

Official pages rechecked:

- Apna College Prime: https://www.apnacollege.in/prime — the current page groups AI/ML learning into Python/data foundations, mathematics and machine-learning concepts. AROUSH keeps its own verified course outline and uses the scannable curriculum hierarchy only.
- i-Medita FAQ: https://www.imedita.com/frequently-asked-questions/ and CCNA course page: https://www.imedita.com/courses/ccna-training/ — pages make location, schedule, language, prerequisites, payment and demo questions easy to locate. AROUSH uses a similarly findable FAQ/enquiry structure but confirms its own programme terms with its team.
- PyNet Labs catalogue: https://www.pynetlabs.com/courses/ and contact page: https://www.pynetlabs.com/contact/ — catalogue groups courses by technology and career-path category; contact page offers human guidance when a visitor is unsure. AROUSH keeps its own searchable filters and direct contact route.

No competitor prices, course counts, discounts, ratings, testimonials, placement data, trainer credentials, hiring partners, schedules or guarantees were copied. The latest public competitor pages contain substantial commercial claims; those claims are intentionally excluded from AROUSH content.


## Session 30 recheck — 7 November 2026

- Apna College Prime: https://www.apnacollege.in/prime — current curriculum remains organised into scannable AI/ML learning groups. AROUSH keeps its own approved course topics and uses only the hierarchy lesson.
- i-Medita FAQ and course pages: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ccna-training/ — common learner questions such as prerequisites, mode, language, schedule and demo are easy to locate. AROUSH keeps those questions in its own contact/FAQ flow and confirms its own terms with the team.
- PyNet Labs catalogue: https://www.pynetlabs.com/courses/ — technology and career-path filters help shorten discovery. AROUSH keeps its own catalogue and goal-based groupings; no third-party course inventory or commercial claims are imported.

No competitor prices, discounts, student counts, placement figures, ratings, testimonials, trainer credentials, batch dates or guarantees were copied.


## Session 31 refresh — 7 November 2026

Official pages rechecked:

- Apna College Prime: https://www.apnacollege.in/prime — current page groups the AI/ML curriculum into Python/data foundations, machine learning, mathematics, deep learning, GenAI and project areas, and separates audience/use-case information from the curriculum and FAQ. AROUSH retains the transferable pattern of scannable curriculum groups and course-specific FAQs, without importing Apna College's batch length, project promises, testimonials, prices or placement language.
- i-Medita FAQ and CCNA pages: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/courses/ccna-training/ — FAQs and course pages make learner questions about location, schedules, prerequisites, payments, demos and certification easy to find. AROUSH keeps its own FAQs adjacent to contact/enquiry paths and directs unconfirmed schedule, fee and venue questions to its team.
- PyNet Labs catalogue and contact pages: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — catalogue exposes technology/category and career-path groupings, while the contact page offers human course guidance. AROUSH retains its own search, category filters, learning-goal collections and contact route.

No competitor prices, discounts, course counts, learner or placement figures, ratings, testimonials, trainers, credentials, partner names, schedules or guarantees were copied.


## Session 32 refresh — 7 November 2026

- Apna College Prime: https://www.apnacollege.in/prime — the current programme page keeps the AI/ML curriculum in scannable topic groups and separates curriculum information from programme-level context. AROUSH keeps the transferable content hierarchy only.
- i-Medita FAQ and contact: https://www.imedita.com/frequently-asked-questions/ and https://www.imedita.com/contact/ — common questions and human contact routes remain prominent. AROUSH keeps its own enquiry path and asks the team to confirm current schedules, venues and fees.
- PyNet Labs course catalogue and contact: https://www.pynetlabs.com/courses/ and https://www.pynetlabs.com/contact/ — the catalogue uses technology/category and career-path groupings, with human guidance for visitors who need help selecting a course. AROUSH keeps its own catalogue filters and human enquiry route.

No competitor course counts, prices, discounts, ratings, testimonials, credentials, trainer claims, partner names, placement figures, schedules or guarantees were copied.
