# Deployment plan

## Phase 1 — public website

- Approve brand assets, address, leadership text, course list and gallery images.
- Run local/Codespaces build and accessibility checks.
- Connect a preview domain and test mobile, tablet and desktop layouts.
- Add redirects from existing WordPress URLs to the new routes, including the legacy team navigation target and the new `/training` route.
- Confirm analytics, cookie/privacy notices and enquiry handling before public launch.

## Phase 2 — CMS and lead workflow

- Add a CMS or admin interface for services, courses, team profiles, gallery and FAQs.
- Add a validated enquiry API with spam protection, consent text, email delivery and audit logging.
- Keep course fees, schedules and availability editable by authorized staff.

## Phase 3 — learning platform and business integrations

- Define LMS scope, learner roles, course modules, assessments and certificate rules.
- Add authentication, database schema and secure file storage only after requirements are approved.
- Add payment, CRM and reporting integrations only after provider accounts and legal requirements are confirmed.

## Legacy URL continuity

`next.config.mjs` contains permanent redirects for the previous About, Contact and team paths plus all 20 course-detail paths. Review `docs/ROUTE-MIGRATION.md` before changing WordPress routing or DNS, and test each redirect on the preview host.

## Deployment gate

Do not deploy to the production domain until the address discrepancy, current course fees, image permissions, contact workflow and live WordPress security issue have been resolved.
