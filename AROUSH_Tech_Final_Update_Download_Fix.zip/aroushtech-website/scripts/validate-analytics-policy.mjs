import assert from "node:assert/strict";
import {
  buildPageViewPayload,
  isValidGaMeasurementId,
  normalizeConsentChoice,
  safePagePath,
  safePageReferrer,
  shouldLoadAnalytics,
} from "../lib/analytics-policy.mjs";

assert.equal(isValidGaMeasurementId("G-ABC123"), true);
assert.equal(isValidGaMeasurementId(" g-abc123 "), true);
assert.equal(isValidGaMeasurementId("UA-12345-6"), false);
assert.equal(isValidGaMeasurementId("G-"), false);
assert.equal(isValidGaMeasurementId(""), false);

assert.equal(normalizeConsentChoice("accepted"), "accepted");
assert.equal(normalizeConsentChoice("rejected"), "rejected");
assert.equal(normalizeConsentChoice("unknown"), null);
assert.equal(normalizeConsentChoice(null), null);

assert.equal(shouldLoadAnalytics({ measurementId: "", choice: "accepted" }), false);
assert.equal(shouldLoadAnalytics({ measurementId: "G-ABC123", choice: null }), false);
assert.equal(shouldLoadAnalytics({ measurementId: "G-ABC123", choice: "rejected" }), false);
assert.equal(shouldLoadAnalytics({ measurementId: "G-ABC123", choice: "accepted" }), true);
assert.equal(shouldLoadAnalytics({ measurementId: "UA-12345-6", choice: "accepted" }), false);

assert.equal(safePagePath("/contact?phone=9876543210#form"), "/contact");
assert.equal(safePagePath("/courses/ccna#outline"), "/courses/ccna");
assert.equal(safePagePath("https://attacker.example/path?email=user@example.com"), "/");
assert.equal(safePagePath(""), "/");

assert.equal(
  safePageReferrer("https://aroushtech.in/courses?email=private@example.com#fees", "https://aroushtech.in"),
  "https://aroushtech.in/courses",
);
assert.equal(
  safePageReferrer("https://search.example/results?q=private@example.com", "https://aroushtech.in"),
  "https://search.example",
);
assert.equal(safePageReferrer("javascript:alert(1)", "https://aroushtech.in"), undefined);
assert.equal(safePageReferrer("not a URL", "https://aroushtech.in"), undefined);

const payload = buildPageViewPayload({
  origin: "https://aroushtech.in/",
  pathname: "/contact?phone=9876543210#form",
  title: "Contact AROUSH Tech",
  referrer: "https://search.example/search?q=private@example.com",
});
assert.deepEqual(payload, {
  page_title: "Contact AROUSH Tech",
  page_location: "https://aroushtech.in/contact",
  page_path: "/contact",
  page_referrer: "https://search.example",
});
assert.equal(JSON.stringify(payload).includes("9876543210"), false);
assert.equal(JSON.stringify(payload).includes("private@example.com"), false);
assert.throws(
  () => buildPageViewPayload({ origin: "javascript:alert(1)", pathname: "/", title: "Home" }),
  TypeError,
);

console.log("Analytics policy tests passed: opt-in gating, Measurement ID validation, stored-choice normalization, query/hash stripping, safe referrers and minimal page-view payloads.");
