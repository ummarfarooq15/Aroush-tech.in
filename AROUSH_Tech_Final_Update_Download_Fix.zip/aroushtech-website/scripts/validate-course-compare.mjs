import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { toggleComparedCourse } from "../lib/course-compare.mjs";

const original = ["ccna"];
assert.deepEqual(toggleComparedCourse(original, "ai-ml"), ["ccna", "ai-ml"], "a new course should be appended");
assert.deepEqual(toggleComparedCourse(original, "ccna"), [], "selecting an existing course should remove it");
assert.deepEqual(toggleComparedCourse(["ccna", "ai-ml", "ceh"], "ccnp"), ["ccna", "ai-ml", "ceh"], "the default comparison limit should be three");
assert.deepEqual(toggleComparedCourse(["ccna", "ai-ml"], "ceh", 2), ["ccna", "ai-ml"], "a custom comparison limit should be respected");
assert.deepEqual(toggleComparedCourse(["ccna", "ai-ml", "ceh"], "ai-ml"), ["ccna", "ceh"], "removal should work when the selection is full");
assert.deepEqual(original, ["ccna"], "selection changes must not mutate the original array");

const component = await readFile(new URL("../components/course-catalogue.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
const content = await readFile(new URL("../lib/content.ts", import.meta.url), "utf8");
for (const marker of [
  'import { toggleComparedCourse } from "@/lib/course-compare.mjs"',
  'aria-pressed={selectedForCompare.includes(course.slug)}',
  'aria-describedby="course-compare-help"',
  'toggleComparedCourse(selectedForCompare, slug, 3)',
  'selectedForCompare.flatMap((slug) =>',
  'disabled={compareLimitReached && !selectedForCompare.includes(course.slug)}',
  'aria-labelledby="course-compare-title"',
  'role="status" aria-live="polite"',
  'Compare courses',
  'scope="col"',
  'scope="row"',
  'details?.outline.length ? "Published" : "Not published"',
  'details?.duration ?? "Not published"',
  'course.feeNote\n                    ? "Confirm with AROUSH"',
  'You can share the comparison link; it contains only course slugs and selected catalogue filters.',
]) {
  assert.ok(component.includes(marker), `course comparison is missing: ${marker}`);
}
assert.ok(component.includes('id="course-compare-help"'), "compare controls need a persistent accessible description");
assert.ok(!/localStorage|sessionStorage|fetch\(|\/api\//.test(component), "comparison must not use browser storage or a backend; shared course slugs may appear in the URL");
assert.ok(styles.includes(".course-compare-table-wrap") && styles.includes("overflow-x: auto"), "comparison table needs horizontal scrolling on narrow screens");
assert.ok(styles.includes(".course-compare-toggle:focus-visible"), "compare controls need visible keyboard focus");
assert.ok(styles.includes("@media(max-width:620px)") && styles.includes(".course-compare-actions"), "comparison actions need a mobile layout");
const catalogue = content.split("export const courses: PublicCourse[] = [")[1]?.split("];", 1)[0] ?? "";
assert.equal([...catalogue.matchAll(/slug: "[^"]+"/g)].length, 20, "comparison must use the 20 published public course records");

console.log("Course comparison tests passed: add/remove, three-course limit, custom limit, non-mutating selection, accessible controls, published-only comparison fields, fee-conflict guard, shareable URL behavior, selected-order preservation, no browser storage/backend and mobile table layout.");
