import fs from 'node:fs';
const source = fs.readFileSync(new URL('../lib/content.ts', import.meta.url), 'utf8');
const required = [
  'DPO-as-a-Service', 'CyberArk PAM Consulting', 'VAPT Subscription',
  'OT / ICS Security Consulting', 'Security Awareness Training',
  'Network Infrastructure & IT Installation', 'Network Security Solutions',
  'Technical Support & Network Assessment', 'Corporate IT & Cybersecurity Training',
  'SOC / SIEM Services: Deployment & Training', 'taj@aroushtech.in',
  '+91 88676 92074', 'U72900KA2022OPC162189',
  'Abdul Aleem Khan', 'Tajuddin', 'Mohammed Khalid', 'Technical Head for Networking Security', 'Corporate Office', 'Registered Office', '#47, 4th Main, 4th Cross', 'Muniswamy L/O',
  'SOC Analyst Foundation', 'SIEM Administration & Operations',
  'Threat Detection, Log Analysis & Incident Response',
  'Advanced SOC Analyst & Threat Hunting', 'Corporate SOC Readiness Workshop'
];
const missing = required.filter((item) => !source.includes(item));
const serviceSection = source.split('export const services = [')[1]?.split('];')[0] ?? '';
const courseSection = source.split('export const courses: PublicCourse[] = [')[1]?.split('];')[0] ?? '';
const socSection = source.split('export const socCourses = [')[1]?.split('];')[0] ?? '';
const industrySection = source.split('export const industries = [')[1]?.split('];')[0] ?? '';
const socSlugs = [...socSection.matchAll(/slug: "([^"]+)"/g)].map((match) => match[1]);
const teamSection = source.split('export const team = [')[1]?.split('];')[0] ?? '';
const gallerySection = source.split('export const gallery = [')[1]?.split('];')[0] ?? '';
const serviceCount = (serviceSection.match(/number: "/g) ?? []).length;
const publicCourseCount = (courseSection.match(/\{ slug: "[^"]+", title: "/g) ?? []).length;
const pricedCourseCount = (courseSection.match(/listedPrice: "/g) ?? []).length;
const previousFeeCount = (courseSection.match(/previousPrice: "/g) ?? []).length;
const feeReviewCount = (courseSection.match(/feeNote: "/g) ?? []).length;
const feeReviewSlugs = [...courseSection.matchAll(/\{ slug: "([^"]+)"[^}]*feeNote: "/g)].map((match) => match[1]);
const courseSlugs = [...courseSection.matchAll(/slug: "([^"]+)"/g)].map((match) => match[1]);
const socCourseCount = (socSection.match(/\{ slug: "/g) ?? []).length;
const teamCount = (teamSection.match(/\{ name: "/g) ?? []).length;
const teamPhotoCount = (teamSection.match(/photo: "https:/g) ?? []).length;
const galleryCount = (gallerySection.match(/\{ src: "/g) ?? []).length;
const industryCount = (industrySection.match(/\{ title: "/g) ?? []).length;
const forbiddenClaims = ['100% job assistance', 'guaranteed placement', '24/7 SOC monitoring', '24×7 SOC monitoring'];
const unapprovedClaims = forbiddenClaims.filter((claim) => source.toLowerCase().includes(claim.toLowerCase()));
const officeCount = (source.split('export const company = {')[1]?.split('};')[0]?.match(/label: \"(?:Corporate|Registered) Office\"/g) ?? []).length;
const testimonialSection = source.split('export const testimonials = [')[1]?.split('];')[0] ?? '';
const testimonialCount = (testimonialSection.match(/\{ quote:/g) ?? []).length;
if (missing.length) {
  console.error('Missing required content:', missing.join(', '));
  process.exit(1);
}
if (officeCount !== 2 || testimonialCount !== 2) {
  console.error(`Expected 2 live-published office addresses and 2 homepage testimonials, found ${officeCount} and ${testimonialCount}`);
  process.exit(1);
}
if (serviceCount !== 10) {
  console.error(`Expected 10 service records, found ${serviceCount}`);
  process.exit(1);
}
if (publicCourseCount !== 20 || pricedCourseCount !== 18 || previousFeeCount !== 18 || feeReviewCount !== 2 || new Set(courseSlugs).size !== 20 || feeReviewSlugs.sort().join(",") !== "ccna,ccna-devnet") {
  console.error(`Expected 20 public courses, 18 consistent fee pairs and owner-review notes for CCNA and CCNA DevNet; found ${publicCourseCount} courses, ${previousFeeCount} previous fees, ${pricedCourseCount} listed fees and ${feeReviewCount} review notes`);
  process.exit(1);
}
if (socCourseCount !== 6 || teamCount !== 3 || teamPhotoCount !== 3 || new Set(socSlugs).size !== 6) {
  console.error(`Expected 6 SOC/SIEM paths and 3 leadership profiles, found ${socCourseCount} and ${teamCount}`);
  process.exit(1);
}
if (!fs.existsSync(new URL('../app/training/page.tsx', import.meta.url))) {
  console.error('Missing dedicated corporate training page.');
  process.exit(1);
}
if (!fs.existsSync(new URL('../app/faqs/page.tsx', import.meta.url))) {
  console.error('Missing dedicated FAQ page.');
  process.exit(1);
}

if (!fs.existsSync(new URL('../app/courses/[slug]/page.tsx', import.meta.url))) {
  console.error('Missing dynamic course-detail route.');
  process.exit(1);
}
const publicRoutes = new Set(["/", "/about", "/services", "/courses", "/training", "/learning-paths", "/faqs", "/team", "/gallery", "/contact", "/privacy"]);
const routeFiles = [];
function collectRouteFiles(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const fullPath = new URL(`../${directory}/${entry.name}`, import.meta.url);
    if (entry.isDirectory()) collectRouteFiles(`${directory}/${entry.name}`);
    else if (/\.tsx$/.test(entry.name)) routeFiles.push(fs.readFileSync(fullPath, "utf8"));
  }
}
collectRouteFiles("app");
collectRouteFiles("components");
const literalInternalLinks = routeFiles.flatMap((file) => [...file.matchAll(/href="(\/[^"]*)"/g)].map((match) => match[1].split(/[?#]/)[0]));
const brokenInternalLinks = [...new Set(literalInternalLinks.filter((route) => !publicRoutes.has(route)))];
if (brokenInternalLinks.length) {
  console.error("Literal internal links without a public route:", brokenInternalLinks.join(", "));
  process.exit(1);
}
const courseCatalogueSource = fs.readFileSync(new URL('../components/course-catalogue.tsx', import.meta.url), 'utf8');
const servicesPageSource = fs.readFileSync(new URL('../app/services/page.tsx', import.meta.url), 'utf8');
if (!courseCatalogueSource.includes("Published outline topics") || !courseCatalogueSource.includes("AROUSH syllabus to confirm") || !courseCatalogueSource.includes("visibleOutlineCount") || !servicesPageSource.includes('id={service.number === "10" ? "soc-siem" : `service-${service.number}`}')) {
  console.error('Course outline status and stable service anchors must be visible in the rebuilt website.');
  process.exit(1);
}
const detailSource = fs.readFileSync(new URL('../lib/course-details.ts', import.meta.url), 'utf8');
const detailSlugs = [...detailSource.matchAll(/^  "([^"]+)": \{/gm)].map((match) => match[1]);
const detailCount = detailSlugs.length;
const outlineCount = (detailSource.match(/outline: \[\s+"/g) ?? []).length;
const unknownDetailSlugs = detailSlugs.filter((slug) => !courseSlugs.includes(slug));
const fortinetRecord = detailSource.split('"fortinet-certified-engineer": {')[1]?.split('\n  }')[0] ?? '';
const cehRecord = detailSource.split('"ceh-certified-ethical-hacker": {')[1]?.split('\n  }')[0] ?? '';
if (detailCount !== 20 || outlineCount !== 18 || unknownDetailSlugs.length || !detailSource.includes('https://aroushtech.in/ciscoise/') || !fortinetRecord.includes('sourceNote:') || !fortinetRecord.includes('https://aroushtech.in/fortinet-certified-engineer/') || !cehRecord.includes('sourceNote:') || !cehRecord.includes('UniNets')) {
  console.error(`Expected 20 course-detail records, 18 source-backed outlines and explicit CEH/Fortinet source-review notes; found ${detailCount} records and ${outlineCount} outlines. Unknown slugs: ${unknownDetailSlugs.join(', ')}`);
  process.exit(1);
}

const header = fs.readFileSync(new URL('../components/site-header.tsx', import.meta.url), 'utf8');
const navigation = fs.readFileSync(new URL('../components/primary-navigation.tsx', import.meta.url), 'utf8');
const footer = fs.readFileSync(new URL('../components/site-footer.tsx', import.meta.url), 'utf8');
const sitemap = fs.readFileSync(new URL('../app/sitemap.ts', import.meta.url), 'utf8');
const coursesPage = fs.readFileSync(new URL('../app/courses/page.tsx', import.meta.url), 'utf8');
if (!coursesPage.includes('Highlighted as the most popular course on the current AROUSH website') || !coursesPage.includes('aiMlCourse.slug')) {
  console.error('The live catalogue AI & ML popular-course highlight is missing.');
  process.exit(1);
}
const nextConfig = fs.readFileSync(new URL('../next.config.mjs', import.meta.url), 'utf8');
const sourceImage = fs.readFileSync(new URL('../components/source-image.tsx', import.meta.url), 'utf8');
const styles = fs.readFileSync(new URL('../app/globals.css', import.meta.url), 'utf8');
if (!header.includes('<PrimaryNavigation links={links} />') || !header.includes('label: "Training", href: "/training"') || !footer.includes('href="/training"') || !sitemap.includes('"/training"') || !sitemap.includes('courses.map')) {
  console.error('Training page must be linked from navigation, footer and sitemap.');
  process.exit(1);
}
if (!navigation.includes('aria-expanded={open}') || !navigation.includes('aria-current={isActive(link.href)') || !navigation.includes('event.key === "Escape"')) {
  console.error('Primary navigation must expose expanded/current-page state and support Escape to close the mobile menu.');
  process.exit(1);
}
if (!["X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy"].every((header) => nextConfig.includes(header))) {
  console.error('Expected baseline browser security headers are missing from Next.js configuration.');
  process.exit(1);
}
if (!coursesPage.includes('id={course.slug}') || !coursesPage.includes('Enquire about this path') || !fs.readFileSync(new URL('../components/course-catalogue.tsx', import.meta.url), 'utf8').includes('href={`/courses/${course.slug}`}')) {
  console.error('SOC/SIEM course anchors and enquiry links are missing.');
  process.exit(1);
}
const legacyRedirectCount = (nextConfig.match(/permanent: true/g) ?? []).length;
const legacyCoursePairs = [...detailSource.matchAll(/^  "([^"]+)": \{\s*\n    sourceUrl: "https:\/\/aroushtech\.in\/([^"]+)"/gm)];
const missingCourseRedirects = legacyCoursePairs.filter(([, slug, legacyPath]) =>
  !nextConfig.includes(`source: "/${legacyPath.replace(/\/$/, "")}"`) ||
  !nextConfig.includes(`destination: "/courses/${slug}"`)
);
if (legacyRedirectCount !== 23 || legacyCoursePairs.length !== 20 || missingCourseRedirects.length || !nextConfig.includes('destination: "/courses/ise-identity-services-engine"') || !nextConfig.includes('destination: "/contact"')) {
  console.error(`Expected 23 permanent redirects including all 20 course-detail paths; found ${legacyRedirectCount} redirects, ${legacyCoursePairs.length} source URLs and ${missingCourseRedirects.length} missing course mappings.`);
  process.exit(1);
}
if (!sourceImage.includes('onError={() => setFailed(true)}') || !sourceImage.includes('decoding="async"')) {
  console.error('Remote source images must have an accessible failure fallback and asynchronous decoding.');
  process.exit(1);
}
const homePage = fs.readFileSync(new URL('../app/page.tsx', import.meta.url), 'utf8');
if (!homePage.includes('Instructor introduction') || !homePage.includes('your trainer for networking and cybersecurity') || !homePage.includes('team.find((person) => person.name === "Tajuddin")')) {
  console.error('The current homepage instructor introduction must be represented using the published Tajuddin profile.');
  process.exit(1);
}
if (!/@media\s*\(max-width:\s*860px\)/.test(styles) || !/\.desktop-nav\s*\{[^}]*display:\s*none/.test(styles) || !/\.mobile-navigation\s*\{[^}]*display:\s*block/.test(styles) || !/\.mobile-nav-panel\[hidden\]\s*\{[^}]*display:\s*none/.test(styles)) {
  console.error('Responsive navigation must switch to the mobile menu before tablet-width layouts and respect the hidden state.');
  process.exit(1);
}
if (!styles.includes('prefers-reduced-motion:reduce') || !styles.includes(':focus-visible') || !styles.includes('--blue: #126fbe')) {
  console.error('Accessibility styles must include reduced-motion support, visible keyboard focus and the contrast-adjusted primary blue.');
  process.exit(1);
}
if (industryCount !== 8) {
  console.error(`Expected 8 target-industry profiles, found ${industryCount}`);
  process.exit(1);
}
if (galleryCount !== 10) {
  console.error(`Expected 10 existing-site gallery references, found ${galleryCount}`);
  process.exit(1);
}
if (unapprovedClaims.length) {
  console.error('Potentially unsupported claims found in content source.');
  process.exit(1);
}
const layoutSource = fs.readFileSync(new URL('../app/layout.tsx', import.meta.url), 'utf8');
const courseDetailPageSource = fs.readFileSync(new URL('../app/courses/[slug]/page.tsx', import.meta.url), 'utf8');
const breadcrumbComponentSource = fs.readFileSync(new URL('../components/breadcrumbs.tsx', import.meta.url), 'utf8');
const requiredStructuredData = [
  [layoutSource, '"@type": "Organization"', 'Organization structured data'],
  [layoutSource, '"@type": "WebSite"', 'WebSite structured data'],
  [courseDetailPageSource, '"@type": "Course"', 'Course structured data'],
  [breadcrumbComponentSource, '"@type": "BreadcrumbList"', 'Shared breadcrumb structured data']
];
const missingStructuredData = requiredStructuredData.filter(([sourceText, marker]) => !sourceText.includes(marker));
if (missingStructuredData.length) {
  console.error('Missing structured data:', missingStructuredData.map(([, , label]) => label).join(', '));
  process.exit(1);
}
if (!layoutSource.includes('company.legalName') || !layoutSource.includes('company.offices.map') || !layoutSource.includes('company.linkedin') || !courseDetailPageSource.includes('company.legalName')) {
  console.error('Structured data must use the verified company identity, published addresses and official LinkedIn destination.');
  process.exit(1);
}
if (courseDetailPageSource.includes('"@type": "AggregateRating"') || courseDetailPageSource.includes('"@type": "Offer"')) {
  console.error('Course structured data must not publish unverified ratings or commercial offers.');
  process.exit(1);
}
const beginnerGuide = fs.readFileSync(new URL('../docs/BEGINNER-DEVELOPER-GUIDE.md', import.meta.url), 'utf8');
const sourceRegister = fs.readFileSync(new URL('../docs/SOURCE-REGISTER.md', import.meta.url), 'utf8');
const contactFormSource = fs.readFileSync(new URL('../components/contact-form.tsx', import.meta.url), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
if (!beginnerGuide.includes('Change a course') || !beginnerGuide.includes('Run the website') || !beginnerGuide.includes('Keep the code easy to maintain') || !sourceRegister.includes('https://aroushtech.in/courses/')) {
  console.error('The beginner-friendly developer guide or source register is incomplete.');
  process.exit(1);
}
if (!fs.existsSync(new URL('../.editorconfig', import.meta.url)) || !fs.existsSync(new URL('../.nvmrc', import.meta.url))) {
  console.error('Developer editor and Node.js version settings are missing.');
  process.exit(1);
}
if (!contactFormSource.includes('mailto:${company.email}') || !contactFormSource.includes('does not save or send personal information to a website server')) {
  console.error('The contact form must clearly disclose its email-app workflow and must not imply server-side submission.');
  process.exit(1);
}
if (!packageJson.scripts?.check || !packageJson.scripts?.['validate:content']) {
  console.error('Expected beginner-friendly project check scripts are missing.');
  process.exit(1);
}
if (packageJson.dependencies?.next !== '15.5.29' || packageJson.dependencies?.react !== '19.3.1' || packageJson.dependencies?.['react-dom'] !== '19.3.1') {
  console.error('Expected the patched Next.js 15.5.29 and React 19.3.1 dependency baseline.');
  process.exit(1);
}
if (packageJson.engines?.node !== '24.x' || fs.readFileSync(new URL('../.nvmrc', import.meta.url), 'utf8').trim() !== '24') {
  console.error('The project must consistently target Node.js 24 LTS.');
  process.exit(1);
}
const contactPageSource = fs.readFileSync(new URL('../app/contact/page.tsx', import.meta.url), 'utf8');
const companySection = source.split('export const company = {')[1]?.split('};')[0] ?? '';
const mapsSearchHelper = source.match(/const mapsSearchUrl = \(address: string\) =>\s*`([^`]+)`;/);
if (!mapsSearchHelper || !mapsSearchHelper[1].includes('/maps/search/?api=1&query=') || !source.includes('encodeURIComponent(address)') || (companySection.match(/mapUrl: mapsSearchUrl\(/g) ?? []).length !== 2 || /maps\.google\.com\/\?q=/.test(companySection) || !contactPageSource.includes('office-map-note') || !contactPageSource.includes('rel="noopener noreferrer"')) {
  console.error('Office map links must search the published address rather than imply an unverified coordinate pin, and the training-centre location caveat must remain visible.');
  process.exit(1);
}
if (!courseDetailPageSource.includes('params: Promise<{ slug: string }>') || !courseDetailPageSource.includes('await params') || !contactPageSource.includes('searchParams: Promise<{') || !contactPageSource.includes('type?: string;') || !contactPageSource.includes('await searchParams')) {
  console.error('Next.js 15 App Router params and searchParams must use asynchronous access.');
  process.exit(1);
}

console.log(`Content validation passed: ${serviceCount} services, ${publicCourseCount} public courses (${outlineCount} source outlines; 2 provider-attribution review notes), 18 consistent catalogue fee pairs (2 course fee conflicts withheld), ${socCourseCount} SOC/SIEM learning paths, ${teamCount} team profiles, ${galleryCount} gallery photographs, ${industryCount} target-industry profiles, ${officeCount} published office addresses, ${testimonialCount} live-site testimonials, ${publicRoutes.size + publicCourseCount} public routes, ${legacyRedirectCount} permanent redirects and Organization/WebSite/Course/Breadcrumb structured data.`);
