import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const fail = (message) => { console.error(`FAQ validation failed: ${message}`); process.exit(1); };

const faqSource = read("lib/content.ts");
const faqPage = read("app/faqs/page.tsx");
const faqBrowser = read("components/faq-browser.tsx");
const header = read("components/site-header.tsx");
const footer = read("components/site-footer.tsx");
const contact = read("app/contact/page.tsx");
const sitemap = read("app/sitemap.ts");
const chatbot = read("lib/chatbot-rules.mjs");
const chatUi = read("components/site-chatbot.tsx");
const faqSection = faqSource.split("export const faqs = [")[1]?.split("];", 1)[0] ?? "";
const questions = [...faqSection.matchAll(/q: "([^"]+)"/g)].map((match) => match[1]);
const categories = [...faqSection.matchAll(/category: "([^"]+)"/g)].map((match) => match[1]);
if (questions.length !== 12 || new Set(questions).size !== questions.length) {
  fail(`expected 12 unique FAQ questions, found ${questions.length}`);
}
if (new Set(categories).size !== 3) {
  fail(`expected 3 FAQ categories, found ${new Set(categories).size}`);
}

for (const question of [
  "Which course areas can I explore?",
  "Is a free course demo available?",
  "How do I confirm prerequisites, duration and the next batch?",
  "Are the course fees shown on the website final?",
  "Where is the AROUSH training centre?",
  "Does the enquiry form send or store my details automatically?",
  "Can I pay for a course through this website?",
  "Does SOC/SIEM include continuous 24×7 human monitoring?",
]) {
  if (!faqSource.includes(question)) fail(`missing verified FAQ: ${question}`);
}

for (const [label, source, marker] of [
  ["FAQ page", faqPage, "<FAQBrowser items={faqs} />"],
  ["searchable FAQ browser", faqBrowser, "filterFaqs(items, query, activeCategory)"],
  ["main navigation", header, 'href: "/faqs"'],
  ["footer navigation", footer, 'href="/faqs"'],
  ["contact page full-FAQ link", contact, 'href="/faqs"'],
  ["contact page relevant FAQ selection", contact, "contactFaqQuestions.has(faq.q)"],
  ["sitemap", sitemap, '"/faqs"'],
  ["chatbot FAQ route", chatbot, 'href: "/faqs"'],
  ["chatbot FAQ quick reply", chatUi, "Where can I find answers to common questions?"],
]) {
  if (!source.includes(marker)) fail(`${label} is not connected to the FAQ route`);
}

if (!faqPage.includes("Course schedules, prerequisites, current fees and service availability can change")) {
  fail("FAQ page must explain which details require direct confirmation");
}
if (!faqSource.includes("withholds those two numeric fees")) {
  fail("CCNA and CCNA DevNet fee conflict must remain visible in the FAQ policy");
}
if (!faqSource.includes("does not provide a complete visitor address")) {
  fail("incomplete J.P. Nagar training-centre address must not be presented as a verified street address");
}

console.log("FAQ validation passed: verified answers, uncertainty notices, navigation, contact link, sitemap and chatbot route are connected.");
