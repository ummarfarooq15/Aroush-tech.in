import { readdirSync } from "node:fs";
import { join, relative } from "node:path";
import { spawnSync } from "node:child_process";

const projectRoot = process.cwd();
const ignoredDirectories = new Set([".git", ".next", "node_modules", "out", "dist"]);
const filesToCheck = [];

function collectJavaScriptFiles(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      if (!ignoredDirectories.has(entry.name)) {
        collectJavaScriptFiles(join(directory, entry.name));
      }
      continue;
    }

    if (entry.isFile() && /\.(?:mjs|js)$/.test(entry.name)) {
      filesToCheck.push(join(directory, entry.name));
    }
  }
}

collectJavaScriptFiles(projectRoot);

let failed = false;
for (const filePath of filesToCheck.sort()) {
  const result = spawnSync(process.execPath, ["--check", filePath], {
    encoding: "utf8",
  });

  if (result.status !== 0) {
    failed = true;
    console.error(`JavaScript syntax failed: ${relative(projectRoot, filePath)}`);
    if (result.stderr) console.error(result.stderr.trim());
  }
}

if (failed) process.exit(1);
console.log(`JavaScript syntax validation passed: ${filesToCheck.length} .js/.mjs files checked with the current Node.js runtime.`);
