import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { filterFaqs } from "../lib/faq-search.mjs";

const sampleFaqs = [
  {
    category: "Courses & learning",
    q: "How do I confirm a course schedule?",
    a: "Ask the AROUSH team to confirm the current batch and delivery format.",
  },
  {
    category: "Courses & learning",
    q: "Are course fees final?",
    a: "Confirm the current fee and payment terms directly before paying.",
  },
  {
    category: "Location & enquiries",
    q: "Where is the training centre?",
    a: "Confirm the exact session venue before travelling.",
  },
  {
    category: "Services & business enquiries",
    q: "Which services can I discuss?",
    a: "Discuss privacy, security, infrastructure, support and training scope.",
  },
];

assert.equal(filterFaqs(sampleFaqs, "", "All questions").length, 4, "All questions should be shown by default");
assert.equal(filterFaqs(sampleFaqs, "   ", "All questions").length, 4, "Whitespace-only search should not hide questions");
assert.equal(filterFaqs(sampleFaqs, "SCHEDULE", "All questions").length, 1, "Search should be case-insensitive");
assert.equal(filterFaqs(sampleFaqs, "payment terms", "All questions").length, 1, "Search should include answer text");
assert.equal(filterFaqs(sampleFaqs, "", "Location & enquiries").length, 1, "Category filters should return only that category");
assert.equal(filterFaqs(sampleFaqs, "confirm", "Courses & learning").length, 2, "Search and category filters should work together");
assert.equal(filterFaqs(sampleFaqs, "does not exist", "All questions").length, 0, "No-match searches should return an empty result");
assert.equal(sampleFaqs.length, 4, "Filtering must not mutate the original FAQ list");

const component = await readFile(new URL("../components/faq-browser.tsx", import.meta.url), "utf8");
const page = await readFile(new URL("../app/faqs/page.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");

for (const marker of [
  'type="search"',
  'aria-label="Filter frequently asked questions by topic"',
  "aria-pressed={activeCategory === category}",
  'role="status" aria-live="polite"',
  "Clear search and filters",
  "No matching questions",
  'href="/contact"',
  "filterFaqs(items, query, activeCategory)",
]) {
  assert.ok(component.includes(marker), `FAQ browser is missing: ${marker}`);
}

assert.ok(page.includes("<FAQBrowser items={faqs} />"), "The FAQ page must use the searchable FAQ browser");
assert.ok(styles.includes(".faq-category-filters button:focus-visible"), "FAQ filter controls must have visible keyboard focus");
assert.ok(styles.includes("@media(max-width:520px)"), "FAQ controls must include a mobile layout");

console.log("FAQ search tests passed: default results, case-insensitive question/answer search, category filtering, combined filters, empty results, non-mutating source data, accessible controls and mobile styles.");
