import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");
const fail = (message) => {
  console.error(`Privacy validation failed: ${message}`);
  process.exit(1);
};

const consent = read("components/analytics-consent.tsx");
const analyticsPolicy = read("lib/analytics-policy.mjs");
const privacyPage = read("app/privacy/page.tsx");
const contactForm = read("components/contact-form.tsx");
const layout = read("app/layout.tsx");
const footer = read("components/site-footer.tsx");
const sitemap = read("app/sitemap.ts");
const envExample = read(".env.example");
const analyticsNotes = read("docs/VISITOR-ANALYTICS-AND-LEADS.md");
const consentNotes = read("docs/COOKIE-CONSENT-IMPLEMENTATION.md");
const normalizedPrivacyPage = privacyPage.replace(/\s+/g, " ");
const packageJson = JSON.parse(read("package.json"));

if (!consentNotes.includes("Opening Privacy settings is informational and preserves the saved choice") || consentNotes.includes("immediately withdraws the previous opt-in")) {
  fail("consent implementation notes must accurately state that opening settings preserves the saved choice until an explicit visitor action");
}

const requiredConsentChecks = [
  ["valid GA4 Measurement ID validation", "isValidGaMeasurementId(GA_ID)"],
  ["opt-in-only script loading", "ready && analyticsAllowed"],
  ["shared analytics policy helper", "shouldLoadAnalytics({ measurementId: GA_ID, choice })"],
  ["query-safe page-view payload helper", "buildPageViewPayload({"],
  ["explicit reject action", "choose(\"rejected\")"],
  ["explicit allow action", "choose(\"accepted\")"],
  ["persistent preference storage", "window.localStorage.setItem(CONSENT_KEY, choice)"],
  ["settings panel preserves saved consent until an explicit choice", "Opening settings is informational. The visitor's saved choice changes"],
  ["settings panel reports the current preference", 'Analytics is currently {choice === "accepted" ? "allowed" : "rejected"}'],
  ["settings panel has a keep-current-choice action", "Keep current choice"],
  ["settings panel keyboard focus", "panelActionRef.current?.focus()"],
  ["settings trigger focus restoration", "settingsButtonRef.current?.focus()"],
  ["explicit choice updates GA collection", 'setAnalyticsDisabled(next !== "accepted");'],
  ["rejection clears GA cookies", 'if (next === "rejected") clearAnalyticsCookies();'],
  ["GA collection disable flag", "ga-disable-${GA_ID}"],
  ["persistent settings control", "className=\"analytics-settings\""],
  ["client-side route pageviews", "usePathname()"],
  ["manual pageview control", "send_page_view: false"],
  ["initial pageview event", "window.gtag('event', 'page_view'"],
  ["one-time GA bootstrap guard", "if (!window.__aroushGaBootstrapDone)"],
  ["bootstrap completion marker", "window.__aroushGaBootstrapDone = true;"],
  ["query-free page location", "window.location.origin + window.location.pathname"],
  ["Google Signals disabled", "allow_google_signals: false"],
  ["advertising personalisation disabled", "allow_ad_personalization_signals: false"],
  ["privacy notice link", "href=\"/privacy\""],
];
for (const [label, marker] of requiredConsentChecks) {
  if (!consent.includes(marker)) fail(`missing ${label}`);
}

if (consent.includes("clearSavedChoice") || consent.includes("safeReferrerOrigin")) {
  fail("opening privacy settings must not silently erase consent or emit a second first-pageview path");
}
const openSettingsBlock = consent.match(/function openSettings\(\)\s*\{([\s\S]*?)\n  \}/);
if (!openSettingsBlock || /setAnalyticsDisabled|clearAnalyticsCookies|setChoice\(null\)/.test(openSettingsBlock[1])) {
  fail("opening privacy settings must preserve the saved choice until the visitor selects Allow or Reject");
}
const chooseBlock = consent.match(/function choose\([^)]*\)\s*\{([\s\S]*?)\n  \}/);
if (
  !chooseBlock ||
  !/next === "accepted"[\s\S]*?analyticsWindow\.__aroushGaBootstrapDone/.test(chooseBlock[1]) ||
  !/analyticsWindow\.gtag\?\.\(\s*"event",\s*"page_view"/.test(chooseBlock[1])
) {
  fail("re-acceptance must send one page view only when GA4 was already bootstrapped in this page session");
}
const initialPageViewCount = (consent.match(/window\.gtag\('event', 'page_view'/g) ?? []).length;
if (initialPageViewCount !== 1) {
  fail("the one-time opt-in bootstrap must contain exactly one initial page-view event");
}
const priceComponent = read("components/course-price.tsx");
for (const [label, relativePath] of [
  ["homepage", "app/page.tsx"],
  ["course catalogue", "components/course-catalogue.tsx"],
  ["course detail", "app/courses/[slug]/page.tsx"],
]) {
  const pageSource = read(relativePath);
  if (!pageSource.includes("CoursePrice") || !priceComponent.includes("Website-listed amount; confirm current fee before payment") || !priceComponent.includes("Confirm current fee")) {
    fail(`${label} must use the shared price component with consistent fee-confirmation and conflict-withholding states`);
  }
}
if (consent.includes("window.location.href") || consent.includes("window.location.search")) {
  fail("analytics page URLs must not include query strings that could contain personal information");
}
const gaConfigBlock = consent.match(/window\.gtag\('config',[\s\S]*?\n\s*\}\);/);
if (gaConfigBlock && /page_(?:location|path|referrer)/.test(gaConfigBlock[0])) {
  fail("page metadata must be sent only through the sanitized manual page-view payload");
}
for (const marker of [
  "export function shouldLoadAnalytics",
  "export function safePagePath",
  "export function safePageReferrer",
  "export function buildPageViewPayload",
]) {
  if (!analyticsPolicy.includes(marker)) fail(`analytics policy helper is missing: ${marker}`);
}
if (!consent.includes("safePageReferrer") && !consent.includes("buildPageViewPayload")) {
  fail("page-view metadata must pass through the privacy policy helper");
}
if (consent.includes("user_id") || consent.includes("phone_number") || consent.includes("gtag('set', 'user_id'")) {
  fail("analytics integration must not send named visitor IDs or phone fields");
}
if (!consent.includes("No Google Analytics script is loaded") || !privacyPage.includes("no analytics script is loaded")) {
  fail("unconfigured analytics status must clearly say that no script is loaded");
}
if (!privacyPage.includes("Google Analytics 4 (GA4)") || !privacyPage.includes("Google LLC")) {
  fail("privacy notice must name the analytics product and provider");
}
for (const marker of [
  "aggregate website insights",
  "approximate geographic area",
  "referral source domain",
  "pseudonymous event-level data",
  "precise GPS location",
  "device fingerprint",
  "shortest suitable period",
  "scroll tracking",
  "outbound clicks",
  "file downloads",
  "video engagement",
  "form interactions",
  "Digital Personal Data Protection Act, 2023",
  "DPDP Rules, 2025",
  "approximate team size",
  "course name",
]) {
  if (!normalizedPrivacyPage.includes(marker)) fail(`privacy notice is missing: ${marker}`);
}

if (!contactForm.includes("Phone number <span className=\"optional\">(optional)</span>")) {
  fail("phone number must remain optional");
}
if (!contactForm.includes("Share a number only if you want the team to contact you by phone")) {
  fail("phone field must explain its voluntary purpose");
}
if (!contactForm.replace(/\s+/g, " ").includes("Your details are not submitted to or stored on this website.")) {
  fail("contact form must disclose that it does not submit/store data on the website");
}
if (!contactForm.replace(/\s+/g, " ").includes("Do not include passwords, API keys, access tokens, personal records or sensitive production logs")) {
  fail("contact form must warn visitors not to send credentials or sensitive production data");
}

if (!/^NEXT_PUBLIC_GA_MEASUREMENT_ID=\s*$/m.test(envExample)) {
  fail(".env.example must leave the GA4 Measurement ID blank by default");
}
const offlineCheck = packageJson.scripts?.["check:offline"] ?? "";
if (!packageJson.scripts?.["validate:privacy"] || !offlineCheck.includes("validate:privacy") || !packageJson.scripts?.check?.includes("check:offline")) {
  fail("package.json must expose the privacy validator through check:offline and run that suite from npm run check");
}
if (!packageJson.scripts?.["validate:analytics-policy"] || !offlineCheck.includes("validate:analytics-policy")) {
  fail("package.json must expose analytics policy tests through check:offline");
}
if (!layout.includes("<AnalyticsConsent />") || !footer.includes('href="/privacy"') || !sitemap.includes('"/privacy"')) {
  fail("privacy controls and notice must be included in the shared layout, footer and sitemap");
}
if (layout.includes("googletagmanager.com") || layout.includes("gtag(")) {
  fail("analytics scripts must be isolated in the opt-in consent component");
}
if (fs.existsSync(path.join(root, "app", "api"))) {
  fail("no server-side lead API is approved for this project");
}
const forbiddenLeadDependencies = Object.keys(packageJson.dependencies ?? {}).filter((name) =>
  /prisma|mongoose|mongodb|supabase|firebase|hubspot|salesforce|intercom/i.test(name),
);
if (forbiddenLeadDependencies.length) {
  fail(`unapproved database/CRM dependencies found: ${forbiddenLeadDependencies.join(", ")}`);
}
for (const marker of [
  "Google Analytics 4",
  "Measurement ID",
  "retention",
  "privacy contact",
  "legal review",
  "owner explicitly approved the full companion visitor-intelligence application",
  "Supabase",
  "No CRM integration",
  "The root marketing website's enquiry form remains a review-first email handoff",
]) {
  if (!analyticsNotes.toLowerCase().includes(marker.toLowerCase())) {
    fail(`owner setup documentation is missing: ${marker}`);
  }
}

console.log("Privacy validation passed: root-site GA4 remains opt-in and unconfigured by default; reject/withdrawal controls remain available; the root marketing site has no server-side lead API; the separate Supabase lead app is explicitly owner-approved; no CRM integration is present.");
