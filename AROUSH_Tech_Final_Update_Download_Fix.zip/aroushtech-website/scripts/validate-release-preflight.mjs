import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const packageJson = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
const actualNodeMajor = Number(process.versions.node.split(".")[0]);
const requiredNodeMajor = Number((packageJson.engines?.node ?? "").match(/^([0-9]+)\.x$/)?.[1] ?? 0);
const requiredPackages = ["next", "react", "react-dom", "typescript", "eslint", "eslint-config-next"];
const blockers = [];
const checks = [];

checks.push({
  label: `Node.js runtime ${process.versions.node}`,
  passed: requiredNodeMajor > 0 && actualNodeMajor === requiredNodeMajor,
  fix: `Switch to Node.js ${requiredNodeMajor}.x (the project also pins ${fs.readFileSync(path.join(root, ".nvmrc"), "utf8").trim()} in .nvmrc).`,
});

checks.push({
  label: "npm package lockfile",
  passed: fs.existsSync(path.join(root, "package-lock.json")),
  fix: "After Node.js is set up and npm registry access works, run npm install to create package-lock.json; review and commit it before using npm ci.",
});

const missingPackages = requiredPackages.filter((name) =>
  !fs.existsSync(path.join(root, "node_modules", name, "package.json")),
);
checks.push({
  label: missingPackages.length === 0 ? "Required dependencies installed" : `Missing dependencies: ${missingPackages.join(", ")}`,
  passed: missingPackages.length === 0,
  fix: "Run npm ci after a reviewed package-lock.json is present.",
});

for (const check of checks) {
  console.log(`${check.passed ? "PASS" : "BLOCKED"} ${check.label}`);
  if (!check.passed) blockers.push(check.fix);
}

if (blockers.length) {
  console.error("\nRelease preflight is not ready:");
  for (const blocker of blockers) console.error(`- ${blocker}`);
  process.exit(1);
}

console.log("\nRelease preflight passed. Run npm run typecheck, npm run lint and npm run build next.");
