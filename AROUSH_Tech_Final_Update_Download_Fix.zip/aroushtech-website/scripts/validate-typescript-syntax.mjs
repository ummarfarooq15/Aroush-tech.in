import { readdirSync, readFileSync, existsSync } from "node:fs";
import { join, relative } from "node:path";
import { createRequire } from "node:module";
import { execFileSync } from "node:child_process";

const projectRoot = process.cwd();
const ignoredDirectories = new Set([".git", ".next", "node_modules", "out", "dist"]);
const sourceFiles = [];

function collectTypeScriptFiles(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const filePath = join(directory, entry.name);

    if (entry.isDirectory()) {
      if (!ignoredDirectories.has(entry.name)) {
        collectTypeScriptFiles(filePath);
      }
      continue;
    }

    if (entry.isFile() && /\.(?:ts|tsx|mts|cts)$/.test(entry.name)) {
      sourceFiles.push(filePath);
    }
  }
}

function loadTypeScript() {
  const localRequire = createRequire(import.meta.url);

  try {
    return localRequire("typescript");
  } catch {
    // The project can run offline source checks before npm install. In that
    // case, use a globally installed TypeScript compiler when available.
    const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";
    const globalRoot = execFileSync(npmCommand, ["root", "-g"], {
      encoding: "utf8",
      stdio: ["ignore", "pipe", "ignore"],
    }).trim();
    const globalCompiler = join(globalRoot, "typescript", "lib", "typescript.js");

    if (!existsSync(globalCompiler)) {
      throw new Error(
        "TypeScript is not installed locally or globally. Run npm install before this check.",
      );
    }

    return localRequire(globalCompiler);
  }
}

let ts;
try {
  ts = loadTypeScript();
} catch (error) {
  console.error(`TypeScript syntax validation could not start: ${error.message}`);
  process.exit(1);
}

collectTypeScriptFiles(projectRoot);

const issues = [];
for (const filePath of sourceFiles.sort()) {
  const sourceText = readFileSync(filePath, "utf8");
  const scriptKind = filePath.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
  const sourceFile = ts.createSourceFile(
    filePath,
    sourceText,
    ts.ScriptTarget.Latest,
    true,
    scriptKind,
  );

  for (const diagnostic of sourceFile.parseDiagnostics) {
    const position = diagnostic.start ?? 0;
    const location = sourceFile.getLineAndCharacterOfPosition(position);
    const message = ts.flattenDiagnosticMessageText(diagnostic.messageText, " ");
    issues.push(
      `${relative(projectRoot, filePath)}:${location.line + 1}:${location.character + 1} ${message}`,
    );
  }
}

if (issues.length) {
  console.error("TypeScript syntax validation failed:");
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}

console.log(
  `TypeScript syntax validation passed: ${sourceFiles.length} .ts/.tsx/.mts/.cts files parsed with TypeScript ${ts.version}. This checks syntax only, not types or module resolution.`,
);
