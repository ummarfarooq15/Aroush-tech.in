import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const fail = (message) => {
  console.error(`Learning-path validation failed: ${message}`);
  process.exit(1);
};

const content = read("lib/content.ts");
const publicSection = content.split("export const courses: PublicCourse[] = [")[1]?.split("];\n\nexport const socCourses")[0] ?? "";
const socSection = content.split("export const socCourses = [")[1]?.split("];\n\nexport const platforms")[0] ?? "";
const publicSlugs = new Set([...publicSection.matchAll(/slug: "([^"]+)"/g)].map((match) => match[1]));
const socSlugs = new Set([...socSection.matchAll(/slug: "([^"]+)"/g)].map((match) => match[1]));
const pathSource = read("lib/learning-paths.ts");
const blocks = [...pathSource.matchAll(/\{\s*slug: "([^"]+)",([\s\S]*?)courseSlugs: \[([\s\S]*?)\],\s*\}/g)];
if (blocks.length !== 4) fail(`expected 4 goal-based collections, found ${blocks.length}`);

const seen = new Set();
let linkedCourses = 0;
for (const [, slug, , list] of blocks) {
  if (seen.has(slug)) fail(`duplicate path slug: ${slug}`);
  seen.add(slug);
  const slugs = [...list.matchAll(/"([^"]+)"/g)].map((match) => match[1]);
  if (!slugs.length) fail(`${slug} has no courses`);
  for (const courseSlug of slugs) {
    if (!publicSlugs.has(courseSlug)) fail(`${slug} references unknown course: ${courseSlug}`);
    linkedCourses += 1;
  }
}

const page = read("app/learning-paths/page.tsx");
if (!page.includes("not mandatory course sequences") || !page.includes("formal prerequisites")) {
  fail("page must state that groupings are not formal sequences or prerequisites");
}
if (!page.includes("socCourses.map") || !socSlugs.size || !/Continuous\s+24×7 monitoring\s+is not implied/.test(page)) {
  fail("SOC/SIEM list must use published records and avoid implying 24×7 monitoring");
}
if (!read("app/sitemap.ts").includes('"/learning-paths"') || !read("components/site-footer.tsx").includes('href="/learning-paths"') || !read("app/courses/page.tsx").includes('href="/learning-paths"')) {
  fail("route must appear in sitemap, footer and course catalogue");
}

console.log(`Learning-path validation passed: ${blocks.length} collections, ${linkedCourses} valid public course links, ${socSlugs.size} SOC/SIEM options and no prerequisite claims.`);
