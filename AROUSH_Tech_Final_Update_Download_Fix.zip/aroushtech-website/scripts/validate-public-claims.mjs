import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceDirectories = ["app", "components", "lib"];
const sourceExtensions = new Set([".ts", ".tsx", ".js", ".jsx", ".mjs"]);

// These are absolute or comparative marketing claims seen on legacy pages or
// commonly copied from competitor sites. They must not enter public UI without
// written owner approval and supporting evidence.
const unapprovedClaimPatterns = [
  { label: "job-assistance guarantee", pattern: /\b100\s*%\s*(?:job\s*)?assistance\b/i },
  { label: "placement guarantee", pattern: /\b(?:100\s*%\s*)?(?:guaranteed\s+)?placement\s+guarantee\b/i },
  { label: "job guarantee", pattern: /\bjob\s+guarantee\b/i },
  { label: "guaranteed hiring outcome", pattern: /\bguaranteed\s+(?:job|employment|hiring)\b/i },
  { label: "guaranteed placement", pattern: /\bguaranteed\s+placement\b/i },
  { label: "unverified top-rated claim", pattern: /\btop[- ]rated\b/i },
  { label: "unverified high-paying career claim", pattern: /\bhigh[- ]paying\s+(?:tech\s+)?career\b/i },
  { label: "unverified fast-hiring claim", pattern: /\b(?:get|be)\s+certified\s+and\s+hired\s*(?:—|-)?\s*fast\b/i },
  { label: "unverified 24/7 lab-access promise", pattern: /\b24\s*[x×/]\s*7\s+lab\s+access\b/i },
  { label: "unverified 24/7 human monitoring promise", pattern: /\b24\s*[x×/]\s*7\s+(?:human\s+)?monitoring\b/i },
];

const files = [];
const issues = [];

function collect(directory) {
  const absolute = path.join(root, directory);
  if (!fs.existsSync(absolute)) return;

  for (const entry of fs.readdirSync(absolute, { withFileTypes: true })) {
    const relative = path.posix.join(directory, entry.name);
    if (entry.isDirectory()) {
      collect(relative);
    } else if (entry.isFile() && sourceExtensions.has(path.extname(entry.name))) {
      files.push(relative);
    }
  }
}

for (const directory of sourceDirectories) collect(directory);

for (const relativePath of files) {
  const source = fs.readFileSync(path.join(root, relativePath), "utf8");
  for (const claim of unapprovedClaimPatterns) {
    const match = claim.pattern.exec(source);
    if (!match) continue;

    // Explicitly cautious statements are allowed. This keeps useful disclosures
    // such as "24×7 monitoring is not assumed" from being treated as promises.
    const beforeMatch = source.slice(Math.max(0, match.index - 150), match.index);
    const afterMatch = source.slice(match.index + match[0].length, match.index + match[0].length + 180);
    const hasNegativeQualifier = /\bnot\s+(?:assumed|implied|included|provided|offered|guaranteed)\b/i.test(afterMatch);
    const noPromiseIsStated = /\bno\b/i.test(beforeMatch)
      && /\b(?:assumed|implied|included|provided|offered|guaranteed)\b/i.test(afterMatch);
    const isDisclaimed = hasNegativeQualifier || noPromiseIsStated;

    if (!isDisclaimed) {
      issues.push(`${relativePath}: contains an unapproved ${claim.label}`);
    }
  }
}

// Prices are allowed only as source-copied catalogue references with a visible
// instruction to confirm the current amount before payment.
const priceComponents = ["components/course-price.tsx"];
for (const relativePath of priceComponents) {
  const source = fs.readFileSync(path.join(root, relativePath), "utf8");
  if (/course-price/.test(source) && !/confirm current fee before payment/i.test(source)) {
    issues.push(`${relativePath}: displays course prices without the current-fee confirmation notice`);
  }
}

if (issues.length) {
  console.error("Public-claims validation failed:");
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}

console.log(
  `Public-claims validation passed: ${files.length} public source files scanned; no unapproved guarantees or comparative claims found; course-price confirmation notices are present.`,
);
