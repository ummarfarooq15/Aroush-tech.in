import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { inspectExternalLinks } from "./external-link-policy.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceDirectories = ["app", "components", "lib", "public"];
const rootSourceFiles = ["next.config.mjs"];
const sourceExtensions = new Set([".ts", ".tsx", ".js", ".jsx", ".mjs", ".json", ".css", ".svg"]);
const issues = [];
const checkedFiles = [];
const checkedHosts = new Set();

function collectFiles(directory) {
  const absoluteDirectory = path.join(root, directory);
  if (!fs.existsSync(absoluteDirectory)) return;

  for (const entry of fs.readdirSync(absoluteDirectory, { withFileTypes: true })) {
    const relativePath = path.posix.join(directory, entry.name);
    if (entry.isDirectory()) {
      collectFiles(relativePath);
      continue;
    }

    if (!entry.isFile() || !sourceExtensions.has(path.extname(entry.name))) continue;
    checkedFiles.push(relativePath);
  }
}

for (const directory of sourceDirectories) collectFiles(directory);
for (const relativePath of rootSourceFiles) {
  if (fs.existsSync(path.join(root, relativePath))) checkedFiles.push(relativePath);
}

for (const relativePath of checkedFiles) {
  const source = fs.readFileSync(path.join(root, relativePath), "utf8");
  const result = inspectExternalLinks(source, relativePath);
  issues.push(...result.issues);
  for (const hostname of result.checkedHosts) checkedHosts.add(hostname);
}

if (issues.length > 0) {
  console.error("External-link security validation failed:");
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}

console.log(
  `External-link security validation passed: ${checkedFiles.length} source files scanned, ${checkedHosts.size} HTTPS hosts reviewed, no HTTP links, known spam domains, spam anchor phrases or unapproved external hosts found.`,
);
