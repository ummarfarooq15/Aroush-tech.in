import fs from "node:fs";

const routes = [
  ["app/about/page.tsx", "About", "/about"],
  ["app/contact/page.tsx", "Contact", "/contact"],
  ["app/courses/page.tsx", "Courses", "/courses"],
  ["app/faqs/page.tsx", "FAQs", "/faqs"],
  ["app/gallery/page.tsx", "Gallery", "/gallery"],
  ["app/learning-paths/page.tsx", "Learning paths", "/learning-paths"],
  ["app/privacy/page.tsx", "Privacy", "/privacy"],
  ["app/services/page.tsx", "Services", "/services"],
  ["app/team/page.tsx", "Team", "/team"],
  ["app/training/page.tsx", "Corporate training", "/training"],
];

const errors = [];
const component = fs.readFileSync("components/breadcrumbs.tsx", "utf8");
const css = fs.readFileSync("app/globals.css", "utf8");

for (const [file, label, href] of routes) {
  const source = fs.readFileSync(file, "utf8");
  if (!source.includes('import { Breadcrumbs } from "@/components/breadcrumbs";')) {
    errors.push(`${file} does not import the shared breadcrumb component.`);
  }
  const expected = `label: "${label}", href: "${href}"`;
  if (!source.includes(expected)) {
    errors.push(`${file} does not provide the expected ${label} breadcrumb.`);
  }
  const count = (source.match(/<Breadcrumbs\s/g) ?? []).length;
  if (count !== 1) errors.push(`${file} should render exactly one breadcrumb trail; found ${count}.`);
}

const coursePage = fs.readFileSync("app/courses/[slug]/page.tsx", "utf8");
if (!coursePage.includes('import { Breadcrumbs } from "@/components/breadcrumbs";')) {
  errors.push("Course detail pages do not use the shared breadcrumb component.");
}
if (!coursePage.includes('label: "Courses", href: "/courses"') || !coursePage.includes("label: course.title")) {
  errors.push("Course detail breadcrumbs must show Courses and the current course title.");
}
if ((coursePage.match(/BreadcrumbList/g) ?? []).length !== 0) {
  errors.push("Course detail pages still contain duplicate breadcrumb structured data.");
}

const privacyPage = fs.readFileSync("app/privacy/page.tsx", "utf8");
if (!privacyPage.includes('variant="dark"')) {
  errors.push("The privacy page must use the dark-text breadcrumb variant on its light background.");
}

for (const [label, marker] of [
  ["accessible navigation label", 'aria-label="Breadcrumb"'],
  ["current page announcement", 'aria-current="page"'],
  ["Home as the first crumb", 'label: "Home", href: "/"'],
  ["BreadcrumbList schema", '"@type": "BreadcrumbList"'],
  ["absolute canonical breadcrumb URLs", 'new URL(item.href, company.website).toString()'],
  ["safe JSON-LD serialization", '.replace(\n            /</g,'],
]) {
  if (!component.includes(marker)) errors.push(`Shared breadcrumb component is missing ${label}.`);
}

for (const [label, marker] of [
  ["visible breadcrumb styling", ".breadcrumbs ol"],
  ["keyboard focus styling", ".breadcrumbs a:focus-visible"],
  ["light-page variant", ".breadcrumbs-dark"],
  ["mobile breadcrumb layout", "@media (max-width: 520px)"],
]) {
  if (!css.includes(marker)) errors.push(`Breadcrumb CSS is missing ${label}.`);
}

if (errors.length) {
  console.error("Breadcrumb validation failed:");
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log(`Breadcrumb validation passed: ${routes.length + 1} content routes use one accessible trail; course detail labels are dynamic; BreadcrumbList schema, safe JSON-LD, keyboard focus and mobile styles are present.`);
