import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import {
  filterCoursesByOutline,
  hasPublishedOutline,
} from "../lib/course-outline-filter.mjs";

const courses = [
  { slug: "ccna", title: "CCNA" },
  { slug: "ai-ml", title: "AI & ML" },
  { slug: "ceh", title: "CEH" },
  { slug: "fortinet", title: "Fortinet" },
];
const details = {
  ccna: { outline: ["Routing", "Switching"] },
  "ai-ml": { outline: ["Python", "Machine learning"] },
  ceh: { outline: [], sourceNote: "Provider attribution requires review." },
  fortinet: { outline: [] },
};

assert.equal(hasPublishedOutline(details.ccna), true);
assert.equal(hasPublishedOutline(details.ceh), false, "provider-attribution review notes must not count as a published AROUSH outline");
assert.equal(hasPublishedOutline(undefined), false);
assert.deepEqual(
  filterCoursesByOutline(courses, details, "published").map((course) => course.slug),
  ["ccna", "ai-ml"],
);
assert.deepEqual(
  filterCoursesByOutline(courses, details, "confirm").map((course) => course.slug),
  ["ceh", "fortinet"],
);
assert.deepEqual(
  filterCoursesByOutline(courses, details, "all").map((course) => course.slug),
  ["ccna", "ai-ml", "ceh", "fortinet"],
);
assert.deepEqual(filterCoursesByOutline(courses, details, "unknown"), courses, "unknown filter values must safely show all courses");
assert.deepEqual(courses.map((course) => course.slug), ["ccna", "ai-ml", "ceh", "fortinet"], "filtering must not mutate the catalogue");
assert.deepEqual(filterCoursesByOutline([], details, "published"), []);

const component = await readFile(new URL("../components/course-catalogue.tsx", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
const packageJson = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
const courseDetails = await readFile(new URL("../lib/course-details.ts", import.meta.url), "utf8");

for (const marker of [
  'import { filterCoursesByOutline, hasPublishedOutline, type CourseOutlineFilter }',
  'const [outlineFilter, setOutlineFilter] = useState<CourseOutlineFilter>("all")',
  'filterCoursesByOutline(matchingCourses, courseDetails, outlineFilter)',
  'value="published"',
  'value="confirm"',
  'Outline availability',
  'Ask AROUSH to confirm',
  'setOutlineFilter("all")',
  'aria-controls="course-results"',
]) {
  assert.ok(component.includes(marker), `course outline filter is missing: ${marker}`);
}
assert.ok(styles.includes(".course-outline-filter select:focus-visible"), "outline filter needs visible keyboard focus");
assert.ok(styles.includes(".course-outline-filter {"), "outline filter needs a matching control layout");
assert.ok(styles.includes("grid-template-columns: minmax(240px, 1.5fr) repeat(2, minmax(160px, 1fr))"), "search, sort and outline controls need a three-column desktop layout");
assert.ok(styles.includes("@media(max-width: 620px)"), "catalogue controls need a stacked mobile layout");
assert.ok(packageJson.scripts["check:offline"].includes("validate:course-outline-filter"), "outline filter tests must run in the offline validation suite");

const outlineEntries = [...courseDetails.matchAll(/outline:\s*\[([\s\S]*?)\]/g)];
const publishedOutlineEntries = outlineEntries.filter((match) => /\S/.test(match[1]));
assert.equal(publishedOutlineEntries.length, 18, "the current source register should retain 18 published course outlines");
assert.equal((courseDetails.match(/sourceNote:/g) ?? []).length, 2, "two course outlines must remain flagged for provider-attribution review");

console.log("Course outline filter tests passed: published outlines, owner-confirmation status, provider-attribution guard, safe fallback, source immutability, accessible controls and mobile layout.");
