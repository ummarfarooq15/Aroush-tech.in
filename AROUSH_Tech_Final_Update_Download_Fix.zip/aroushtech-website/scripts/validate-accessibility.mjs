import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sourceDirectories = ["app", "components"];
const sourceFiles = [];
const issues = [];

function collectFiles(directory) {
  const absoluteDirectory = path.join(root, directory);
  for (const entry of fs.readdirSync(absoluteDirectory, { withFileTypes: true })) {
    const relativePath = path.posix.join(directory, entry.name);
    if (entry.isDirectory()) {
      collectFiles(relativePath);
    } else if (entry.isFile() && entry.name.endsWith(".tsx")) {
      sourceFiles.push(relativePath);
    }
  }
}

for (const directory of sourceDirectories) collectFiles(directory);

function hasAccessibleLabel(controlTag, source, index) {
  if (/\baria-label\s*=|\baria-labelledby\s*=/.test(controlTag)) return true;

  const id = controlTag.match(/\bid\s*=\s*["']([^"']+)["']/)?.[1];
  if (id) {
    const escapedId = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    if (new RegExp(`htmlFor\\s*=\\s*["']${escapedId}["']`).test(source)) return true;
  }

  const beforeControl = source.slice(0, index);
  return beforeControl.lastIndexOf("<label") > beforeControl.lastIndexOf("</label>");
}

for (const relativePath of sourceFiles) {
  const source = fs.readFileSync(path.join(root, relativePath), "utf8");

  for (const tag of source.matchAll(/<(?:img|Image)\b[^>]*>/g)) {
    if (!/\balt\s*=/.test(tag[0])) {
      issues.push(`${relativePath}: image is missing an alt attribute`);
    }
  }

  for (const tag of source.matchAll(/<a\b[^>]*\btarget\s*=\s*["']_blank["'][^>]*>/g)) {
    const rel = tag[0].match(/\brel\s*=\s*["']([^"']+)["']/)?.[1] ?? "";
    if (!/\b(?:noreferrer|noopener)\b/.test(rel)) {
      issues.push(`${relativePath}: a new-tab link must include rel="noreferrer" or rel="noopener"`);
    }
  }

  for (const tag of source.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)) {
    const attributes = tag[1];
    const visibleContent = tag[2].replace(/\{\s*\/\*[\s\S]*?\*\/\s*\}/g, "").trim();
    if (!/\baria-label\s*=/.test(attributes) && !visibleContent) {
      issues.push(`${relativePath}: button has no accessible name`);
    }
  }

  for (const tag of source.matchAll(/<(input|textarea|select)\b[^>]*>/g)) {
    if (!hasAccessibleLabel(tag[0], source, tag.index)) {
      issues.push(`${relativePath}: ${tag[1]} control has no associated accessible label`);
    }
  }
}

const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");
const layout = read("app/layout.tsx");
const styles = read("app/globals.css");
const chatbot = read("components/site-chatbot.tsx");
const catalogue = read("components/course-catalogue.tsx");
const navigation = read("components/primary-navigation.tsx");
const contactForm = read("components/contact-form.tsx");
const faqPage = read("app/faqs/page.tsx");
const faqBrowser = read("components/faq-browser.tsx");
const courseCatalogue = read("components/course-catalogue.tsx");
const breadcrumbs = read("components/breadcrumbs.tsx");

const requiredMarkers = [
  ["document language", layout.includes('<html lang="en-IN">')],
  ["accessible page breadcrumbs", breadcrumbs.includes('aria-label="Breadcrumb"') && breadcrumbs.includes('aria-current="page"')],
  ["skip-to-content link", layout.includes('href="#main-content"')],
  ["main content landmark", layout.includes('<main id="main-content">')],
  ["visible keyboard focus styles", styles.includes(":focus-visible")],
  ["reduced-motion support", styles.includes("prefers-reduced-motion:reduce")],
  ["chat conversation log announcement", chatbot.includes('role="log"') && chatbot.includes('aria-live="polite"')],
  ["course result count and sort announcement", catalogue.includes('aria-live="polite"') && catalogue.includes("sortAnnouncement")],
  ["course rank follows the visible result order", catalogue.includes('className="sr-only">Course </span>{String(index + 1).padStart(2, "0")')],
  ["mobile navigation disclosure state", navigation.includes("aria-expanded={open}") && navigation.includes('aria-controls="mobile-navigation-panel"')],
  ["mobile navigation focus return after route change", navigation.includes("previousPathnameRef.current !== pathname") && navigation.includes("toggleRef.current?.focus()")],
  ["expandable chatbot quick replies", chatbot.includes('aria-expanded={showMoreQuickQuestions}') && chatbot.includes('aria-controls="chatbot-extra-questions"')],
  ["named enquiry form", contactForm.includes('aria-label="AROUSH enquiry form"')],
  ["email review region has an accessible heading", contactForm.includes('aria-labelledby="email-review-title"') && contactForm.includes('role="region"')],
  ["email review status is announced politely", contactForm.includes('role="status" aria-live="polite"') && contactForm.includes("Not sent")],
  ["enquiry type has an accessible label", contactForm.includes("I am enquiring as") && contactForm.includes('name="enquiryType"')],
  ["learner and business paths have accessible names", read("app/contact/page.tsx").includes('aria-label="Enquiry types"') && read("app/contact/page.tsx").includes("Start a learner enquiry") && read("app/contact/page.tsx").includes("Start a business enquiry")],
  ["enquiry form is an in-page destination", read("app/contact/page.tsx").includes('id="enquiry-form"') && styles.includes(".contact-form-wrap { scroll-margin-top")],
  ["native FAQ disclosure controls", faqBrowser.includes("<details") && faqBrowser.includes("<summary") && styles.includes(".faq-list summary:focus-visible")],
  ["labelled FAQ search control", faqBrowser.includes("Search FAQ questions and answers") && faqBrowser.includes('type="search"')],
  ["accessible FAQ category filters", faqBrowser.includes("aria-pressed={activeCategory === category}") && faqBrowser.includes('role="group"')],
  ["FAQ result announcements", faqBrowser.includes('role="status" aria-live="polite"')],
  ["FAQ empty-state contact recovery", faqBrowser.includes("No matching questions") && faqBrowser.includes('href="/contact"')],
  ["labelled course sort control", courseCatalogue.includes("Sort courses") && courseCatalogue.includes("<select")],
  ["course sort result relationship", courseCatalogue.includes('aria-controls="course-results"')],
  ["course comparison toggle state", courseCatalogue.includes("aria-pressed={selectedForCompare.includes(course.slug)}") && courseCatalogue.includes('aria-describedby="course-compare-help"')],
  ["course comparison table semantics", courseCatalogue.includes('scope="col"') && courseCatalogue.includes('scope="row"') && courseCatalogue.includes('aria-labelledby="course-compare-title"')],
];

for (const [label, passed] of requiredMarkers) {
  if (!passed) issues.push(`shared accessibility requirement is missing: ${label}`);
}

if (issues.length) {
  console.error("Accessibility source validation failed:");
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}

console.log(`Accessibility source validation passed: ${sourceFiles.length} TSX files checked for image alternatives, new-tab link safety, named buttons and labelled form controls; skip-link, landmarks, keyboard focus recovery, expandable chatbot quick replies, keyboard-visible FAQ disclosure controls, reduced-motion and live-region safeguards are present.`);
