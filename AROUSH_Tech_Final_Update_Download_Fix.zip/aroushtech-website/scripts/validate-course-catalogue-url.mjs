import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import {
  buildCourseCatalogueSearch,
  parseCourseCatalogueState,
  MAX_COURSE_SEARCH_LENGTH,
  MAX_COMPARISON_PARAMETER_LENGTH,
} from "../lib/course-catalogue-url.mjs";

const categories = [
  "All courses",
  "Networking",
  "Network Security",
  "AI & Machine Learning",
];
const courseSlugs = ["ccna", "ccna-devnet", "ceh-certified-ethical-hacker", "ai-ml"];

assert.deepEqual(
  parseCourseCatalogueState("?q=ccna&category=Networking&sort=name-asc&outline=published", categories, courseSlugs),
  { query: "ccna", category: "Networking", sortOrder: "name-asc", outlineFilter: "published", compareSlugs: [] },
  "a shared catalogue URL should restore all four discovery controls",
);
assert.deepEqual(
  parseCourseCatalogueState("?category=Unknown&sort=made-up&outline=missing", categories, courseSlugs),
  { query: "", category: "All courses", sortOrder: "featured", outlineFilter: "all", compareSlugs: [] },
  "unknown category and filter values must safely fall back to defaults",
);
assert.deepEqual(
  parseCourseCatalogueState("?q=firewall+%26+VPN&category=AI+%26+Machine+Learning", categories, courseSlugs),
  { query: "firewall & VPN", category: "AI & Machine Learning", sortOrder: "featured", outlineFilter: "all", compareSlugs: [] },
  "URL encoding must preserve spaces and ampersands in searches and category names",
);

assert.deepEqual(
  parseCourseCatalogueState("?compare=ccna,ai-ml,ccna-devnet", categories, courseSlugs).compareSlugs,
  ["ccna", "ai-ml", "ccna-devnet"],
  "a shared comparison URL should restore up to three known course slugs in the selected order",
);
assert.deepEqual(
  parseCourseCatalogueState("?compare=ccna,unknown,ccna,ceh-certified-ethical-hacker,ai-ml", categories, courseSlugs).compareSlugs,
  ["ccna", "ceh-certified-ethical-hacker", "ai-ml"],
  "comparison URLs must remove unknown and duplicate slugs and clamp selections to three courses",
);
assert.deepEqual(
  parseCourseCatalogueState("?compare=ccna,ai-ml", categories).compareSlugs,
  [],
  "comparison slugs must not be trusted unless they match the current catalogue",
);
assert.equal(MAX_COMPARISON_PARAMETER_LENGTH, 128, "comparison URL input must have a small explicit length limit");
assert.deepEqual(
  parseCourseCatalogueState(`?compare=${"unknown-course,".repeat(100)}`, categories, courseSlugs).compareSlugs,
  [],
  "oversized comparison parameters must be bounded before parsing",
);

const longSearchTerm = "cybersecurity ".repeat(20);
assert.equal(MAX_COURSE_SEARCH_LENGTH, 100, "course search URLs must have a documented length limit");
assert.equal(
  parseCourseCatalogueState(`?q=${encodeURIComponent(longSearchTerm)}`, categories).query.length,
  MAX_COURSE_SEARCH_LENGTH,
  "opening a URL with an overlong search must clamp the restored query",
);
const boundedSearch = new URLSearchParams(buildCourseCatalogueSearch("", {
  query: longSearchTerm,
  category: "All courses",
  sortOrder: "featured",
  outlineFilter: "all",
  compareSlugs: [],
}, categories, courseSlugs));
assert.equal(boundedSearch.get("q").length, MAX_COURSE_SEARCH_LENGTH, "generated share links must clamp search terms to 100 characters");

const sharedSearch = buildCourseCatalogueSearch(
  "?utm_source=student-email&campaign=course-guide&old=remove-me",
  {
    query: "  firewall & VPN  ",
    category: "AI & Machine Learning",
    sortOrder: "name-desc",
    outlineFilter: "confirm",
    compareSlugs: ["ccna", "ai-ml", "ccna-devnet"],
  },
  categories,
  courseSlugs,
);
const sharedParams = new URLSearchParams(sharedSearch);
assert.equal(sharedParams.get("q"), "firewall & VPN");
assert.equal(sharedParams.get("category"), "AI & Machine Learning");
assert.equal(sharedParams.get("sort"), "name-desc");
assert.equal(sharedParams.get("outline"), "confirm");
assert.equal(sharedParams.get("compare"), "ccna,ai-ml,ccna-devnet", "share links must include the selected comparison courses");
assert.equal(sharedParams.get("utm_source"), "student-email", "unrelated campaign parameters must be preserved");
assert.equal(sharedParams.get("campaign"), "course-guide", "unrelated campaign parameters must be preserved");
assert.equal(sharedParams.get("old"), "remove-me", "the helper must not delete unrelated query parameters");

const resetSearch = buildCourseCatalogueSearch(
  "?q=old&category=Networking&sort=name-asc&outline=published&utm_medium=share",
  { query: "", category: "All courses", sortOrder: "featured", outlineFilter: "all" },
  categories,
);
const resetParams = new URLSearchParams(resetSearch);
assert.equal(resetParams.has("q"), false);
assert.equal(resetParams.has("category"), false);
assert.equal(resetParams.has("sort"), false);
assert.equal(resetParams.has("outline"), false);
assert.equal(resetParams.has("compare"), false, "clearing comparison selections must remove the comparison URL parameter");
assert.equal(resetParams.get("utm_medium"), "share", "resetting filters must preserve unrelated URL parameters");

const safeFallbackSearch = buildCourseCatalogueSearch(
  "?q=old",
  { query: "new", category: "not-a-real-category", sortOrder: "invalid", outlineFilter: "invalid" },
  categories,
);
const safeFallbackParams = new URLSearchParams(safeFallbackSearch);
assert.equal(safeFallbackParams.get("q"), "new");
assert.equal(safeFallbackParams.has("category"), false);
assert.equal(safeFallbackParams.has("sort"), false);
assert.equal(safeFallbackParams.has("outline"), false);

const boundedComparison = new URLSearchParams(buildCourseCatalogueSearch(
  "?compare=old",
  { query: "", category: "All courses", sortOrder: "featured", outlineFilter: "all", compareSlugs: ["ccna", "unknown", "ccna", "ai-ml", "ccna-devnet", "ceh-certified-ethical-hacker"] },
  categories,
  courseSlugs,
));
assert.equal(boundedComparison.get("compare"), "ccna,ai-ml,ccna-devnet", "serialized comparison selections must be known, unique and limited to three courses");

const component = await readFile(new URL("../components/course-catalogue.tsx", import.meta.url), "utf8");
const urlHelper = await readFile(new URL("../lib/course-catalogue-url.mjs", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
const packageJson = JSON.parse(await readFile(new URL("../package.json", import.meta.url), "utf8"));
for (const marker of [
  'import { buildCourseCatalogueSearch, parseCourseCatalogueState }',
  "parseCourseCatalogueState(window.location.search, categories, courseSlugs)",
  "buildCourseCatalogueSearch(window.location.search",
  "compareSlugs: selectedForCompare",
  "setSelectedForCompare(state.compareSlugs)",
  "setShowComparison(state.compareSlugs.length >= 2)",
  'sharingComparison ? "AROUSH Tech course comparison"',
  'window.addEventListener("popstate", readCatalogueUrl)',
  'window.history.replaceState(window.history.state, "", nextUrl)',
  'typeof navigator.share === "function"',
  "navigator.share({",
  "navigator.clipboard.writeText(shareUrl)",
  "Share course view",
  "Sharing cancelled.",
  "Do not enter personal information in the course search.",
  "selected course comparisons appear in the page address",
  "routine server logs",
  "maxLength={100}",
  "Search is limited to 100 characters.",
  'role="status" aria-live="polite">{shareStatus}',
  "Sharing is unavailable in this browser",
]) {
  assert.ok(component.includes(marker), `shareable catalogue state is missing: ${marker}`);
}
assert.ok(urlHelper.includes("MAX_COMPARISON_PARAMETER_LENGTH = 128"), "comparison URL parsing must have a bounded input length");
assert.ok(styles.includes(".catalogue-result-actions"), "share and reset actions need a layout wrapper");
assert.ok(styles.includes(".catalogue-share-button:focus-visible"), "copy action needs visible keyboard focus");
assert.ok(styles.includes("min-height: 44px"), "share actions need touch-sized mobile controls");
assert.ok(packageJson.scripts["check:offline"].includes("validate:course-catalogue-url"), "URL-state tests must run in the offline validation suite");
assert.equal(packageJson.scripts["validate:course-catalogue-url"], "node scripts/validate-course-catalogue-url.mjs");
assert.ok(!/localStorage|sessionStorage|fetch\(|\/api\//.test(component), "catalogue URL state must not use browser storage or an application API; URL values may appear in normal page requests");

console.log("Course catalogue sharing tests passed: shareable search/category/sort/outline/comparison state, known-slug allowlist, duplicate removal, three-course limit, 128-character comparison-parameter bound, native Web Share API, clipboard fallback, share-cancel handling, 100-character search limit, safe invalid-value fallback, URL encoding, campaign-parameter preservation, reset behavior, browser history restoration, accessibility, URL privacy disclosure and no separate storage/API tracking.");
