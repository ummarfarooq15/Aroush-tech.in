import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { sortCourses } from "../lib/course-sort.mjs";

const sample = [
  { title: "CCNA", category: "Networking" },
  { title: "AI & ML", category: "AI" },
  { title: "CEH", category: "Cybersecurity" },
];

assert.deepEqual(sortCourses(sample).map((item) => item.title), ["CCNA", "AI & ML", "CEH"], "default order must preserve the AROUSH catalogue order");
assert.deepEqual(sortCourses(sample, "name-asc").map((item) => item.title), ["AI & ML", "CCNA", "CEH"], "A–Z sorting must use course names");
assert.deepEqual(sortCourses(sample, "name-desc").map((item) => item.title), ["CEH", "CCNA", "AI & ML"], "Z–A sorting must reverse alphabetical order");
assert.deepEqual(sortCourses(sample, "unknown").map((item) => item.title), ["CCNA", "AI & ML", "CEH"], "unknown sort values must safely preserve source order");

const numberedCourses = [{ title: "CCNP 10" }, { title: "CCNP 2" }, { title: "CCNP 1" }];
assert.deepEqual(sortCourses(numberedCourses, "name-asc").map((item) => item.title), ["CCNP 1", "CCNP 2", "CCNP 10"], "A–Z sorting should use natural numeric order");
assert.deepEqual(sortCourses(numberedCourses, "name-desc").map((item) => item.title), ["CCNP 10", "CCNP 2", "CCNP 1"], "Z–A sorting should use natural numeric order");
assert.deepEqual(sortCourses([]), [], "an empty filtered catalogue should remain empty");
assert.deepEqual(sample.map((item) => item.title), ["CCNA", "AI & ML", "CEH"], "sorting must not mutate the source catalogue");

const component = await readFile(new URL("../components/course-catalogue.tsx", import.meta.url), "utf8");
const content = await readFile(new URL("../lib/content.ts", import.meta.url), "utf8");
const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
const catalogueSection = content.split("export const courses: PublicCourse[] = [")[1]?.split("];", 1)[0] ?? "";
const actualCourseTitles = [...catalogueSection.matchAll(/title: "([^"]+)"/g)].map((match) => match[1]);
assert.equal(actualCourseTitles.length, 20, "the source catalogue should contain 20 public courses");
assert.deepEqual(
  sortCourses(actualCourseTitles.map((title) => ({ title })), "name-asc").map((course) => course.title),
  [...actualCourseTitles].sort((first, second) => new Intl.Collator("en", { numeric: true, sensitivity: "base" }).compare(first, second)),
  "the natural A–Z sort should work across all current AROUSH catalogue titles",
);
for (const marker of [
  'import { sortCourses, type CourseSortOrder }',
  'value="featured"',
  'value="name-asc"',
  'value="name-desc"',
  'aria-controls="course-results"',
  'Reset search, filters and sort',
  'sortCourses(outlineFilteredCourses, sortOrder)',
  'const sortAnnouncement = sortOrder === "name-asc"',
  'sorted A to Z',
  'sorted Z to A',
  'className="sr-only">Course </span>{String(index + 1).padStart(2, "0")',
  'filtered.map((course, index) =>',
]) {
  assert.ok(component.includes(marker), `course catalogue is missing: ${marker}`);
}
assert.ok(styles.includes(".course-sort select:focus-visible"), "sort control needs visible keyboard focus");
assert.ok(styles.includes("@media(max-width: 620px)"), "sort control needs a narrow-screen layout");

console.log("Course sorting tests passed: source order, A–Z, Z–A, natural numeric order, empty results, unknown-value fallback, source immutability, current-result numbering, live sort announcement, accessible select and mobile layout.");
