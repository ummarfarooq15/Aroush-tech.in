import fs from "node:fs";
import { buildEnquiryEmail } from "../lib/enquiry-path.mjs";

const checks = [];
function assert(label, condition) {
  checks.push(label);
  if (!condition) {
    console.error(`Enquiry safety validation failed: ${label}`);
    process.exit(1);
  }
}

const hostileSubject = buildEnquiryEmail({
  type: "learner",
  interest: "Course enquiry\r\nBcc: attacker@example.com",
  name: "Student",
  email: "student@example.com",
  message: "Please share details.",
});
assert("subject contains no carriage return", !hostileSubject.subject.includes("\r"));
assert("subject contains no line feed", !hostileSubject.subject.includes("\n"));
assert("subject injection cannot create a second header line", !hostileSubject.subject.includes("\nBcc:"));

const hostileBody = buildEnquiryEmail({
  type: "business",
  interest: "Corporate training\nCc: attacker@example.com",
  name: "Example Organisation\r\nPhone: +1 555 0100",
  email: "contact@example.com\nBcc: attacker@example.com",
  phone: "+91 90000 00000\r\nOrganization: Fake",
  organization: "Example College\nTeam size: 999999",
  teamSize: "11–50\r\nAdmin: true",
  course: "Networking\nPayment: complete",
  message: "First line\r\nSecond line\u0000 hidden control",
});
assert("name cannot inject a second labelled field", !hostileBody.body.includes("Name: Example Organisation\nPhone:"));
assert("email cannot inject a Bcc line", !hostileBody.body.includes("Email: contact@example.com\nBcc:"));
assert("phone cannot inject an organization line", !hostileBody.body.includes("Phone: +91 90000 00000\nOrganization:"));
assert("organization cannot inject team-size fields", !hostileBody.body.includes("Organization: Example College\nTeam size: 999999"));
assert("team size remains a single line", !hostileBody.body.includes("Team size: 11–50\nAdmin:"));
assert("course remains a single line", !hostileBody.body.includes("Course of interest: Networking\nPayment:"));
assert("interest remains a single line", !hostileBody.body.includes("Area of interest: Corporate training\nCc:"));
assert("message line breaks are preserved", hostileBody.body.includes("First line\nSecond line"));
assert("null control characters are removed", !hostileBody.body.includes("\u0000"));


const unknownType = buildEnquiryEmail({
  type: "__proto__",
  interest: "General enquiry",
  name: "Example",
  email: "example@example.com",
  message: "Hello",
});
assert("unknown enquiry types use the safe general label", unknownType.subject.includes("General enquiry") && !unknownType.subject.includes("[object Object]"));

const longSubject = buildEnquiryEmail({
  type: "general",
  interest: "A".repeat(500),
  name: "Example",
  email: "example@example.com",
  message: "Hello",
});
assert("subject has a bounded length", longSubject.subject.length <= 180);

const longMessage = buildEnquiryEmail({
  type: "general",
  interest: "General enquiry",
  name: "Example",
  email: "example@example.com",
  message: "M".repeat(4000),
});
assert("message has a bounded length", longMessage.body.endsWith("M".repeat(3000)));

const source = fs.readFileSync(new URL("../components/contact-form.tsx", import.meta.url), "utf8");
assert("form previews the generated subject and body before handoff", source.includes("{preparedEmail.subject}") && source.includes("{preparedEmail.body}"));
assert("email app opens only through an explicit mailto link", source.includes("href={preparedEmail.mailto}") && !source.includes("window.location.href = mailto"));
assert("visitor sees a not-sent status before handoff", source.includes("email-review-status") && source.includes("Not sent"));
assert("visitor can return to edit the enquiry", source.includes("Edit enquiry") && source.includes("setPreparedEmail(null)"));
assert("editing the form clears the previous draft preview", source.includes('onChange={() => setPreparedEmail(null)}'));
assert("form does not submit to a server", !source.includes("fetch(") && !source.includes("/api/"));
assert("phone remains optional", source.includes('type="tel"') && source.includes("(optional)"));

console.log(`Root-site enquiry safety tests passed: ${checks.length} checks covering email-subject line breaks, single-line field sanitisation, message handling, length limits, review-before-send and explicit local-only email handoff. The separate owner-approved companion lead app is not connected to this form.`);
