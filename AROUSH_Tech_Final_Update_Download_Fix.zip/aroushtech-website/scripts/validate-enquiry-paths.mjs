import fs from "node:fs";
import {
  buildEnquiryEmail,
  defaultInterestForType,
  normalizeEnquiryType,
} from "../lib/enquiry-path.mjs";

const fail = (message) => {
  console.error(`Enquiry-path validation failed: ${message}`);
  process.exit(1);
};

const checks = [];
const assert = (label, condition) => {
  checks.push(label);
  if (!condition) fail(label);
};

assert("learner route is preserved", normalizeEnquiryType("learner") === "learner");
assert("business route is preserved", normalizeEnquiryType("business") === "business");
assert("general route is preserved", normalizeEnquiryType("general") === "general");
assert("unknown route safely defaults to general", normalizeEnquiryType("unknown") === "general");
assert("course deep link defaults to learner", normalizeEnquiryType(undefined, true) === "learner");
assert("learner route has learner interest", defaultInterestForType("learner") === "Individual course enquiry");
assert("business route has corporate interest", defaultInterestForType("business") === "Corporate / campus training");
assert("general route has general interest", defaultInterestForType("general") === "General enquiry");

const learnerEmail = buildEnquiryEmail({
  type: "learner",
  interest: "Individual course enquiry",
  name: "Example Learner",
  email: "learner@example.com",
  course: "CCNA",
  message: "Please share the current outline.",
});
assert("learner email identifies the selected course", learnerEmail.body.includes("Course of interest: CCNA"));
assert("learner email does not invent a phone number", learnerEmail.body.includes("Phone: Not provided"));
assert("learner email uses a clear subject", learnerEmail.subject.includes("Individual learner"));

const businessEmail = buildEnquiryEmail({
  type: "business",
  interest: "Corporate / campus training",
  name: "Example Contact",
  email: "contact@example.com",
  organization: "Example College",
  teamSize: "11–50",
  message: "Discuss a campus learning programme.",
});
assert("business email includes the organization", businessEmail.body.includes("Organization: Example College"));
assert("business email includes optional team size", businessEmail.body.includes("Team size: 11–50"));
assert("business email identifies the business route", businessEmail.subject.includes("Business / institution"));

const root = new URL("..", import.meta.url);
const read = (file) => fs.readFileSync(new URL(file, root), "utf8");
const contactPage = read("app/contact/page.tsx");
const contactForm = read("components/contact-form.tsx");
const normalizedContactForm = contactForm.replace(/\s+/g, " ");
const coursesPage = read("app/courses/[slug]/page.tsx");
const courseCataloguePage = read("app/courses/page.tsx");
const homePage = read("app/page.tsx");
const trainingPage = read("app/training/page.tsx");
const servicesPage = read("app/services/page.tsx");
const styles = read("app/globals.css");
const packageJson = JSON.parse(read("package.json"));

assert("contact page defines learner, business and general routes", ['type: "learner"', 'type: "business"', 'type: "general"'].every((marker) => contactPage.includes(marker)) && contactPage.includes("type=${path.type}"));
assert("contact page exposes a real enquiry form anchor", contactPage.includes('id="enquiry-form"'));
assert("contact form receives the selected route", contactPage.includes("initialType={activeType}"));
assert("contact form synchronizes query-driven route changes", contactForm.includes("useEffect(() =>") && contactForm.includes("setEnquiryType(initialEnquiryType)") && contactForm.includes("setInterest(initialInterestValue)"));
assert("course deep links update controlled course and message fields", contactForm.includes("value={course}") && contactForm.includes("value={message}") && contactForm.includes("setMessage(courseEnquiryMessage(courseName))"));
assert("editing or changing an enquiry path clears a stale email draft", contactForm.includes('onChange={() => setPreparedEmail(null)}') && contactForm.includes("setPreparedEmail(null)"));
assert("contact form uses the tested local email helper", contactForm.includes("buildEnquiryEmail({"));
assert("contact form previews the complete email before handoff", contactForm.includes("Review your email draft") && contactForm.includes("{preparedEmail.body}"));
assert("email app opens only after an explicit visitor click", contactForm.includes("href={preparedEmail.mailto}") && !contactForm.includes("window.location.href = mailto"));
assert("visitor can edit after reviewing the draft", contactForm.includes("Edit enquiry") && contactForm.includes("setPreparedEmail(null)"));
assert("learner course pages open the learner route", coursesPage.includes("/contact?type=learner&interest="));
assert("corporate training opens the business route", trainingPage.includes("/contact?type=business&interest="));
assert("service enquiries open the business route", servicesPage.includes("/contact?type=business&interest="));
assert("homepage offers separate learner and business CTAs", homePage.includes("/contact?type=learner") && homePage.includes("/contact?type=business"));
assert("course catalogue offers separate learner and business CTAs", courseCataloguePage.includes("/contact?type=learner") && courseCataloguePage.includes("/contact?type=business"));
assert("phone remains optional", contactForm.includes('type="tel"') && contactForm.includes("(optional)"));
assert("form explicitly explains no website storage", normalizedContactForm.includes("not submitted to or stored on this website"));
assert("email preview explains that nothing has been sent yet", normalizedContactForm.includes("Nothing is sent until you choose to open your email app and send the message"));
assert("business team size is optional", contactForm.includes('name="teamSize" defaultValue=""'));
assert("path cards have responsive layout and visible focus", styles.includes(".contact-path-card:focus-visible") && styles.includes("@media(max-width:900px) { .contact-paths"));
assert("homepage and catalogue CTA groups can wrap on mobile", styles.includes(".final-cta-actions") && styles.includes("@media(max-width:760px) { .final-cta-actions"));
assert("contact form does not call an API", !contactForm.includes("fetch(") && !contactForm.includes("/api/"));
assert("offline validation includes this test", packageJson.scripts?.["check:offline"]?.includes("validate:enquiry-paths"));

console.log(`Enquiry-path tests passed: ${checks.length} checks covering route defaults, learner and business email previews, explicit mail-app handoff, edit recovery, optional phone, privacy boundary, deep links, accessibility and responsive layout.`);
