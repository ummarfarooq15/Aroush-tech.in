import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");
const fail = (message) => {
  console.error(`UX validation failed: ${message}`);
  process.exit(1);
};

const chatbot = read("components/site-chatbot.tsx");
const chatbotRules = read("lib/chatbot-rules.mjs");
if (!chatbotRules.includes("current AROUSH homepage advertises a free course demo")) {
  fail("chatbot free-demo answer is missing from its rule module");
}
const contactForm = read("components/contact-form.tsx");
const enquiryPath = read("lib/enquiry-path.mjs");
const normalizedContactForm = contactForm.replace(/\s+/g, " ");
const courseCatalogue = read("components/course-catalogue.tsx");
const courseCatalogueUrl = read("lib/course-catalogue-url.mjs");
if (normalizedContactForm.includes("window.location.href = mailto")) fail("contact form must not launch the visitor email app automatically");

for (const [label, marker] of [
  ["native mobile share", 'typeof navigator.share === "function"'],
  ["clipboard fallback", "navigator.clipboard.writeText(shareUrl)"],
  ["bounded shareable search", "maxLength={100}"],
  ["share cancellation feedback", "Sharing cancelled."],
  ["shareable course comparison state", "compareSlugs: selectedForCompare"],
  ["restore selected comparison courses from URL", "setSelectedForCompare(state.compareSlugs)"],
  ["automatically reopen a shared comparison", "setShowComparison(state.compareSlugs.length >= 2)"],
  ["comparison-aware share title", 'sharingComparison ? "AROUSH Tech course comparison"'],
  ["course view sharing action", "Share course view"],
]) {
  if (!courseCatalogue.includes(marker)) fail(`course catalogue is missing ${label}`);
}
if (!courseCatalogueUrl.includes("MAX_COURSE_SEARCH_LENGTH = 100")) {
  fail("shareable course searches must be capped to avoid oversized URLs");
}
const faqBrowser = read("components/faq-browser.tsx");
const navigation = read("components/primary-navigation.tsx");
const packageJson = JSON.parse(read("package.json"));

if (normalizedContactForm.includes("window.location.href = mailto")) fail("contact form must not launch the visitor email app automatically");

for (const [label, marker] of [
  ["persistent quick replies", "quickQuestions.slice(0, 4).map"],
  ["expandable additional quick replies", "chatbot-extra-questions"],
  ["accessible quick-reply expansion state", "aria-expanded={showMoreQuickQuestions}"],
  ["payment-safety quick reply", "Can I pay for a course online?"],
  ["typed question input", 'id="chatbot-question"'],
  ["Escape-to-close support", 'event.key === "Escape"'],
  ["free-demo answer module", "getChatAnswer"],
  ["privacy notice response", 'href: "/privacy"'],
  ["focus on the question field", "questionInputRef.current?.focus()"],
  ["focus return to the launcher", "launcherRef.current?.focus()"],
  ["live conversation announcements", 'role="log"'],
  ["chat history scroll container", "messagesContainerRef.current"],
  ["quick-reply focus recovery", "focusMessagesAfterReplyRef.current"],
  ["focusable conversation log", "tabIndex={-1}"],
  ["mobile focus avoids opening the keyboard", "closeButtonRef.current?.focus()"],
  ["chat input help association", 'aria-describedby="chatbot-note"'],
  ["conditional chatbot control reference", 'aria-controls={isOpen ? "aroush-chatbot-panel" : undefined}'],
  ["mobile keyboard is not forced open", 'window.matchMedia("(min-width: 700px)").matches'],
  ["unknown questions route to the team", 'label: "Contact the AROUSH team"'],
  ["rule-based support disclosure", "not live human or AI support"],
]) {
  if (!chatbot.includes(marker) && !chatbotRules.includes(marker)) fail(`chatbot is missing ${label}`);
}

if (!chatbot.includes("What does the AI & ML course cover?")) {
  fail("the verified AI & ML course quick reply is missing");
}
if (!chatbot.includes('aria-controls="chatbot-extra-questions"') || !chatbot.includes('aria-expanded={showMoreQuickQuestions}')) {
  fail("quick replies must remain available after an answer and expose an accessible expand/collapse control");
}

if (normalizedContactForm.includes("window.location.href = mailto")) fail("contact form must not launch the visitor email app automatically");

for (const [label, marker] of [
  ["voluntary phone number", 'type="tel"'],
  ["optional phone label", "(optional)"],
  ["phone purpose explanation", "Share a number only if you want the team to contact you by phone"],
  ["local email handoff", "mailto:${company.email}"],
  ["review-before-send panel", "Review your email draft"],
  ["explicit email-app handoff", "href={preparedEmail.mailto}"],
  ["accessible enquiry form name", 'aria-label="AROUSH enquiry form"'],
  ["no website database disclosure", "not submitted to or stored on this website"],
  ["general enquiry fallback", '"General enquiry"'],
  ["enquiry type selector", 'name="enquiryType"'],
  ["learner-specific course field", 'name="course"'],
  ["business organization field", 'name="organization"'],
  ["business team-size field", 'name="teamSize"'],
  ["locally prepared email helper", "buildEnquiryEmail({"],
  ["enquiry type included in email draft", "Enquiry type: ${label}"],
]) {
  if (!normalizedContactForm.includes(marker) && !enquiryPath.includes(marker)) fail(`contact form is missing ${label}`);
}

if (/setQuestion\(""\);\s*questionInputRef\.current\?\.focus\(\)/.test(chatbot)) {
  fail("quick replies must not force the mobile keyboard open");
}
if (courseCatalogue.includes("localStorage") || courseCatalogue.includes("sessionStorage") || courseCatalogue.includes("fetch(") || courseCatalogue.includes("/api/") || courseCatalogueUrl.includes("localStorage") || courseCatalogueUrl.includes("fetch(")) {
  fail("course comparison must not use browser storage, API calls or a backend; shareable course slugs may appear in the URL");
}
if (contactForm.includes("fetch(") || contactForm.includes("/api/")) {
  fail("contact form must not introduce an unapproved server-side lead endpoint");
}
if (normalizedContactForm.includes("window.location.href = mailto")) fail("contact form must not launch the visitor email app automatically");

for (const [label, marker] of [
  ["course search", 'type="search"'],
  ["search result relationship", 'aria-controls="course-results"'],
  ["search help association", 'aria-describedby="catalogue-count catalogue-url-note"'],
  ["category filters", "aria-pressed={activeCategory === category}"],
  ["category result relationship", 'aria-controls="course-results"'],
  ["stable results region", 'id="course-results"'],
  ["result count announcement", 'aria-live="polite"'],
  ["empty-state recovery", "Clear filters"],
  ["clear active filters control", "Reset search, filters and sort"],
  ["clear-filter visibility state", "hasActiveFilters"],
  ["published outline status on course cards", "Published outline topics"],
  ["owner confirmation status for incomplete syllabus", "AROUSH syllabus to confirm"],
  ["published duration on course cards", "courseDetails[course.slug]?.duration"],
  ["visible outline count", "visibleOutlineCount"],
  ["course sorting control", "Sort courses"],
  ["catalogue-order option", "AROUSH catalogue order"],
  ["alphabetical sort options", "name-asc"],
  ["sort helper integration", "sortCourses(outlineFilteredCourses, sortOrder)"],
  ["outline availability filter", "Outline availability"],
  ["published outline filter", 'value="published"'],
  ["outline confirmation filter", 'value="confirm"'],
  ["outline filter helper", "filterCoursesByOutline(matchingCourses, courseDetails, outlineFilter)"],
  ["sort order announced to assistive technology", 'const sortAnnouncement = sortOrder === "name-asc"'],
  ["course rank follows visible result order", `className="sr-only">Course </span>{String(index + 1).padStart(2, "0")`],
  ["sort reset with search and filters", "Reset search, filters and sort"],
  ["course comparison selection helper", "toggleComparedCourse(selectedForCompare, slug, 3)"],
  ["course comparison maximum selection", "compareLimitReached && !selectedForCompare.includes(course.slug)"],
  ["course comparison accessible toggle", "aria-pressed={selectedForCompare.includes(course.slug)}"],
  ["course comparison details table", "course-compare-table"],
  ["course comparison fee-conflict handling", '? "Confirm with AROUSH"'],
  ["course comparison share disclosure", "selected course comparisons appear in the page address"],
  ["course comparison local-only disclosure", "A shared comparison link includes only course slugs, not personal information."],
]) {
  if (!courseCatalogue.includes(marker)) fail(`course discovery is missing ${label}`);
}

if (normalizedContactForm.includes("window.location.href = mailto")) fail("contact form must not launch the visitor email app automatically");

for (const [label, marker] of [
  ["FAQ search input", 'type="search"'],
  ["FAQ category filters", "aria-pressed={activeCategory === category}"],
  ["FAQ result count announcement", 'role="status" aria-live="polite"'],
  ["FAQ filter reset", "Clear search and filters"],
  ["FAQ no-results contact handoff", 'href="/contact"'],
]) {
  if (!faqBrowser.includes(marker)) fail(`FAQ discovery is missing ${label}`);
}

const courseDetailPage = read("app/courses/[slug]/page.tsx");
if (!courseDetailPage.includes("This rebuilt website does not take online course payments") || !courseDetailPage.includes("Confirm payment instructions directly with AROUSH")) {
  fail("course pages must explain that this rebuild has no online checkout and direct visitors to verify payment instructions with AROUSH");
}
if (courseDetailPage.includes("demosites.royal-elementor-addons.com")) {
  fail("course pages must not reuse the unverified third-party checkout destination from the live WordPress pages");
}
const servicesPage = read("app/services/page.tsx");
if (!servicesPage.includes('id={service.number === "10" ? "soc-siem" : `service-${service.number}`}')) {
  fail("service detail sections must expose stable anchors for direct chatbot links");
}
if (!navigation.includes("aria-expanded") || !navigation.includes("aria-controls") || !navigation.includes("firstLinkRef.current?.focus()")) {
  fail("mobile navigation disclosure controls are missing accessible state attributes");
}
if (!navigation.includes("previousPathnameRef.current !== pathname") || !navigation.includes("toggleRef.current?.focus()")) {
  fail("mobile navigation must return keyboard focus to its toggle after route changes");
}
const notFoundPage = read("app/not-found.tsx");
for (const href of ['href="/courses"', 'href="/services"', 'href="/contact"']) {
  if (!notFoundPage.includes(href)) fail(`the 404 recovery page is missing ${href}`);
}
if (fs.existsSync(path.join(root, "app", "api"))) {
  fail("an unapproved server-side API directory exists");
}
const unapprovedDependencies = Object.keys(packageJson.dependencies ?? {}).filter((name) =>
  /prisma|mongoose|mongodb|supabase|firebase|hubspot|salesforce|intercom/i.test(name),
);
if (unapprovedDependencies.length) {
  fail(`unapproved database/CRM dependencies found: ${unapprovedDependencies.join(", ")}`);
}


const css = read("app/globals.css");
if (normalizedContactForm.includes("window.location.href = mailto")) fail("contact form must not launch the visitor email app automatically");

for (const [label, marker] of [
  ["touch-sized chatbot close button", "width: 40px; height: 40px"],
  ["touch-sized chatbot quick replies", "min-height: 40px"],
  ["bounded expanded quick-reply list", "max-height: 116px"],
  ["hidden expanded quick-reply state", ".chatbot-quick-questions[hidden]"],
  ["touch-sized chatbot send controls", "min-height: 44px"],
  ["mobile safe-area support", "env(safe-area-inset-right)"],
]) {
  if (!css.includes(marker)) fail(`mobile accessibility is missing ${label}`);
}

console.log("UX validation passed: grounded chatbot answers, persistent quick replies, accessible navigation, shareable course-catalogue state, FAQ search, learner/business/general enquiry paths, review-first voluntary email handoff and browser-side comparison sharing are covered; no server-side lead/CRM integration is present.");
