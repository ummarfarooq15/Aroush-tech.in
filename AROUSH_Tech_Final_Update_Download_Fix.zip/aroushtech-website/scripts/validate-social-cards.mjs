import fs from "node:fs";

const read = (file) => fs.readFileSync(file, "utf8");
const files = [
  "components/social-card.tsx",
  "app/opengraph-image.tsx",
  "app/twitter-image.tsx",
  "app/courses/[slug]/opengraph-image.tsx",
  "app/courses/[slug]/twitter-image.tsx",
];

for (const file of files) {
  if (!fs.existsSync(file)) {
    console.error(`Social-card validation failed: missing ${file}`);
    process.exit(1);
  }
}

const component = read("components/social-card.tsx");
const rootOpenGraph = read("app/opengraph-image.tsx");
const rootTwitter = read("app/twitter-image.tsx");
const courseOpenGraph = read("app/courses/[slug]/opengraph-image.tsx");
const courseTwitter = read("app/courses/[slug]/twitter-image.tsx");
const layout = read("app/layout.tsx");
const coursePage = read("app/courses/[slug]/page.tsx");

const errors = [];
for (const [label, source] of [
  ["root Open Graph", rootOpenGraph],
  ["root Twitter", rootTwitter],
  ["course Open Graph", courseOpenGraph],
  ["course Twitter", courseTwitter],
]) {
  if (!source.includes('from "next/og"') || !source.includes("new ImageResponse(")) {
    errors.push(`${label} must use Next.js ImageResponse`);
  }
  if (!source.includes("width: 1200") || !source.includes("height: 630")) {
    errors.push(`${label} must use 1200 × 630 dimensions`);
  }
  if (!source.includes('contentType = "image/png"')) {
    errors.push(`${label} must declare PNG output`);
  }
}

if (!component.includes("company") && !component.includes("AROUSH TECH")) {
  errors.push("shared social card must identify the AROUSH brand");
}
if (!component.includes("CONNECT · SECURE · SUPPORT · TRAIN")) {
  errors.push("shared social card must use the published AROUSH brand promise");
}
if (!courseOpenGraph.includes('import { courses } from "@/lib/content"') || !courseTwitter.includes('import { courses } from "@/lib/content"')) {
  errors.push("course social cards must use the verified course catalogue");
}
if (!courseOpenGraph.includes("courses.find") || !courseTwitter.includes("courses.find")) {
  errors.push("course social cards must resolve titles through the catalogue allowlist");
}
if (!courseOpenGraph.includes("course?.category") || !courseTwitter.includes("course?.category")) {
  errors.push("course social cards must show the catalogue category");
}
if (!layout.includes('twitter: { card: "summary_large_image" }') || !coursePage.includes('twitter: { card: "summary_large_image" }')) {
  errors.push("root and course metadata must request large social preview cards");
}

const allSource = files.map(read).join("\n");
if (/₹\s?[0-9]|\b(?:%\s?placement|job guarantee|100%\s+job)\b/i.test(allSource)) {
  errors.push("social cards must not invent or expose unapproved commercial claims");
}
if (/pynetlabs|imedita|apna college/i.test(allSource)) {
  errors.push("competitor names must not appear in AROUSH social cards");
}
if (/https?:\/\//i.test(component)) {
  errors.push("shared social-card artwork must not fetch remote assets");
}

if (errors.length) {
  console.error("Social-card validation failed:");
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log("Social-card validation passed: root and course Open Graph/Twitter cards use 1200 × 630 PNG output, verified AROUSH/course content, safe fallbacks and no unapproved commercial or competitor claims.");
