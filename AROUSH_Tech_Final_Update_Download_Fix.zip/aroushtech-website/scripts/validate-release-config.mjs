import { readFileSync, existsSync } from "node:fs";

const packageJson = JSON.parse(readFileSync("package.json", "utf8"));
const nodeVersion = readFileSync(".nvmrc", "utf8").trim();
const environmentExample = readFileSync(".env.example", "utf8");
const expectedNodeMajor = packageJson.engines?.node;
const requiredScripts = [
  "validate:content",
  "validate:privacy",
  "validate:analytics-policy",
  "validate:brand",
  "validate:ux",
  "validate:accessibility",
  "validate:links",
  "validate:breadcrumbs",
  "validate:social-cards",
  "validate:external-links",
  "test:external-link-policy",
  "preflight:release",
  "validate:public-claims",
  "validate:learning-paths",
  "validate:faqs",
  "validate:faq-search",
  "validate:course-sort",
  "validate:course-outline-filter",
  "validate:course-catalogue-url",
  "validate:course-compare",
  "validate:enquiry-paths",
  "validate:enquiry-safety",
  "validate:chatbot",
  "validate:javascript",
  "validate:typescript-syntax",
  "validate:release-config",
  "validate:visitor-intelligence",
];

const errors = [];

if (expectedNodeMajor !== "24.x") {
  errors.push(`package.json engines.node must be 24.x; found ${expectedNodeMajor ?? "missing"}.`);
}

if (nodeVersion !== "24") {
  errors.push(`.nvmrc must contain 24; found ${nodeVersion || "empty"}.`);
}

if (packageJson.scripts?.lint !== "eslint .") {
  errors.push('The lint script must call "eslint ." directly for Next.js 15.5+ compatibility.');
}

const offlineCheck = packageJson.scripts?.["check:offline"] ?? "";
if (!offlineCheck.includes("validate:visitor-intelligence") || !offlineCheck.includes("validate:breadcrumbs") || !offlineCheck.includes("validate:social-cards") || !offlineCheck.includes("validate:external-links") || !offlineCheck.includes("test:external-link-policy") || !offlineCheck.includes("validate:public-claims") || !offlineCheck.includes("validate:accessibility") || !offlineCheck.includes("validate:typescript-syntax") || !offlineCheck.includes("validate:faqs") || !offlineCheck.includes("validate:faq-search") || !offlineCheck.includes("validate:course-sort") || !offlineCheck.includes("validate:course-outline-filter") || !offlineCheck.includes("validate:course-catalogue-url") || !offlineCheck.includes("validate:course-compare") || !offlineCheck.includes("validate:enquiry-paths") || !offlineCheck.includes("validate:enquiry-safety")) {
  errors.push("check:offline must include external-link policy tests, external-link validation, public-claims validation, accessibility validation and TypeScript syntax validation.");
}

for (const scriptName of requiredScripts) {
  if (!packageJson.scripts?.[scriptName]) {
    errors.push(`Missing npm script: ${scriptName}.`);
  }
}

for (const scriptName of requiredScripts) {
  const command = packageJson.scripts?.[scriptName] ?? "";
  const scriptPath = command.match(/node\s+(scripts\/[^\s]+)/)?.[1];
  if (scriptPath && !existsSync(scriptPath)) {
    errors.push(`The ${scriptName} script points to a missing file: ${scriptPath}.`);
  }
}

const measurementIdLine = environmentExample
  .split(/\r?\n/)
  .find((line) => line.startsWith("NEXT_PUBLIC_GA_MEASUREMENT_ID="));

if (!measurementIdLine || measurementIdLine !== "NEXT_PUBLIC_GA_MEASUREMENT_ID=") {
  errors.push(".env.example must keep NEXT_PUBLIC_GA_MEASUREMENT_ID blank by default.");
}

if (errors.length > 0) {
  console.error("Release configuration validation failed:");
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log("Release configuration validation passed: Node 24 pin, direct ESLint CLI, required validation scripts, breadcrumb and social-card validation, external-link policy tests, release preflight, public-claims guard, TypeScript syntax validation and blank GA4 Measurement ID and shareable catalogue URL tests are consistent.");
