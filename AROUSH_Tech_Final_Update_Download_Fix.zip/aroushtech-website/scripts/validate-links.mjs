import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");
const fail = (message) => {
  console.error(`Link validation failed: ${message}`);
  process.exit(1);
};

const routes = new Set(["/"]);
const dynamicCourseRoute = "/courses/[slug]";
const routeFiles = [];

function collectFiles(directory) {
  for (const entry of fs.readdirSync(path.join(root, directory), { withFileTypes: true })) {
    const relativePath = path.posix.join(directory, entry.name);
    if (entry.isDirectory()) {
      collectFiles(relativePath);
    } else if (entry.isFile() && /\.(tsx|ts)$/.test(entry.name)) {
      routeFiles.push(relativePath);
      if (entry.name === "page.tsx" && directory.startsWith("app")) {
        const route = directory === "app" ? "/" : `/${directory.slice(4)}`;
        routes.add(route.replace(/\/+/g, "/"));
      }
    }
  }
}

collectFiles("app");
collectFiles("components");

const content = read("lib/content.ts");
const courseSection = content.split("export const courses: PublicCourse[] = [")[1]?.split("];\n\nexport const socCourses")[0] ?? "";
const courseSlugs = new Set([...courseSection.matchAll(/slug: "([^"]+)"/g)].map((match) => match[1]));
if (courseSlugs.size !== 20) fail(`expected 20 unique course slugs, found ${courseSlugs.size}`);

const checked = new Set();
const broken = [];
const externalHttp = [];
const missingAnchors = [];

function checkHref(rawValue, sourceFile) {
  const value = rawValue.trim();
  if (!value || value.includes("${")) {
    if (value.startsWith("/courses/${")) return;
    if (value.startsWith("/contact?")) {
      checked.add("/contact");
      if (!routes.has("/contact")) broken.push(`${sourceFile}: /contact`);
    }
    return;
  }
  if (value.startsWith("mailto:") || value.startsWith("tel:") || value.startsWith("#")) {
    if (value.startsWith("#")) {
      const id = value.slice(1);
      const allSource = read("app/layout.tsx");
      if (!allSource.includes(`id="${id}"`)) missingAnchors.push(`${sourceFile}: #${id}`);
    }
    return;
  }
  if (/^http:\/\//i.test(value)) {
    externalHttp.push(`${sourceFile}: ${value}`);
    return;
  }
  if (/^https:\/\//i.test(value)) return;
  if (!value.startsWith("/")) return;

  const [pathname, hash] = value.split("#", 2);
  const pathOnly = pathname.split("?", 1)[0] || "/";
  checked.add(pathOnly);

  if (pathOnly.startsWith("/courses/")) {
    const slug = pathOnly.slice("/courses/".length).replace(/\/$/, "");
    if (slug && slug !== "${course.slug}" && !courseSlugs.has(slug)) {
      broken.push(`${sourceFile}: ${pathOnly}`);
    }
  } else if (!routes.has(pathOnly)) {
    broken.push(`${sourceFile}: ${pathOnly}`);
  }

  if (hash) {
    const routeFile = pathOnly === "/" ? "app/page.tsx" : `app${pathOnly}/page.tsx`;
    const candidates = [routeFile, "app/layout.tsx"];
    const anchorFound = candidates.some((candidate) =>
      fs.existsSync(path.join(root, candidate)) &&
      read(candidate).includes(`"${hash}"`),
    );
    if (!anchorFound) missingAnchors.push(`${sourceFile}: ${pathOnly}#${hash}`);
  }
}

for (const relativePath of routeFiles) {
  const source = read(relativePath);
  const patterns = [
    /\bhref\s*=\s*"([^"]+)"/g,
    /\bhref\s*=\s*'([^']+)'/g,
    /\bhref\s*=\s*\{\s*"([^"]+)"\s*\}/g,
    /\bhref\s*=\s*\{\s*'([^']+)'\s*\}/g,
    /\bhref\s*=\s*\{\s*`([^`]+)`\s*\}/g,
    /\bhref:\s*"([^"]+)"/g,
  ];
  for (const pattern of patterns) {
    for (const match of source.matchAll(pattern)) checkHref(match[1], relativePath);
  }
}

const redirects = read("next.config.mjs");
for (const match of redirects.matchAll(/destination:\s*"([^"]+)"/g)) {
  checkHref(match[1], "next.config.mjs");
}

if (externalHttp.length) fail(`non-HTTPS external links found: ${externalHttp.join("; ")}`);
if (broken.length) fail(`broken internal routes found: ${[...new Set(broken)].join("; ")}`);
if (missingAnchors.length) fail(`missing in-page targets found: ${[...new Set(missingAnchors)].join("; ")}`);

console.log(`Link validation passed: ${checked.size} internal paths checked, ${courseSlugs.size} course slugs registered, redirects inspected, no broken internal routes or non-HTTPS external links found.`);
