import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const read = (relativePath) => fs.readFileSync(path.join(root, relativePath), "utf8");
const exists = (relativePath) => fs.existsSync(path.join(root, relativePath));
const fail = (message) => {
  console.error(`Brand validation failed: ${message}`);
  process.exit(1);
};

const optimizedLogo = "public/images/aroush-solutions-logo.webp";
const symbolLogo = "public/images/aroush-solutions-symbol.webp";
const originalLogo = "public/images/aroush-solutions-3d-logo.png";
const favicon = "app/icon.png";

for (const file of [optimizedLogo, symbolLogo, originalLogo, favicon]) {
  if (!exists(file)) fail(`missing approved brand asset: ${file}`);
  if (fs.statSync(path.join(root, file)).size < 10_000) {
    fail(`brand asset looks unexpectedly small: ${file}`);
  }
}

const requiredLogoReferences = [
  ["site header emblem", "components/site-header.tsx", "/images/aroush-solutions-symbol.webp"],
  ["homepage emblem", "app/page.tsx", "/images/aroush-solutions-symbol.webp"],
  ["chatbot emblem", "components/site-chatbot.tsx", "/images/aroush-solutions-symbol.webp"],
  ["site footer full lockup", "components/site-footer.tsx", "/images/aroush-solutions-logo.webp"],
  ["structured-data full lockup", "app/layout.tsx", "/images/aroush-solutions-logo.webp"],
];

for (const [label, file, asset] of requiredLogoReferences) {
  if (!read(file).includes(asset)) {
    fail(`${label} does not use the correct approved logo asset`);
  }
}

const header = read("components/site-header.tsx");
const footer = read("components/site-footer.tsx");
const chatbot = read("components/site-chatbot.tsx");
const layout = read("app/layout.tsx");
const css = read("app/globals.css");

if (!header.includes('alt=""') || !header.includes("brand-wordmark")) {
  fail("header logo must avoid duplicate screen-reader text and retain a readable wordmark");
}
if (!footer.includes('alt="AROUSH Solutions logo"')) {
  fail("footer logo must have descriptive alternative text");
}
if (!chatbot.includes('alt=""')) {
  fail("chatbot logo must be decorative when its adjacent title already names the brand");
}
if (!layout.includes('icons: { icon: "/icon.png"')) {
  fail("browser icon metadata is missing");
}
for (const selector of [".brand-logo", ".hero-brand-logo", ".footer-logo", ".chatbot-brand img", "@media(max-width:720px)"]) {
  if (!css.includes(selector)) fail(`responsive brand styling is missing: ${selector}`);
}
if (!read("docs/BRAND-IDENTITY-UPDATE-2026-11-06.md").includes("aroush-solutions-logo.webp")) {
  fail("brand documentation does not describe the optimized WebP display asset");
}

console.log("Brand validation passed: the approved original logo is retained, the emblem derivative is used in compact placements, the full lockup is used in the footer and structured data, and the favicon is present.");
