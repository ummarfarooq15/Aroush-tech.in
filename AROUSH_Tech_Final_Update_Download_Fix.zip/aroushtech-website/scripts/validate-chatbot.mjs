import assert from "node:assert/strict";
import { getChatAnswer } from "../lib/chatbot-rules.mjs";

const cases = [
  ["cybersecurity consulting", "/services"],
  ["Do you provide firewall setup?", "/services#service-07"],
  ["Can I learn firewall configuration?", "/courses"],
  ["Do you have cybersecurity courses?", "/courses"],
  ["Can you deploy a SIEM?", "/services#soc-siem"],
  ["How much does SOC deployment cost?", "/contact"],
  ["Do you offer SOC analyst training?", "/training#soc-siem"],
  ["Corporate training for our campus", "/training"],
  ["What is the CCNA syllabus?", "/courses/ccna"],
  ["What is the current course fee?", "/courses"],
  ["Can you confirm the CCNA course fee?", "/contact?interest=Individual%20course%20enquiry"],
  ["What is the CCNA DevNet fee?", "/contact?interest=Individual%20course%20enquiry"],
  ["What is the service fee for VAPT?", "/contact"],
  ["What is the fee for SOC training?", "/contact"],
  ["What is the fee for corporate training?", "/contact"],
  ["When does the next batch start?", "/contact"],
  ["Can I get a job guarantee?", "/contact"],
  ["Where can I find answers to common questions?", "/faqs"],
  ["How do I contact the team?", "/contact"],
  ["Who is on the AROUSH team?", "/team"],
  ["What is AROUSH’s vision and mission?", "/about"],
  ["Show me the training gallery", "/gallery"],
  ["Where are the AROUSH offices?", "/contact"],
  ["Where is AROUSH located?", "/contact"],
  ["How does analytics consent work?", "/privacy"],
  ["Is a free course demo available?", "/contact?interest=Individual%20course%20enquiry"],
  ["Do you offer network automation training?", "/courses"],
  ["Do you provide SOC monitoring?", "/services#soc-siem"],
  ["Can you deploy Wazuh?", "/services#soc-siem"],
  ["Do you train people on Microsoft Sentinel?", "/training#soc-siem"],
  ["Can I take a CyberArk PAM course?", "/services#service-02"],
  ["I need help securing a cloud environment", "/services"],
  ["I need network support", "/services"],
  ["Can you advise on DPO-as-a-Service?", "/services#service-01"],
  ["Do you provide CyberArk PAM consulting?", "/services#service-02"],
  ["Do you offer a VAPT subscription?", "/services#service-03"],
  ["Can you help with OT/ICS security?", "/services#service-04"],
  ["Do you offer security awareness training?", "/services#service-05"],
  ["Can you install network infrastructure?", "/services#service-06"],
  ["Do you configure firewall and VPN?", "/services#service-07"],
  ["Can I get technical support?", "/services#service-08"],
  ["What does the AI & ML course cover?", "/courses/ai-ml"],
  ["How long is AI/ML training?", "/courses/ai-ml"],
  ["How many hours is the machine learning course?", "/courses/ai-ml"],
  ["What is the AI & ML course fee?", "/courses"],
  ["Can I pay for a course online?", "/contact"],
  ["Does the enquiry form send my details?", "/contact"],
  ["What does the Agentic AI LangGraph course cover?", "/courses/agentic-ai-langgraph-langchain"],
  ["Show me the LangGraph syllabus", "/courses/agentic-ai-langgraph-langchain"],
  ["What does the LangChain and Hugging Face course cover?", "/courses/agentic-ai-langchain-hugging-face"],
  ["Show me the Hugging Face curriculum", "/courses/agentic-ai-langchain-hugging-face"],
];

for (const [question, expectedHref] of cases) {
  const answer = getChatAnswer(question);
  assert.equal(answer.link.href, expectedHref, `Unexpected route for: ${question}`);
  assert.ok(answer.text.length > 20, `Answer is too short for: ${question}`);
}

const teamAnswer = getChatAnswer("Who is on the AROUSH team?");
assert.ok(teamAnswer.text.includes("Abdul Aleem Khan") && teamAnswer.text.includes("Tajuddin") && teamAnswer.text.includes("Mohammed Khalid"), "Team answers must use the three names and roles published by AROUSH");
const officeAnswer = getChatAnswer("Where are the AROUSH offices?");
assert.ok(officeAnswer.text.includes("Corporate Office") && officeAnswer.text.includes("Registered Office") && officeAnswer.text.includes("does not give a complete visitor address"), "Office answers must distinguish published offices from the incomplete J.P. Nagar training-centre location");
const missionAnswer = getChatAnswer("What is AROUSH’s vision and mission?");
assert.ok(missionAnswer.text.includes("preferred consulting and training services company") && missionAnswer.text.includes("helping them realise their potential"), "Company overview answers must stay grounded in the published vision and mission");

const faqAnswer = getChatAnswer("Where can I find answers to common questions?");
assert.ok(faqAnswer.text.includes("verified information") && faqAnswer.link.href === "/faqs", "FAQ questions must link to the dedicated verified FAQ page");

const unknown = getChatAnswer("Can you teleport a server to Mars?");
assert.equal(unknown.link.href, "/contact", "Unknown questions must reach the human team");

const langGraphAnswer = getChatAnswer("What does the Agentic AI LangGraph course cover?");
assert.ok(langGraphAnswer.text.includes("LangSmith") && langGraphAnswer.text.includes("human-in-the-loop"), "LangGraph answers must use topics from the published AROUSH outline");
assert.ok(langGraphAnswer.text.includes("does not state a course duration"), "LangGraph answers must not invent a duration");

const huggingFaceAnswer = getChatAnswer("What does the LangChain and Hugging Face course cover?");
assert.ok(huggingFaceAnswer.text.includes("Hugging Face") && huggingFaceAnswer.text.includes("vector and graph databases"), "Hugging Face answers must use topics from the published AROUSH outline");
assert.ok(huggingFaceAnswer.text.includes("does not state a course duration"), "Hugging Face answers must not invent a duration");

const { readFile } = await import("node:fs/promises");
const servicePage = await readFile(new URL("../app/services/page.tsx", import.meta.url), "utf8");
const chatbotComponent = await readFile(new URL("../components/site-chatbot.tsx", import.meta.url), "utf8");
assert.ok(servicePage.includes('id={service.number === "10" ? "soc-siem" : `service-${service.number}`}'), "Service detail sections must expose stable anchors for chatbot links");
assert.ok(chatbotComponent.includes("What does the LangGraph course cover?") && chatbotComponent.includes("What does the Hugging Face course cover?"), "The chatbot must expose quick replies for both published Agentic AI outlines");
assert.ok(chatbotComponent.includes("Can I pay for a course online?"), "The chatbot must expose a payment-safety quick reply");
assert.ok(chatbotComponent.includes("Does the enquiry form send my details?"), "The chatbot must explain the privacy-preserving email-draft enquiry flow");
assert.ok(chatbotComponent.includes("Who is on the AROUSH team?") && chatbotComponent.includes("What is AROUSH’s vision and mission?") && chatbotComponent.includes("Show me the training gallery"), "The chatbot must expose verified company, team and gallery quick replies");
assert.ok(chatbotComponent.includes("quickQuestions.slice(0, 4).map"), "The chatbot must keep a compact set of quick replies visible after the first answer");
assert.ok(chatbotComponent.includes("chatbot-extra-questions") && chatbotComponent.includes("aria-expanded={showMoreQuickQuestions}"), "The chatbot must expose additional quick replies through an accessible expand/collapse control");
const enquiryAnswer = getChatAnswer("Does the enquiry form send my details?");
assert.ok(enquiryAnswer.text.includes("shows a preview of the email on this page") && enquiryAnswer.text.includes("does not send your details to this website") && enquiryAnswer.text.includes("choose Open email app"), "Enquiry answers must accurately explain the review-first email workflow");
assert.ok(enquiryAnswer.text.includes("phone number is optional") && enquiryAnswer.text.includes("Do not include passwords"), "Enquiry answers must preserve voluntary phone and sensitive-data guidance");
assert.ok(chatbotComponent.includes("Can you confirm the CCNA course fee?"), "The chatbot must expose a fee-confirmation quick reply for conflicting source amounts");
const paymentAnswer = getChatAnswer("Can I pay for a course online?");
assert.ok(paymentAnswer.text.includes("does not process course payments") && paymentAnswer.text.includes("confirm the current payment instructions directly"), "Payment answers must explain that the rebuild has no checkout and direct visitors to AROUSH");
const ccnaFeeAnswer = getChatAnswer("Can you confirm the CCNA course fee?");
assert.ok(ccnaFeeAnswer.text.includes("show different fee amounts") && ccnaFeeAnswer.text.includes("withholds a numeric fee"), "CCNA fee answers must explain the source conflict and withhold an unconfirmed amount");
const devnetFeeAnswer = getChatAnswer("What is the CCNA DevNet fee?");
assert.ok(devnetFeeAnswer.text.includes("CCNA DevNet") && devnetFeeAnswer.text.includes("show different fee amounts"), "CCNA DevNet fee answers must explain the source conflict");

console.log(`Chatbot rule tests passed: ${cases.length + 1} intent-routing cases, including service-specific links, AI/ML and Agentic AI course outlines, payment-safety routing, verified outline-topic assertions, quick replies, SOC/SIEM, pricing, privacy and unknown-question handoff.`);
