import assert from "node:assert/strict";
import { inspectExternalLinks } from "./external-link-policy.mjs";

function issuesFor(source) {
  return inspectExternalLinks(source, "test-fixture").issues;
}

assert.deepEqual(issuesFor('const link = "https://aroushtech.in/contact";'), []);
assert.deepEqual(issuesFor('const link = "//aroushtech.in/contact";'), []);
assert.match(issuesFor('const link = "http://aroushtech.in/contact";').join("\n"), /must use HTTPS/);
assert.match(issuesFor('const link = "https://unknown-example.test/path";').join("\n"), /needs review/);
assert.match(issuesFor('const link = "//unknown-example.test/path";').join("\n"), /needs review/);
assert.match(issuesFor('const link = "https://homelabfabric.com/path";').join("\n"), /live WordPress footer/);
assert.match(
  issuesFor('const checkout = "https://demosites.royal-elementor-addons.com/checkout";').join("\n"),
  /unverified third-party checkout host.*owner approval is required/,
);
assert.match(issuesFor('const label = "bettilt";').join("\n"), /gambling\/spam anchor phrase/);
assert.deepEqual(issuesFor('const contact = "mailto:team@example.test"; const phone = "tel:+911234567890";'), []);

console.log("External-link policy tests passed: HTTPS allowlist, HTTP rejection, protocol-relative URLs, unknown hosts, known spam domains, the unverified third-party checkout host, spam anchor text and mailto/tel handling.");
