const approvedHosts = new Set([
  "aroushtech.in",
  "in.linkedin.com",
  "www.google.com",
  "policies.google.com",
  "support.google.com",
  "www.meity.gov.in",
  "www.googletagmanager.com",
  "schema.org",
  "aroush.invalid", // Test-only URL used by the analytics policy unit tests.
]);

// These domains were visible as unrelated outbound links in the live WordPress footer.
const knownSpamHosts = new Set([
  "homelabfabric.com",
  "www.yigithidrolik.com",
  "locksmithintelaviv.com",
  "lotusdermatoloji.com",
  "breakoutfinder.com",
  "homezo.net",
  "www.caobaparis.com",
  "hbgstampede.com",
  "ormanistanbul.com",
  "zurichberg.com",
  "www.athenaiss.com",
  "shopharbourroad.com",
  "nationpacksla.com",
  "hopscotchfriday.com",
  "www.jailbreakwizard.net",
  "akidshaircompany.com",
]);

const spamAnchorPattern = /\b(?:bettilt|pinup|pinco|bahsegel|paribahis|casino(?:m)?u?hub|casinomub|rokubet|slotbey|casino\s+siteleri|bahis\s+siteleri)\b/i;

// The live AROUSH course pages currently expose a Buy Course link to this
// third-party demo domain. It has not been verified by the owner, so it must
// stay blocked even if someone later adds it to the general host allowlist.
const unverifiedCheckoutHosts = new Set([
  "demosites.royal-elementor-addons.com",
]);

// Match HTTPS, HTTP and protocol-relative URLs. HTTP is detected so it can be
// rejected instead of silently escaping the HTTPS-only allowlist.
const urlPattern = /(?<!\\)(?:https?:\/\/|\/\/)[a-z0-9.-]+(?::\d+)?(?:\/[^\s"'`<>)]*)?/gi;

export function inspectExternalLinks(source, relativePath = "source") {
  const issues = [];
  const checkedHosts = new Set();

  if (spamAnchorPattern.test(source)) {
    issues.push(`${relativePath}: contains a known gambling/spam anchor phrase`);
  }

  for (const match of source.matchAll(urlPattern)) {
    const rawUrl = match[0];
    const normalizedUrl = rawUrl.startsWith("//") ? `https:${rawUrl}` : rawUrl;
    let parsed;

    try {
      parsed = new URL(normalizedUrl);
    } catch {
      issues.push(`${relativePath}: contains an invalid external URL (${rawUrl})`);
      continue;
    }

    const hostname = parsed.hostname.toLowerCase();
    checkedHosts.add(hostname);

    if (parsed.protocol !== "https:") {
      issues.push(`${relativePath}: external URL must use HTTPS (${rawUrl})`);
    } else if (unverifiedCheckoutHosts.has(hostname)) {
      issues.push(`${relativePath}: contains an unverified third-party checkout host observed on an AROUSH course page (${hostname}); owner approval is required before use`);
    } else if (knownSpamHosts.has(hostname)) {
      issues.push(`${relativePath}: contains a domain observed in the live WordPress footer (${hostname})`);
    } else if (!approvedHosts.has(hostname)) {
      issues.push(`${relativePath}: external host needs review and explicit approval (${hostname})`);
    }
  }

  return { issues, checkedHosts };
}
