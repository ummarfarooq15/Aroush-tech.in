# AROUSH Tech website rebuild

A responsive public website rebuild for **AROUSH SOLUTIONS (OPC) PRIVATE LIMITED**. The project uses Next.js 15.5.29, React 19.3.1, TypeScript and plain CSS. It is organised into small pages and reusable components so a developer or intern can understand and maintain it without a large framework stack.

## Start here

If you are new to the project, read [`docs/BEGINNER-DEVELOPER-GUIDE.md`](docs/BEGINNER-DEVELOPER-GUIDE.md) first. It explains the folders and shows exactly where to edit company details, services, courses, team members and pages.

## Included pages

- `/` — Home
- `/about` — Company, mission, vision and approach
- `/services` — Ten service areas from the 2026 company profile
- `/courses` — Twenty courses from the public catalogue with keyword/category filters, natural A–Z / Z–A sorting, an outline-availability filter, shareable search/filter URLs and an in-browser comparison table for up to three courses
- `/faqs` — Searchable verified answers about courses, training formats, fees, locations, enquiries and service scope
- `/learning-paths` — Goal-based collections across the public catalogue; not prerequisite sequences
- `/courses/[slug]` — Individual course details
- `/training` — Corporate and campus training, including six SOC/SIEM learning paths
- `/team` — Three team profiles from the public About page
- `/gallery` — Training and learner photographs from the public gallery
- `/contact` — Public contact details with separate learner, business/institution and general enquiry paths; the form prepares an email draft on the visitor's device
- `/privacy` — Draft privacy notice and analytics preference information

All interior routes include accessible breadcrumbs with matching `BreadcrumbList` structured data; the homepage remains the root entry point. The site and individual course pages also generate branded 1200 × 630 Open Graph and X/Twitter preview cards from verified company and catalogue content.

The site also includes a custom 404 page, robots file, sitemap, metadata, structured data and permanent redirects for the legacy About, Contact, Team and course URLs.

## Run locally or in GitHub Codespaces

Requirements: Node.js 24 LTS and npm. As of 7 November 2026, the official Node.js release page lists v24.22.2 as the latest 24.x maintenance-LTS release. The project pins Next.js 15.5.29 and React 19.3.1; Next.js 15.5.29 is the 3 November 2026 security-fix release on the 15.x line. The lockfile and full npm audit are still pending.

```bash
npm install
# Review and commit the generated package-lock.json before CI use
npm run check:offline  # Run offline source checks; TS syntax uses local/global TypeScript
npm run check          # Run offline validators, then the full TypeScript typecheck
npm run dev
```

Open `http://localhost:3000` locally. In Codespaces, open the forwarded port 3000 from the **Ports** tab.

## Useful commands

```bash
npm run validate:content  # Check key content and route coverage
npm run validate:privacy  # Check consent, analytics and lead-privacy safeguards
npm run validate:visitor-intelligence # Check aggregate analytics, OTP, Turnstile and lead-storage safeguards
npm run validate:analytics-policy # Test opt-in gating and query-safe analytics payloads
npm run validate:brand    # Check approved logo assets and responsive placements
npm run validate:ux       # Check chatbot, course discovery and enquiry safeguards
npm run validate:accessibility # Check image alternatives, labelled controls, keyboard and motion safeguards
npm run validate:links    # Check internal routes, course links and redirects
npm run validate:breadcrumbs # Check visible breadcrumb trails and BreadcrumbList structured data
npm run validate:social-cards # Check branded Open Graph/X cards and verified course data
npm run test:external-link-policy # Test HTTPS-only, host allowlist and spam detection rules
npm run validate:external-links # Check HTTPS-only external URLs, reviewed hosts and known SEO-spam domains
npm run validate:public-claims # Block unapproved placement, hiring, top-rated and monitoring promises
npm run validate:learning-paths # Check goal-based course collections
npm run validate:faqs         # Check verified FAQ answers and route connections
npm run validate:faq-search   # Test FAQ question/answer search, category filters and empty-state recovery
npm run validate:course-sort  # Test natural A–Z / Z–A sorting, visible ranks and source-order preservation
npm run validate:course-outline-filter # Test published-outline and owner-confirmation filters
npm run validate:course-catalogue-url # Test shareable search, category, sort and outline-filter URLs
npm run validate:course-compare # Test local-only course comparison, selection limits and fee-conflict handling
npm run validate:enquiry-paths # Test learner/business/general routes and local email-draft behavior
npm run validate:chatbot      # Test chatbot intent routing without dependencies
npm run validate:javascript  # Syntax-check project .js and .mjs files
npm run validate:typescript-syntax # Parse .ts/.tsx/.mts/.cts files; syntax only
npm run validate:release-config # Check Node, lint, scripts and GA4 defaults
npm run preflight:release # Report actual Node, lockfile and installed dependency blockers
npm run typecheck         # Check TypeScript types
npm run lint              # Run ESLint directly (Next.js 15.5 deprecates next lint)
npm run build             # Create a production build
npm run audit             # Check installed dependency advisories
npm run check:offline     # Run offline content, privacy, accessibility, UX, FAQ, link-policy and syntax checks
npm run check             # Run offline checks, then full TypeScript typechecking
```

## Content and source rules

- The current public website is the primary source for published company, contact, course and gallery information.
- The 2026 company profile and brochure are supporting sources for expanded services, corporate training and SOC/SIEM learning paths.
- Conflicting or unverified details are documented for owner review. Do not invent facts, prices, credentials, service availability or guarantees.
- Published catalogue prices are references, not final quotes. CCNA and CCNA DevNet fees are withheld because their individual course pages list a different amount from the catalogue.
- CEH and Fortinet long-form details are withheld pending AROUSH-approved copy because the legacy pages contain trainer/course material attributed to other providers.
- Office map links search the published street address instead of using unverified coordinate pins; the J.P. Nagar training-centre venue must still be confirmed separately.

## Important live-source security finding — owner action required

Repeated public crawls on 6 November 2026 exposed the same 16 unrelated gambling/betting footer links on the current WordPress homepage; the latest recheck still showed them. This is consistent with possible SEO-spam injection, but the crawl alone does not prove the entry point or full compromise. The rebuilt source excludes those links and now includes an external-host allowlist validator. Before any migration or domain cutover, the authorised WordPress/hosting administrator must investigate the database, theme, plugins, accounts, filesystem, logs and Search Console. See [`docs/WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md`](docs/WORDPRESS-SEO-SPAM-INCIDENT-REVIEW-2026-11-06.md). No live cleanup was performed by this project.

## Important limitations

- The contact form has learner, business/institution and general paths. It prepares a `mailto:` draft on the visitor's device; it does not save leads or send data to a backend. Phone, organisation, team size and course name remain optional.
- The approved AROUSH logo is stored locally, including the unchanged original 4096 × 4096 artwork, a full-lockup derivative and an emblem-only derivative for compact placements. Team portraits and gallery photos still load from the existing AROUSH website; confirm image rights and move approved originals into `public/` before production migration.
- Optional GA4 is disabled by default. It loads only after an explicit visitor opt-in and an owner-configured Measurement ID; see `docs/VISITOR-ANALYTICS-AND-LEADS.md`.
- The root marketing website has no CMS, LMS, server-side lead database, authentication, payment processing or CRM integration. The separate visitor-intelligence companion app has its own approved development-only Supabase lead database and admin authentication.
- No GitHub push, WordPress modification, DNS change or production deployment has been performed.

## Design and competitor review

The homepage includes an original illustrative cybersecurity training image at `public/images/aroush-cybersecurity-training.webp`. It is generated artwork, not a photograph of AROUSH staff or premises. See [`docs/GENERATED-IMAGE-NOTE.md`](docs/GENERATED-IMAGE-NOTE.md).

The latest public UX benchmark and recommendations for Apna College, i-Medita and PyNet Labs are documented in [`docs/COMPETITOR-REVIEW-2026-11-07-SESSION-48.md`](docs/COMPETITOR-REVIEW-2026-11-07-SESSION-48.md), with earlier reviews retained for history. Their claims and marketing statistics have not been copied into AROUSH pages.

## Latest maintenance report

Session 48 refreshes the official AROUSH source review, adds verified team/mission/gallery/office answers and quick replies to the website chatbot, and expands regression coverage. The complete offline suite passes. Semantic typechecking, production builds, provider/database tests and browser QA remain blocked by the Node 22 / missing-dependency environment. See `docs/SESSION-48-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION48.md`, `docs/VALIDATION-REPORT-2026-11-07-SESSION48.md` and `docs/COMPETITOR-REVIEW-2026-11-07-SESSION-48.md`.

Session 43 extends the shareable course catalogue so a link can restore a comparison of up to three known courses and open the comparison table automatically. The `compare` URL parameter is allowlisted against current catalogue slugs, deduplicated and limited to three entries. Search, category, sort and outline filters remain shareable alongside the comparison. The `compare` parameter contains course slugs only; search text remains capped at 100 characters and the page warns that URL values may appear in browser history and routine server logs. No browser storage, backend, database, CRM or analytics event is added. See `docs/SESSION-43-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION43.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION43.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION43.md`.

Session 42 improves the Session 41 shareable course catalogue for phones: supported browsers use the native share sheet, unsupported browsers fall back to clipboard copy, and a cancelled share does not unexpectedly copy. Search terms are capped at 100 characters, and the UI warns that searches appear in the URL. No backend, storage or analytics event was added. See `docs/SESSION-42-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION42.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION42.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION42.md`.

Session 41 added shareable course-catalogue URLs for keyword search, category, sort and outline-availability filters. Visitors can share the filtered view and restore it by opening the link; unrelated query parameters are preserved. See `docs/SESSION-41-REPORT.md` and the Session 41 source/competitor/validation reports.

Session 40 adds a course-outline availability filter that separates published AROUSH outline topics from courses requiring owner confirmation, including provider-attribution holds. The new validator covers 17 assertions and is part of the 22-validator offline suite. See `docs/SESSION-40-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION40.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION40.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION40.md`.

Session 39 fixes query-driven enquiry-form state synchronisation, keeps unrelated visitor-entered fields when switching enquiry paths, clears stale prepared-email fallback links after edits, and sanitises email-draft subject/single-line fields against CR/LF/control-character injection. The new enquiry-safety validator covers 19 cases; enquiry-route validation covers 33 assertions. See `docs/SESSION-39-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION39.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION39.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION39.md`.

Session 38 adds distinct learner, business/institution and general enquiry routes. Course and learning-path links preselect the learner route; corporate training and service links preselect the business route. The email draft identifies the enquiry type and includes only details the visitor chooses to provide. No server endpoint, database, CRM or analytics event was added. See `docs/SESSION-38-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION38.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION38.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION38.md`.

Session 37 adds an accessible, browser-only course comparison tray for up to three courses. Visitors can compare category, outline availability, source-published duration and catalogue fee/confirmation status. CCNA and CCNA DevNet fees remain withheld because the catalogue lists ₹19,999 while the individual detail pages list ₹19,000. Comparison selections are not stored, transmitted or tracked. The current official AROUSH pages and competitor UX references were refreshed. See `docs/SESSION-37-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION37.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION39.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION37.md`.

Session 36 refines the course catalogue sort behavior: alphabetical sorting now uses natural numeric ordering, visible card numbers follow the current filtered/sorted result order, and the live result announcement states the active sort. It also refreshes the public AROUSH and competitor UX review. See `docs/SESSION-36-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION36.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION36.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION36.md`.

Session 35 adds A–Z and Z–A course sorting while preserving the source catalogue order by default, and refreshes the official-source and competitor reviews. See `docs/SESSION-35-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION35.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION35.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION35.md`.

Session 34 adds a searchable FAQ browser with question/answer search, topic filters, a live result count and a Contact handoff when no answer matches. See `docs/SESSION-34-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION34.md`, `docs/COMPETITOR-REVIEW-2026-11-07-SESSION34.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION34.md`.

Session 33 adds a dedicated, grouped FAQ page, links it from navigation/footer/contact and the sitemap, adds a verified FAQ chatbot quick reply, and keeps the contact page FAQ shortlist focused on practical enquiry questions. See `docs/SESSION-33-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION33.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION33.md`.

Session 32 keeps chatbot quick replies available after an answer, adds an accessible expand/collapse list, returns keyboard focus to the mobile menu toggle after route changes, and makes the 404 page a useful recovery path. It also reopens the official AROUSH pages and refreshes competitor UX notes. See `docs/SESSION-32-REPORT.md`, `docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION32.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION32.md`.

Session 31 adds clearer enquiry privacy guidance, mobile-friendly email/telephone entry, and an FAQ/chatbot explanation of the email-draft workflow. It warns visitors not to include credentials or sensitive production logs. See `docs/SESSION-31-REPORT.md` and `docs/VALIDATION-REPORT-2026-11-07-SESSION31.md`.


See [`docs/SESSION-30-REPORT.md`](docs/SESSION-30-REPORT.md) for the current course-fee conflict handling, CEH provider-attribution review, safer office map links and fresh official-source checks. See [`docs/SESSION-29-REPORT.md`](docs/SESSION-29-REPORT.md) for payment-link safeguards. See [`docs/SESSION-28-REPORT.md`](docs/SESSION-28-REPORT.md) for the two new Agentic AI chatbot outline answers, quick replies, current source review and the checkout-link verification item. See [`docs/SESSION-27-REPORT.md`](docs/SESSION-27-REPORT.md) for course-outline status labels, direct chatbot service links and the AI & ML duration answer. See [`docs/SESSION-26-REPORT.md`](docs/SESSION-26-REPORT.md) for the TypeScript syntax validator and previous source review. See [`docs/SESSION-25-REPORT.md`](docs/SESSION-25-REPORT.md) for the accessibility source validator and previous live-source/competitor recheck. See [`docs/SESSION-24-REPORT.md`](docs/SESSION-24-REPORT.md) for the external-link policy tests and release preflight. See [`docs/SESSION-23-REPORT.md`](docs/SESSION-23-REPORT.md) for the public-claim validator and accessible course-filter relationships. See [`docs/SESSION-22-REPORT.md`](docs/SESSION-22-REPORT.md) for the initial live WordPress SEO-spam finding and external-host allowlist validator. See [`docs/SESSION-21-REPORT.md`](docs/SESSION-21-REPORT.md) for the offline validation workflow, direct ESLint CLI migration and refreshed source/competitor review. See [`docs/SESSION-20-REPORT.md`](docs/SESSION-20-REPORT.md) for the testable analytics policy, query-safe page-view payloads and previous validation status. See [`docs/SESSION-19-REPORT.md`](docs/SESSION-19-REPORT.md) for the privacy-settings consent-preservation fix and consistent course-fee caution labels. See [`docs/SESSION-18-REPORT.md`](docs/SESSION-18-REPORT.md) for chatbot intent routing and mobile accessibility. Earlier work is recorded in the Session 17, 16 and 15 reports.

## Before launch

1. Complete [`docs/OWNER-APPROVAL-CHECKLIST.md`](docs/OWNER-APPROVAL-CHECKLIST.md).
2. Review [`docs/SOURCE-REGISTER.md`](docs/SOURCE-REGISTER.md), [`docs/CONTENT-AUDIT.md`](docs/CONTENT-AUDIT.md), and the latest [`docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION34.md`](docs/LIVE-SOURCE-REVIEW-2026-11-07-SESSION34.md), alongside the earlier session reviews retained for history.
3. Complete the live WordPress SEO-spam investigation and obtain owner/host remediation confirmation before migration or domain cutover.
4. Resolve the CCNA/CCNA DevNet fee conflicts and approve the CEH/Fortinet syllabus content before publishing those details.
5. Install dependencies, run all checks and test all routes in a staging browser at mobile, tablet and desktop sizes.
6. Obtain explicit owner approval before changing the live website or DNS.

## Website assistant

A rule-based FAQ assistant is included with contextual links for courses, CCNA, AI & ML, both published Agentic AI outlines, fees, schedules, corporate training, SOC/SIEM, the dedicated FAQ page and numbered service sections. It gives the published 40-hour AI & ML duration only when asked about that course; the Agentic AI pages do not state a duration, so visitors are directed to confirm it with the team. Unknown questions are routed to the human team. Read `docs/CHATBOT-NOTE.md` for its scope and editing instructions. It is not connected to a live AI service or CRM.


## Course payment safety

This rebuild does not provide online course checkout. Course pages show enquiry actions only and ask visitors to confirm payment instructions directly with AROUSH. The external-link security policy explicitly blocks the unverified third-party checkout host observed on multiple live course pages. Do not add a payment link or payment provider until the owner confirms merchant ownership, payment processing, privacy/data handling, refund terms and authorisation.

## Companion visitor-intelligence service

The separately deployable full visitor-intelligence app is staged under `apps/visitor-intelligence/`. The owner explicitly approved its development scope on 7 November 2026, including aggregate analytics, voluntary email/SMS OTP verification, Supabase lead storage and an admin dashboard. It has its own Node 24 runtime and deployment lifecycle; it is not part of the primary website build, is not connected to the live website and has not been deployed. Review `docs/security/VISITOR_INTELLIGENCE_INTEGRATION_REVIEW.md` and clear every production blocker before connecting or deploying it. Deployment still requires separate explicit approval.
