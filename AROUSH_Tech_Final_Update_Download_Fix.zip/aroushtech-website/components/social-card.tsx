type SocialCardProps = {
  eyebrow: string;
  title: string;
  description: string;
  category?: string;
};

/**
 * Shared social preview artwork for Open Graph and X cards.
 * Keep the content limited to verified AROUSH brand and course information.
 */
export function SocialCard({
  eyebrow,
  title,
  description,
  category,
}: SocialCardProps) {
  const titleSize = title.length > 34 ? 54 : title.length > 24 ? 62 : 72;

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        position: "relative",
        overflow: "hidden",
        padding: 64,
        background: "linear-gradient(135deg, #071a2b 0%, #0b2b40 58%, #123f50 100%)",
        color: "#f7fbfd",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <div
        style={{
          position: "absolute",
          right: -115,
          top: -165,
          width: 520,
          height: 520,
          borderRadius: 260,
          background: "linear-gradient(135deg, #1d9b9b, #176079)",
          opacity: 0.3,
        }}
      />
      <div
        style={{
          position: "absolute",
          right: 95,
          bottom: -260,
          width: 430,
          height: 430,
          borderRadius: 215,
          border: "2px solid rgba(125, 220, 210, 0.2)",
        }}
      />

      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          position: "relative",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
          <span
            style={{
              fontSize: 27,
              fontWeight: 800,
              letterSpacing: 3,
              color: "#ffffff",
            }}
          >
            AROUSH TECH
          </span>
          <span style={{ fontSize: 15, color: "#b7cbd5", letterSpacing: 1 }}>
            AROUSH SOLUTIONS (OPC) PRIVATE LIMITED
          </span>
        </div>
        <span
          style={{
            padding: "12px 18px",
            borderRadius: 999,
            border: "1px solid #39798a",
            background: "rgba(13, 62, 78, 0.85)",
            color: "#bdf0e9",
            fontSize: 15,
            fontWeight: 700,
            letterSpacing: 1,
          }}
        >
          BENGALURU · INDIA
        </span>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          maxWidth: 1000,
          position: "relative",
          marginTop: 35,
        }}
      >
        <span
          style={{
            color: "#78ddd1",
            fontSize: 19,
            fontWeight: 700,
            letterSpacing: 2.5,
          }}
        >
          {eyebrow.toUpperCase()}
        </span>
        {category ? (
          <span
            style={{
              alignSelf: "flex-start",
              marginTop: 12,
              padding: "7px 13px",
              borderRadius: 999,
              background: "rgba(255,255,255,0.1)",
              color: "#d6e9ee",
              fontSize: 17,
            }}
          >
            {category}
          </span>
        ) : null}
        <span
          style={{
            marginTop: category ? 14 : 22,
            fontSize: titleSize,
            fontWeight: 800,
            lineHeight: 1.08,
            letterSpacing: -1.5,
            color: "#ffffff",
          }}
        >
          {title}
        </span>
        <span
          style={{
            marginTop: 22,
            fontSize: 25,
            lineHeight: 1.35,
            color: "#c3d4dd",
            maxWidth: 940,
          }}
        >
          {description}
        </span>
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          position: "relative",
          borderTop: "1px solid rgba(185, 218, 226, 0.25)",
          paddingTop: 20,
        }}
      >
        <span
          style={{
            color: "#a8c0cc",
            fontSize: 17,
            fontWeight: 700,
            letterSpacing: 2,
          }}
        >
          CONNECT · SECURE · SUPPORT · TRAIN
        </span>
        <span style={{ color: "#83e0d5", fontSize: 19, fontWeight: 700 }}>
          aroushtech.in ↗
        </span>
      </div>
    </div>
  );
}
