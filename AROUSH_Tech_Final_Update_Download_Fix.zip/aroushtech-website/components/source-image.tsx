"use client";

import { useState } from "react";

type SourceImageProps = {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
  priority?: boolean;
};

/**
 * Remote images currently come from the existing AROUSH WordPress media library.
 * If a source image is unavailable, render a deliberate fallback instead of a
 * broken-image icon or an empty layout.
 */
export function SourceImage({
  src,
  alt,
  className,
  fallbackLabel = "Image unavailable",
  priority = false,
}: SourceImageProps) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className={`source-image-fallback${className ? ` ${className}` : ""}`} role="img" aria-label={alt}>
        <span>{fallbackLabel}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className={className}
      loading={priority ? "eager" : "lazy"}
      decoding="async"
      fetchPriority={priority ? "high" : "auto"}
      onError={() => setFailed(true)}
    />
  );
}
