"use client";

import { useEffect, useState, type FormEvent } from "react";
import { company } from "@/lib/content";
import {
  buildEnquiryEmail,
  defaultInterestForType,
  normalizeEnquiryType,
  type EnquiryType,
} from "@/lib/enquiry-path.mjs";

type ContactFormProps = {
  initialCourse?: string;
  initialInterest?: string;
  initialType?: string;
};

function courseEnquiryMessage(courseName: string) {
  return courseName
    ? `I am interested in ${courseName}. Please share the current syllabus, prerequisites, schedule, delivery format and fees.`
    : "";
}

const interestOptions = [
  "General enquiry",
  "Cybersecurity consulting",
  "Network infrastructure",
  "Technical support",
  "Corporate / campus training",
  "Curriculum & lab development",
  "Train-the-trainer",
  "Individual course enquiry",
  "SOC / SIEM training",
  "SOC / SIEM consulting",
  "Other",
];

/**
 * This form prepares an email on the visitor's device.
 * It does not save or send personal information to a website server.
 */
export function ContactForm({
  initialCourse,
  initialInterest,
  initialType,
}: ContactFormProps) {
  const courseName = initialCourse?.trim().slice(0, 120) ?? "";
  const initialEnquiryType = normalizeEnquiryType(initialType, Boolean(courseName));
  const initialInterestValue =
    initialInterest && interestOptions.includes(initialInterest)
      ? initialInterest
      : defaultInterestForType(initialEnquiryType);

  const [enquiryType, setEnquiryType] = useState<EnquiryType>(initialEnquiryType);
  const [interest, setInterest] = useState(initialInterestValue);
  const [course, setCourse] = useState(courseName);
  const [message, setMessage] = useState(() => courseEnquiryMessage(courseName));
  const [preparedEmail, setPreparedEmail] = useState<{ mailto: string; subject: string; body: string } | null>(null);

  // Keep query-driven enquiry cards in sync when the visitor changes route
  // without resetting the name, email or other details they already entered.
  useEffect(() => {
    setEnquiryType(initialEnquiryType);
    setInterest(initialInterestValue);
    setPreparedEmail(null);
  }, [initialEnquiryType, initialInterestValue]);

  // Course links can change while the contact page remains mounted. Update
  // only the course-specific fields when that query value changes.
  useEffect(() => {
    setCourse(courseName);
    setMessage(courseEnquiryMessage(courseName));
    setPreparedEmail(null);
  }, [courseName]);

  function handleEnquiryTypeChange(value: string) {
    if (value !== "learner" && value !== "business" && value !== "general") {
      return;
    }

    setEnquiryType(value);
    setInterest(defaultInterestForType(value));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const form = new FormData(event.currentTarget);
    const name = String(form.get("name") || "").trim();
    const email = String(form.get("email") || "").trim();
    const organization = String(form.get("organization") || "").trim();
    const teamSize = String(form.get("teamSize") || "").trim();
    const phone = String(form.get("phone") || "").trim();
    const course = String(form.get("course") || "").trim();
    const message = String(form.get("message") || "").trim();

    const emailDraft = buildEnquiryEmail({
      type: enquiryType,
      interest,
      name,
      email,
      phone,
      organization,
      teamSize,
      course,
      message,
    });
    const subject = encodeURIComponent(emailDraft.subject);
    const body = encodeURIComponent(emailDraft.body);
    const mailto = `mailto:${company.email}?subject=${subject}&body=${body}`;

    // Show the exact email first. The visitor chooses when to open their email app.
    setPreparedEmail({
      mailto,
      subject: emailDraft.subject,
      body: emailDraft.body,
    });
  }

  return (
    <form className="contact-form" aria-label="AROUSH enquiry form" onSubmit={handleSubmit} onChange={() => setPreparedEmail(null)}>
      <label>
        I am enquiring as
        <select
          name="enquiryType"
          value={enquiryType}
          onChange={(event) => handleEnquiryTypeChange(event.target.value)}
          required
        >
          <option value="learner">An individual learner</option>
          <option value="business">A business, college or institution</option>
          <option value="general">A general enquiry</option>
        </select>
      </label>

      <div className="form-grid">
        <label>
          Your name
          <input
            name="name"
            required
            maxLength={100}
            placeholder="Full name"
            autoComplete="name"
            autoCapitalize="words"
          />
        </label>
        <label>
          Email address
          <input
            name="email"
            type="email"
            required
            maxLength={254}
            placeholder="you@company.com"
            autoComplete="email"
            autoCapitalize="none"
            autoCorrect="off"
          />
        </label>
      </div>

      <div className="form-grid">
        <label>
          Phone number <span className="optional">(optional)</span>
          <input
            name="phone"
            type="tel"
            maxLength={30}
            autoComplete="tel"
            inputMode="tel"
            placeholder="Your phone number"
            aria-describedby="phone-privacy-note"
          />
          <small id="phone-privacy-note" className="field-help">
            Share a number only if you want the team to contact you by phone. It
            is included in the email you choose to send.
          </small>
        </label>

        {enquiryType === "learner" ? (
          <label>
            Course you are interested in <span className="optional">(optional)</span>
            <input
              name="course"
              maxLength={120}
              value={course}
              onChange={(event) => setCourse(event.target.value)}
              placeholder="Course name, if known"
            />
          </label>
        ) : null}

        {enquiryType === "business" ? (
          <>
            <label>
              Organization <span className="optional">(optional)</span>
              <input
                name="organization"
                maxLength={120}
                placeholder="Company or institution"
                autoComplete="organization"
              />
            </label>
            <label>
              Approximate team size <span className="optional">(optional)</span>
              <select name="teamSize" defaultValue="">
                <option value="">Select if useful</option>
                <option value="1–10">1–10 people</option>
                <option value="11–50">11–50 people</option>
                <option value="51–200">51–200 people</option>
                <option value="201+">201+ people</option>
                <option value="To be discussed">To be discussed</option>
              </select>
            </label>
          </>
        ) : null}

        <label>
          What can we help with?
          <select
            name="interest"
            value={interest}
            onChange={(event) => setInterest(event.target.value)}
            required
          >
            {interestOptions.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        </label>
      </div>

      <label>
        {enquiryType === "business"
          ? "Tell us about your organisation's requirement"
          : enquiryType === "learner"
            ? "What would you like to learn?"
            : "Tell us how we can help"}
        <textarea
          name="message"
          required
          maxLength={3000}
          rows={5}
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          placeholder={
            enquiryType === "business"
              ? "Share the business context, team needs, technologies and preferred timeline."
              : enquiryType === "learner"
                ? "Share your current experience, learning goal and any course questions."
                : "Share your question or requirement."
          }
          aria-describedby="message-safety-note"
        />
        <small id="message-safety-note" className="field-help">
          Do not include passwords, API keys, access tokens, personal records or
          sensitive production logs. Share sensitive technical details only
          through a secure channel agreed with the AROUSH team.
        </small>
      </label>

      <button className="button" type="submit">
        Review email enquiry <span aria-hidden="true">→</span>
      </button>

      {preparedEmail ? (
        <section className="email-review" aria-labelledby="email-review-title" role="region">
          <div className="email-review-heading">
            <div>
              <p className="eyebrow">Before you send</p>
              <h3 id="email-review-title">Review your email draft</h3>
            </div>
            <span className="email-review-status">Not sent</span>
          </div>
          <dl className="email-review-meta">
            <div><dt>To</dt><dd>{company.email}</dd></div>
            <div><dt>Subject</dt><dd>{preparedEmail.subject}</dd></div>
          </dl>
          <pre className="email-review-body">{preparedEmail.body}</pre>
          <p className="email-review-note" role="status" aria-live="polite">
            This preview stays in this page only. The website does not submit or
            store it. Nothing is sent until you choose to open your email app and
            send the message there.
          </p>
          <div className="email-review-actions">
            <a className="button" href={preparedEmail.mailto}>
              Open email app <span aria-hidden="true">↗</span>
            </a>
            <button className="email-review-edit" type="button" onClick={() => setPreparedEmail(null)}>
              Edit enquiry
            </button>
          </div>
        </section>
      ) : (
        <p className="form-note">
          This form prepares an email draft on your device for review. Your
          details are not submitted to or stored on this website. Phone number
          is optional and is included only if you choose to provide it. Nothing
          is sent until you choose to open your email app and send the message.
        </p>
      )}
    </form>
  );
}
