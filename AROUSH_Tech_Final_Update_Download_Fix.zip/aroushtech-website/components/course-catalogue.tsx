"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { courses } from "@/lib/content";
import { CoursePrice } from "@/components/course-price";
import { courseDetails } from "@/lib/course-details";
import { sortCourses, type CourseSortOrder } from "@/lib/course-sort.mjs";
import { filterCoursesByOutline, hasPublishedOutline, type CourseOutlineFilter } from "@/lib/course-outline-filter.mjs";
import { toggleComparedCourse } from "@/lib/course-compare.mjs";
import { buildCourseCatalogueSearch, parseCourseCatalogueState } from "@/lib/course-catalogue-url.mjs";

type Course = (typeof courses)[number];

export function CourseCatalogue({ items }: { items: Course[] }) {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All courses");
  const [sortOrder, setSortOrder] = useState<CourseSortOrder>("featured");
  const [outlineFilter, setOutlineFilter] = useState<CourseOutlineFilter>("all");
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);
  const [showComparison, setShowComparison] = useState(false);
  const [urlReady, setUrlReady] = useState(false);
  const [shareStatus, setShareStatus] = useState("");
  const categories = useMemo(() => ["All courses", ...Array.from(new Set(items.map((item) => item.category)))], [items]);
  const courseSlugs = useMemo(() => items.map((item) => item.slug), [items]);

  useEffect(() => {
    function readCatalogueUrl() {
      const state = parseCourseCatalogueState(window.location.search, categories, courseSlugs);
      setQuery(state.query);
      setActiveCategory(state.category);
      setSortOrder(state.sortOrder);
      setOutlineFilter(state.outlineFilter);
      setSelectedForCompare(state.compareSlugs);
      setShowComparison(state.compareSlugs.length >= 2);
    }

    readCatalogueUrl();
    setUrlReady(true);
    window.addEventListener("popstate", readCatalogueUrl);
    return () => window.removeEventListener("popstate", readCatalogueUrl);
  }, [categories, courseSlugs]);

  useEffect(() => {
    if (!urlReady) return;

    const search = buildCourseCatalogueSearch(window.location.search, {
      query,
      category: activeCategory,
      sortOrder,
      outlineFilter,
      compareSlugs: selectedForCompare,
    }, categories, courseSlugs);
    const nextUrl = `${window.location.pathname}${search ? `?${search}` : ""}${window.location.hash}`;
    const currentUrl = `${window.location.pathname}${window.location.search}${window.location.hash}`;

    if (nextUrl !== currentUrl) {
      window.history.replaceState(window.history.state, "", nextUrl);
    }
  }, [urlReady, query, activeCategory, sortOrder, outlineFilter, selectedForCompare, categories, courseSlugs]);
  const filtered = useMemo(() => {
    const term = query.trim().toLowerCase();
    const matchingCourses = items.filter((course) => {
      const categoryMatches = activeCategory === "All courses" || course.category === activeCategory;
      const outlineText = courseDetails[course.slug]?.outline.join(" ") ?? "";
      const queryMatches = !term || `${course.title} ${course.category} ${course.description} ${outlineText}`.toLowerCase().includes(term);
      return categoryMatches && queryMatches;
    });

    const outlineFilteredCourses = filterCoursesByOutline(matchingCourses, courseDetails, outlineFilter);
    return sortCourses(outlineFilteredCourses, sortOrder);
  }, [items, query, activeCategory, sortOrder, outlineFilter]);

  const hasActiveFilters = Boolean(query.trim()) || activeCategory !== "All courses" || sortOrder !== "featured" || outlineFilter !== "all";
  const hasShareableView = hasActiveFilters || selectedForCompare.length > 0;
  const sortAnnouncement = sortOrder === "name-asc"
    ? "sorted A to Z"
    : sortOrder === "name-desc"
      ? "sorted Z to A"
      : "in AROUSH catalogue order";
  const visibleOutlineCount = filtered.filter((course) => hasPublishedOutline(courseDetails[course.slug])).length;
  const outlineAnnouncement = outlineFilter === "published"
    ? "with published outline topics"
    : outlineFilter === "confirm"
      ? "with outlines to confirm with AROUSH"
      : "across all outline statuses";
  const comparedCourses = selectedForCompare.flatMap((slug) => {
    const course = items.find((item) => item.slug === slug);
    return course ? [course] : [];
  });
  const compareLimitReached = selectedForCompare.length >= 3;

  function clearFilters() {
    setShareStatus("");
    setQuery("");
    setActiveCategory("All courses");
    setSortOrder("featured");
    setOutlineFilter("all");
  }

  async function shareFilteredLink() {
    const search = buildCourseCatalogueSearch(window.location.search, {
      query,
      category: activeCategory,
      sortOrder,
      outlineFilter,
      compareSlugs: selectedForCompare,
    }, categories, courseSlugs);
    const shareUrl = `${window.location.origin}${window.location.pathname}${search ? `?${search}` : ""}${window.location.hash}`;
    const sharingComparison = selectedForCompare.length >= 2;

    if (typeof navigator.share === "function") {
      try {
        await navigator.share({
          title: sharingComparison ? "AROUSH Tech course comparison" : "AROUSH Tech course catalogue",
          text: sharingComparison
            ? "Compare these selected courses using AROUSH Tech's published course information."
            : "Explore this course list from AROUSH Tech.",
          url: shareUrl,
        });
        setShareStatus("Course link shared.");
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") {
          setShareStatus("Sharing cancelled. Your filtered course list is unchanged.");
          return;
        }
      }
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      setShareStatus("Filtered course link copied.");
    } catch {
      setShareStatus("Sharing is unavailable in this browser. The filtered view remains in your address bar.");
    }
  }

  function toggleCompare(slug: string) {
    setShareStatus("");
    const nextSelection = toggleComparedCourse(selectedForCompare, slug, 3);
    setSelectedForCompare(nextSelection);
    if (nextSelection.length < 2) setShowComparison(false);
  }

  function clearComparison() {
    setShareStatus("");
    setSelectedForCompare([]);
    setShowComparison(false);
  }

  return <>
    <div className="catalogue-tools">
      <div className="catalogue-search-row">
        <label className="course-search">
          <span className="sr-only">Search the course catalogue</span>
          <input
            id="course-catalogue-search"
            type="search"
            value={query}
            onChange={(event) => { setShareStatus(""); setQuery(event.target.value); }}
            placeholder="Search courses, skills or technologies"
            aria-controls="course-results"
            aria-describedby="catalogue-count catalogue-url-note"
            maxLength={100}
          />
        </label>
        <label className="course-sort">
          <span>Sort courses</span>
          <select
            value={sortOrder}
            onChange={(event) => { setShareStatus(""); setSortOrder(event.target.value as CourseSortOrder); }}
            aria-controls="course-results"
          >
            <option value="featured">AROUSH catalogue order</option>
            <option value="name-asc">Name: A to Z</option>
            <option value="name-desc">Name: Z to A</option>
          </select>
        </label>
        <label className="course-outline-filter">
          <span>Outline availability</span>
          <select
            value={outlineFilter}
            onChange={(event) => { setShareStatus(""); setOutlineFilter(event.target.value as CourseOutlineFilter); }}
            aria-controls="course-results"
          >
            <option value="all">All outline statuses</option>
            <option value="published">Published outline topics</option>
            <option value="confirm">Ask AROUSH to confirm</option>
          </select>
        </label>
      </div>
      <div className="category-pills" role="group" aria-label="Filter courses by category" aria-controls="course-results">
        {categories.map((category) => <button key={category} type="button" className={activeCategory === category ? "active" : ""} aria-pressed={activeCategory === category} aria-controls="course-results" onClick={() => { setShareStatus(""); setActiveCategory(category); }}>{category}</button>)}
      </div>
    </div>
    <p id="catalogue-url-note" className="catalogue-url-note">Searches, filters and selected course comparisons appear in the page address so you can share this view. Search is limited to 100 characters. URLs may appear in browser history, copied links and routine server logs. Do not enter personal information in the course search.</p>
    <p id="course-compare-help" className="sr-only">Choose up to three courses to compare. A shared comparison link includes only course slugs, not personal information.</p>
    <div className="catalogue-result-row">
      <p id="catalogue-count" className="catalogue-count" role="status" aria-live="polite">Showing {filtered.length} of {items.length} courses, {sortAnnouncement}, {outlineAnnouncement} · {visibleOutlineCount} with published outline topics</p>
      {hasShareableView ? (
        <div className="catalogue-result-actions">
          <button type="button" className="catalogue-share-button" onClick={shareFilteredLink}>
            Share course view
          </button>
          <button type="button" className="catalogue-clear-button" onClick={clearFilters}>
            Reset search, filters and sort
          </button>
        </div>
      ) : null}
    </div>
    {shareStatus ? <p className="catalogue-share-status" role="status" aria-live="polite">{shareStatus}</p> : null}
    <div id="course-results">
      {filtered.length ? <div className="course-grid">{filtered.map((course, index) => {
        return <article className="course-card" key={course.title}>
          <div className="course-card-top"><span><span className="sr-only">Course </span>{String(index + 1).padStart(2, "0")}</span><span>{course.category}</span></div>
          <h3>{course.title}</h3><p>{course.description}</p>
          <div className="course-card-meta" role="group" aria-label="Course outline and duration information">
            <span className={`course-outline-badge${courseDetails[course.slug]?.outline.length ? " is-available" : " is-pending"}`}>
              {courseDetails[course.slug]?.outline.length ? "Published outline topics" : "AROUSH syllabus to confirm"}
            </span>
            {courseDetails[course.slug]?.duration ? (
              <span className="course-duration">{courseDetails[course.slug].duration}</span>
            ) : null}
          </div>
          <CoursePrice previousPrice={course.previousPrice} listedPrice={course.listedPrice} feeNote={course.feeNote} />
          <button
            type="button"
            className="course-compare-toggle"
            aria-pressed={selectedForCompare.includes(course.slug)}
            aria-describedby="course-compare-help"
            disabled={compareLimitReached && !selectedForCompare.includes(course.slug)}
            onClick={() => toggleCompare(course.slug)}
          >
            {selectedForCompare.includes(course.slug) ? "Remove from comparison" : "Add to comparison"}
          </button>
          <Link href={`/courses/${course.slug}`} className="arrow-link">View course details <span>↗</span></Link>
        </article>;
      })}</div> : <div className="empty-courses"><h3>No matching courses</h3><p>Try another search term or choose a different category.</p><button type="button" className="button button-outline" onClick={clearFilters}>Clear filters</button></div>}
    </div>
    {comparedCourses.length > 0 ? (
      <section className="course-compare-panel" aria-labelledby="course-compare-title">
        <div className="course-compare-heading">
          <div>
            <h3 id="course-compare-title">Compare courses</h3>
            <p>Choose up to three courses. You can share the comparison link; it contains only course slugs and selected catalogue filters.</p>
          </div>
          <span className="course-compare-count" role="status" aria-live="polite">{comparedCourses.length} of 3 selected</span>
        </div>
        <div className="course-compare-selected" aria-label="Selected courses">
          {comparedCourses.map((course) => (
            <span className="course-compare-chip" key={course.slug}>
              {course.title}
              <button type="button" aria-label={`Remove ${course.title} from comparison`} onClick={() => toggleCompare(course.slug)}>×</button>
            </span>
          ))}
        </div>
        <div className="course-compare-actions">
          <button type="button" className="button" disabled={comparedCourses.length < 2} onClick={() => setShowComparison((current) => !current)}>
            {showComparison ? "Hide comparison" : `Compare ${comparedCourses.length} courses`}
          </button>
          <button type="button" className="catalogue-clear-button" onClick={clearComparison}>Clear comparison</button>
        </div>
        {showComparison && comparedCourses.length >= 2 ? (
          <div className="course-compare-table-wrap">
            <table className="course-compare-table">
              <caption>Published course information. Confirm current fees, schedules and delivery details with AROUSH before enrolling.</caption>
              <thead>
                <tr>
                  <th scope="col">Course</th>
                  <th scope="col">Category</th>
                  <th scope="col">Outline</th>
                  <th scope="col">Duration</th>
                  <th scope="col">Catalogue fee</th>
                </tr>
              </thead>
              <tbody>
                {comparedCourses.map((course) => {
                  const details = courseDetails[course.slug];
                  const fee = course.feeNote
                    ? "Confirm with AROUSH"
                    : course.listedPrice
                      ? `₹${course.listedPrice}`
                      : "Ask AROUSH";
                  return (
                    <tr key={course.slug}>
                      <th scope="row"><Link href={`/courses/${course.slug}`}>{course.title}</Link></th>
                      <td>{course.category}</td>
                      <td>{details?.outline.length ? "Published" : "Not published"}</td>
                      <td>{details?.duration ?? "Not published"}</td>
                      <td>{fee}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : null}
      </section>
    ) : null}
  </>;
}
