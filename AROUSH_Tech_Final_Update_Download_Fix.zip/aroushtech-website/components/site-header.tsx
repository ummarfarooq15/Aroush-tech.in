import Link from "next/link";
import Image from "next/image";
import { PrimaryNavigation } from "@/components/primary-navigation";

const links = [
  { label: "About", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Courses", href: "/courses" },
  { label: "FAQs", href: "/faqs" },
  { label: "Training", href: "/training" },
  { label: "Team", href: "/team" },
  { label: "Gallery", href: "/gallery" },
  { label: "Contact", href: "/contact" },
];

export function SiteHeader() {
  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link href="/" className="brand" aria-label="Aroush Tech home">
          <Image
            src="/images/aroush-solutions-symbol.webp"
            alt=""
            className="brand-logo"
            width={64}
            height={64}
            priority
          />
          <span className="brand-wordmark">AROUSH <small>SOLUTIONS</small></span>
        </Link>

        <PrimaryNavigation links={links} />

        <Link className="button button-small header-cta" href="/contact">
          Talk to our team <span aria-hidden="true">↗</span>
        </Link>
      </div>
    </header>
  );
}
