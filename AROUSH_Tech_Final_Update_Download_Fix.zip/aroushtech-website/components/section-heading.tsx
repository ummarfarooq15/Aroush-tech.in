export function SectionHeading({ eyebrow, title, text, light = false }: { eyebrow: string; title: string; text?: string; light?: boolean }) {
  return <div className={`section-heading${light ? " section-heading-light" : ""}`}>
    <p className="eyebrow">{eyebrow}</p>
    <h2>{title}</h2>
    {text ? <p className="section-intro">{text}</p> : null}
  </div>;
}
