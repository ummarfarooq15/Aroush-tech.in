type CoursePriceProps = {
  previousPrice?: string;
  listedPrice?: string;
  feeNote?: string;
  detail?: boolean;
};

/** Shows a source-listed fee, or a confirmation note when official pages conflict. */
export function CoursePrice({
  previousPrice,
  listedPrice,
  feeNote,
  detail = false,
}: CoursePriceProps) {
  const className = `course-price${detail ? " course-detail-price" : ""}`;

  if (feeNote || !previousPrice || !listedPrice) {
    return (
      <div className={`${className} course-price-pending`}>
        <strong>Confirm current fee</strong>
        <small>
          {feeNote ?? "Please contact AROUSH to confirm the current fee before payment."}
        </small>
      </div>
    );
  }

  return (
    <div className={className}>
      <del>₹{previousPrice}</del>
      <strong>₹{listedPrice}</strong>
      <small>Website-listed amount; confirm current fee before payment</small>
    </div>
  );
}
