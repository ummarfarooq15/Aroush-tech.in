"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { getChatAnswer } from "@/lib/chatbot-rules.mjs";

type ChatMessage = {
  from: "bot" | "visitor";
  text: string;
  link?: { href: string; label: string };
};


const quickQuestions = [
  "Show me the courses",
  "What is the CCNA course about?",
  "Can you confirm the CCNA course fee?",
  "What does the AI & ML course cover?",
  "What does the LangGraph course cover?",
  "What does the Hugging Face course cover?",
  "Can I pay for a course online?",
  "Does the enquiry form send my details?",
  "Do you offer corporate training?",
  "Where can I find answers to common questions?",
  "How do I contact the team?",
  "Who is on the AROUSH team?",
  "What is AROUSH’s vision and mission?",
  "Where are the AROUSH offices?",
  "Show me the training gallery",
  "Is a free course demo available?",
];

export function SiteChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [showMoreQuickQuestions, setShowMoreQuickQuestions] = useState(false);
  const launcherRef = useRef<HTMLButtonElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const questionInputRef = useRef<HTMLInputElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const focusMessagesAfterReplyRef = useRef(false);
  const wasOpenRef = useRef(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      from: "bot",
      text: "Hello! I'm the AROUSH website assistant. Ask me about courses, CCNA, corporate training, services or contacting the team.",
      link: { href: "/courses", label: "Browse courses" },
    },
  ]);

  useEffect(() => {
    if (isOpen) {
      wasOpenRef.current = true;
      // On desktop, focus the question field. On touch-sized screens, focus
      // the close control instead so the on-screen keyboard stays closed.
      if (window.matchMedia("(min-width: 700px)").matches) {
        questionInputRef.current?.focus();
      } else {
        closeButtonRef.current?.focus();
      }

      function handleKeyDown(event: KeyboardEvent) {
        if (event.key === "Escape") setIsOpen(false);
      }

      document.addEventListener("keydown", handleKeyDown);
      return () => document.removeEventListener("keydown", handleKeyDown);
    }

    if (wasOpenRef.current) {
      launcherRef.current?.focus();
      wasOpenRef.current = false;
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) return;
    const messagePanel = messagesContainerRef.current;
    if (messagePanel) messagePanel.scrollTop = messagePanel.scrollHeight;
    if (focusMessagesAfterReplyRef.current) {
      messagePanel?.focus();
      focusMessagesAfterReplyRef.current = false;
    }
  }, [messages, isOpen]);

  function sendMessage(text: string, focusMessages = false) {
    const cleanText = text.trim().slice(0, 500);
    if (!cleanText) return;

    const answer = getChatAnswer(cleanText);
    focusMessagesAfterReplyRef.current = focusMessages;
    setMessages((current) => [
      ...current,
      { from: "visitor", text: cleanText },
      { from: "bot", ...answer },
    ]);
    setQuestion("");
  }

  return (
    <aside className="chatbot-widget" aria-label="AROUSH website assistant">
      {isOpen ? (
        <section
          id="aroush-chatbot-panel"
          className="chatbot-panel"
          aria-labelledby="aroush-chatbot-title"
          role="region"
        >
          <header className="chatbot-header">
            <div className="chatbot-brand">
              <Image
                src="/images/aroush-solutions-symbol.webp"
                alt=""
                width={48}
                height={48}
              />
              <div>
                <strong id="aroush-chatbot-title">Ask AROUSH</strong>
                <span>AROUSH Solutions · Website assistant</span>
              </div>
            </div>
            <button
              className="chatbot-close"
              type="button"
              onClick={() => setIsOpen(false)}
              aria-label="Close chat"
            >
              ×
            </button>
          </header>

          <div
            ref={messagesContainerRef}
            className="chatbot-messages"
            role="log"
            aria-live="polite"
            aria-relevant="additions"
            aria-label="Conversation"
            tabIndex={-1}
          >
            {messages.map((message, index) => (
              <div
                className={`chat-message-wrap ${message.from}`}
                key={`${index}-${message.from}`}
              >
                <p className={`chat-message ${message.from}`}>{message.text}</p>
                {message.from === "bot" && message.link ? (
                  <Link className="chat-message-link" href={message.link.href}>
                    {message.link.label} <span aria-hidden="true">↗</span>
                  </Link>
                ) : null}
              </div>
            ))}
          </div>

          <div className="chatbot-quick-questions" aria-label="Suggested questions">
            {quickQuestions.slice(0, 4).map((item) => (
              <button type="button" key={item} onClick={() => sendMessage(item, true)}>
                {item}
              </button>
            ))}
            <button
              type="button"
              className="chatbot-more-questions"
              aria-expanded={showMoreQuickQuestions}
              aria-controls="chatbot-extra-questions"
              aria-label={showMoreQuickQuestions ? "Show fewer suggested questions" : "Show more suggested questions"}
              onClick={() => setShowMoreQuickQuestions((current) => !current)}
            >
              {showMoreQuickQuestions ? "Fewer questions" : "More questions"}
            </button>
          </div>
          <div
            id="chatbot-extra-questions"
            className="chatbot-quick-questions chatbot-quick-questions-extra"
            aria-label="More suggested questions"
            hidden={!showMoreQuickQuestions}
          >
            {quickQuestions.slice(4).map((item) => (
              <button type="button" key={item} onClick={() => sendMessage(item, true)}>
                {item}
              </button>
            ))}
          </div>

          <form
            className="chatbot-form"
            onSubmit={(event) => {
              event.preventDefault();
              sendMessage(question);
            }}
          >
            <label className="sr-only" htmlFor="chatbot-question">
              Your question
            </label>
            <input
              ref={questionInputRef}
              id="chatbot-question"
              value={question}
              onChange={(event) => setQuestion(event.target.value)}
              placeholder="Ask a question..."
              autoComplete="off"
              maxLength={500}
              aria-describedby="chatbot-note"
            />
            <button
              type="submit"
              disabled={!question.trim()}
              aria-label="Send message"
            >
              Send
            </button>
          </form>
          <p className="chatbot-note" id="chatbot-note">
            Automated answers based on published information; not live human or AI support. For
            confirmation, <Link href="/contact">contact our team</Link>.
          </p>
        </section>
      ) : null}

      <button
        ref={launcherRef}
        className="chatbot-launcher"
        type="button"
        onClick={() => setIsOpen((open) => !open)}
        aria-expanded={isOpen}
        aria-controls={isOpen ? "aroush-chatbot-panel" : undefined}
        aria-label={isOpen ? "Close website assistant" : "Open website assistant"}
      >
        <span aria-hidden="true">{isOpen ? "×" : "✦"}</span>
        {isOpen ? "Close" : "Ask AROUSH"}
      </button>
    </aside>
  );
}
