import Link from "next/link";
import { company } from "@/lib/content";

type BreadcrumbItem = {
  label: string;
  href: string;
};

type BreadcrumbsProps = {
  items: BreadcrumbItem[];
  variant?: "light" | "dark";
};

/**
 * A small, accessible breadcrumb trail with matching search-engine data.
 * Pass only real pages from this website; the last item is the current page.
 */
export function Breadcrumbs({ items, variant = "light" }: BreadcrumbsProps) {
  if (items.length === 0) return null;

  const allItems: BreadcrumbItem[] = [
    { label: "Home", href: "/" },
    ...items,
  ];
  const breadcrumbStructuredData = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: allItems.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.label,
      item: new URL(item.href, company.website).toString(),
    })),
  };

  return (
    <>
      <nav className={`breadcrumbs breadcrumbs-${variant}`} aria-label="Breadcrumb">
        <ol>
          {allItems.map((item, index) => {
            const isCurrent = index === allItems.length - 1;

            return (
              <li key={`${item.href}-${item.label}`}>
                {isCurrent ? (
                  <span aria-current="page">{item.label}</span>
                ) : (
                  <Link href={item.href}>{item.label}</Link>
                )}
              </li>
            );
          })}
        </ol>
      </nav>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(breadcrumbStructuredData).replace(
            /</g,
            "\\u003c",
          ),
        }}
      />
    </>
  );
}
