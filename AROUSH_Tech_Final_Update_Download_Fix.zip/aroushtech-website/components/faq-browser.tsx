"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { filterFaqs, type FAQSearchItem } from "@/lib/faq-search.mjs";

const ALL_CATEGORIES = "All questions";

export function FAQBrowser({ items }: { items: FAQSearchItem[] }) {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState(ALL_CATEGORIES);

  const categories = useMemo(
    () => [ALL_CATEGORIES, ...Array.from(new Set(items.map((item) => item.category)))],
    [items],
  );

  const filteredFaqs = useMemo(
    () => filterFaqs(items, query, activeCategory),
    [items, query, activeCategory],
  );

  const visibleGroups = categories.filter((category) => category !== ALL_CATEGORIES);
  const hasActiveFilters = Boolean(query.trim()) || activeCategory !== ALL_CATEGORIES;

  function clearFilters() {
    setQuery("");
    setActiveCategory(ALL_CATEGORIES);
  }

  return (
    <div className="faq-browser">
      <div className="faq-browser-tools">
        <label className="faq-search">
          <span className="sr-only">Search FAQ questions and answers</span>
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search fees, schedules, courses or services"
            aria-controls="faq-results"
            aria-describedby="faq-result-count"
          />
        </label>

        <div
          className="faq-category-filters"
          role="group"
          aria-label="Filter frequently asked questions by topic"
        >
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              className={activeCategory === category ? "active" : ""}
              aria-pressed={activeCategory === category}
              aria-controls="faq-results"
              onClick={() => setActiveCategory(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      <div className="faq-browser-status">
        <p id="faq-result-count" role="status" aria-live="polite">
          Showing {filteredFaqs.length} of {items.length} questions
        </p>
        {hasActiveFilters ? (
          <button type="button" className="faq-clear-button" onClick={clearFilters}>
            Clear search and filters
          </button>
        ) : null}
      </div>

      {filteredFaqs.length > 0 ? (
        <div id="faq-results" className="faq-page-groups">
          {visibleGroups.map((category) => {
            const categoryFaqs = filteredFaqs.filter((faq) => faq.category === category);
            if (categoryFaqs.length === 0) return null;

            const headingId = `faq-${category.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}`;

            return (
              <section className="faq-group" key={category} aria-labelledby={headingId}>
                <h2 id={headingId}>{category}</h2>
                <div className="faq-list">
                  {categoryFaqs.map((faq) => (
                    <details key={faq.q}>
                      <summary>
                        {faq.q}
                        <span aria-hidden="true">+</span>
                      </summary>
                      <p>{faq.a}</p>
                    </details>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      ) : (
        <div id="faq-results" className="faq-empty-state">
          <h2>No matching questions</h2>
          <p>Try a different word or clear the filters. If you still need help, the AROUSH team can confirm the detail.</p>
          <div className="faq-empty-actions">
            <button type="button" className="button button-outline" onClick={clearFilters}>
              Clear filters
            </button>
            <Link href="/contact" className="button">
              Contact AROUSH <span aria-hidden="true">↗</span>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
