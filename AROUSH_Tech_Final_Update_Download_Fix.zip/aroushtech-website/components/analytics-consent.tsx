"use client";

import Script from "next/script";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import {
  buildPageViewPayload,
  isValidGaMeasurementId,
  normalizeConsentChoice,
  shouldLoadAnalytics,
} from "@/lib/analytics-policy.mjs";

const GA_ID = process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID?.trim() ?? "";
const GA_CONFIGURED = isValidGaMeasurementId(GA_ID);
const CONSENT_KEY = "aroush-analytics-consent-v2";

type ConsentChoice = "accepted" | "rejected" | null;
type GtagFunction = (...args: unknown[]) => void;

type AnalyticsWindow = Window & {
  dataLayer?: unknown[];
  gtag?: GtagFunction;
  __aroushGaBootstrapDone?: boolean;
};

function setAnalyticsDisabled(disabled: boolean) {
  if (!GA_CONFIGURED || typeof window === "undefined") return;

  // Google documents this flag as a way to disable collection for a GA property.
  (window as unknown as Record<string, unknown>)[`ga-disable-${GA_ID}`] = disabled;

  const analyticsWindow = window as AnalyticsWindow;
  analyticsWindow.gtag?.("consent", "update", {
    analytics_storage: disabled ? "denied" : "granted",
  });
}

function readSavedChoice(): ConsentChoice {
  try {
    return normalizeConsentChoice(window.localStorage.getItem(CONSENT_KEY));
  } catch {
    // If storage is unavailable, start with analytics off and ask again next visit.
    return null;
  }
}

function saveChoice(choice: Exclude<ConsentChoice, null>) {
  try {
    window.localStorage.setItem(CONSENT_KEY, choice);
  } catch {
    // The choice still applies for this page view even if storage is blocked.
  }
}

function clearAnalyticsCookies() {
  if (typeof document === "undefined") return;

  const analyticsCookieNames = document.cookie
    .split(";")
    .map((cookie) => cookie.trim().split("=")[0])
    .filter((name) => /^_ga(?:_|$)/.test(name));

  const hostParts = window.location.hostname.split(".");
  const domains = hostParts
    .slice(0, Math.max(1, hostParts.length - 1))
    .map((_, index) => hostParts.slice(index).join("."));

  for (const name of analyticsCookieNames) {
    document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`;
    for (const domain of domains) {
      document.cookie = `${name}=; Max-Age=0; path=/; domain=.${domain}; SameSite=Lax`;
    }
  }
}

/** Loads GA4 only after an explicit opt-in and keeps a persistent settings control. */
export function AnalyticsConsent() {
  const [choice, setChoice] = useState<ConsentChoice>(null);
  const [ready, setReady] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);
  const pathname = usePathname();
  const lastPathname = useRef<string | null>(null);
  const settingsButtonRef = useRef<HTMLButtonElement>(null);
  const panelActionRef = useRef<HTMLButtonElement>(null);
  const focusPanelAfterOpenRef = useRef(false);
  const returnFocusAfterCloseRef = useRef(false);

  useEffect(() => {
    const saved = readSavedChoice();
    setChoice(saved);
    setPanelOpen(GA_CONFIGURED && saved === null);
    setAnalyticsDisabled(saved !== "accepted");
    if (saved !== "accepted") clearAnalyticsCookies();
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;

    if (lastPathname.current === null) {
      lastPathname.current = pathname;
      return;
    }

    const previousPathname = lastPathname.current;
    if (pathname !== previousPathname && choice === "accepted" && GA_CONFIGURED) {
      const analyticsWindow = window as AnalyticsWindow;
      analyticsWindow.gtag?.(
        "event",
        "page_view",
        buildPageViewPayload({
          origin: window.location.origin,
          pathname,
          title: document.title,
          referrer: previousPathname
            ? `${window.location.origin}${previousPathname}`
            : document.referrer,
        }),
      );
    }

    lastPathname.current = pathname;
  }, [pathname, choice, ready]);

  useEffect(() => {
    if (panelOpen && focusPanelAfterOpenRef.current) {
      panelActionRef.current?.focus();
      focusPanelAfterOpenRef.current = false;
    }

    if (!panelOpen && returnFocusAfterCloseRef.current) {
      settingsButtonRef.current?.focus();
      returnFocusAfterCloseRef.current = false;
    }
  }, [panelOpen]);

  function choose(next: Exclude<ConsentChoice, null>) {
    returnFocusAfterCloseRef.current = true;
    saveChoice(next);
    setAnalyticsDisabled(next !== "accepted");
    if (next === "rejected") clearAnalyticsCookies();

    // The first opt-in sends its page view from the bootstrap script. If this
    // browser already bootstrapped GA4 earlier in the same page session, send
    // one page view for the explicit re-acceptance instead of relying on a
    // cached Next.js Script component to execute again.
    const analyticsWindow = window as AnalyticsWindow;
    if (
      next === "accepted" &&
      GA_CONFIGURED &&
      analyticsWindow.__aroushGaBootstrapDone
    ) {
      analyticsWindow.gtag?.(
        "event",
        "page_view",
        buildPageViewPayload({
          origin: window.location.origin,
          pathname: window.location.pathname,
          title: document.title,
          referrer: document.referrer,
        }),
      );
    }

    setChoice(next);
    setPanelOpen(false);
  }

  function openSettings() {
    // Opening settings is informational. The visitor's saved choice changes
    // only after they explicitly select Allow or Reject.
    focusPanelAfterOpenRef.current = true;
    setPanelOpen(true);
  }

  function closeSettings() {
    returnFocusAfterCloseRef.current = true;
    setPanelOpen(false);
  }

  const analyticsAllowed = shouldLoadAnalytics({ measurementId: GA_ID, choice });
  const showConsentPanel = ready && GA_CONFIGURED && choice === null && panelOpen;
  const showSavedSettingsPanel = ready && GA_CONFIGURED && choice !== null && panelOpen;
  const showUnconfiguredPanel = ready && !GA_CONFIGURED && panelOpen;
  const showSettingsButton = ready && !panelOpen && (choice !== null || !GA_CONFIGURED);

  return (
    <>
      {ready && analyticsAllowed ? (
        <>
          <Script id="aroush-google-analytics-bootstrap" strategy="afterInteractive">
            {`if (!window.__aroushGaBootstrapDone) {
                window.dataLayer = window.dataLayer || [];
                window.gtag = function(){window.dataLayer.push(arguments);};
                window.gtag('consent', 'default', { analytics_storage: 'denied' });
                window.gtag('consent', 'update', { analytics_storage: 'granted' });
                window.gtag('js', new Date());
                window.gtag('config', '${GA_ID}', {
                  allow_google_signals: false,
                  allow_ad_personalization_signals: false,
                  send_page_view: false
                });
                window.gtag('event', 'page_view', {
                  page_title: document.title,
                  page_location: window.location.origin + window.location.pathname,
                  page_path: window.location.pathname,
                  page_referrer: document.referrer ? new URL(document.referrer).origin : undefined
                });
                window.__aroushGaBootstrapDone = true;
              }`}
          </Script>
          <Script
            src={`https://www.googletagmanager.com/gtag/js?id=${GA_ID}`}
            strategy="afterInteractive"
          />
        </>
      ) : null}

      {showConsentPanel ? (
        <aside className="analytics-consent" aria-label="Analytics preferences">
          <div>
            <strong>Choose your analytics preference</strong>
            <p>
              If enabled by the site owner, Google Analytics 4 measures aggregate
              page visits, engagement time, device and browser categories, traffic
              sources and approximate geographic areas. It is optional and loads
              only after you allow it. Read the <Link href="/privacy">privacy notice</Link>.
            </p>
          </div>
          <div className="analytics-consent-actions">
            <button ref={panelActionRef} type="button" className="analytics-reject" onClick={() => choose("rejected")}>
              Reject
            </button>
            <button type="button" className="analytics-accept" onClick={() => choose("accepted")}>
              Allow analytics
            </button>
          </div>
        </aside>
      ) : null}

      {showSavedSettingsPanel ? (
        <aside className="analytics-consent" aria-label="Privacy and analytics settings">
          <div>
            <strong>Privacy settings</strong>
            <p aria-live="polite">
              Analytics is currently {choice === "accepted" ? "allowed" : "rejected"}.
              Opening settings does not change this choice. You can change it here
              or close this panel to keep your current preference. Read the{" "}
              <Link href="/privacy">privacy notice</Link>.
            </p>
          </div>
          <div className="analytics-consent-actions">
            {choice === "accepted" ? (
              <button ref={panelActionRef} type="button" className="analytics-reject" onClick={() => choose("rejected")}>
                Reject analytics
              </button>
            ) : (
              <button ref={panelActionRef} type="button" className="analytics-accept" onClick={() => choose("accepted")}>
                Allow analytics
              </button>
            )}
            <button type="button" className="analytics-reject" onClick={closeSettings}>
              Keep current choice
            </button>
          </div>
        </aside>
      ) : null}

      {showUnconfiguredPanel ? (
        <aside className="analytics-consent analytics-consent-status" aria-label="Analytics status">
          <div>
            <strong>Analytics is currently disabled</strong>
            <p>
              AROUSH has not configured a valid GA4 Measurement ID in this website
              package. No Google Analytics script is loaded. If the owner configures
              it later, the site will ask for your permission first. See the{" "}
              <Link href="/privacy">privacy notice</Link>.
            </p>
          </div>
          <div className="analytics-consent-actions">
            <button ref={panelActionRef} type="button" className="analytics-reject" onClick={closeSettings}>
              Close
            </button>
          </div>
        </aside>
      ) : null}

      {showSettingsButton ? (
        <button
          ref={settingsButtonRef}
          type="button"
          className="analytics-settings"
          onClick={openSettings}
          aria-label="Open privacy and analytics settings"
        >
          Privacy settings
        </button>
      ) : null}
    </>
  );
}
