import Link from "next/link";
import Image from "next/image";
import { company } from "@/lib/content";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container footer-top">
        <div className="footer-brand-block">
          <Link href="/" className="footer-logo-link" aria-label="AROUSH Solutions home">
            <Image
              src="/images/aroush-solutions-logo.webp"
              alt="AROUSH Solutions logo"
              width={240}
              height={220}
              className="footer-logo"
            />
          </Link>
          <p className="footer-tagline">
            Technology, connected to your business.
          </p>
          <p className="muted-light">Connect. Secure. Support. Train.</p>
        </div>

        <div>
          <h3>Explore</h3>
          <Link href="/about">About us</Link>
          <Link href="/services">Services</Link>
          <Link href="/courses">Courses</Link>
          <Link href="/faqs">Frequently asked questions</Link>
          <Link href="/learning-paths">Learning paths</Link>
          <Link href="/training">Corporate training</Link>
          <Link href="/team">Our team</Link>
          <Link href="/gallery">Gallery</Link>
          <Link href="/privacy">Privacy notice</Link>
        </div>

        <div>
          <h3>Get in touch</h3>
          <a href={`mailto:${company.email}`}>{company.email}</a>
          <a href={`tel:${company.phoneHref}`}>{company.phone}</a>
          <a href={company.linkedin} target="_blank" rel="noreferrer">
            LinkedIn ↗
          </a>
        </div>

        <div className="footer-offices">
          <h3>Our offices</h3>
          {company.offices.map((office) => (
            <div key={office.label}>
              <strong>{office.label}</strong>
              <p>{office.address}</p>
            </div>
          ))}
          <Link href="/contact" className="footer-link">
            Plan a conversation ↗
          </Link>
        </div>
      </div>

      <div className="container footer-bottom">
        <p>
          © {new Date().getFullYear()} {company.legalName}. All rights reserved.
        </p>
        <p>CIN: {company.cin}</p>
      </div>
    </footer>
  );
}
