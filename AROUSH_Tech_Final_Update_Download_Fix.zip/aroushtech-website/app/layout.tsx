import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { SiteChatbot } from "@/components/site-chatbot";
import { AnalyticsConsent } from "@/components/analytics-consent";
import { company } from "@/lib/content";

// Search engines use this information to understand the company and website.
const organizationStructuredData = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: company.brand,
  legalName: company.legalName,
  url: company.website,
  logo: `${company.website}/images/aroush-solutions-logo.webp`,
  email: company.email,
  telephone: company.phone,
  sameAs: [company.linkedin],
  address: company.offices.map((office) => ({
    "@type": "PostalAddress",
    streetAddress: office.address,
    addressLocality: "Bengaluru",
    addressRegion: "Karnataka",
    postalCode: office.label === "Corporate Office" ? "560029" : "560078",
    addressCountry: "IN",
  })),
};

const websiteStructuredData = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: company.brand,
  url: company.website,
  publisher: {
    "@type": "Organization",
    name: company.legalName,
    url: company.website,
  },
};

export const metadata: Metadata = {
  metadataBase: new URL(company.website),
  icons: { icon: "/icon.png", shortcut: "/icon.png", apple: "/icon.png" },
  title: {
    default: "Aroush Tech | Enterprise IT, Cybersecurity & Corporate Training",
    template: "%s | Aroush Tech",
  },
  description:
    "Bengaluru-based IT consulting and training across cybersecurity, network infrastructure, technical support, cloud and practical technology learning.",
  twitter: { card: "summary_large_image" },
  openGraph: {
    type: "website",
    locale: "en_IN",
    siteName: "Aroush Tech",
    title: "Aroush Tech | Technology, connected to your business",
    description: "Connect. Secure. Support. Train.",
    url: "https://aroushtech.in",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en-IN">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(organizationStructuredData).replace(
              /</g,
              "\\u003c",
            ),
          }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(websiteStructuredData).replace(
              /</g,
              "\\u003c",
            ),
          }}
        />
      </head>
      <body>
        <a className="skip-link" href="#main-content">
          Skip to content
        </a>
        <SiteHeader />
        <main id="main-content">{children}</main>
        <SiteFooter />
        <SiteChatbot />
        <AnalyticsConsent />
      </body>
    </html>
  );
}
