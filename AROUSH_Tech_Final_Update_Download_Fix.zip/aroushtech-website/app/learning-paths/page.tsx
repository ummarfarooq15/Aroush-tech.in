import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";
import { SectionHeading } from "@/components/section-heading";
import { courses, socCourses } from "@/lib/content";
import { learningPaths } from "@/lib/learning-paths";

export const metadata: Metadata = {
  title: "Learning Paths | Networking, Cybersecurity, Cloud & AI",
  description:
    "Browse AROUSH courses by learning goal across networking, network security, cybersecurity, penetration testing, cloud, automation, AI and SOC/SIEM.",
  alternates: { canonical: "/learning-paths" },
  openGraph: {
    title: "Learning Paths | AROUSH Tech",
    description:
      "Find a starting point across AROUSH networking, cybersecurity, cloud, automation, AI and SOC/SIEM learning.",
    url: "/learning-paths",
  },
};

export default function LearningPathsPage() {
  return (
    <>
      <section className="page-hero">
        <div className="container">
          <Breadcrumbs items={[{ label: "Learning paths", href: "/learning-paths" }]} />
          <p className="eyebrow">Choose by learning goal</p>
          <h1>
            Find a useful <em>starting point.</em>
          </h1>
          <p>
            Explore the published AROUSH course catalogue through a few broad
            technical themes. Open any course to review its available details.
          </p>
        </div>
      </section>

      <section className="section section-padded">
        <div className="container">
          <SectionHeading
            eyebrow="Browse learning paths"
            title="Start with the area you want to explore."
            text="These collections make the catalogue easier to browse. They are not mandatory course sequences, formal prerequisites or promises of a particular career outcome."
          />

          <div className="learning-path-grid">
            {learningPaths.map((path, index) => {
              const pathCourses = path.courseSlugs.flatMap((slug) => {
                const course = courses.find((item) => item.slug === slug);
                return course ? [course] : [];
              });

              return (
                <article className="learning-path-card" key={path.slug}>
                  <div className="learning-path-card-top">
                    <span>0{index + 1}</span>
                    <span>{pathCourses.length} courses</span>
                  </div>
                  <h2>{path.title}</h2>
                  <p>{path.summary}</p>
                  <ul className="learning-path-course-list">
                    {pathCourses.map((course) => (
                      <li key={course.slug}>
                        <Link href={`/courses/${course.slug}`}>
                          {course.title}
                          <span aria-hidden="true">↗</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </article>
              );
            })}
          </div>

          <p className="catalog-note learning-path-note">
            Course availability, current fees, prerequisites, duration and
            delivery format can change or vary by programme. Confirm these
            details with AROUSH before enrolling or making a payment.
          </p>
        </div>
      </section>

      <section className="section section-dark section-padded">
        <div className="container">
          <SectionHeading
            eyebrow="SOC / SIEM learning"
            title="Explore dedicated operations-focused training."
            text="The AROUSH company profile lists these focused learning options for analysts, administrators and teams developing SOC capability."
            light
          />
          <div className="soc-course-grid">
            {socCourses.map((course, index) => (
              <article id={course.slug} key={course.slug}>
                <div className="soc-course-top">
                  <span>0{index + 1}</span>
                  <b>{course.duration}</b>
                </div>
                <h3>{course.title}</h3>
                <p>{course.focus}</p>
                <Link
                  href={`/contact?type=learner&interest=${encodeURIComponent("SOC / SIEM training")}&course=${encodeURIComponent(course.title)}`}
                  className="arrow-link"
                >
                  Ask about this programme <span aria-hidden="true">↗</span>
                </Link>
              </article>
            ))}
          </div>
          <p className="scope-note scope-note-dark">
            Platform access, prerequisites, delivery resources and scope are
            confirmed with AROUSH for each programme. Continuous 24×7 monitoring
            is not implied by these training options.
          </p>
        </div>
      </section>

      <section className="final-cta">
        <div className="container final-cta-inner">
          <div>
            <p className="eyebrow eyebrow-light">Need help choosing?</p>
            <h2>Share your background and the skills you want to build.</h2>
          </div>
          <Link className="button button-light" href="/contact?type=learner&interest=Individual%20course%20enquiry">
            Talk to the training team <span aria-hidden="true">↗</span>
          </Link>
        </div>
      </section>
    </>
  );
}
