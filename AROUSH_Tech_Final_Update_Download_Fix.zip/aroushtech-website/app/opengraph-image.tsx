import { ImageResponse } from "next/og";
import { SocialCard } from "@/components/social-card";

export const runtime = "edge";
export const alt = "Aroush Tech — enterprise IT, cybersecurity and practical training";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function OpenGraphImage() {
  return new ImageResponse(
    (
      <SocialCard
        eyebrow="Enterprise IT · Cybersecurity · Training"
        title="Technology, connected to your business."
        description="A coordinated portfolio for reliable connectivity, appropriate security, responsive support and practical learning."
      />
    ),
    size,
  );
}
