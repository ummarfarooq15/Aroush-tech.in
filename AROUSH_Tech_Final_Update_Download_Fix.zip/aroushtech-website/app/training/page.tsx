import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";
import { SectionHeading } from "@/components/section-heading";
import { SourceImage } from "@/components/source-image";
import { company, socCourses, team } from "@/lib/content";

export const metadata: Metadata = {
  title: "Corporate IT & Cybersecurity Training",
  description: "Corporate and campus technical learning, curriculum and lab-guide development, train-the-trainer programmes, and SOC/SIEM learning paths from AROUSH in Bengaluru.",
  alternates: { canonical: "/training" },
  openGraph: {
    title: "Corporate IT & Cybersecurity Training | Aroush Tech",
    description: "Practical technical learning shaped around your team's starting point.",
    url: "/training"
  }
};

const capabilities = [
  { title: "Corporate technical programmes", text: "Structured learning for enterprise IT teams and learning-and-development departments." },
  { title: "Campus learning programmes", text: "Technical learning engagements for colleges and training organisations." },
  { title: "Curriculum & lab-guide development", text: "Learning plans, practical exercises and lab guides aligned to agreed objectives." },
  { title: "Train-the-trainer engagements", text: "Support for trainers delivering agreed technical subjects and learning outcomes." },
  { title: "Networking, firewall & security", text: "Technical learning across networking, firewall technologies and cybersecurity." },
  { title: "Cloud learning", text: "Cloud learning shaped around the learner's starting point and the agreed platform scope." }
];

const steps = [
  "Understand learner roles, current skills and business objectives",
  "Agree the curriculum, prerequisites, delivery format and assessment",
  "Prepare demonstrations, lab guides and authorized practice environments",
  "Deliver instructor-led learning with practical exercises",
  "Review learning evidence and provide agreed handover materials"
];

export default function TrainingPage() {
  return <>
    <section className="page-hero"><div className="container"><Breadcrumbs items={[{ label: "Corporate training", href: "/training" }]} /><p className="eyebrow">Corporate & campus learning</p><h1>Practical skills.<br /><em>Built around your team.</em></h1><p>Technical learning that connects agreed objectives with demonstrations, labs and assessment suited to the learner’s starting point.</p><div className="hero-actions"><Link className="button" href={`/contact?type=business&interest=${encodeURIComponent("Corporate / campus training")}`}>Discuss a training programme <span>↗</span></Link><Link className="text-link" href="/courses">Explore individual courses <span>→</span></Link></div></div></section>

    <section className="section section-padded"><div className="container"><div className="about-intro-grid"><div><p className="eyebrow">Training portfolio</p><h2>Learning with a clear purpose.</h2></div><div><p className="large-copy">AROUSH provides corporate technical training programmes, campus learning programmes, curriculum design and development, technical lab and lab-guide development, and train-the-trainer engagements.</p><p>Learning areas include networking, firewall, cybersecurity and cloud technologies. Individual course enquiries are handled separately from corporate programme discussions.</p></div></div></div></section>

    <section className="section section-soft section-padded"><div className="container"><SectionHeading eyebrow="What can be scoped" title="A programme shaped to the requirement." text="The following capabilities are listed in the company profile. Specific subjects, learner levels, trainer availability and delivery arrangements are confirmed for each engagement." /><div className="pillar-grid">{capabilities.map((item, i) => <article className="pillar-card" key={item.title}><span className="number-tag">{String(i + 1).padStart(2, "0")}</span><h3>{item.title}</h3><p>{item.text}</p></article>)}</div></div></section>

    <section className="section section-padded"><div className="container"><SectionHeading eyebrow="Practical learning" title="From objectives to usable practice." text="Typical programme outputs may include a training-needs summary, curriculum, lab guides, learner assessment and a feedback report." /><div className="process-grid training-process">{steps.map((step, i) => <div key={step}><b>{String(i + 1).padStart(2, "0")}</b><h3>{step}</h3></div>)}</div><p className="catalog-note">Prerequisites, trainer availability, lab capacity, dates and assessment are confirmed per programme. Exam vouchers, vendor accreditation and placement outcomes are not implied.</p></div></section>

    <section id="soc-siem" className="section section-dark section-padded"><div className="container"><SectionHeading eyebrow="SOC / SIEM learning" title="Focused learning for security operations teams." text="The company profile lists six learning paths with indicative durations. Platform-specific delivery is subject to a confirmed supported environment, access and licensing." light /><div className="soc-course-grid">{socCourses.map((course, i) => <article key={course.slug}><div className="soc-course-top"><span>0{i + 1}</span><b>{course.duration}</b></div><h3>{course.title}</h3><p>{course.focus}</p><Link href={`/contact?type=learner&interest=${encodeURIComponent("SOC / SIEM training")}&course=${encodeURIComponent(course.title)}`} className="arrow-link">Enquire about this path <span>↗</span></Link></article>)}</div><p className="scope-note scope-note-dark">Training uses authorized, isolated learning scenarios. Platform version, software/lab rights, trainer capability and learner seats must be ready and confirmed. Official vendor certification and exam vouchers are not implied.</p></div></section>

    <section className="section section-padded"><div className="container training-audience-grid"><div><SectionHeading eyebrow="Who it is for" title="Designed for people building technical capability." text="The company profile identifies these audiences and decision-makers." /></div><div className="audience-list"><div><h3>Learning participants</h3><p>Enterprise IT teams, SOC analysts, IT administrators, cybersecurity students, colleges and training organisations.</p></div><div><h3>Programme stakeholders</h3><p>IT leaders, learning-and-development departments, department heads and placement officers.</p></div><div><h3>Delivery options</h3><p>Bengaluru onsite or online across India. Hybrid delivery and hosted labs can be discussed by agreement.</p></div></div></div></section>

    <section className="section section-soft section-padded"><div className="container"><SectionHeading eyebrow="Meet the team" title="People behind the training." text="The names and role titles below are reproduced from the current AROUSH website." /><div className="team-grid">{team.map((person) => <article className="team-card" key={person.name}><div className="team-avatar"><SourceImage src={person.photo} alt={`Portrait of ${person.name}`} fallbackLabel={person.initials} /></div><p className="eyebrow">{person.role}</p><h2>{person.name}</h2><p className="team-role-note">Role title as published on the AROUSH website.</p></article>)}</div><p className="catalog-note">Specific trainer allocation and platform competence are confirmed for each programme. <Link href="/team">Meet the team →</Link></p></div></section>

    <section className="final-cta"><div className="container final-cta-inner"><div><p className="eyebrow eyebrow-light">Plan a programme</p><h2>Tell us about your learners, goals and technical environment.</h2><p className="muted-light">{company.email} · {company.phone}</p></div><Link href={`/contact?type=business&interest=${encodeURIComponent("Corporate / campus training")}`} className="button button-light">Start a training enquiry <span>↗</span></Link></div></section>
  </>;
}
