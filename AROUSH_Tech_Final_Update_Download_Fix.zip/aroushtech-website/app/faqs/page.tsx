import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";
import { FAQBrowser } from "@/components/faq-browser";
import { SectionHeading } from "@/components/section-heading";
import { faqs } from "@/lib/content";

export const metadata: Metadata = {
  title: "Frequently Asked Questions",
  description: "Search answers about AROUSH courses, training formats, fees, office locations, enquiries and IT services.",
  alternates: { canonical: "/faqs" },
  openGraph: {
    title: "Frequently Asked Questions | Aroush Tech",
    description: "Search practical answers about courses, training, enquiries and services.",
    url: "/faqs",
  },
};

export default function FAQsPage() {
  return (
    <>
      <section className="page-hero">
        <div className="container">
          <Breadcrumbs items={[{ label: "FAQs", href: "/faqs" }]} />
          <p className="eyebrow">Help & information</p>
          <h1>Clear answers.<br /><em>Before you decide.</em></h1>
          <p>Search practical information about published courses, training arrangements, enquiries and service scope. If a detail is not confirmed here, the AROUSH team can verify it.</p>
        </div>
      </section>

      <section className="section section-padded">
        <div className="container faq-page-layout">
          <div className="faq-page-intro">
            <SectionHeading
              eyebrow="Frequently asked questions"
              title="Start with what is known."
              text="Course schedules, prerequisites, current fees and service availability can change. Confirm those details directly with AROUSH before making a booking or payment."
            />
            <Link href="/contact" className="button button-outline">
              Ask the AROUSH team <span aria-hidden="true">↗</span>
            </Link>
          </div>
          <FAQBrowser items={faqs} />
        </div>
      </section>

      <section className="final-cta">
        <div className="container final-cta-inner">
          <div>
            <p className="eyebrow eyebrow-light">Need a specific answer?</p>
            <h2>Tell us what you need to confirm.</h2>
          </div>
          <Link href="/contact" className="button button-light">
            Contact AROUSH <span aria-hidden="true">↗</span>
          </Link>
        </div>
      </section>
    </>
  );
}
