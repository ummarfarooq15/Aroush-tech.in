import Link from "next/link";

export default function NotFound() {
  return (
    <section className="not-found">
      <div className="container">
        <p className="eyebrow">404 · Page not found</p>
        <h1>This page isn&apos;t here.</h1>
        <p>
          The link may have changed. You can browse the course catalogue, explore
          AROUSH services or ask the team for help.
        </p>
        <div className="not-found-actions">
          <Link className="button" href="/courses">Explore courses <span aria-hidden="true">↗</span></Link>
          <Link className="button button-outline" href="/services">Explore services <span aria-hidden="true">↗</span></Link>
          <Link className="text-link" href="/contact">Contact the team <span aria-hidden="true">↗</span></Link>
        </div>
      </div>
    </section>
  );
}
