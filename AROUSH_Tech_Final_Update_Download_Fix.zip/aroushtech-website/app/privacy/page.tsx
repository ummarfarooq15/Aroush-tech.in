import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Privacy Notice",
  description:
    "How AROUSH Tech handles optional website analytics and information visitors choose to share.",
  alternates: { canonical: "/privacy" },
};

const analyticsConfigured = /^G-[A-Z0-9]+$/i.test(
  process.env.NEXT_PUBLIC_GA_MEASUREMENT_ID?.trim() ?? "",
);

export default function PrivacyPage() {
  return (
    <section className="section section-padded">
      <div className="container legal-content">
        <Breadcrumbs items={[{ label: "Privacy", href: "/privacy" }]} variant="dark" />
        <p className="eyebrow">Privacy</p>
        <h1>Website privacy notice</h1>
        <p>
          This notice explains what the AROUSH Tech website may process when you
          browse the site or choose to contact the team. It is a draft for owner
          and legal review. The company must approve the final privacy contact,
          retention settings and legal wording before production launch.
        </p>

        <h2>1. Optional website analytics</h2>
        <p>
          The website package supports Google Analytics 4 (GA4), provided by
          Google LLC. {analyticsConfigured
            ? "A GA4 Measurement ID is configured for this build. GA4 remains off until you explicitly allow analytics."
            : "No GA4 Measurement ID is configured for this build, so GA4 is disabled and no analytics script is loaded."}
        </p>
        <p>
          If the site owner configures GA4, the analytics script will load only
          after you select <strong>Allow analytics</strong>. You can select
          <strong> Reject</strong>, or reopen <strong>Privacy settings</strong> at
          any time to review or change your choice. Opening that panel does not
          change your saved preference; selecting Reject withdraws permission and
          disables GA collection for this property.
        </p>
        <p>
          The intended reporting is limited to aggregate website insights:
          visited pages, visit and engagement time, broad device and browser
          categories, referral source domain and approximate geographic area such
          as country, region or city. Query strings are excluded from page paths so
          personal information is not accidentally included in analytics URLs.
          GA4 may process pseudonymous event-level data
          to produce those reports; aggregate reporting does not mean that the
          underlying processing is completely anonymous.
        </p>
        <p>
          This implementation does not request precise GPS location, discover a
          visitor&apos;s phone number, add device fingerprinting, set a user ID,
          or configure advertising personalization or Google Signals. Google
          Analytics may use first-party analytics storage after you opt in. When
          you reject or withdraw consent, the site disables further GA collection
          and attempts to clear GA cookies set on this site. You may also clear
          site cookies in your browser. Google states that GA4 does not log or
          store IP addresses; IP-derived location is approximate and must not be
          treated as an exact address.
        </p>
        <p>
          Provider information: <a href="https://policies.google.com/privacy" target="_blank" rel="noreferrer">Google Privacy Policy</a> and{" "}
          <a href="https://support.google.com/analytics/answer/9019185" target="_blank" rel="noreferrer">Google Analytics privacy controls</a>.
        </p>
        <p>
          A separate AROUSH Visitor Intelligence companion app is being prepared for development testing. It is not deployed, no tracker from that app is installed on this website, and this website does not currently send visitor analytics or enquiry data to that companion service. If it is connected in future, this notice and the consent experience will be updated before activation.
        </p>

        <h2>2. Information you choose to provide</h2>
        <p>
          The enquiry form asks for your name, email address, enquiry type,
          area of interest and message. Depending on the path you choose, you
          may also provide a course name, organisation or approximate team
          size; those fields are optional. Phone number is always optional.
          Add a number only if you want the AROUSH team to use it to respond to
          your enquiry by phone.
        </p>
        <p>
          At present, the form first displays an email preview in the current page. The
          preview is held in page memory only while the page remains open; it is
          not saved to browser storage. The website does not send the details to
          an AROUSH website server, save them in a website database or create a
          CRM record. If you choose Open email app, your email application opens
          with the prepared message. The information is sent only if you review
          and send it from that email application. The email provider and
          recipient then handle that message under their own terms.
        </p>

        <h2>3. What this website does not collect automatically</h2>
        <ul>
          <li>No personal phone number is discovered from a website visit.</li>
          <li>No exact home or street address is inferred or reported.</li>
          <li>No precise GPS location or covert device fingerprint is used.</li>
          <li>No server-side visitor profile, lead database or CRM is connected to this website at present. The separate companion app is still a development-only package and is not deployed or connected.</li>
        </ul>

        <h2>4. Analytics retention and owner setup</h2>
        <p>
          The AROUSH owner must create or select the GA4 property, configure its
          Measurement ID, restrict access to authorised staff and select a data
          retention period before enabling analytics. Google Analytics provides
          configurable user-level data retention settings; the owner should
          select the shortest suitable period and disclose the final setting here
          after it is confirmed. Standard aggregated reports may be retained
          differently from event-level data.
        </p>
        <p>
          Before activation, the owner must turn off Enhanced Measurement events
          outside this limited purpose, including scroll tracking, outbound clicks,
          file downloads, video engagement, site search and form interactions.
          Keep only page views and the standard session/engagement, device/browser,
          referrer and approximate-geography information needed for the stated
          aggregate reports. Google Signals and advertising features must remain
          disabled; Google Ads, BigQuery export and other integrations require
          separate approval. The owner must review data-processing terms and
          international transfers and define a process for access, withdrawal and
          deletion requests. Do not enter phone numbers, names, email addresses or
          message contents into analytics event names, URLs, custom dimensions or
          other analytics fields.
        </p>

        <h2>5. Retention, privacy contact and legal review</h2>
        <p>
          AROUSH must confirm the privacy contact, the retention period for
          enquiries sent by email, the process for handling privacy requests and
          the person responsible for the GA4 property. These details are not yet
          approved for publication. The final setup must be reviewed against the
          Indian Digital Personal Data Protection Act, 2023, the notified DPDP
          Rules, 2025 and other applicable requirements in force on the launch
          date. This notice is not legal advice.
        </p>
        <p>
          Official reference: <a href="https://www.meity.gov.in/documents/act-and-policies/digital-personal-data-protection-rules-2025-gDOxUjMtQWa?pageTitle=Digital-Personal-Data-Protection-Rules-2025" target="_blank" rel="noreferrer">MeitY — Digital Personal Data Protection Rules, 2025</a>.
        </p>

        <h2>6. Contact</h2>
        <p>
          For general company enquiries, use the details on our{" "}
          <Link href="/contact">Contact page</Link>. The owner must confirm a
          dedicated privacy contact before this notice is finalised.
        </p>
        <p className="form-note">
          Draft notice for AROUSH owner/legal review. Last reviewed: 7 November
          2026. Update this page whenever the analytics provider, data use,
          retention period or contact process changes.
        </p>
      </div>
    </section>
  );
}
