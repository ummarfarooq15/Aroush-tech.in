import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { SectionHeading } from "@/components/section-heading";
import { SourceImage } from "@/components/source-image";
import { CoursePrice } from "@/components/course-price";
import { pillars, services, courses, gallery, testimonials, team } from "@/lib/content";

export const metadata: Metadata = {
  title: { absolute: "Aroush Tech | Enterprise IT, Cybersecurity & Corporate Training" },
  description: "A Bengaluru-based portfolio connecting enterprise IT, cybersecurity, network infrastructure, technical support and practical corporate training.",
  alternates: { canonical: "/" },
  openGraph: { title: "Aroush Tech | Technology, connected to your business", description: "Connect. Secure. Support. Train.", url: "/" }
};

export default function HomePage() {
  const instructor = team.find((person) => person.name === "Tajuddin");
  const featuredServices = services.filter((service) =>
    ["06", "01", "08", "09"].includes(service.number),
  );
  const featuredCourseTitles = [
    "Agentic AI with LangChain & Hugging Face",
    "CCNP Security",
    "CEH (Certified Ethical Hacker)",
  ];

  return <>
    <section className="hero">
      <div className="hero-grid"></div>
      <div className="container hero-layout">
        <div className="hero-copy">
          <div className="hero-brand-lockup">
            <Image
              src="/images/aroush-solutions-symbol.webp"
              alt=""
              width={88}
              height={88}
              priority
              className="hero-brand-logo"
            />
            <p className="eyebrow eyebrow-light"><span className="eyebrow-dot"></span> Bengaluru · India · Enterprise IT</p>
          </div>
          <h1>Technology,<br /><em>connected</em> to<br />your business.</h1>
          <p className="hero-lead">A coordinated portfolio for reliable connectivity, appropriate security, responsive support and practical learning.</p>
          <div className="hero-actions"><Link className="button button-light" href="/contact">Start a conversation <span>↗</span></Link><Link className="text-link text-link-light" href="/services">Explore our services <span>→</span></Link></div>
          <div className="hero-meta"><span>Consulting</span><i></i><span>Implementation</span><i></i><span>Corporate training</span></div>
        </div>
        <div className="hero-image-frame">
          <Image
            src="/images/aroush-cybersecurity-training.webp"
            alt="Illustrative cybersecurity training lab with an instructor guiding learners through network security dashboards"
            fill
            priority
            sizes="(max-width: 720px) 100vw, 50vw"
            className="hero-image"
          />
          <div className="hero-image-caption"><span className="caption-dot"></span> CONNECT · SECURE · SUPPORT · TRAIN</div>
        </div>
      </div>
      <div className="container hero-bottom"><span>Enterprise IT</span><span>Cybersecurity</span><span>Corporate training</span><span>Cloud & networking</span></div>
    </section>

    <section className="trust-strip"><div className="container trust-inner"><span>Built around your business</span><strong>Clear scope</strong><strong>Practical delivery</strong><strong>Documented handover</strong><strong>Learning beyond handover</strong></div></section>

    <section className="section section-padded">
      <div className="container"><SectionHeading eyebrow="The Aroush framework" title="Four pillars. One connected lifecycle." text="Choose one service or connect related scopes—from building a reliable network to strengthening security, supporting operations and developing the people who run it." />
        <div className="pillar-grid">{pillars.map((pillar) => <article className="pillar-card" key={pillar.title}><span className="number-tag">{pillar.number}</span><h3>{pillar.title}</h3><p>{pillar.text}</p><small>{pillar.services}</small></article>)}</div>
      </div>
    </section>

    <section className="section section-soft section-padded">
      <div className="container"><div className="split-heading"><SectionHeading eyebrow="Our services" title="Technology support, from planning to practical handover." text="Ten connected service areas designed around real operating requirements—not one-size-fits-all packages." /><Link href="/services" className="button button-outline">View all services <span>→</span></Link></div>
        <div className="service-preview-grid">{featuredServices.map((service) => <article className="service-preview" key={service.number}><div className="service-preview-top"><span>{service.number}</span><span>{service.pillar}</span></div><h3>{service.title}</h3><p>{service.summary}</p><Link href="/services" className="arrow-link">Explore service <span>↗</span></Link></article>)}</div>
      </div>
    </section>

    <section className="section section-padded">
      <div className="container"><div className="split-heading"><SectionHeading eyebrow="Learning & development" title="Build skills that translate into action." text="A broad technical learning catalogue across networking, cybersecurity, cloud, automation and AI—plus dedicated SOC/SIEM learning paths." /><div className="learning-actions"><Link href="/courses" className="button button-outline">Explore courses <span>→</span></Link><Link href="/learning-paths" className="text-link">Browse by learning goal <span>↗</span></Link></div></div>
        <div className="course-feature-grid">{courses.filter((course) => featuredCourseTitles.includes(course.title)).map((course) => <article className="course-feature" key={course.title}><span className="course-category">{course.category}</span><h3>{course.title}</h3><p>{course.description}</p><CoursePrice previousPrice={course.previousPrice} listedPrice={course.listedPrice} feeNote={course.feeNote} /><Link href={`/courses/${course.slug}`} className="arrow-link">View course details <span>↗</span></Link></article>)}</div>
        <p className="catalog-note">Where official pages agree, published catalogue amounts are shown as references. CCNA and CCNA DevNet fees are withheld because their catalogue and individual course pages conflict. Confirm every current fee with AROUSH before payment. Course availability, prerequisites and delivery format are confirmed per programme.</p>
        <p className="course-demo-cta"><strong>Interested in a course demo?</strong> The current AROUSH homepage advertises a free demo; ask the team to confirm eligibility and timing for your selected course. <Link href="/contact?type=learner&interest=Individual%20course%20enquiry">Ask about a demo ↗</Link></p>
      </div>
    </section>

    <section className="soc-band"><div className="container soc-layout"><div><p className="eyebrow eyebrow-light">New business line · Service 10</p><h2>From telemetry<br />to a usable SOC workflow.</h2><p>Plan, deploy, connect, detect and transfer the knowledge your team needs to operate its SIEM environment.</p><Link href="/services#soc-siem" className="button button-light">Explore SOC / SIEM <span>↗</span></Link></div><div className="soc-steps"><div><b>01</b><span>Assess & plan</span></div><div><b>02</b><span>Deploy & connect</span></div><div><b>03</b><span>Detect & tune</span></div><div><b>04</b><span>Make it usable</span></div><div><b>05</b><span>Transfer & improve</span></div><p>Platform, people, access and service scope are confirmed before commitment. 24×7 monitoring is not assumed.</p></div></div></section>

    <section className="section section-soft section-padded">
      <div className="container training-callout">
        <div><p className="eyebrow">For organizations & institutions</p><h2>Training designed around your team’s starting point.</h2><p>Corporate programmes, campus learning, curriculum and lab-guide development, and train-the-trainer engagements.</p></div>
        <Link href="/training" className="button button-outline">Explore corporate training <span>↗</span></Link>
      </div>
    </section>

    <section className="section section-padded">
      <div className="container"><div className="split-heading"><SectionHeading eyebrow="Inside Aroush" title="Practical learning. Real people. Shared progress." text="A glimpse of training environments and the people behind the learning experience." /><Link href="/gallery" className="text-link">View gallery <span>→</span></Link></div>
        <div className="home-gallery">{gallery.slice(0, 3).map((item) => <figure key={item.src}><SourceImage src={item.src} alt={item.alt} fallbackLabel="AROUSH training photograph" /><figcaption>{item.caption}</figcaption></figure>)}</div>
      </div>
    </section>

    <section className="quote-section"><div className="container"><SectionHeading eyebrow="Student feedback" title="What learners have shared." text="These testimonials are reproduced from the current AROUSH homepage." /><div className="testimonial-grid">{testimonials.map((item) => <article className="testimonial-card" key={item.name}><div className="quote-mark">“</div><blockquote>{item.quote}</blockquote><p><strong>{item.name}</strong><span>{item.role}</span></p></article>)}</div></div></section>

    {instructor ? <section className="section section-padded instructor-section"><div className="container instructor-intro"><div className="instructor-photo"><SourceImage src={instructor.photo} alt="Portrait of Tajuddin, listed as Technical Head – Networking & Cyber Security" fallbackLabel="Tajuddin" /></div><div className="instructor-copy"><p className="eyebrow">Instructor introduction</p><h2>Meet Tajuddin.</h2><p className="instructor-quote">“Hello Everyone! This is Tajuddin — your trainer for networking and cybersecurity. Get ready to dive deep into hands-on training and industry case studies.”</p><p className="instructor-source-note">Introduction reproduced from the current AROUSH homepage. Trainer allocation is confirmed for each programme.</p></div></div></section> : null}

    <section className="final-cta"><div className="container final-cta-inner"><div><p className="eyebrow eyebrow-light">Your next step</p><h2>Let’s build a secure, skilled and future-ready organization together.</h2></div><div className="final-cta-actions"><Link href="/contact?type=learner" className="button button-light">Individual learner enquiry <span>↗</span></Link><Link href="/contact?type=business" className="text-link text-link-light">Business / institution enquiry <span>→</span></Link></div></div></section>
  </>;
}
