import type { MetadataRoute } from "next";
import { courses } from "@/lib/content";

export default function sitemap(): MetadataRoute.Sitemap {
  const routes = ["", "/about", "/services", "/courses", "/learning-paths", "/faqs", ...courses.map((course) => `/courses/${course.slug}`), "/training", "/team", "/gallery", "/contact", "/privacy"];
  return routes.map((route) => ({
    url: `https://aroushtech.in${route}`,
    changeFrequency: "monthly",
    priority: route === "" ? 1 : 0.7
  }));
}
