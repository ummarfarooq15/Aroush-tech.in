import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";
import { ContactForm } from "@/components/contact-form";
import { SectionHeading } from "@/components/section-heading";
import { company, faqs } from "@/lib/content";
import { normalizeEnquiryType } from "@/lib/enquiry-path.mjs";

const contactFaqQuestions = new Set([
  "Is a free course demo available?",
  "Can training be delivered online, offline or in a hybrid format?",
  "Are the course fees shown on the website final?",
  "Where is the AROUSH training centre?",
  "Does the enquiry form send or store my details automatically?",
  "How can I contact the AROUSH team?",
]);

const enquiryPaths = [
  {
    type: "learner",
    number: "01",
    audience: "INDIVIDUAL LEARNERS",
    title: "Find the right course",
    description:
      "Ask about a course outline, prerequisites, current fees, delivery options or a demo.",
    action: "Start a learner enquiry",
  },
  {
    type: "business",
    number: "02",
    audience: "BUSINESSES & INSTITUTIONS",
    title: "Discuss a team requirement",
    description:
      "Share a training, infrastructure, cybersecurity or technical-support requirement.",
    action: "Start a business enquiry",
  },
  {
    type: "general",
    number: "03",
    audience: "GENERAL",
    title: "Ask the team",
    description:
      "For other questions, partnerships or a requirement that does not fit the first two paths.",
    action: "Start a general enquiry",
  },
] as const;

export const metadata: Metadata = {
  title: "Contact Aroush",
  description:
    "Contact AROUSH in Bengaluru about enterprise IT, cybersecurity, network infrastructure, technical support and corporate training.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Contact Aroush Tech",
    description:
      "Start a scoped discussion about IT, cybersecurity, support or training requirements.",
    url: "/contact",
  },
};

type ContactPageProps = {
  searchParams: Promise<{
    course?: string;
    interest?: string;
    type?: string;
  }>;
};

export default async function ContactPage({ searchParams }: ContactPageProps) {
  const enquiry = await searchParams;
  const activeType = normalizeEnquiryType(enquiry.type, Boolean(enquiry.course));

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <Breadcrumbs items={[{ label: "Contact", href: "/contact" }]} />
          <p className="eyebrow">Contact us</p>
          <h1>
            Tell us what needs
            <br />
            <em>to work better.</em>
          </h1>
          <p>A new workplace. A security priority. A support need. A learning goal.</p>
        </div>
      </section>

      <section className="section section-padded">
        <div className="container">
          <div className="contact-path-intro">
            <SectionHeading
              eyebrow="Choose your enquiry path"
              title="Start in the right place."
              text="Individual course questions and organisation-wide requirements need different details. Choose the closest route; you can change it in the form."
            />
          </div>

          <div className="contact-paths" role="group" aria-label="Enquiry types">
            {enquiryPaths.map((path) => (
              <Link
                key={path.type}
                className={`contact-path-card${activeType === path.type ? " is-selected" : ""}`}
                href={`/contact?type=${path.type}#enquiry-form`}
                aria-current={activeType === path.type ? "page" : undefined}
              >
                <span>
                  {path.number} · {path.audience}
                </span>
                <strong>{path.title}</strong>
                <p>{path.description}</p>
                <b>{path.action} ↗</b>
              </Link>
            ))}
          </div>

          <div className="contact-layout">
            <div>
              <SectionHeading
                eyebrow="Direct contact"
                title="Prefer to speak with the team?"
                text="Use the published contact details below. Confirm the exact training venue before travelling."
              />

              <div className="contact-details">
                <div>
                  <span>Email</span>
                  <a href={`mailto:${company.email}`}>{company.email}</a>
                </div>
                <div>
                  <span>Phone</span>
                  <a href={`tel:${company.phoneHref}`}>{company.phone}</a>
                </div>

                <div className="office-list">
                  <span>Office addresses (as published on aroushtech.in)</span>
                  {company.offices.map((office) => (
                    <div className="office-item" key={office.label}>
                      <strong>{office.label}</strong>
                      <p>{office.address}</p>
                      <a
                        className="map-link"
                        href={office.mapUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Search this address in Google Maps ↗
                      </a>
                    </div>
                  ))}
                  <p className="office-map-note">
                    Map links search the published office address; they are not
                    a confirmation of a precise entrance or training venue.
                    The Contact page separately refers to a J.P. Nagar training
                    centre, so confirm the exact session location with the
                    team before travelling.
                  </p>
                </div>

                <div>
                  <span>LinkedIn</span>
                  <a href={company.linkedin} target="_blank" rel="noreferrer">
                    Aroush Solutions ↗
                  </a>
                </div>
              </div>
            </div>

            <div id="enquiry-form" className="contact-form-wrap">
              <h2>Prepare your enquiry</h2>
              <p className="contact-form-intro">
                The form adapts to the path you selected. It prepares an email
                for you to review; it does not submit details to a website
                database.
              </p>
              <ContactForm
                initialCourse={enquiry.course}
                initialInterest={enquiry.interest}
                initialType={activeType}
              />
            </div>
          </div>
        </div>
      </section>

      <section className="section section-soft section-padded">
        <div className="container">
          <SectionHeading
            eyebrow="Frequently asked questions"
            title="A few useful details before we talk."
          />
          <div className="faq-list">
            {faqs
              .filter((faq) => contactFaqQuestions.has(faq.q))
              .map((faq) => (
                <details key={faq.q}>
                  <summary>
                    {faq.q}
                    <span>+</span>
                  </summary>
                  <p>{faq.a}</p>
                </details>
              ))}
          </div>
          <p className="faq-more-link">
            <Link href="/faqs" className="arrow-link">
              Read all frequently asked questions <span>↗</span>
            </Link>
          </p>
        </div>
      </section>

      <section className="legal-strip">
        <div className="container">
          <p>
            <strong>{company.legalName}</strong> · CIN {company.cin}
          </p>
          <p>
            Service scope, platform rights, delivery capability, resources and
            commercial terms are confirmed in a written proposal before
            commitment.
          </p>
        </div>
      </section>
    </>
  );
}
