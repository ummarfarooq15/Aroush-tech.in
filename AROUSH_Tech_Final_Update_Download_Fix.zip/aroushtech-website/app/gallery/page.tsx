import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { SectionHeading } from "@/components/section-heading";
import { SourceImage } from "@/components/source-image";
import { gallery } from "@/lib/content";
export const metadata: Metadata = { title: "Training Gallery", description: "View training and corporate learning photographs featured in the AROUSH website gallery.", alternates: { canonical: "/gallery" }, openGraph: { title: "Training Gallery | Aroush Tech", description: "Glimpses from AROUSH technical training and corporate learning sessions.", url: "/gallery" } };

export default function GalleryPage() {
  return <>
    <section className="page-hero"><div className="container"><Breadcrumbs items={[{ label: "Gallery", href: "/gallery" }]} /><p className="eyebrow">Gallery</p><h1>Learning happens<br /><em>by doing.</em></h1><p>A look at practical learning environments and training sessions featured in AROUSH's existing gallery.</p></div></section>
    <section className="section section-padded"><div className="container"><SectionHeading eyebrow="Training moments" title="Glimpses from the learning journey." text="Photographs are sourced from the existing AROUSH website gallery. Captions are descriptive and do not imply a new client endorsement." /><div className="gallery-grid">{gallery.map((item, i) => <figure className={`gallery-item gallery-item-${i + 1}`} key={item.src}><SourceImage src={item.src} alt={item.alt} fallbackLabel="AROUSH training photograph" /><figcaption><span>{item.caption}</span><small>AROUSH training gallery</small></figcaption></figure>)}</div></div></section>
  </>;
}
