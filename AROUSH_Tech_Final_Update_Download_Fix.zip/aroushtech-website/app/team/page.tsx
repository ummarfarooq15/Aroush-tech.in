import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import { SectionHeading } from "@/components/section-heading";
import { SourceImage } from "@/components/source-image";
import { team } from "@/lib/content";
export const metadata: Metadata = { title: "Leadership & Team", description: "Meet the three team members and role titles published on the AROUSH website.", alternates: { canonical: "/team" }, openGraph: { title: "Leadership & Team | Aroush Tech", description: "Leadership across cybersecurity, cloud, networking and corporate training.", url: "/team" } };

export default function TeamPage() {
  return <>
    <section className="page-hero"><div className="container"><Breadcrumbs items={[{ label: "Team", href: "/team" }]} /><p className="eyebrow">People behind the portfolio</p><h1>People behind<br /><em>the learning.</em></h1><p>Meet the team members and technical role holders listed on the AROUSH website.</p></div></section>
    <section className="section section-padded"><div className="container"><SectionHeading eyebrow="Leadership" title="Practical knowledge. Technical depth." text="Names and role titles below follow the current AROUSH About page." /><div className="team-grid">{team.map((person) => <article className="team-card" key={person.name}><div className="team-avatar"><SourceImage src={person.photo} alt={`Portrait of ${person.name}`} fallbackLabel={person.initials} /></div><p className="eyebrow">{person.role}</p><h2>{person.name}</h2><p className="team-role-note">Role title as published on the AROUSH website.</p></article>)}</div></div></section>
    <section className="section section-soft section-padded"><div className="container team-note"><div><p className="eyebrow">A connected team</p><h2>Learning shaped around the needs of the organization.</h2></div><p>For each engagement, trainer or specialist availability, platform competence, access rights and delivery scope are confirmed before commitment.</p></div></section>
  </>;
}
