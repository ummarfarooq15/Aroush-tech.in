import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";
import { notFound } from "next/navigation";
import { courses, company } from "@/lib/content";
import { CoursePrice } from "@/components/course-price";
import { courseDetails } from "@/lib/course-details";

export function generateStaticParams() {
  return courses.map((course) => ({ slug: course.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const course = courses.find((item) => item.slug === slug);
  if (!course) return { title: "Course not found" };
  return {
    title: `${course.title} Training`,
    description: `${course.description} Ask AROUSH to confirm the latest syllabus, prerequisites, schedule, delivery format and fee.`,
    alternates: { canonical: `/courses/${course.slug}` },
    twitter: { card: "summary_large_image" },
    openGraph: {
      title: `${course.title} Training | Aroush Tech`,
      description: course.description,
      url: `/courses/${course.slug}`
    }
  };
}

export default async function CourseDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const course = courses.find((item) => item.slug === slug);
  if (!course) return notFound();
  const detail = courseDetails[course.slug];
  const courseStructuredData = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: course.title,
    description: course.description,
    provider: {
      "@type": "Organization",
      name: company.legalName,
      url: company.website
    }
  };

  return <>
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(courseStructuredData).replace(/</g, "\\u003c") }} />
    <section className="page-hero course-detail-hero">
      <div className="container">
        <Breadcrumbs items={[{ label: "Courses", href: "/courses" }, { label: course.title, href: `/courses/${course.slug}` }]} />
        <p className="eyebrow">{course.category}</p>
        <h1>{course.title}</h1>
        <p>{course.description}</p>
        <div className="hero-actions">
          <Link className="button" href={`/contact?type=learner&interest=${encodeURIComponent("Individual course enquiry")}&course=${encodeURIComponent(course.title)}`}>Ask about this course <span>↗</span></Link>
          <Link className="text-link" href="/courses">Back to all courses <span>→</span></Link>
        </div>
      </div>
    </section>

    <section className="section section-padded">
      <div className="container course-detail-layout">
        <div className="course-detail-main">
          <p className="eyebrow">Course overview</p>
          <h2>What this course covers</h2>
          <p className="large-copy">{course.description}</p>
          {detail?.sourceNote ? <div className="course-outline-pending"><strong>AROUSH-approved syllabus required</strong><p>{detail.sourceNote}</p></div> : detail?.outline?.length ? <>
            <h3 className="course-detail-subheading">Published outline topics</h3>
            <ol className="course-outline-list">{detail.outline.map((topic, index) => <li key={`${course.slug}-${index}`}><span>{String(index + 1).padStart(2, "0")}</span>{topic}</li>)}</ol>
          </> : <div className="course-outline-pending"><strong>Detailed outline to be confirmed</strong><p>The current public catalogue lists this course, but a complete outline has not yet been migrated into this new website. Ask AROUSH for the latest syllabus and prerequisites before enrolment.</p></div>}
          {detail?.prerequisites?.length ? <>
            <h3 className="course-detail-subheading">Recommended prerequisites</h3>
            <ul className="course-prereq-list">{detail.prerequisites.map((item) => <li key={item}>{item}</li>)}</ul>
          </> : null}
          {detail?.delivery ? <div className="course-detail-note"><strong>Delivery information from the published course page</strong><p>{detail.delivery}</p></div> : null}
        </div>

        <aside className="course-detail-aside">
          <p className="eyebrow">Course information</p>
          <h2>{course.title}</h2>
          <p className="course-detail-category">{course.category}</p>
          <CoursePrice previousPrice={course.previousPrice} listedPrice={course.listedPrice} feeNote={course.feeNote} detail />
          {detail?.duration ? <p className="course-meta-row"><span>Published duration</span><strong>{detail.duration}</strong></p> : null}
          <p className="course-meta-row"><span>Outline status</span><strong>{detail?.sourceNote ? "Owner-approved copy required" : detail?.outline?.length ? "Source outline migrated" : "Confirm with AROUSH"}</strong></p>
          <Link className="button button-block" href={`/contact?type=learner&interest=${encodeURIComponent("Individual course enquiry")}&course=${encodeURIComponent(course.title)}`}>Request current details <span>↗</span></Link>
          <p className="course-detail-disclaimer">Fees are copied from the current public course catalogue and are not a final quotation. Confirm current fee, availability, prerequisites, schedule, delivery mode and payment terms directly with AROUSH before payment.</p>
          <p className="course-detail-disclaimer"><strong>Payment safety:</strong> This rebuilt website does not take online course payments. Confirm payment instructions directly with AROUSH using the contact details on this website before paying.</p>
        </aside>
      </div>
    </section>

    <section className="final-cta"><div className="container final-cta-inner"><div><p className="eyebrow eyebrow-light">Need help choosing?</p><h2>Tell us your experience level and what you want to learn.</h2></div><Link href={`/contact?type=learner&interest=${encodeURIComponent("Individual course enquiry")}&course=${encodeURIComponent(course.title)}`} className="button button-light">Talk to AROUSH <span>↗</span></Link></div></section>
  </>;
}
