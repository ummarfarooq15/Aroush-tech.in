import { ImageResponse } from "next/og";
import { courses } from "@/lib/content";
import { SocialCard } from "@/components/social-card";

export const runtime = "edge";
export const alt = "AROUSH Tech course overview";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function CourseTwitterImage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const course = courses.find((item) => item.slug === slug);

  return new ImageResponse(
    (
      <SocialCard
        eyebrow="AROUSH course overview"
        title={course?.title ?? "IT and cybersecurity courses"}
        category={course?.category ?? "Technical learning"}
        description={
          course?.description ??
          "Explore technical learning across networking, cybersecurity, cloud, Linux, automation and AI."
        }
      />
    ),
    size,
  );
}
