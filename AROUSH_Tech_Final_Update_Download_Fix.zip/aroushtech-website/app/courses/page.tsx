import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/breadcrumbs";
import Link from "next/link";
import { SectionHeading } from "@/components/section-heading";
import { courses, socCourses } from "@/lib/content";
import { CourseCatalogue } from "@/components/course-catalogue";
export const metadata: Metadata = {
  title: "IT, Networking & Cybersecurity Courses",
  description: "Explore AROUSH technical learning across networking, cybersecurity, Linux, cloud, automation, AI and SOC/SIEM. Ask about current schedules, prerequisites and fees.",
  alternates: { canonical: "/courses" },
  openGraph: { title: "IT, Networking & Cybersecurity Courses | Aroush Tech", description: "Technical learning across networking, cybersecurity, Linux, cloud, automation, AI and SOC/SIEM.", url: "/courses" }
};

export default function CoursesPage() {
  const aiMlCourse = courses.find((course) => course.slug === "ai-ml");

  return <>
    <section className="page-hero"><div className="container"><Breadcrumbs items={[{ label: "Courses", href: "/courses" }]} /><p className="eyebrow">Learning & development</p><h1>Learn with purpose.<br /><em>Practice with confidence.</em></h1><p>Technical learning across networking, cybersecurity, Linux, cloud, automation and AI—shaped around learner starting points and practical objectives.</p></div></section>
    <section className="section section-padded"><div className="container"><SectionHeading eyebrow="Course catalogue" title="Explore technical learning paths." text="The current public catalogue includes the following course areas. Search and filter the list, then copy a link to share the same view. Ask the team to confirm the latest syllabus, prerequisites, schedule, delivery mode and fees." />
      <div className="learning-path-intro"><p>Prefer to browse by goal rather than course name?</p><Link href="/learning-paths" className="button button-outline">Browse learning paths <span aria-hidden="true">↗</span></Link></div>
      <CourseCatalogue items={courses} />
      <p className="catalog-note">The current AROUSH homepage advertises a free course demo. Ask the team whether a demo is available for your selected course and preferred schedule.</p>
      <p className="catalog-note">Fees shown are copied from the current live AROUSH course catalogue as rechecked on 7 November 2026. They are website-listed amounts, not a final quotation; confirm the current fee, availability and payment terms directly with AROUSH before payment.</p>
    </div></section>
    {aiMlCourse ? <section className="section section-soft section-padded popular-course-section"><div className="container popular-course-card"><div><p className="eyebrow">Highlighted as the most popular course on the current AROUSH website</p><h2>{aiMlCourse.title}</h2><p>AI and machine learning are described on the source page through applications such as virtual assistants, chatbots, self-driving cars and personalized recommendations.</p></div><Link href={`/courses/${aiMlCourse.slug}`} className="button button-outline">Explore AI &amp; ML <span>↗</span></Link></div></section> : null}
    <section className="section section-dark section-padded"><div className="container"><SectionHeading eyebrow="SOC / SIEM learning" title="Hands-on skills for the people doing the work." text="Dedicated learning paths for analysts, administrators and teams developing SOC capability." light /><div className="soc-course-grid">{socCourses.map((course, i) => <article id={course.slug} key={course.title}><div className="soc-course-top"><span>0{i + 1}</span><b>{course.duration}</b></div><h3>{course.title}</h3><p>{course.focus}</p><Link href={`/contact?type=learner&interest=${encodeURIComponent("SOC / SIEM training")}&course=${encodeURIComponent(course.title)}`} className="arrow-link">Enquire about this path <span>↗</span></Link></article>)}</div><p className="scope-note scope-note-dark">Official vendor certification, exam vouchers, regulatory approval and placement are not implied. Assessment, lab access and course prerequisites are agreed for each programme.</p></div></section>
    <section className="final-cta"><div className="container final-cta-inner"><div><p className="eyebrow eyebrow-light">Choose your next step</p><h2>Tell us what you want to learn—and where you want to apply it.</h2></div><div className="final-cta-actions"><Link href="/contact?type=learner" className="button button-light">Individual learner enquiry <span>↗</span></Link><Link href="/contact?type=business" className="text-link text-link-light">Business / institution enquiry <span>→</span></Link></div></div></section>
  </>;
}
