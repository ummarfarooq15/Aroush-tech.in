-- AROUSH Tech Visitor Intelligence
-- Fresh-project schema. Run this in a new Supabase project before deploying the app.
-- Browser clients never access these tables directly; server-only credentials are used.

create extension if not exists pgcrypto;

-- Aggregate analytics only. session_key is an HMAC of a random, tab-scoped token.
-- It cannot be used to recognise a person across browser sessions or devices.
create table if not exists public.visitor_events (
  id uuid primary key default gen_random_uuid(),
  site_id text not null,
  session_key text not null,
  event_name text not null check (event_name in ('page_view', 'page_time')),
  path text not null,
  referrer text,
  source text,
  medium text,
  campaign text,
  browser text,
  os text,
  device text,
  country text,
  region text,
  city text,
  duration_seconds integer check (duration_seconds is null or duration_seconds between 0 and 1800),
  is_bot boolean not null default false,
  consent_version text not null default '2026-11',
  created_at timestamptz not null default now()
);

create index if not exists visitor_events_site_created_idx
  on public.visitor_events (site_id, created_at desc);
create index if not exists visitor_events_site_event_idx
  on public.visitor_events (site_id, event_name, created_at desc);
create index if not exists visitor_events_site_session_idx
  on public.visitor_events (site_id, session_key, created_at desc);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  site_id text not null,
  name text not null,
  email text not null,
  phone text not null,
  company text,
  interest text,
  message text,
  email_verified_at timestamptz not null,
  phone_verified_at timestamptz not null,
  contact_consent_at timestamptz not null,
  contact_consent_version text not null default '2026-11-v1',
  status text not null default 'new',
  source text not null default 'direct',
  created_at timestamptz not null default now()
);

create index if not exists leads_site_created_idx
  on public.leads (site_id, created_at desc);

create table if not exists public.lead_verifications (
  channel text not null check (channel in ('email', 'phone')),
  identifier text not null,
  otp_hash text,
  provider_request_id text,
  expires_at timestamptz not null,
  last_sent_at timestamptz not null,
  attempts integer not null default 0 check (attempts >= 0),
  verified_at timestamptz,
  verification_token uuid,
  verification_started_at timestamptz,
  created_at timestamptz not null default now(),
  primary key (channel, identifier)
);

create index if not exists lead_verifications_expiry_idx
  on public.lead_verifications (expires_at);

-- Atomic API rate limiting. Raw IP addresses, email addresses and phone numbers are never keys.
create table if not exists public.api_rate_limits (
  rate_key text primary key,
  window_started_at timestamptz not null default now(),
  request_count integer not null default 0
);

-- Server-side only: direct browser roles have no table access.
alter table public.visitor_events enable row level security;
alter table public.leads enable row level security;
alter table public.lead_verifications enable row level security;
alter table public.api_rate_limits enable row level security;

revoke all on public.visitor_events from anon, authenticated;
revoke all on public.leads from anon, authenticated;
revoke all on public.lead_verifications from anon, authenticated;
revoke all on public.api_rate_limits from anon, authenticated;

grant all on public.visitor_events to service_role;
grant all on public.leads to service_role;
grant all on public.lead_verifications to service_role;
grant all on public.api_rate_limits to service_role;

create or replace function public.consume_rate_limit(
  p_key text, p_limit integer, p_window_seconds integer
) returns boolean
language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  current_count integer;
begin
  insert into public.api_rate_limits(rate_key, window_started_at, request_count)
  values (p_key, now(), 1)
  on conflict (rate_key) do update set
    window_started_at = case
      when api_rate_limits.window_started_at <= now() - make_interval(secs => p_window_seconds) then now()
      else api_rate_limits.window_started_at end,
    request_count = case
      when api_rate_limits.window_started_at <= now() - make_interval(secs => p_window_seconds) then 1
      else api_rate_limits.request_count + 1 end
  returning request_count into current_count;
  return current_count <= p_limit;
end;
$$;

-- Atomically reserve an OTP send and enforce the per-recipient cooldown across all IPs.
create or replace function public.reserve_lead_verification(
  p_channel text,
  p_identifier text,
  p_otp_hash text,
  p_expires_at timestamptz,
  p_cooldown_seconds integer default 60
) returns boolean
language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  reserved boolean := false;
begin
  if p_channel not in ('email', 'phone') then return false; end if;
  insert into public.lead_verifications (
    channel, identifier, otp_hash, provider_request_id, expires_at,
    last_sent_at, attempts, verified_at, verification_token, verification_started_at
  ) values (
    p_channel, p_identifier, p_otp_hash, null, p_expires_at,
    now(), 0, null, null, null
  )
  on conflict (channel, identifier) do update set
    otp_hash = excluded.otp_hash,
    provider_request_id = null,
    expires_at = excluded.expires_at,
    last_sent_at = now(),
    attempts = 0,
    verified_at = null,
    verification_token = null,
    verification_started_at = null
  where lead_verifications.last_sent_at <= now() - make_interval(secs => p_cooldown_seconds)
  returning true into reserved;
  return coalesce(reserved, false);
end;
$$;

-- The server compares the submitted code with the stored HMAC, then this RPC
-- locks the row and atomically records either a failed attempt or one-time success.
create or replace function public.verify_email_otp_atomic(
  p_identifier text,
  p_expected_hash text,
  p_is_correct boolean
) returns text
language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  challenge public.lead_verifications%rowtype;
begin
  select * into challenge
  from public.lead_verifications
  where channel = 'email' and identifier = p_identifier
  for update;

  if not found then return 'missing'; end if;
  if challenge.verified_at is not null then return 'already_verified'; end if;
  if challenge.expires_at <= now() then return 'expired'; end if;
  if challenge.attempts >= 5 then return 'locked'; end if;
  if challenge.otp_hash is distinct from p_expected_hash then return 'stale'; end if;

  if not p_is_correct then
    update public.lead_verifications
    set attempts = attempts + 1
    where channel = 'email' and identifier = p_identifier;
    if challenge.attempts + 1 >= 5 then return 'locked'; end if;
    return 'invalid';
  end if;

  update public.lead_verifications
  set verified_at = now(), otp_hash = null,
      verification_token = null, verification_started_at = null
  where channel = 'email' and identifier = p_identifier;
  return 'verified';
end;
$$;

-- Reserve a single in-flight MSG91 verification so parallel requests cannot
-- race the provider and consume the same challenge more than once.
create or replace function public.begin_phone_otp_verification(
  p_identifier text
) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  challenge public.lead_verifications%rowtype;
  new_token uuid;
begin
  select * into challenge
  from public.lead_verifications
  where channel = 'phone' and identifier = p_identifier
  for update;

  if not found then return jsonb_build_object('status', 'missing'); end if;
  if challenge.verified_at is not null then return jsonb_build_object('status', 'already_verified'); end if;
  if challenge.expires_at <= now() then return jsonb_build_object('status', 'expired'); end if;
  if challenge.attempts >= 5 then return jsonb_build_object('status', 'locked'); end if;
  if challenge.verification_started_at is not null
     and challenge.verification_started_at > now() - interval '90 seconds' then
    return jsonb_build_object('status', 'in_progress');
  end if;

  new_token := gen_random_uuid();
  update public.lead_verifications
  set attempts = attempts + 1,
      verification_token = new_token,
      verification_started_at = now()
  where channel = 'phone' and identifier = p_identifier;

  return jsonb_build_object('status', 'ready', 'token', new_token);
end;
$$;

create or replace function public.finish_phone_otp_verification(
  p_identifier text,
  p_token uuid,
  p_result text
) returns text
language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  affected integer;
begin
  if p_result not in ('success', 'invalid', 'error') then return 'invalid_result'; end if;

  update public.lead_verifications
  set verified_at = case when p_result = 'success' then now() else null end,
      attempts = case when p_result = 'error' then greatest(attempts - 1, 0) else attempts end,
      verification_token = null,
      verification_started_at = null
  where channel = 'phone'
    and identifier = p_identifier
    and verification_token = p_token
    and expires_at > now()
    and verified_at is null;

  get diagnostics affected = row_count;
  if affected = 0 then return 'stale'; end if;
  if p_result = 'success' then return 'verified'; end if;
  if p_result = 'invalid' then return 'invalid'; end if;
  return 'retry';
end;
$$;

-- Atomically consume both verified challenges and create one lead.
drop function if exists public.create_verified_lead(text, text, text, text, text, text, text, text);
create or replace function public.create_verified_lead(
  p_site_id text,
  p_name text,
  p_email text,
  p_phone text,
  p_company text,
  p_interest text,
  p_message text,
  p_source text,
  p_consent_version text
) returns jsonb
language plpgsql security definer set search_path = pg_catalog, public as $$
declare
  email_challenge public.lead_verifications%rowtype;
  phone_challenge public.lead_verifications%rowtype;
  new_lead_id uuid;
begin
  select * into email_challenge
  from public.lead_verifications
  where channel = 'email' and identifier = p_email
  for update;
  if not found then return jsonb_build_object('status', 'email_not_verified'); end if;

  select * into phone_challenge
  from public.lead_verifications
  where channel = 'phone' and identifier = p_phone
  for update;
  if not found then return jsonb_build_object('status', 'phone_not_verified'); end if;

  if email_challenge.verified_at is null or email_challenge.expires_at <= now() then
    return jsonb_build_object('status', 'email_not_verified');
  end if;
  if phone_challenge.verified_at is null or phone_challenge.expires_at <= now() then
    return jsonb_build_object('status', 'phone_not_verified');
  end if;

  insert into public.leads (
    site_id, name, email, phone, company, interest, message,
    email_verified_at, phone_verified_at, contact_consent_at, contact_consent_version,
    status, source, created_at
  ) values (
    p_site_id, p_name, p_email, p_phone, p_company, p_interest, p_message,
    email_challenge.verified_at, phone_challenge.verified_at, now(), coalesce(p_consent_version, '2026-11-v1'),
    'new', p_source, now()
  ) returning id into new_lead_id;

  delete from public.lead_verifications
  where (channel = 'email' and identifier = p_email)
     or (channel = 'phone' and identifier = p_phone);

  return jsonb_build_object('status', 'created', 'lead_id', new_lead_id);
end;
$$;

-- Only the server's service role may execute privileged functions.
revoke all on function public.consume_rate_limit(text, integer, integer) from public, anon, authenticated;
revoke all on function public.reserve_lead_verification(text, text, text, timestamptz, integer) from public, anon, authenticated;
revoke all on function public.verify_email_otp_atomic(text, text, boolean) from public, anon, authenticated;
revoke all on function public.begin_phone_otp_verification(text) from public, anon, authenticated;
revoke all on function public.finish_phone_otp_verification(text, uuid, text) from public, anon, authenticated;
revoke all on function public.create_verified_lead(text, text, text, text, text, text, text, text, text) from public, anon, authenticated;

grant execute on function public.consume_rate_limit(text, integer, integer) to service_role;
grant execute on function public.reserve_lead_verification(text, text, text, timestamptz, integer) to service_role;
grant execute on function public.verify_email_otp_atomic(text, text, boolean) to service_role;
grant execute on function public.begin_phone_otp_verification(text) to service_role;
grant execute on function public.finish_phone_otp_verification(text, uuid, text) to service_role;
grant execute on function public.create_verified_lead(text, text, text, text, text, text, text, text, text) to service_role;

-- No retention schedule is activated by this schema. Owner-approved retention
-- periods and a scheduled cleanup job must be configured before production.
