-- DEVELOPMENT-ONLY MIGRATION FROM THE EARLIER VISITOR-PROFILE DRAFT.
-- Take a database backup first. This deliberately deletes old visitor-level
-- analytics and stale OTP/rate-limit state. Existing lead records are retained.

begin;

-- Remove the previous persistent visitor profiles and per-event visitor/session IDs.
drop table if exists public.visitor_profiles;
drop table if exists public.visitor_events;

-- Old rate-limit hashes used a different key scheme; clear them before switching to HMAC.
do $$
begin
  if to_regclass('public.api_rate_limits') is not null then
    execute 'truncate table public.api_rate_limits';
  end if;
  if to_regclass('public.lead_verifications') is not null then
    execute 'delete from public.lead_verifications';
  end if;
end
$$;

-- Add the new verification lock fields and version the contact-consent copy.
alter table if exists public.lead_verifications
  add column if not exists verification_token uuid;
alter table if exists public.lead_verifications
  add column if not exists verification_started_at timestamptz;
alter table if exists public.leads
  add column if not exists contact_consent_version text not null default '2026-11-v1';

-- The new atomic lead RPC has an additional consent-version parameter.
drop function if exists public.create_verified_lead(text, text, text, text, text, text, text, text);

commit;

-- After this migration, run ../schema.sql to create the aggregate-only events
-- table and the current server-only RPC functions. Do not use this migration
-- on a production database without an owner-approved backup/retention plan.
