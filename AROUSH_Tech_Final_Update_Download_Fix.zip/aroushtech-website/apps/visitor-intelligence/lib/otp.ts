import { createHmac, randomInt, timingSafeEqual } from "node:crypto";

export function createEmailOtp(): string {
  return String(randomInt(100000, 1000000));
}

export function hashEmailOtp(email: string, code: string): string {
  const pepper = process.env.OTP_PEPPER;
  if (!pepper || pepper.length < 24) throw new Error("OTP_PEPPER must contain at least 24 characters.");
  return createHmac("sha256", pepper).update(`${email.toLowerCase()}:${code}`).digest("hex");
}

export function safeHashCompare(actual: string, expected: string): boolean {
  const a = Buffer.from(actual, "hex");
  const b = Buffer.from(expected, "hex");
  return a.length === b.length && timingSafeEqual(a, b);
}

export function normalizeEmail(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const email = value.trim().toLowerCase();
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}

export function normalizePhone(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const phone = value.replace(/[\s()-]/g, "");
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) return null;
  return phone;
}

export function validText(value: unknown, maxLength: number): string | null {
  if (typeof value !== "string") return null;
  const text = value.trim();
  return text.length > 0 && text.length <= maxLength ? text : null;
}
