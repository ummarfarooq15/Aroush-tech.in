import { createHmac } from "node:crypto";
import { supabaseAdmin } from "@/lib/supabase-admin";

function clientAddress(request: Request): string {
  // Trust only the hosting platform's overwritten header. Do not trust arbitrary X-Forwarded-For values.
  return request.headers.get("x-vercel-forwarded-for")?.split(",")[0]?.trim() || "unknown";
}

export async function enforceRateLimit(
  request: Request,
  scope: string,
  limit: number,
  windowSeconds: number,
  subject = "",
  subjectOnly = false
): Promise<boolean> {
  const pepper = process.env.RATE_LIMIT_PEPPER;
  if (!pepper || pepper.length < 24) {
    console.error("RATE_LIMIT_PEPPER must contain at least 24 characters.");
    return false;
  }
  const material = subjectOnly
    ? `${scope}:${subject}`
    : `${scope}:${clientAddress(request)}:${subject}`;
  const key = createHmac("sha256", pepper).update(material).digest("hex");
  try {
    const { data, error } = await supabaseAdmin().rpc("consume_rate_limit", {
      p_key: key,
      p_limit: limit,
      p_window_seconds: windowSeconds
    });
    if (error) throw error;
    return data === true;
  } catch (error) {
    console.error("Rate-limit check failed closed:", error);
    return false;
  }
}
