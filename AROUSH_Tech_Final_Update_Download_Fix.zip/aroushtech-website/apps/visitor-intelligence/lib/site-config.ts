export function allowedSiteIds(): string[] {
  return (process.env.ALLOWED_SITE_IDS || "aroush-existing,aroush-new")
    .split(",")
    .map((value: string) => value.trim())
    .filter(Boolean);
}

export function isAllowedSiteId(siteId: unknown): siteId is string {
  return typeof siteId === "string" && allowedSiteIds().includes(siteId);
}

export function defaultSiteId(): string {
  const fallback = allowedSiteIds()[0] || "aroush-existing";
  const configured = process.env.DEFAULT_SITE_ID;
  return configured && isAllowedSiteId(configured) ? configured : fallback;
}
