import { createHmac, timingSafeEqual } from "node:crypto";

const COOKIE_NAME = "aroush_admin_session";
const SESSION_SECONDS = 60 * 60 * 4;

function sign(value: string): string {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error("ADMIN_SESSION_SECRET must contain at least 32 characters.");
  }
  return createHmac("sha256", secret).update(value).digest("base64url");
}

function safeEqual(left: string, right: string): boolean {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function verifyAdminCredentials(email: string, password: string): boolean {
  const expectedEmail = process.env.ADMIN_EMAIL || "";
  const expectedPassword = process.env.ADMIN_PASSWORD || "";
  if (!expectedEmail || !expectedPassword) return false;
  return safeEqual(email.trim().toLowerCase(), expectedEmail.trim().toLowerCase()) &&
    safeEqual(password, expectedPassword);
}

export function createAdminCookie(): string {
  const email = process.env.ADMIN_EMAIL || "";
  const expires = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const payload = `${expires}.${Buffer.from(email).toString("base64url")}`;
  const token = `${payload}.${sign(payload)}`;
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${SESSION_SECONDS}${secure}`;
}

export function clearAdminCookie(): string {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure}`;
}

export function isAdminRequest(request: Request): boolean {
  try {
    const rawCookie = request.headers.get("cookie") || "";
    const pair = rawCookie.split(";").map((part) => part.trim())
      .find((part) => part.startsWith(`${COOKIE_NAME}=`));
    if (!pair) return false;
    const token = pair.slice(COOKIE_NAME.length + 1);
    const [expiresRaw, emailEncoded, signature] = token.split(".");
    if (!expiresRaw || !emailEncoded || !signature) return false;
    const payload = `${expiresRaw}.${emailEncoded}`;
    if (!safeEqual(signature, sign(payload))) return false;
    const expires = Number(expiresRaw);
    const email = Buffer.from(emailEncoded, "base64url").toString("utf8");
    return Number.isFinite(expires) && expires > Date.now() / 1000 &&
      email.toLowerCase() === (process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  } catch {
    return false;
  }
}
