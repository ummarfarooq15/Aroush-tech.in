const SITEVERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify";

type SiteverifyResponse = {
  success?: boolean;
  hostname?: string;
};

export async function verifyTurnstile(request: Request, token: unknown): Promise<boolean> {
  const secret = process.env.TURNSTILE_SECRET_KEY;

  // Local development can run without a Cloudflare account. Production fails closed.
  if (!secret) return process.env.NODE_ENV !== "production";
  if (typeof token !== "string" || token.length < 10 || token.length > 2048) return false;

  const origin = request.headers.get("origin");
  if (!origin) return false;

  let expectedHostname: string;
  try {
    expectedHostname = new URL(origin).hostname.toLowerCase();
  } catch {
    return false;
  }

  try {
    const response = await fetch(SITEVERIFY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ secret, response: token }),
      signal: AbortSignal.timeout(8_000)
    });
    const result = await response.json().catch(() => ({})) as SiteverifyResponse;
    return response.ok && result.success === true &&
      typeof result.hostname === "string" && result.hostname.toLowerCase() === expectedHostname;
  } catch (error) {
    console.error("Turnstile verification failed:", error);
    return false;
  }
}
