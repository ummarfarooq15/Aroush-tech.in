const SAFE_METHODS = "GET, POST, OPTIONS";
const SAFE_HEADERS = "Content-Type, Authorization";

export function originIsAllowed(origin: string | null): boolean {
  if (!origin) return false; // Browser-facing APIs require an explicit allowlisted origin.
  const configured = (process.env.ALLOWED_ORIGINS || "")
    .split(",")
    .map((item: string) => item.trim().replace(/\/$/, ""))
    .filter(Boolean);
  return configured.includes(origin.replace(/\/$/, ""));
}

export function corsHeaders(request: Request): HeadersInit {
  const origin = request.headers.get("origin");
  const headers: Record<string, string> = {
    "Access-Control-Allow-Methods": SAFE_METHODS,
    "Access-Control-Allow-Headers": SAFE_HEADERS,
    "Access-Control-Max-Age": "600",
    Vary: "Origin"
  };
  if (origin && originIsAllowed(origin)) {
    headers["Access-Control-Allow-Origin"] = origin;
  }
  return headers;
}

export function jsonWithCors(request: Request, body: unknown, status = 200): Response {
  return Response.json(body, { status, headers: corsHeaders(request) });
}

export function optionsResponse(request: Request): Response {
  return new Response(null, { status: 204, headers: corsHeaders(request) });
}
