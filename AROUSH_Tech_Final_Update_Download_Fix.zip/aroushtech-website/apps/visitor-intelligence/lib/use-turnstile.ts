"use client";

import { useCallback, useEffect, useRef, useState } from "react";

type TurnstileApi = {
  ready(callback: () => void): void;
  render(container: HTMLElement, options: {
    sitekey: string;
    execution: "execute";
    appearance: "interaction-only";
    callback(token: string): void;
    "error-callback"(): void;
    "expired-callback"(): void;
  }): string;
  execute(widgetId: string): void;
  reset(widgetId: string): void;
  remove(widgetId: string): void;
};

declare global {
  interface Window {
    turnstile?: TurnstileApi;
  }
}

export function useTurnstileToken() {
  const siteKey = process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || "";
  const [ready, setReady] = useState(false);
  const [loadError, setLoadError] = useState("");
  const containerRef = useRef<HTMLDivElement | null>(null);
  const widgetIdRef = useRef<string | null>(null);
  const pendingRef = useRef<{ resolve: (token: string) => void; reject: (error: Error) => void } | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (!siteKey || !containerRef.current) return;

    let cancelled = false;
    const scriptUrl = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
    let script = document.querySelector<HTMLScriptElement>(`script[src="${scriptUrl}"]`);

    const renderWidget = () => {
      if (cancelled || !containerRef.current || !window.turnstile || widgetIdRef.current) return;
      window.turnstile.ready(() => {
        if (cancelled || !containerRef.current || !window.turnstile) return;
        widgetIdRef.current = window.turnstile.render(containerRef.current, {
          sitekey: siteKey,
          execution: "execute",
          appearance: "interaction-only",
          callback: (token) => {
            if (timeoutRef.current) clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
            const pending = pendingRef.current;
            pendingRef.current = null;
            pending?.resolve(token);
            if (widgetIdRef.current && window.turnstile) window.turnstile.reset(widgetIdRef.current);
          },
          "error-callback": () => {
            if (timeoutRef.current) clearTimeout(timeoutRef.current);
            timeoutRef.current = null;
            pendingRef.current?.reject(new Error("Human verification could not be completed. Please try again."));
            pendingRef.current = null;
          },
          "expired-callback": () => {
            pendingRef.current?.reject(new Error("Human verification expired. Please try again."));
            pendingRef.current = null;
          }
        });
        setReady(true);
      });
    };

    if (!script) {
      script = document.createElement("script");
      script.src = scriptUrl;
      script.async = true;
      script.defer = true;
      script.onload = renderWidget;
      script.onerror = () => setLoadError("Human verification could not load. Check your connection and try again.");
      document.head.appendChild(script);
    } else if (window.turnstile) {
      renderWidget();
    } else {
      script.addEventListener("load", renderWidget, { once: true });
    }

    return () => {
      cancelled = true;
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      pendingRef.current?.reject(new Error("Human verification was cancelled."));
      pendingRef.current = null;
      if (widgetIdRef.current && window.turnstile) window.turnstile.remove(widgetIdRef.current);
      widgetIdRef.current = null;
    };
  }, [siteKey]);

  const getToken = useCallback(async (): Promise<string> => {
    if (!siteKey) {
      if (process.env.NODE_ENV !== "production") return "";
      throw new Error("Human verification is not configured. Please contact the Aroush Tech team.");
    }
    if (!ready || !widgetIdRef.current || !window.turnstile) {
      throw new Error(loadError || "Human verification is still loading. Please try again.");
    }
    if (pendingRef.current) throw new Error("Human verification is already running.");

    return new Promise((resolve, reject) => {
      pendingRef.current = { resolve, reject };
      timeoutRef.current = setTimeout(() => {
        pendingRef.current?.reject(new Error("Human verification timed out. Please try again."));
        pendingRef.current = null;
        timeoutRef.current = null;
        if (widgetIdRef.current && window.turnstile) window.turnstile.reset(widgetIdRef.current);
      }, 120_000);
      window.turnstile?.execute(widgetIdRef.current!);
    });
  }, [loadError, ready, siteKey]);

  return { containerRef, getToken, ready: ready || (!siteKey && process.env.NODE_ENV !== "production"), loadError };
}
