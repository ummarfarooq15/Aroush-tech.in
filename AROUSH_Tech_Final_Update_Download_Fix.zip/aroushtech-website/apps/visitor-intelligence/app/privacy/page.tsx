import Link from "next/link";

export default function PrivacyPage() {
  return <main className="privacy-page-shell">
    <header className="lead-topbar"><Link href="/" className="brand-mark"><span className="brand-symbol">A</span><span>AR<strong>OUSH</strong> TECH</span></Link><Link href="/lead" className="text-button">Contact Aroush Tech →</Link></header>
    <article className="privacy-document">
      <div className="eyebrow">PRIVACY NOTICE · DEVELOPMENT DRAFT</div>
      <h1>Privacy & visitor analytics notice</h1>
      <p className="privacy-updated">Draft for owner and legal review · 7 November 2026</p>
      <p>This is a development draft, not an approved public privacy notice. Aroush Tech must replace the privacy contact placeholder, approve the retention schedule and obtain qualified legal review before enabling this service for public visitors.</p>
      <h2>1. Optional aggregate analytics</h2>
      <p>Analytics starts only after you choose “Accept analytics” in the consent banner. Rejecting optional analytics does not affect your ability to use the website. A persistent Privacy control lets you reopen the choice and withdraw permission. No analytics request is sent before acceptance.</p>
      <h2>2. Analytics information</h2>
      <p>After consent, the tracker may process query-free page paths, approximate active page time, referral source, non-personal campaign labels, browser family, operating system, device category and approximate city, region or country when supplied by the hosting platform. A random token exists only in the current browser tab and is HMAC-hashed on the server to group events within that temporary tab session. It is not a persistent visitor ID and is not used to recognise returning people or link sessions across devices.</p>
      <h2>3. Information excluded from analytics</h2>
      <p>The analytics system does not store raw or masked IP addresses, persistent visitor profiles, screen dimensions, language, timezone, precise GPS, device fingerprints, keystrokes, form contents, passwords, contact lists or files. Dashboard analytics are aggregate breakdowns only; individual visitor journeys and session keys are not shown.</p>
      <h2>4. Enquiry form and verification</h2>
      <p>If you choose to submit an enquiry, the form asks you to provide your name, email address, mobile number, optional company name, area of interest and message. These details are used only to respond to the enquiry. Email and mobile verification are required before the enquiry is saved. The phone number is collected only when you voluntarily enter it in the clearly described form. If you do not want to provide a mobile number, the main AROUSH contact page offers an alternative form where phone is optional. Marketing messages require separate permission. Lead details are stored separately from aggregate analytics and are visible only to authorised administrators.</p>
      <h2>5. Service providers and security</h2>
      <p>The planned providers are Supabase for server-side database storage, Vercel for application hosting, Resend for email verification, MSG91 for SMS verification and Cloudflare Turnstile for bot protection. Provider configuration, data-processing terms, ownership and any international processing must be reviewed by Aroush Tech before launch. Server credentials must remain in private deployment environment variables.</p>
      <h2>6. Retention and your choices</h2>
      <p>Retention periods are not yet approved or configured. Aroush Tech must define and implement deletion periods for aggregate analytics events, enquiries, OTP challenges and hashed rate-limit records before public launch. You may reject or withdraw optional analytics through the banner or persistent Privacy control. For access, correction or deletion requests about an enquiry, contact the official privacy contact once it is published.</p>
      <h2>7. Contact</h2>
      <p>Privacy contact: <strong>[Add Aroush Tech's official monitored privacy email before launch]</strong>.</p>
      <p className="privacy-disclaimer">This technical draft is not legal advice and does not claim legal compliance. Aroush Tech must confirm its purposes, lawful basis/consent wording, retention periods, provider contracts, data-subject request process and applicable Indian DPDP and other jurisdictional requirements before publication.</p>
      <Link href="/" className="button button-quiet">← Back to Aroush Tech</Link>
    </article>
  </main>;
}
