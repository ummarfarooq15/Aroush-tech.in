import Link from "next/link";

export default function HomePage() {
  return (
    <main className="landing-shell">
      <nav className="landing-nav">
        <Link href="/" className="brand-mark"><span className="brand-symbol">A</span><span>AR<strong>OUSH</strong> TECH</span></Link>
        <div className="nav-actions"><Link className="nav-link" href="/lead">Open enquiry form</Link><Link className="button button-primary" href="/login">Admin sign in <span>↗</span></Link></div>
      </nav>
      <section className="landing-hero">
        <div className="eyebrow"><span className="pulse-dot"/> VISITOR INTELLIGENCE · DEVELOPMENT PREVIEW</div>
        <h1>Understand your traffic.<br/><span>Convert real enquiries.</span></h1>
        <p className="landing-subtitle">A consent-based aggregate analytics and verified enquiry platform being prepared for Aroush Tech. This preview is not deployed or connected to the live website.</p>
        <div className="hero-actions"><Link className="button button-primary" href="/login">Open dashboard <span>→</span></Link><Link className="button button-quiet" href="/lead">View verified enquiry flow</Link></div>
        <div className="hero-proof"><span>● Consent-first tracking</span><span>● Email OTP</span><span>● SMS OTP</span><span>● Development preview</span></div>
      </section>
      <section className="landing-grid">
        <article className="feature-card"><div className="feature-icon" aria-hidden="true">◉</div><h3>Aggregate visitor insights</h3><p>Report aggregate page views, visit time, device/browser, traffic sources and approximate geography after explicit analytics consent. No persistent visitor profiles.</p></article>
        <article className="feature-card"><div className="feature-icon" aria-hidden="true">⌁</div><h3>Verified leads</h3><p>Collect contact details only when people submit the enquiry form, then verify email and mobile by OTP.</p></article>
        <article className="feature-card"><div className="feature-icon" aria-hidden="true">◇</div><h3>Separate site reporting</h3><p>Separate reporting labels for the existing and redesigned Aroush Tech websites, once each site is deliberately connected.</p></article>
      </section>
      <footer className="landing-footer"><span>AROUSHTECH.IN · VISITOR INTELLIGENCE</span><span>Privacy-first by design</span></footer>
    </main>
  );
}
