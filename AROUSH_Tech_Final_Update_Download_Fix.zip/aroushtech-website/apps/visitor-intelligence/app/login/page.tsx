"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTurnstileToken } from "@/lib/use-turnstile";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const turnstile = useTurnstileToken();

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const turnstileToken = await turnstile.getToken();
      const response = await fetch("/api/admin/login", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, turnstileToken })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Sign in failed.");
      router.replace("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    } finally {
      setBusy(false);
    }
  }

  return <main className="auth-shell">
    <Link href="/" className="brand-mark"><span className="brand-symbol">A</span><span>AR<strong>OUSH</strong> TECH</span></Link>
    <section className="auth-card">
      <div className="eyebrow"><span className="pulse-dot"/> SECURE ADMIN ACCESS</div>
      <h1>Welcome back.</h1>
      <p>Sign in to your visitor intelligence dashboard.</p>
      <form onSubmit={submit} className="stack-form">
        <label>Email address<input type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin@aroushtech.in"/></label>
        <label>Password<input type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your admin password"/></label>
        <div ref={turnstile.containerRef} className="turnstile-container" aria-label="Human verification" />
        {turnstile.loadError && <div className="form-error" role="alert">{turnstile.loadError}</div>}
        {!turnstile.ready && <div className="form-error" role="alert">Human verification is loading or has not been configured yet.</div>}
        {error && <div className="form-error" role="alert">{error}</div>}
        <button className="button button-primary button-full" disabled={busy || !turnstile.ready}>{busy ? "Signing in…" : "Sign in securely"} <span>→</span></button>
      </form>
      <div className="auth-note">Admin credentials are stored as server environment variables, not in the website code.</div>
    </section>
  </main>;
}
