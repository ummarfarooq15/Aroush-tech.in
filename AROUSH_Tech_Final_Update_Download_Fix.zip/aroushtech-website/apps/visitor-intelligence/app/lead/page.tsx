"use client";

import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";
import { useTurnstileToken } from "@/lib/use-turnstile";

export default function LeadPage() {
  const [siteId, setSiteId] = useState("aroush-existing");
  const [source, setSource] = useState("direct");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("+91");
  const [company, setCompany] = useState("");
  const [interest, setInterest] = useState("Cybersecurity training");
  const [message, setMessage] = useState("");
  const [emailCode, setEmailCode] = useState("");
  const [phoneCode, setPhoneCode] = useState("");
  const [emailSent, setEmailSent] = useState(false);
  const [phoneSent, setPhoneSent] = useState(false);
  const [emailVerified, setEmailVerified] = useState(false);
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [contactConsent, setContactConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [messageText, setMessageText] = useState("");
  const [success, setSuccess] = useState(false);
  const turnstile = useTurnstileToken();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const requested = params.get("site");
    if (requested === "aroush-new" || requested === "aroush-existing") setSiteId(requested);
    const utmSource = params.get("utm_source");
    setSource(utmSource || (document.referrer ? "referral" : "direct"));
  }, []);

  async function callApi(path: string, body: Record<string, unknown>, protectWithHumanCheck = false) {
    const turnstileToken = protectWithHumanCheck ? await turnstile.getToken() : "";
    const response = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...body, ...(protectWithHumanCheck ? { turnstileToken } : {}) }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Request failed.");
    return data;
  }

  async function sendEmailOtp() {
    setBusy(true); setMessageText("");
    try { await callApi("/api/lead/email/send", { email }, true); setEmailSent(true); setEmailVerified(false); setEmailCode(""); setMessageText("Email verification code sent."); }
    catch (error) { setMessageText(error instanceof Error ? error.message : "Could not send email code."); }
    finally { setBusy(false); }
  }
  async function verifyEmailOtp() {
    setBusy(true); setMessageText("");
    try { await callApi("/api/lead/email/verify", { email, code: emailCode }); setEmailVerified(true); setMessageText("Email address verified."); }
    catch (error) { setMessageText(error instanceof Error ? error.message : "Email verification failed."); }
    finally { setBusy(false); }
  }
  async function sendPhoneOtp() {
    setBusy(true); setMessageText("");
    try { await callApi("/api/lead/phone/send", { phone }, true); setPhoneSent(true); setPhoneVerified(false); setPhoneCode(""); setMessageText("SMS verification code sent."); }
    catch (error) { setMessageText(error instanceof Error ? error.message : "Could not send SMS code."); }
    finally { setBusy(false); }
  }
  async function verifyPhoneOtp() {
    setBusy(true); setMessageText("");
    try { await callApi("/api/lead/phone/verify", { phone, code: phoneCode }); setPhoneVerified(true); setMessageText("Mobile number verified."); }
    catch (error) { setMessageText(error instanceof Error ? error.message : "Mobile verification failed."); }
    finally { setBusy(false); }
  }
  async function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessageText("");
    try {
      await callApi("/api/lead/submit", { siteId, name, email, phone, company, interest, message, contactConsent, source }, true);
      setSuccess(true);
    } catch (error) { setMessageText(error instanceof Error ? error.message : "Could not submit enquiry."); }
    finally { setBusy(false); }
  }

  if (success) return <main className="lead-shell"><section className="lead-card success-card"><div className="success-symbol">✓</div><div className="eyebrow">ENQUIRY RECEIVED</div><h1>Thank you, {name.split(" ")[0] || "there"}.</h1><p>Your contact details were verified and your enquiry has been securely recorded. The Aroush Tech team can follow up using the details you provided.</p><Link className="button button-primary" href="/">Back to Aroush Tech</Link></section></main>;

  return <main className="lead-shell">
    <div className="lead-topbar"><Link href="/" className="brand-mark"><span className="brand-symbol">A</span><span>AR<strong>OUSH</strong> TECH</span></Link><span className="secure-label"><span className="pulse-dot"/> SECURE ENQUIRY</span></div>
    <div className="lead-wrap">
      <div className="lead-intro"><div className="eyebrow">LET'S TALK ABOUT YOUR GOALS</div><h1>Start a conversation<br/><span>with our team.</span></h1><p>Share your requirements. To help prevent spam and protect your contact details, we verify both your email address and mobile number.</p><div className="verification-steps"><span className={emailVerified ? "step done" : "step"}><b>{emailVerified ? "✓" : "01"}</b>Email OTP</span><span className={phoneVerified ? "step done" : "step"}><b>{phoneVerified ? "✓" : "02"}</b>SMS OTP</span><span className="step"><b>03</b>Submit enquiry</span></div></div>
      <form className="lead-card lead-form" onSubmit={submitForm}>
        <div className="form-header"><div><h2>Contact details</h2><p>Fields marked * are required.</p></div><span className="form-lock">⌑ HTTPS WHEN HOSTED</span></div>
        <label>Full name *<input required maxLength={100} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your full name"/></label>
        <div className="verify-field"><label>Email address *<input required type="email" value={email} onChange={(e) => { setEmail(e.target.value); setEmailVerified(false); setEmailSent(false); }} placeholder="you@example.com"/></label><button type="button" className={emailVerified ? "verify-button verified" : "verify-button"} onClick={sendEmailOtp} disabled={busy || !email || emailVerified || !turnstile.ready}>{emailVerified ? "✓ Verified" : emailSent ? "Resend code" : "Send email OTP"}</button></div>
        {emailSent && !emailVerified && <div className="otp-row"><input aria-label="Email verification code" inputMode="numeric" maxLength={6} value={emailCode} onChange={(e) => setEmailCode(e.target.value.replace(/\D/g, ""))} placeholder="6-digit email code"/><button type="button" className="mini-button" onClick={verifyEmailOtp} disabled={busy || emailCode.length !== 6}>Verify email</button></div>}
        <div className="verify-field"><label>Mobile number *<input required type="tel" maxLength={20} value={phone} onChange={(e) => { setPhone(e.target.value); setPhoneVerified(false); setPhoneSent(false); }} placeholder="+919876543210"/></label><button type="button" className={phoneVerified ? "verify-button verified" : "verify-button"} onClick={sendPhoneOtp} disabled={busy || !phone || phoneVerified || !turnstile.ready}>{phoneVerified ? "✓ Verified" : phoneSent ? "Resend SMS" : "Send SMS OTP"}</button></div>
        {phoneSent && !phoneVerified && <div className="otp-row"><input aria-label="SMS verification code" inputMode="numeric" maxLength={6} value={phoneCode} onChange={(e) => setPhoneCode(e.target.value.replace(/\D/g, ""))} placeholder="6-digit SMS code"/><button type="button" className="mini-button" onClick={verifyPhoneOtp} disabled={busy || phoneCode.length !== 6}>Verify mobile</button></div>}
        <div className="form-two-col"><label>Company / organisation<input maxLength={120} value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Company name (optional)"/></label><label>I'm interested in<select value={interest} onChange={(e) => setInterest(e.target.value)}><option>Cybersecurity training</option><option>Networking</option><option>Cloud & DevOps</option><option>AI & Machine Learning</option><option>IT services / consulting</option><option>Internship / career guidance</option><option>Other</option></select></label></div>
        <label>How can we help?<textarea rows={4} maxLength={3000} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Tell us a little about what you need…"/></label>
        <label className="consent-check"><input type="checkbox" checked={contactConsent} onChange={(e) => setContactConsent(e.target.checked)}/><span>I agree that Aroush Tech may use the details I voluntarily provide to respond to this enquiry. My email and mobile number must be verified to submit it. Marketing messages require separate permission.</span></label>
        <p className="form-note">Mobile verification is required for this verified enquiry route. If you prefer not to share a phone number, use the <a href="https://aroushtech.in/contact" target="_blank" rel="noreferrer">main AROUSH contact form</a>, where phone is optional.</p>
        <div ref={turnstile.containerRef} className="turnstile-container" aria-label="Human verification" />
        {turnstile.loadError && <div className="form-status" role="status" aria-live="polite">{turnstile.loadError}</div>}
        {!turnstile.ready && <div className="form-status" role="status" aria-live="polite">Human verification is loading or has not been configured yet.</div>}
        {messageText && <div className="form-status" role="status" aria-live="polite">{messageText}</div>}
        <button type="submit" className="button button-primary button-full" disabled={busy || !emailVerified || !phoneVerified || !contactConsent || !turnstile.ready}>{busy ? "Processing…" : "Submit verified enquiry"} <span>→</span></button>
        <div className="form-footnote">We use your contact details to respond to this enquiry. Marketing messages require separate permission.</div>
      </form>
    </div>
  </main>;
}
