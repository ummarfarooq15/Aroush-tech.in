import { createHmac } from "node:crypto";
import { jsonWithCors, optionsResponse, originIsAllowed } from "@/lib/cors";
import { readJson } from "@/lib/http";
import { isAllowedSiteId } from "@/lib/site-config";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

function clean(value: unknown, max = 300): string | null {
  if (typeof value !== "string") return null;
  const text = value.trim();
  return text ? text.slice(0, max) : null;
}

function safePath(value: unknown): string {
  if (typeof value !== "string") return "/";
  let path = value.trim().slice(0, 300);
  try { path = new URL(path, "https://aroush.invalid").pathname; } catch { return "/"; }
  path = path.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "[redacted]");
  path = path.replace(/(?:\+?\d[\d\s().-]{7,}\d)/g, "[redacted]");
  path = path.replace(/[0-9a-f]{8}-[0-9a-f-]{27,}/gi, "[redacted]");
  return path || "/";
}

function safeReferrer(value: unknown): string | null {
  if (typeof value !== "string") return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return `${url.origin}${safePath(url.pathname)}`;
  } catch { return null; }
}

function safeCampaign(value: unknown, max: number): string | null {
  const text = clean(value, max);
  if (!text || /@|\+?\d{8,}/.test(text)) return null;
  return /^[a-z0-9._-]+$/i.test(text) ? text.toLowerCase() : "other";
}

function maskBot(userAgent: string): boolean {
  // Heuristic only; it is not proof that a request came from a bot.
  return /bot|crawler|spider|slurp|preview|headless|curl|wget|python-requests|monitoring/i.test(userAgent);
}

function sourceFromReferrer(referrer: string | null, utmSource: string | null): string {
  if (utmSource) return utmSource.slice(0, 100);
  if (!referrer) return "direct";
  try {
    const host = new URL(referrer).hostname.replace(/^www\./, "");
    if (/google\./i.test(host)) return "google";
    if (/instagram\./i.test(host)) return "instagram";
    if (/facebook\./i.test(host)) return "facebook";
    if (/linkedin\./i.test(host)) return "linkedin";
    if (/youtube\./i.test(host)) return "youtube";
    return host.slice(0, 100);
  } catch { return "referral"; }
}

export async function OPTIONS(request: Request) {
  return optionsResponse(request);
}

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) {
    return jsonWithCors(request, { error: "Origin is not allowed." }, 403);
  }
  if (!(await enforceRateLimit(request, "visitor-track", 120, 60))) {
    return jsonWithCors(request, { error: "Too many analytics events. Try again shortly." }, 429);
  }

  const body = await readJson(request);
  if (!body || body.analyticsConsent !== true) {
    return jsonWithCors(request, { error: "Analytics consent is required." }, 400);
  }

  const siteId = body.siteId;
  const sessionId = clean(body.sessionId, 80);
  const eventType = body.eventType;
  const path = safePath(body.path);
  if (!isAllowedSiteId(siteId) || !sessionId || !/^[a-z0-9-]{16,80}$/i.test(sessionId) ||
      (eventType !== "page_view" && eventType !== "page_time")) {
    return jsonWithCors(request, { error: "Invalid analytics event." }, 400);
  }

  const sessionPepper = process.env.ANALYTICS_SESSION_PEPPER;
  if (!sessionPepper || sessionPepper.length < 24) {
    return jsonWithCors(request, { error: "Aggregate analytics is not configured." }, 503);
  }
  const sessionKey = createHmac("sha256", sessionPepper)
    .update(`${siteId}:${sessionId}`)
    .digest("hex");

  const userAgent = request.headers.get("user-agent") || "";
  const isBot = maskBot(userAgent);
  const now = new Date().toISOString();

  if (eventType === "page_time") {
    const durationSeconds = Number(body.durationSeconds);
    if (!Number.isInteger(durationSeconds) || durationSeconds < 0 || durationSeconds > 1800) {
      return jsonWithCors(request, { error: "Invalid page-time value." }, 400);
    }
    try {
      const { error } = await supabaseAdmin().from("visitor_events").insert({
        site_id: siteId,
        session_key: sessionKey,
        event_name: "page_time",
        path,
        duration_seconds: durationSeconds,
        is_bot: isBot,
        consent_version: clean(body.consentVersion, 30) || "2026-11-aggregate",
        created_at: now
      });
      if (error) throw error;
      return jsonWithCors(request, { ok: true }, 201);
    } catch (error) {
      console.error("Aggregate page-time event failed:", error);
      return jsonWithCors(request, { error: "Page-time event could not be stored." }, 500);
    }
  }

  const referrer = safeReferrer(body.referrer);
  const utmSource = safeCampaign(body.utmSource, 100);
  const utmMedium = safeCampaign(body.utmMedium, 100);
  const utmCampaign = safeCampaign(body.utmCampaign, 150);
  const source = sourceFromReferrer(referrer, utmSource);

  try {
    const { error } = await supabaseAdmin().from("visitor_events").insert({
      site_id: siteId,
      session_key: sessionKey,
      event_name: "page_view",
      path,
      referrer,
      source,
      medium: utmMedium,
      campaign: utmCampaign,
      browser: clean(body.browser, 30),
      os: clean(body.os, 30),
      device: clean(body.device, 20),
      country: clean(request.headers.get("x-vercel-ip-country"), 3),
      region: clean(request.headers.get("x-vercel-ip-country-region"), 80),
      city: clean(request.headers.get("x-vercel-ip-city"), 100),
      is_bot: isBot,
      consent_version: clean(body.consentVersion, 30) || "2026-11-aggregate",
      created_at: now
    });
    if (error) throw error;
    return jsonWithCors(request, { ok: true, source }, 201);
  } catch (error) {
    console.error("Aggregate page-view event failed:", error);
    return jsonWithCors(request, { error: "Page-view event could not be stored." }, 500);
  }
}
