import { originIsAllowed } from "@/lib/cors";
import { clearAdminCookie } from "@/lib/admin-auth";

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) {
    return Response.json({ error: "Origin is not allowed." }, { status: 403, headers: { "Cache-Control": "no-store" } });
  }
  return Response.json({ ok: true }, {
    headers: { "Set-Cookie": clearAdminCookie(), "Cache-Control": "no-store" }
  });
}
