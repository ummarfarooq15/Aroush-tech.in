import { isAdminRequest } from "@/lib/admin-auth";
import { defaultSiteId, isAllowedSiteId } from "@/lib/site-config";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

type AnalyticsEvent = {
  session_key: string;
  event_name: "page_view" | "page_time";
  path: string;
  source: string | null;
  browser: string | null;
  device: string | null;
  country: string | null;
  region: string | null;
  city: string | null;
  duration_seconds: number | null;
  is_bot: boolean;
  created_at: string;
};

function countBy(items: string[], minimumCount = 1): { label: string; count: number }[] {
  const counts = new Map<string, number>();
  for (const item of items) {
    const label = item.trim() || "Unknown";
    counts.set(label, (counts.get(label) || 0) + 1);
  }
  const visible = [...counts.entries()].filter(([, count]) => count >= minimumCount);
  const suppressed = [...counts.values()].filter((count) => count < minimumCount).reduce((sum, count) => sum + count, 0);
  const result = visible.map(([label, count]) => ({ label, count }));
  if (suppressed > 0) result.push({ label: "Other / low volume", count: suppressed });
  return result.sort((a, b) => b.count - a.count).slice(0, 8);
}

export async function GET(request: Request) {
  if (!isAdminRequest(request)) return Response.json({ error: "Unauthorized." }, { status: 401, headers: { "Cache-Control": "no-store" } });
  if (!(await enforceRateLimit(request, "admin-dashboard-data", 60, 60))) {
    return Response.json({ error: "Too many dashboard requests. Wait a moment and try again." }, { status: 429, headers: { "Cache-Control": "no-store" } });
  }
  const url = new URL(request.url);
  const requestedSite = url.searchParams.get("site") || defaultSiteId();
  const siteId = isAllowedSiteId(requestedSite) ? requestedSite : defaultSiteId();

  try {
    const db = supabaseAdmin();
    const now = Date.now();
    const since24h = new Date(now - 24 * 60 * 60 * 1000).toISOString();
    const since30d = new Date(now - 30 * 24 * 60 * 60 * 1000).toISOString();
    const [eventsResult, leadsResult] = await Promise.all([
      db.from("visitor_events")
        .select("session_key,event_name,path,source,browser,device,country,region,city,duration_seconds,is_bot,created_at")
        .eq("site_id", siteId)
        .gte("created_at", since30d)
        .order("created_at", { ascending: false })
        .limit(10_000),
      db.from("leads")
        .select("id,site_id,name,email,phone,company,interest,message,email_verified_at,phone_verified_at,contact_consent_version,status,source,created_at", { count: "exact" })
        .eq("site_id", siteId)
        .order("created_at", { ascending: false })
        .limit(50)
    ]);
    if (eventsResult.error) throw eventsResult.error;
    if (leadsResult.error) throw leadsResult.error;

    const events = (eventsResult.data || []) as AnalyticsEvent[];
    const pageViews = events.filter((event) => event.event_name === "page_view" && !event.is_bot);
    const pageTimes = events.filter((event) => event.event_name === "page_time" && !event.is_bot);
    const pageViews24h = pageViews.filter((event) => event.created_at >= since24h);
    const pageTimes24h = pageTimes.filter((event) => event.created_at >= since24h);
    const sessions24h = new Set(pageViews24h.map((event) => event.session_key));

    const durationBySession = new Map<string, number>();
    for (const event of pageTimes24h) {
      durationBySession.set(event.session_key, (durationBySession.get(event.session_key) || 0) + (event.duration_seconds || 0));
    }
    const measuredDurations = [...durationBySession.values()].filter((seconds) => seconds > 0);
    const averageVisitSeconds24h = measuredDurations.length
      ? Math.round(measuredDurations.reduce((sum, seconds) => sum + seconds, 0) / measuredDurations.length)
      : null;

    const sources = countBy(pageViews24h.map((event) => event.source || "direct"));
    const pages = countBy(pageViews24h.map((event) => event.path || "/"));
    const devices = countBy(pageViews24h.map((event) => event.device || "Unknown"));
    const browsers = countBy(pageViews24h.map((event) => event.browser || "Unknown"));
    const locations = countBy(pageViews24h.map((event) => [event.city, event.region, event.country].filter(Boolean).join(", ") || "Approximate location unavailable"), 3);

    return Response.json({
      siteId,
      stats: {
        sessions24h: sessions24h.size,
        pageViews24h: pageViews24h.length,
        pageViews30d: pageViews.length,
        averageVisitSeconds24h,
        measuredSessions24h: measuredDurations.length,
        leads: leadsResult.count || 0
      },
      breakdowns: { sources, pages, devices, browsers, locations },
      leads: leadsResult.data || [],
      eventWindow: { from: since30d, to: new Date(now).toISOString(), truncated: events.length >= 10_000 },
      lastUpdated: new Date().toISOString()
    }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("Dashboard query failed:", error);
    return Response.json({ error: "Could not load dashboard data. Check Supabase tables and server keys." }, { status: 500, headers: { "Cache-Control": "no-store" } });
  }
}
