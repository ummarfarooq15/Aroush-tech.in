import { createAdminCookie, verifyAdminCredentials } from "@/lib/admin-auth";
import { readJson } from "@/lib/http";
import { enforceRateLimit } from "@/lib/rate-limit";
import { originIsAllowed } from "@/lib/cors";
import { verifyTurnstile } from "@/lib/turnstile";

export const runtime = "nodejs";

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) {
    return Response.json({ error: "Origin is not allowed." }, { status: 403, headers: { "Cache-Control": "no-store" } });
  }
  if (!(await enforceRateLimit(request, "admin-login", 5, 900))) {
    return Response.json({ error: "Too many login attempts. Try again in 15 minutes." }, { status: 429, headers: { "Cache-Control": "no-store" } });
  }
  const body = await readJson(request);
  if (!(await verifyTurnstile(request, body?.turnstileToken))) {
    return Response.json({ error: "Human verification failed. Please try again." }, { status: 403, headers: { "Cache-Control": "no-store" } });
  }
  const email = typeof body?.email === "string" ? body.email : "";
  const password = typeof body?.password === "string" ? body.password : "";
  if (!verifyAdminCredentials(email, password)) {
    return Response.json({ error: "Invalid administrator credentials." }, { status: 401, headers: { "Cache-Control": "no-store" } });
  }
  try {
    return Response.json({ ok: true }, {
      headers: { "Set-Cookie": createAdminCookie(), "Cache-Control": "no-store" }
    });
  } catch (error) {
    return Response.json({ error: error instanceof Error ? error.message : "Login is not configured." }, { status: 500 });
  }
}
