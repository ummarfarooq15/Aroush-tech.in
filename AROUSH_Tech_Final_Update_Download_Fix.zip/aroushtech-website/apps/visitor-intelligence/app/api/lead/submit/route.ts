import { jsonWithCors, optionsResponse, originIsAllowed } from "@/lib/cors";
import { readJson } from "@/lib/http";
import { normalizeEmail, normalizePhone, validText } from "@/lib/otp";
import { isAllowedSiteId } from "@/lib/site-config";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";
import { verifyTurnstile } from "@/lib/turnstile";

export const runtime = "nodejs";

export async function OPTIONS(request: Request) { return optionsResponse(request); }

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) return jsonWithCors(request, { error: "Origin is not allowed." }, 403);
  if (!(await enforceRateLimit(request, "lead-submit", 5, 900))) {
    return jsonWithCors(request, { error: "Too many enquiries. Please try again later." }, 429);
  }

  const body = await readJson(request);
  const name = validText(body?.name, 100);
  const email = normalizeEmail(body?.email);
  const phone = normalizePhone(body?.phone);
  const siteId = body?.siteId;
  const company = validText(body?.company, 120);
  const interest = validText(body?.interest, 120);
  const message = validText(body?.message, 3000);
  if (!name || !email || !phone || !isAllowedSiteId(siteId)) {
    return jsonWithCors(request, { error: "Please provide a name, valid email, mobile number and valid site." }, 400);
  }
  if (body?.contactConsent !== true) return jsonWithCors(request, { error: "Contact consent is required to submit this enquiry." }, 400);
  if (!(await verifyTurnstile(request, body?.turnstileToken))) return jsonWithCors(request, { error: "Human verification failed. Please try again." }, 403);

  try {
    const sourceRaw = validText(body?.source, 100) || "direct";
    const source = /^[a-z0-9._-]{1,100}$/i.test(sourceRaw) && !/@|\+?\d{8,}/.test(sourceRaw)
      ? sourceRaw.toLowerCase()
      : "other";
    const { data: result, error } = await supabaseAdmin().rpc("create_verified_lead", {
      p_site_id: siteId,
      p_name: name,
      p_email: email,
      p_phone: phone,
      p_company: company,
      p_interest: interest,
      p_message: message,
      p_source: source,
      p_consent_version: "2026-11-v1"
    });
    if (error) throw error;
    const created = result as { status?: string; lead_id?: string } | null;
    if (created?.status === "email_not_verified") return jsonWithCors(request, { error: "Verify your email address before submitting." }, 403);
    if (created?.status === "phone_not_verified") return jsonWithCors(request, { error: "Verify your mobile number before submitting." }, 403);
    if (created?.status !== "created" || !created.lead_id) return jsonWithCors(request, { error: "Your enquiry could not be saved. Please try again." }, 500);
    return jsonWithCors(request, { ok: true, message: "Your enquiry has been submitted." }, 201);
  } catch (error) {
    console.error("Lead submission failed:", error);
    return jsonWithCors(request, { error: "Your enquiry could not be saved. Please try again." }, 500);
  }
}
