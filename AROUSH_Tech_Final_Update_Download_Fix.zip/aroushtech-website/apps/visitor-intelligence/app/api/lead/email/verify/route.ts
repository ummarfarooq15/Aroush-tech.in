import { jsonWithCors, optionsResponse, originIsAllowed } from "@/lib/cors";
import { readJson } from "@/lib/http";
import { hashEmailOtp, normalizeEmail, safeHashCompare } from "@/lib/otp";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

export async function OPTIONS(request: Request) { return optionsResponse(request); }

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) return jsonWithCors(request, { error: "Origin is not allowed." }, 403);
  if (!(await enforceRateLimit(request, "email-otp-verify", 12, 900))) return jsonWithCors(request, { error: "Too many verification attempts. Try again later." }, 429);
  const body = await readJson(request);
  const email = normalizeEmail(body?.email);
  const code = typeof body?.code === "string" ? body.code.trim() : "";
  if (!email || !/^\d{6}$/.test(code)) return jsonWithCors(request, { error: "Enter the email address and six-digit code." }, 400);

  try {
    const db = supabaseAdmin();
    const { data: challenge, error } = await db.from("lead_verifications")
      .select("otp_hash,verified_at")
      .eq("channel", "email")
      .eq("identifier", email)
      .maybeSingle();
    if (error) throw error;
    if (!challenge) return jsonWithCors(request, { error: "Request a new verification code first." }, 400);
    if (challenge.verified_at) return jsonWithCors(request, { ok: true, verified: true }, 200);
    if (!challenge.otp_hash) return jsonWithCors(request, { error: "Request a new verification code first." }, 400);

    const expectedHash = challenge.otp_hash as string;
    const isCorrect = safeHashCompare(hashEmailOtp(email, code), expectedHash);
    const { data: result, error: verifyError } = await db.rpc("verify_email_otp_atomic", {
      p_identifier: email,
      p_expected_hash: expectedHash,
      p_is_correct: isCorrect
    });
    if (verifyError) throw verifyError;

    if (result === "verified" || result === "already_verified") {
      return jsonWithCors(request, { ok: true, verified: true }, 200);
    }
    if (result === "locked") return jsonWithCors(request, { error: "Too many attempts. Request a new code later." }, 429);
    if (result === "expired") return jsonWithCors(request, { error: "Code expired. Request a new one." }, 400);
    if (result === "missing") return jsonWithCors(request, { error: "Request a new verification code first." }, 400);
    if (result === "stale") return jsonWithCors(request, { error: "A newer code was requested. Use the latest email code." }, 409);
    return jsonWithCors(request, { error: "That code is incorrect." }, 400);
  } catch (error) {
    console.error("Email OTP verification failed:", error);
    return jsonWithCors(request, { error: "Could not verify the email code." }, 500);
  }
}
