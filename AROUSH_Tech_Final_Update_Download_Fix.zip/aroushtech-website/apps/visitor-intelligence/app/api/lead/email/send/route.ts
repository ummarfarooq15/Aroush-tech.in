import { jsonWithCors, optionsResponse, originIsAllowed } from "@/lib/cors";
import { readJson } from "@/lib/http";
import { createEmailOtp, hashEmailOtp, normalizeEmail } from "@/lib/otp";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";
import { verifyTurnstile } from "@/lib/turnstile";

export const runtime = "nodejs";

export async function OPTIONS(request: Request) { return optionsResponse(request); }

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) return jsonWithCors(request, { error: "Origin is not allowed." }, 403);
  if (!(await enforceRateLimit(request, "email-otp-send", 5, 900))) return jsonWithCors(request, { error: "Too many verification requests. Try again later." }, 429);

  const body = await readJson(request);
  const email = normalizeEmail(body?.email);
  if (!email) return jsonWithCors(request, { error: "Enter a valid email address." }, 400);
  if (!(await verifyTurnstile(request, body?.turnstileToken))) return jsonWithCors(request, { error: "Human verification failed. Please try again." }, 403);
  if (!(await enforceRateLimit(request, "email-otp-recipient", 3, 3600, email, true))) {
    return jsonWithCors(request, { error: "Too many codes requested for this address. Try again later." }, 429);
  }

  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM;
  if (!apiKey || !from) return jsonWithCors(request, { error: "Email provider is not configured." }, 503);

  try {
    const db = supabaseAdmin();
    const code = createEmailOtp();
    const expiresAt = new Date(Date.now() + 10 * 60_000).toISOString();
    const { data: reserved, error: reserveError } = await db.rpc("reserve_lead_verification", {
      p_channel: "email",
      p_identifier: email,
      p_otp_hash: hashEmailOtp(email, code),
      p_expires_at: expiresAt,
      p_cooldown_seconds: 60
    });
    if (reserveError) throw reserveError;
    if (reserved !== true) return jsonWithCors(request, { error: "Please wait 60 seconds before requesting another code." }, 429);

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [email],
        subject: "Your Aroush Tech verification code",
        html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:28px;color:#101828"><h2>Aroush Tech</h2><p>Use this one-time code to verify your email address:</p><div style="font-size:32px;font-weight:700;letter-spacing:8px;padding:18px;background:#f2f4f7;border-radius:12px;text-align:center">${code}</div><p>This code expires in 10 minutes. Do not share it with anyone.</p><p style="font-size:12px;color:#667085">You received this because someone submitted an enquiry on Aroush Tech. If this wasn't you, you can ignore this email.</p></div>`
      }),
      signal: AbortSignal.timeout(10_000)
    });
    if (!response.ok) {
      await db.from("lead_verifications").delete().eq("channel", "email").eq("identifier", email);
      console.error("Resend rejected email OTP with status:", response.status);
      return jsonWithCors(request, { error: "Email could not be sent. Check the verified sender domain and provider account." }, 502);
    }
    return jsonWithCors(request, { ok: true, message: "Verification code sent." }, 200);
  } catch (error) {
    console.error("Email OTP error:", error);
    return jsonWithCors(request, { error: "Could not send email verification code." }, 500);
  }
}
