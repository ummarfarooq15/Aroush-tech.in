import { jsonWithCors, optionsResponse, originIsAllowed } from "@/lib/cors";
import { readJson } from "@/lib/http";
import { normalizePhone } from "@/lib/otp";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";

export async function OPTIONS(request: Request) { return optionsResponse(request); }

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) return jsonWithCors(request, { error: "Origin is not allowed." }, 403);
  if (!(await enforceRateLimit(request, "sms-otp-verify", 12, 900))) return jsonWithCors(request, { error: "Too many verification attempts. Try again later." }, 429);
  const body = await readJson(request);
  const phone = normalizePhone(body?.phone);
  const code = typeof body?.code === "string" ? body.code.trim() : "";
  if (!phone || !/^\d{6}$/.test(code)) return jsonWithCors(request, { error: "Enter the mobile number and six-digit code." }, 400);
  const authKey = process.env.MSG91_AUTH_KEY;
  if (!authKey) return jsonWithCors(request, { error: "SMS provider is not configured." }, 503);

  const db = supabaseAdmin();
  try {
    const { data: reservation, error: beginError } = await db.rpc("begin_phone_otp_verification", {
      p_identifier: phone
    });
    if (beginError) throw beginError;
    const state = reservation as { status?: string; token?: string } | null;
    if (state?.status === "already_verified") return jsonWithCors(request, { ok: true, verified: true }, 200);
    if (state?.status === "missing") return jsonWithCors(request, { error: "Request an SMS code first." }, 400);
    if (state?.status === "expired") return jsonWithCors(request, { error: "Code expired. Request a new one." }, 400);
    if (state?.status === "locked") return jsonWithCors(request, { error: "Too many attempts. Request a new code later." }, 429);
    if (state?.status === "in_progress") return jsonWithCors(request, { error: "A verification attempt is already running. Please wait a moment." }, 409);
    if (state?.status !== "ready" || !state.token) return jsonWithCors(request, { error: "Could not start mobile verification." }, 500);

    let providerAccepted = false;
    try {
      const query = new URLSearchParams({ mobile: phone.replace("+", ""), otp: code });
      const response = await fetch(`https://control.msg91.com/api/v5/otp/verify?${query.toString()}`, {
        method: "GET",
        headers: { authkey: authKey },
        signal: AbortSignal.timeout(10_000)
      });
      const providerResult = await response.json().catch(() => ({})) as { type?: string };
      providerAccepted = response.ok && providerResult.type === "success";
    } catch (error) {
      await db.rpc("finish_phone_otp_verification", {
        p_identifier: phone,
        p_token: state.token,
        p_result: "error"
      });
      console.error("MSG91 verification request failed:", error);
      return jsonWithCors(request, { error: "SMS verification provider is temporarily unavailable. Please try again." }, 502);
    }

    const { data: finishResult, error: finishError } = await db.rpc("finish_phone_otp_verification", {
      p_identifier: phone,
      p_token: state.token,
      p_result: providerAccepted ? "success" : "invalid"
    });
    if (finishError) throw finishError;
    if (finishResult === "verified") return jsonWithCors(request, { ok: true, verified: true }, 200);
    if (finishResult === "invalid") return jsonWithCors(request, { error: "That SMS code is incorrect or expired." }, 400);
    if (finishResult === "stale") return jsonWithCors(request, { error: "The verification request expired. Request a new code." }, 409);
    return jsonWithCors(request, { error: "Could not complete mobile verification." }, 500);
  } catch (error) {
    console.error("Phone OTP verification failed:", error);
    return jsonWithCors(request, { error: "Could not verify the mobile number." }, 500);
  }
}
