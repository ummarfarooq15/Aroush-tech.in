import { jsonWithCors, optionsResponse, originIsAllowed } from "@/lib/cors";
import { readJson } from "@/lib/http";
import { normalizePhone } from "@/lib/otp";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { enforceRateLimit } from "@/lib/rate-limit";
import { verifyTurnstile } from "@/lib/turnstile";

export const runtime = "nodejs";

export async function OPTIONS(request: Request) { return optionsResponse(request); }

export async function POST(request: Request) {
  if (!originIsAllowed(request.headers.get("origin"))) return jsonWithCors(request, { error: "Origin is not allowed." }, 403);
  if (!(await enforceRateLimit(request, "sms-otp-send", 3, 900))) return jsonWithCors(request, { error: "Too many SMS requests. Try again later." }, 429);
  const body = await readJson(request);
  const phone = normalizePhone(body?.phone);
  if (!phone) return jsonWithCors(request, { error: "Use international format, for example +919876543210." }, 400);
  if (!(await verifyTurnstile(request, body?.turnstileToken))) return jsonWithCors(request, { error: "Human verification failed. Please try again." }, 403);
  if (!(await enforceRateLimit(request, "sms-otp-recipient", 3, 3600, phone, true))) {
    return jsonWithCors(request, { error: "Too many codes requested for this number. Try again later." }, 429);
  }

  const authKey = process.env.MSG91_AUTH_KEY;
  const templateId = process.env.MSG91_OTP_TEMPLATE_ID;
  if (!authKey || !templateId) return jsonWithCors(request, { error: "SMS provider is not configured." }, 503);

  try {
    const db = supabaseAdmin();
    const expiresAt = new Date(Date.now() + 5 * 60_000).toISOString();
    const { data: reserved, error: reserveError } = await db.rpc("reserve_lead_verification", {
      p_channel: "phone",
      p_identifier: phone,
      p_otp_hash: null,
      p_expires_at: expiresAt,
      p_cooldown_seconds: 60
    });
    if (reserveError) throw reserveError;
    if (reserved !== true) return jsonWithCors(request, { error: "Please wait 60 seconds before requesting another SMS." }, 429);

    const query = new URLSearchParams({
      template_id: templateId,
      mobile: phone.replace("+", ""),
      otp_length: "6",
      otp_expiry: "5"
    });
    const response = await fetch(`https://control.msg91.com/api/v5/otp?${query.toString()}`, {
      method: "POST",
      headers: { authkey: authKey, "Content-Type": "application/json" },
      body: JSON.stringify({}),
      signal: AbortSignal.timeout(10_000)
    });
    const providerResult = await response.json().catch(() => ({})) as { type?: string; request_id?: string };
    if (!response.ok || providerResult.type !== "success") {
      await db.from("lead_verifications").delete().eq("channel", "phone").eq("identifier", phone);
      console.error("MSG91 send OTP failed with status:", response.status);
      return jsonWithCors(request, { error: "SMS could not be sent. Check the OTP template, balance and DLT setup." }, 502);
    }
    const { error: updateError } = await db.from("lead_verifications")
      .update({ provider_request_id: providerResult.request_id || null })
      .eq("channel", "phone")
      .eq("identifier", phone);
    if (updateError) throw updateError;
    return jsonWithCors(request, { ok: true, message: "SMS verification code sent." }, 200);
  } catch (error) {
    console.error("Phone OTP send failed:", error);
    return jsonWithCors(request, { error: "Could not send SMS verification code." }, 500);
  }
}
