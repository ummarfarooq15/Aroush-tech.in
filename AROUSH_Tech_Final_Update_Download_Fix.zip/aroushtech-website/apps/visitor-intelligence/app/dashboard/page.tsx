"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

type Lead = {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string | null;
  interest: string | null;
  message: string | null;
  status: string;
  source: string;
  created_at: string;
  email_verified_at: string;
  phone_verified_at: string;
  contact_consent_version: string;
};
type BreakdownItem = { label: string; count: number };
type DashboardData = {
  stats: {
    sessions24h: number;
    pageViews24h: number;
    pageViews30d: number;
    averageVisitSeconds24h: number | null;
    measuredSessions24h: number;
    leads: number;
  };
  breakdowns: {
    sources: BreakdownItem[];
    pages: BreakdownItem[];
    devices: BreakdownItem[];
    browsers: BreakdownItem[];
    locations: BreakdownItem[];
  };
  leads: Lead[];
  eventWindow: { truncated: boolean };
  lastUpdated: string;
};
type Tab = "overview" | "engagement" | "leads" | "attribution" | "privacy";

const tabs: { id: Tab; label: string; icon: string }[] = [
  { id: "overview", label: "Overview", icon: "◫" },
  { id: "engagement", label: "Engagement", icon: "◎" },
  { id: "leads", label: "Verified leads", icon: "◇" },
  { id: "attribution", label: "Attribution", icon: "↗" },
  { id: "privacy", label: "Privacy & setup", icon: "⌑" }
];

function formatTime(value?: string | null) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en-IN", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}

function formatDuration(seconds: number | null) {
  if (seconds === null) return "Not available";
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remaining = seconds % 60;
  return remaining ? `${minutes}m ${remaining}s` : `${minutes}m`;
}

export default function DashboardPage() {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("overview");
  const [site, setSite] = useState("aroush-existing");
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [lastRefresh, setLastRefresh] = useState("");

  const load = useCallback(async () => {
    try {
      const response = await fetch(`/api/admin/data?site=${encodeURIComponent(site)}`, { cache: "no-store" });
      if (response.status === 401) { router.replace("/login"); return; }
      const payload = await response.json();
      if (!response.ok) throw new Error(payload.error || "Could not load analytics.");
      setData(payload);
      setLastRefresh(new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
      setError("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not load analytics.");
    } finally { setLoading(false); }
  }, [site, router]);

  useEffect(() => {
    void load();
    const id = window.setInterval(() => { void load(); }, 15000);
    return () => window.clearInterval(id);
  }, [load]);

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.replace("/login");
  }

  const selectedTab = tabs.find((item) => item.id === tab)?.label || "Overview";
  const maximumSource = useMemo(() => Math.max(1, ...(data?.breakdowns.sources || []).map((item) => item.count)), [data]);

  return <main className="dashboard-layout">
    <aside className="sidebar">
      <a href="/" className="brand-mark sidebar-brand"><span className="brand-symbol">A</span><span>AR<strong>OUSH</strong> TECH</span></a>
      <div className="sidebar-caption">WORKSPACE</div>
      <nav className="side-nav">
        {tabs.map((item) => <button key={item.id} onClick={() => setTab(item.id)} className={tab === item.id ? "side-nav-item active" : "side-nav-item"}><span className="side-icon" aria-hidden="true">{item.icon}</span>{item.label}{item.id === "leads" && data?.stats.leads ? <span className="nav-count">{data.stats.leads}</span> : null}</button>)}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-status"><span className="pulse-dot"/><div><strong>Development preview</strong><small>Not deployed</small></div></div>
        <button className="logout-button" onClick={logout}>↪ Sign out</button>
      </div>
    </aside>

    <section className="dashboard-main">
      <header className="topbar">
        <div><div className="breadcrumb">Aroush Tech <span>/</span> Intelligence</div><div className="page-title">{selectedTab}</div></div>
        <div className="topbar-actions">
          <label className="site-select-label"><span>WEBSITE</span><select value={site} onChange={(e) => setSite(e.target.value)}><option value="aroush-existing">Existing website</option><option value="aroush-new">New website</option></select></label>
          <div className="live-pill"><span className="pulse-dot"/> DEVELOPMENT</div>
          <button className="icon-button" onClick={() => { setLoading(true); void load(); }} aria-label="Refresh dashboard">↻</button>
        </div>
      </header>

      <div className="content-area">
        {error && <div className="notice notice-error" role="alert">{error}</div>}
        {loading && !data ? <div className="loading-panel" role="status"><span className="loader" aria-hidden="true"/> Loading aggregate analytics…</div> : null}
        {data && <>
          <div className="welcome-row"><div><div className="eyebrow">CONSENTED AGGREGATE INSIGHTS</div><h1>Understand website engagement.</h1><p>Traffic trends and verified enquiries—without individual visitor profiles.</p></div><div className="updated-label">Updated {lastRefresh || "just now"}<br/><span>Refreshes every 15 seconds</span></div></div>

          {tab === "overview" && <>
            <div className="metric-grid">
              <Metric label="Sessions · 24h" value={data.stats.sessions24h.toLocaleString("en-IN")} detail="Temporary tab sessions" icon="◎"/>
              <Metric label="Page views · 24h" value={data.stats.pageViews24h.toLocaleString("en-IN")} detail="Consented page views" icon="▤"/>
              <Metric label="Average visit time" value={formatDuration(data.stats.averageVisitSeconds24h)} detail={`${data.stats.measuredSessions24h} measured sessions · 24h`} icon="◷"/>
              <Metric label="Verified enquiries" value={data.stats.leads.toLocaleString("en-IN")} detail="Email + mobile verified" icon="◇"/>
            </div>
            <div className="content-grid-two">
              <section className="panel"><div className="panel-heading"><div><h2>Traffic sources</h2><p>Aggregate sources from consented page views</p></div><span className="panel-kicker">LAST 24 HOURS</span></div>
                <BreakdownList items={data.breakdowns.sources} maximum={maximumSource} empty="Traffic sources will appear after visitors accept analytics."/>
              </section>
              <section className="panel"><div className="panel-heading"><div><h2>Popular pages</h2><p>Pages receiving the most consented views</p></div><span className="panel-kicker">LAST 24 HOURS</span></div>
                <BreakdownList items={data.breakdowns.pages} empty="Page totals will appear after consented visits."/>
              </section>
            </div>
            {data.eventWindow.truncated && <div className="notice">The 30-day analytics query reached its 10,000-event display limit. Older events in this window are not included in the current breakdown.</div>}
            <section className="panel"><div className="panel-heading"><div><h2>Measurement scope</h2><p>Aggregate reporting only; no named visitor list or returning-person tracking.</p></div><button className="text-button" onClick={() => setTab("privacy")}>Review privacy →</button></div><div className="privacy-grid"><PrivacyItem title="Temporary sessions" body="A random tab-scoped token is HMAC-hashed on the server and not exposed in dashboard results."/><PrivacyItem title="No visitor profiles" body="No persistent visitor ID, raw IP, device fingerprint, or individual visitor journey is stored or displayed."/></div></section>
          </>}

          {tab === "engagement" && <div className="privacy-stack">
            <div className="content-grid-two">
              <section className="panel"><div className="panel-heading"><div><h2>Device categories</h2><p>Aggregate page views by device</p></div></div><BreakdownList items={data.breakdowns.devices} empty="Device breakdown is not available yet."/></section>
              <section className="panel"><div className="panel-heading"><div><h2>Browser families</h2><p>Aggregate page views by browser</p></div></div><BreakdownList items={data.breakdowns.browsers} empty="Browser breakdown is not available yet."/></section>
              <section className="panel"><div className="panel-heading"><div><h2>Approximate geography</h2><p>Coarse location supplied by the hosting platform</p></div></div><BreakdownList items={data.breakdowns.locations} empty="Approximate geography is not available yet."/></section>
              <section className="panel"><div className="panel-heading"><div><h2>Most viewed pages</h2><p>Aggregate page views · last 24 hours</p></div></div><BreakdownList items={data.breakdowns.pages} empty="Page totals will appear after consented visits."/></section>
            </div>
            <section className="panel"><div className="panel-heading"><div><h2>Visit-time measurement</h2><p>Active page time, grouped into temporary tab sessions</p></div></div><div className="metric-grid"><Metric label="Average session time" value={formatDuration(data.stats.averageVisitSeconds24h)} detail="Measured sessions only" icon="◷"/><Metric label="Measured sessions" value={data.stats.measuredSessions24h.toLocaleString("en-IN")} detail="Sessions with a page-time event" icon="◎"/><Metric label="Page views · 30d" value={data.stats.pageViews30d.toLocaleString("en-IN")} detail="Human-filtered heuristic" icon="▤"/></div><p className="info-footnote">Time is approximate active tab time. Browser shutdowns, network loss and blocked requests can prevent a final timing event from being recorded.</p></section>
          </div>}

          {tab === "leads" && <section className="panel table-panel"><div className="panel-heading"><div><h2>Verified enquiries</h2><p>Lead details are separate from aggregate analytics and visible only to authorised administrators.</p></div><a className="text-button" href={`/lead?site=${site}`} target="_blank" rel="noreferrer">Open enquiry form ↗</a></div>
            {data.leads.length ? <div className="lead-list">{data.leads.map((lead) => <article className="lead-card" key={lead.id}><div className="lead-top"><div><strong>{lead.name}</strong><span>{lead.company || "Individual enquiry"}</span></div><span className="status-chip">{lead.status}</span></div><div className="lead-contact"><a href={`mailto:${lead.email}`}>{lead.email}</a><a href={`tel:${lead.phone}`}>{lead.phone}</a></div><div className="lead-meta"><span><i/> Email verified</span><span><i/> Mobile verified</span><span>{lead.interest || "General enquiry"}</span><span>Consent {lead.contact_consent_version}</span><span>{formatTime(lead.created_at)}</span></div>{lead.message && <p className="lead-message">{lead.message}</p>}</article>)}</div> : <Empty text="No verified enquiries yet. The hosted enquiry form must be configured before it can collect leads."/>}
          </section>}

          {tab === "attribution" && <div className="privacy-stack">
            <section className="panel"><div className="panel-heading"><div><h2>Traffic attribution</h2><p>UTM source labels and referral domains from consented page views.</p></div></div><BreakdownList items={data.breakdowns.sources} empty="No attribution data has been collected yet."/><div className="info-footnote">Use non-personal UTM tags such as ?utm_source=instagram&utm_medium=social&utm_campaign=november_launch. Do not put names, phone numbers, email addresses or other personal information in URLs.</div></section>
            <section className="panel"><div className="panel-heading"><div><h2>Page interest</h2><p>Which public pages receive the most consented views</p></div></div><BreakdownList items={data.breakdowns.pages} empty="Page totals will appear after consented visits."/></section>
          </div>}

          {tab === "privacy" && <div className="privacy-stack">
            <section className="panel"><div className="panel-heading"><div><h2>Aggregate-only analytics</h2><p>What is collected after explicit consent—and what is excluded.</p></div><span className="status-chip">CONSENT-BASED</span></div><div className="privacy-grid">
              <PrivacyItem title="Collected after consent" body="Page path, approximate active page time, referral source, campaign labels, browser family, operating system, device category and approximate city/region/country when the host supplies them."/>
              <PrivacyItem title="Temporary session key" body="A random tab-scoped token is HMAC-hashed server-side only to group page views within one tab session. It is not used to recognise returning people or link sessions across devices."/>
              <PrivacyItem title="Not collected by analytics" body="No persistent visitor ID, raw or masked IP display, device fingerprint, screen size, language, timezone, precise GPS, contact list or hidden identity lookup."/>
              <PrivacyItem title="Lead details are separate" body="Name, email, mobile and enquiry details are saved only after a visitor voluntarily submits the clearly described form, grants contact consent and completes email and SMS verification."/>
            </div></section>
            <section className="panel"><div className="panel-heading"><div><h2>Website installation</h2><p>Install only after the analytics service is configured and consent has been tested.</p></div></div><div className="install-snippet"><code>{'<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-existing"></script>'}</code><button onClick={() => navigator.clipboard.writeText('<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-existing"></script>')}>Copy</button></div><div className="install-snippet"><code>{'<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-new"></script>'}</code><button onClick={() => navigator.clipboard.writeText('<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-new"></script>')}>Copy</button></div><p className="muted-small">Replace the placeholder only after a staging deployment is approved. No tracker has been installed on the live website.</p></section>
            <section className="panel"><div className="panel-heading"><div><h2>Owner actions before production</h2><p>Configuration and legal decisions are still required.</p></div></div><div className="privacy-grid"><PrivacyItem title="Provider setup" body="Confirm Supabase, Vercel, Resend, MSG91 and Cloudflare Turnstile accounts, owners and data-processing terms."/><PrivacyItem title="Retention" body="Approve retention periods and deletion workflows for aggregate analytics, leads, OTP challenges and hashed rate-limit keys. No cleanup schedule is active."/><PrivacyItem title="Privacy notice" body="Replace the placeholder privacy contact, confirm purpose/consent wording and have qualified counsel review applicable DPDP and other requirements."/><PrivacyItem title="Admin access" body="Use unique administrator credentials, MFA where available, secret rotation, backups, named staff access and an incident-response contact."/></div></section>
          </div>}

          <footer className="dashboard-footer"><span>AROUSHTECH.IN · VISITOR INTELLIGENCE</span><span>Development preview · Not deployed</span></footer>
        </>}
      </div>
    </section>
  </main>;
}

function Metric({ label, value, detail, icon }: { label: string; value: string; detail: string; icon: string }) {
  return <article className="metric-card"><div className="metric-top"><span>{label}</span><b aria-hidden="true">{icon}</b></div><strong className="metric-value">{value}</strong><small>{detail}</small></article>;
}

function BreakdownList({ items, maximum, empty }: { items: BreakdownItem[]; maximum?: number; empty: string }) {
  if (!items.length) return <Empty text={empty}/>;
  const scale = maximum || Math.max(1, ...items.map((item) => item.count));
  return <div className="source-list">{items.map((item) => <div className="source-row" key={item.label}><div className="source-label"><span>{item.label}</span><strong>{item.count.toLocaleString("en-IN")}</strong></div><div className="bar-track" aria-hidden="true"><div className="bar-fill" style={{ width: `${Math.max(3, item.count / scale * 100)}%` }}/></div></div>)}</div>;
}

function Empty({ text }: { text: string }) { return <div className="empty-state"><span>◎</span><p>{text}</p></div>; }
function PrivacyItem({ title, body }: { title: string; body: string }) { return <div className="privacy-item"><span className="privacy-check">✓</span><div><strong>{title}</strong><p>{body}</p></div></div>; }
