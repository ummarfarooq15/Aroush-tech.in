# AROUSH Tech Visitor Intelligence

A separate Next.js companion application for consent-based aggregate website insights and verified enquiries. It is part of the development bundle only. It is **not deployed**, is not connected to the live AROUSH Tech website, and is not production-approved.

## What is included

- Aggregate analytics dashboard for the existing and redesigned website labels.
- Consent banner with explicit **Accept analytics** and **Reject optional** choices, plus a persistent Privacy control.
- Aggregate page views, approximate active page time, browser/device categories, traffic source and approximate geography.
- No persistent visitor ID, no individual visitor list, no visitor journey display, no raw or masked IP storage, and no device fingerprinting.
- Enquiry form that saves details only after explicit contact consent and successful email + SMS OTP verification.
- Supabase server-side storage with Row Level Security and privileged RPC functions.
- Atomic email OTP attempt/verification handling, single in-flight SMS verification reservation, and atomic one-time lead creation.
- Cloudflare Turnstile server-side validation for OTP sends and lead submission. Production fails closed if Turnstile is not configured.
- Admin dashboard protected by server-side credentials and a signed HTTP-only cookie.

The owner explicitly approved Supabase lead storage and voluntary email/phone OTP verification on 7 November 2026. This approval does not authorise deployment, DNS changes, live WordPress edits, GitHub pushes or production account changes.

## Architecture

```text
Existing website ──┐
                   ├─ tracker.js (only after analytics opt-in) ──> API ──> Supabase events
New staging site ──┘

Enquiry form ──> Turnstile ──> email OTP (Resend) + SMS OTP (MSG91)
                                  │
                                  └─> atomic verified lead creation ──> Supabase leads

Admin browser ──> signed HTTP-only session ──> aggregate dashboard + authorised lead view
```

## Analytics data scope

| Data | Purpose and safeguards |
|---|---|
| Query-free page path | Aggregate page interest. Sensitive-looking email, phone and UUID patterns are redacted server-side. |
| Temporary tab session | Random token exists in `sessionStorage` only. The server stores an HMAC digest so page views can be grouped within the tab session. It is not used across sessions or devices. |
| Page time | Approximate active tab time, capped at 30 minutes per page event. Browser shutdown, network loss or blocked requests can prevent the final event. |
| Browser, OS and device category | Coarse categories only; raw user-agent strings are not stored. |
| Referral and campaign | Referral origin/path and allowlisted, non-personal UTM labels. Query strings and fragments are not collected. |
| Approximate geography | City/region/country only when supplied by the hosting platform. No precise GPS. |

The dashboard returns aggregate breakdowns only. It does not expose session keys, individual visitor journeys or a list of visitors. Location groups with fewer than three matching page views are suppressed into a low-volume bucket. The database stores a temporary session HMAC solely to calculate approximate session duration and group page views within a tab. This is still pseudonymous session-level processing and must be described in the approved privacy notice.

The tracker does not read form fields, passwords, keystrokes, contacts or files. It does not store raw or masked IP addresses, persistent visitor IDs, screen dimensions, locale, timezone, device fingerprints, phone numbers or precise location. The hosting provider may process request IP addresses as part of normal service operation; the application does not write them to the analytics tables.

## Enquiry data scope

When a visitor intentionally submits the clearly described form, the app stores the name, email, mobile number, optional company, area of interest and message they provide. The visitor must tick the contact-consent checkbox. Email and mobile verification are required before the lead is saved. Phone numbers are never inferred from website visits and are not sent to analytics. Marketing permission is separate and is not included in this form.

Lead details are separate from aggregate analytics. They are visible only to authorised administrators through the protected dashboard. Use named staff access, unique credentials, and an approved deletion/access process.

## 1. Runtime and installation

Use **Node.js 24.x**. The project pins `24` in `.nvmrc` and declares Node 24 in `package.json`.

For a developer with a local environment or Codespace:

```bash
cd apps/visitor-intelligence
npm install
npm run dev
```

Before release:

```bash
npm run typecheck
npm run build
```

From the repository root, `npm run lint` runs the shared ESLint checks across the project source, including the companion app.

No lockfile is included in this development package yet. Generate and review `package-lock.json` using Node 24/npm before any deployment. Do not install dependencies with Node 22 and do not bypass the engine requirement.

## 2. Supabase setup

1. Create a Supabase project owned by AROUSH Tech.
2. Open the Supabase SQL Editor.
3. Run `supabase/schema.sql` in a fresh project.
4. Copy the Project URL and the new server-side `sb_secret_...` API key into private hosting environment variables `SUPABASE_URL` and `SUPABASE_SECRET_KEY`. Supabase is deprecating the legacy `anon` and `service_role` keys by the end of 2026; prefer the new publishable/secret keys. See https://supabase.com/docs/guides/getting-started/migrating-to-new-api-keys.
5. Never expose the secret key in browser code or any `NEXT_PUBLIC_` variable.

The schema enables RLS, revokes direct access from `anon` and `authenticated`, and grants privileged table/RPC access only to `service_role`. Test this in a non-production project first.

If an earlier development database was created using the previous visitor-profile schema, take a backup and run `supabase/migrations/20261107_aggregate_analytics_and_otp_hardening.sql` first, then run the current `supabase/schema.sql`. The migration intentionally drops the old `visitor_profiles` and `visitor_events` tables (removing old pseudonymous visitor/session data), clears stale OTP challenges and old rate-limit keys, adds the current OTP lock/consent-version fields, and retains existing lead records. Do not use it on production without an owner-approved backup and retention plan. No production database was connected by this project.

## 3. Email OTP with Resend

1. Create a Resend account owned by AROUSH Tech.
2. Verify a sending domain and publish its required DNS records.
3. Create an API key.
4. Configure `RESEND_API_KEY` and `EMAIL_FROM` in the hosting environment.

Email codes are six digits, expire after 10 minutes and are HMAC-hashed before storage. The database RPC atomically checks the attempt count and consumes a successful challenge once. A per-address cooldown and rate limit are also enforced.

## 4. SMS OTP with MSG91

1. Create or sign in to the AROUSH Tech MSG91 account.
2. Create an approved six-digit OTP template and copy its template ID.
3. Complete applicable India DLT entity, sender/header and content-template registration steps.
4. Configure `MSG91_AUTH_KEY` and `MSG91_OTP_TEMPLATE_ID`.

The code expires after five minutes. The database reserves one verification attempt at a time and atomically marks a successful challenge as verified. Provider delivery, DLT approval, telecom filtering and charges remain controlled by MSG91 and the relevant operators.

## 5. Bot protection with Cloudflare Turnstile

1. Create a Turnstile widget in the AROUSH Tech Cloudflare account.
2. Add only the exact staging/production hostnames that will display the form.
3. Configure `NEXT_PUBLIC_TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY` in the app's hosting environment.
4. Test successful, expired, replayed and invalid tokens.

The browser widget alone is not treated as protection. The server calls Cloudflare Siteverify and checks that the returned hostname matches the request origin. Tokens are single-use and expire after five minutes. Production requests fail closed when the secret or valid token is missing. Local development may bypass Turnstile only when `NODE_ENV` is not `production` and the secret is not configured.

Official documentation: https://developers.cloudflare.com/turnstile/get-started/server-side-validation/ and https://developers.cloudflare.com/turnstile/get-started/client-side-rendering/widget-configurations/.

## 6. Required environment variables

Copy `.env.example` into the private hosting environment and supply real values there. Never commit a real `.env` file.

- `SUPABASE_URL`
- `SUPABASE_SECRET_KEY`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `ADMIN_SESSION_SECRET` (at least 32 random characters)
- `OTP_PEPPER` (at least 24 random characters)
- `RATE_LIMIT_PEPPER` (at least 24 random characters)
- `ANALYTICS_SESSION_PEPPER` (at least 24 random characters)
- `RESEND_API_KEY`
- `EMAIL_FROM`
- `MSG91_AUTH_KEY`
- `MSG91_OTP_TEMPLATE_ID`
- `NEXT_PUBLIC_TURNSTILE_SITE_KEY`
- `TURNSTILE_SECRET_KEY`
- `ALLOWED_ORIGINS`
- `ALLOWED_SITE_IDS=aroush-existing,aroush-new`
- `DEFAULT_SITE_ID=aroush-existing`

Keep all secrets different and private. Use the hosting platform's environment variable manager. Never send credentials through chat or add them to GitHub.

## 7. Hosting and website connection plan

The main AROUSH Tech website and this companion app are separate applications. Do not merge the two Next.js apps into one runtime. The companion app can be deployed separately when the owner authorises it and supplies the provider accounts.

The current public hostname `https://aroushtech.in` must remain untouched during development. Use a staging hostname or a Vercel preview URL for the new website. Do not attach either tracker until the app is deployed, the privacy notice is approved, and accept/reject/withdrawal tests pass.

After an approved deployment, the tracker snippets are:

```html
<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-existing"></script>
<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-new"></script>
```

Install only one matching snippet on each actual site. The analytics app origin and both actual site origins must be listed exactly in `ALLOWED_ORIGINS`. Do not use the placeholder hostnames in production.

## 8. Admin access

Open `/login` on the deployed app and sign in using `ADMIN_EMAIL` and `ADMIN_PASSWORD`. The app issues a signed HTTP-only, SameSite=Strict cookie. Use a unique long password, rotate secrets, restrict access to named staff, enable MFA at the hosting/provider account level where available, and review session expiry. Application-level admin MFA is not implemented in this version.

## 9. Retention and legal review

No automatic retention schedule is enabled. Before public launch, the owner must approve and configure deletion periods for:

- aggregate page-view and page-time events;
- enquiry records and related contact details;
- expired OTP challenges;
- hashed API rate-limit records; and
- provider-side email/SMS logs.

The owner must also approve the official privacy contact, purposes and consent wording, data access roles, deletion/access/grievance workflow, provider contracts, backups, incident-response contact, and applicable Indian DPDP and other jurisdictional requirements. Obtain qualified legal review. This technical README is not legal advice.

## Current status and deployment boundary

- Development integration only; not deployed.
- No Supabase project, Resend account, MSG91 account, Cloudflare Turnstile widget, Vercel project or GitHub repository has been modified.
- No secrets were supplied or stored in this package.
- No tracker has been installed on the current live website.
- The root AROUSH Tech website still keeps its GA4 Measurement ID blank until the owner configures an authorised property; GA4 also remains opt-in only.
- Full semantic TypeScript checking, dependency installation, production build, provider delivery tests, Supabase RLS tests and real browser/device tests remain release gates.
