/*
 * Aroush Tech aggregate analytics tracker.
 * Nothing is sent until the visitor explicitly accepts optional analytics.
 * Uses only a temporary tab-scoped session token; there is no persistent visitor ID.
 * No fingerprinting, raw IP storage, form-field reading, or exact GPS collection.
 */
(function () {
  'use strict';

  var script = document.currentScript;
  if (!script) return;
  var siteId = script.getAttribute('data-site-id') || 'aroush-existing';
  var apiBase = (script.getAttribute('data-endpoint') || new URL(script.src).origin).replace(/\/$/, '');
  var consentKey = 'aroush_analytics_consent_v2';
  var sessionKey = 'aroush_tab_session_v2';
  var lastPath = '';
  var consentVersion = '2026-11-aggregate';
  var activeStartedAt = 0;
  var activeMilliseconds = 0;
  var pageTimeSent = true;
  var memorySessionId = '';

  function getConsent() {
    try { return localStorage.getItem(consentKey); } catch (_) { return null; }
  }

  function setConsent(value) {
    try { localStorage.setItem(consentKey, value); } catch (_) { /* If storage is unavailable, consent is not persisted. */ }
  }

  function makeId() {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    var bytes = new Uint8Array(16);
    window.crypto.getRandomValues(bytes);
    return Array.prototype.map.call(bytes, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
  }

  function getSessionId() {
    try {
      var value = sessionStorage.getItem(sessionKey);
      if (!value) {
        value = makeId();
        sessionStorage.setItem(sessionKey, value);
      }
      return value;
    } catch (_) {
      if (!memorySessionId) memorySessionId = makeId();
      return memorySessionId;
    }
  }

  function getBrowser(ua) {
    if (/Edg\//.test(ua)) return 'Edge';
    if (/OPR\//.test(ua)) return 'Opera';
    if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) return 'Chrome';
    if (/Firefox\//.test(ua)) return 'Firefox';
    if (/Safari\//.test(ua) && !/Chrome\//.test(ua)) return 'Safari';
    return 'Other';
  }

  function getOS(ua) {
    if (/Android/.test(ua)) return 'Android';
    if (/iPhone|iPad|iPod/.test(ua)) return 'iOS';
    if (/Windows NT/.test(ua)) return 'Windows';
    if (/Mac OS X/.test(ua)) return 'macOS';
    if (/Linux/.test(ua)) return 'Linux';
    return 'Other';
  }

  function getDevice(ua) {
    if (/iPad|Tablet/.test(ua)) return 'Tablet';
    if (/Mobi|Android|iPhone|iPod/.test(ua)) return 'Mobile';
    return 'Desktop';
  }

  function safeReferrer(value) {
    if (!value) return null;
    try {
      var url = new URL(value);
      return url.origin + url.pathname.slice(0, 300); // Drop query strings and fragments.
    } catch (_) { return null; }
  }

  function currentPath() {
    return window.location.pathname.slice(0, 300) || '/'; // Never send query strings or fragments.
  }

  function postEvent(payload) {
    return fetch(apiBase + '/api/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      keepalive: true,
      mode: 'cors'
    }).catch(function () { /* Analytics must never interrupt the website. */ });
  }

  function sendPageTime() {
    if (pageTimeSent || !lastPath || getConsent() !== 'accepted') return;
    pageTimeSent = true;
    if (activeStartedAt) {
      activeMilliseconds += Date.now() - activeStartedAt;
      activeStartedAt = 0;
    }
    var seconds = Math.min(1800, Math.max(0, Math.round(activeMilliseconds / 1000)));
    postEvent({
      siteId: siteId,
      sessionId: getSessionId(),
      eventType: 'page_time',
      analyticsConsent: true,
      consentVersion: consentVersion,
      path: lastPath,
      durationSeconds: seconds
    });
  }

  function sendPageView() {
    if (getConsent() !== 'accepted') return;
    var path = currentPath();
    if (path === lastPath) return;
    sendPageTime();
    lastPath = path;
    activeMilliseconds = 0;
    activeStartedAt = document.visibilityState === 'hidden' ? 0 : Date.now();
    pageTimeSent = false;

    var params = new URLSearchParams(window.location.search);
    var ua = navigator.userAgent || '';
    postEvent({
      siteId: siteId,
      sessionId: getSessionId(),
      eventType: 'page_view',
      analyticsConsent: true,
      consentVersion: consentVersion,
      path: path,
      referrer: safeReferrer(document.referrer),
      browser: getBrowser(ua),
      os: getOS(ua),
      device: getDevice(ua),
      utmSource: params.get('utm_source'),
      utmMedium: params.get('utm_medium'),
      utmCampaign: params.get('utm_campaign')
    });
  }

  function handleVisibilityChange() {
    if (document.visibilityState === 'hidden') {
      if (activeStartedAt) {
        activeMilliseconds += Date.now() - activeStartedAt;
        activeStartedAt = 0;
      }
      return;
    }
    if (!pageTimeSent && !activeStartedAt) activeStartedAt = Date.now();
  }

  function addPrivacyButton() {
    if (document.getElementById('aroush-privacy-settings')) return;
    var privacy = document.createElement('button');
    privacy.id = 'aroush-privacy-settings';
    privacy.type = 'button';
    privacy.textContent = 'Privacy';
    privacy.setAttribute('aria-label', 'Change analytics privacy choice');
    privacy.style.cssText = 'position:fixed;z-index:2147482000;right:14px;bottom:14px;background:#101827;color:#d8e4ee;border:1px solid #334155;border-radius:18px;padding:7px 11px;font:11px system-ui;cursor:pointer;box-shadow:0 5px 20px rgba(0,0,0,.22)';
    privacy.addEventListener('click', function () {
      sendPageTime();
      try { localStorage.removeItem(consentKey); } catch (_) {}
      try { sessionStorage.removeItem(sessionKey); } catch (_) {}
      privacy.remove();
      lastPath = '';
      addConsentBanner();
    });
    document.body.appendChild(privacy);
  }

  function addConsentBanner() {
    var choice = getConsent();
    if (choice) {
      if (choice === 'accepted') sendPageView();
      addPrivacyButton();
      return;
    }
    if (document.getElementById('aroush-consent-banner')) return;

    var banner = document.createElement('section');
    banner.id = 'aroush-consent-banner';
    banner.setAttribute('role', 'dialog');
    banner.setAttribute('aria-label', 'Optional analytics privacy choice');
    banner.style.cssText = 'position:fixed;z-index:2147483000;left:16px;right:16px;bottom:16px;max-width:720px;margin:auto;padding:18px 20px;background:#101827;color:#edf2f7;border:1px solid #334155;border-radius:16px;box-shadow:0 18px 55px rgba(0,0,0,.32);font:14px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;display:flex;gap:16px;align-items:center;justify-content:space-between;flex-wrap:wrap';

    var content = document.createElement('div');
    content.style.cssText = 'flex:1;min-width:220px';
    var title = document.createElement('strong');
    title.textContent = 'Your privacy matters';
    title.style.cssText = 'display:block;font-size:15px;margin-bottom:4px;color:#fff';
    var description = document.createElement('span');
    description.textContent = 'Allow optional aggregate analytics to help Aroush Tech improve this website. Reports show pages, visit time, device/browser, traffic source and approximate geography—not individual visitor profiles.';
    description.style.color = '#cbd5e1';
    content.appendChild(title);
    content.appendChild(description);
    var privacyLink = document.createElement('a');
    privacyLink.href = apiBase + '/privacy';
    privacyLink.target = '_blank';
    privacyLink.rel = 'noopener noreferrer';
    privacyLink.textContent = 'Read the privacy notice';
    privacyLink.style.cssText = 'display:inline-block;margin-top:6px;color:#86efac;text-decoration:underline;font-size:12px';
    content.appendChild(privacyLink);

    var actions = document.createElement('div');
    actions.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap';
    function button(label, accepted, primary) {
      var item = document.createElement('button');
      item.type = 'button';
      item.textContent = label;
      item.style.cssText = 'border:1px solid ' + (primary ? '#22c55e' : '#64748b') + ';border-radius:9px;padding:9px 12px;font:600 12px system-ui;cursor:pointer;background:' + (primary ? '#16a34a' : 'transparent') + ';color:#fff';
      item.addEventListener('click', function () {
        setConsent(accepted ? 'accepted' : 'rejected');
        banner.remove();
        addPrivacyButton();
        if (accepted) sendPageView();
        else { try { sessionStorage.removeItem(sessionKey); } catch (_) {} }
      });
      return item;
    }
    actions.appendChild(button('Reject optional', false, false));
    actions.appendChild(button('Accept analytics', true, true));
    banner.appendChild(content);
    banner.appendChild(actions);
    document.body.appendChild(banner);
  }

  function init() {
    addConsentBanner();
    window.addEventListener('popstate', sendPageView);
    window.addEventListener('pagehide', sendPageTime);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    var originalPushState = history.pushState;
    history.pushState = function () {
      originalPushState.apply(history, arguments);
      setTimeout(sendPageView, 0);
    };
    var originalReplaceState = history.replaceState;
    history.replaceState = function () {
      originalReplaceState.apply(history, arguments);
      setTimeout(sendPageView, 0);
    };
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
