# AROUSH Tech dual-site integration plan

## Current boundary

- Current public website: `https://aroushtech.in` — keep untouched during development.
- Redesigned website: use a staging hostname or provider preview URL until the owner approves cutover.
- Visitor Intelligence: a separate Next.js companion app in `apps/visitor-intelligence`.
- No tracker is installed on either website and no hosted lead form has been connected to the live site.

## Site identifiers

- `aroush-existing` — current public website.
- `aroush-new` — redesigned website on staging after it exists.

## Aggregate-only tracker

The tracker sends no events until the visitor explicitly accepts optional analytics. Reject and persistent Privacy settings are available. It uses a temporary tab-scoped token, HMAC-hashed on the server, only to group page views within that tab. It does not store persistent visitor IDs, raw or masked IPs, device fingerprints or individual visitor journeys. The dashboard displays aggregate page, time, device/browser, source and approximate-geography breakdowns only.

## Future tracker snippets (not active)

```html
<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-existing"></script>
<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-new"></script>
```

Replace the placeholder only after the companion app is deployed with explicit approval. Add the exact analytics app and website origins to `ALLOWED_ORIGINS`. Do not install two different site IDs on the same hostname simultaneously.

## Future enquiry links (not active)

```text
https://YOUR-DEPLOYED-DOMAIN/lead?site=aroush-existing
https://YOUR-DEPLOYED-DOMAIN/lead?site=aroush-new
```

The enquiry app stores a lead only after contact consent, email OTP, SMS OTP and Turnstile checks succeed. Phone numbers are collected only when a visitor voluntarily enters them in the clearly described form. The root website's existing review-first email form remains unchanged until the hosted form domain is approved.

## Required owner approvals before production

1. Approve exact staging and analytics hostnames.
2. Supply AROUSH-owned Supabase, Resend, MSG91 and Cloudflare Turnstile accounts.
3. Approve provider processing terms, data retention and deletion workflow.
4. Approve the final privacy notice and official privacy contact after legal review.
5. Complete Node 24 builds, RLS/OTP/Turnstile tests and Android/desktop browser QA.
6. Give separate explicit permission for GitHub, hosting, DNS or live-site changes.

No live or cloud changes have been made by this development integration.
