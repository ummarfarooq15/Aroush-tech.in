# AROUSH Tech Visitor Intelligence — Android setup guide

This guide explains the eventual cloud setup from an Android phone. **It is not permission to deploy.** The owner approved the development integration, but no GitHub, Vercel, Supabase, Resend, MSG91, Cloudflare, DNS or live WordPress changes may be made until separate deployment approval is given.

## 1. Development requirements

- Node.js 24.x (the app's `.nvmrc` is `24`).
- A private GitHub repository, if the owner later authorises one.
- A Vercel project, if the owner later authorises deployment.
- An AROUSH-owned Supabase project.
- AROUSH-owned Resend and MSG91 accounts.
- A Cloudflare Turnstile widget.

Do not use Node 22. Do not commit real `.env` files, API keys, database secrets, OTP peppers or administrator passwords.

## 2. Create a private development repository (only after approval)

1. Open GitHub in Chrome and sign in.
2. Choose **+ → New repository** and set it to **Private**.
3. Use a clear project name such as `aroushtech-platform`.
4. If using Codespaces, create a Codespace on a development branch.
5. Upload the approved source bundle and extract it in the Codespace.
6. Confirm `.env.example` is present but no real `.env` or secrets are included.
7. Review the changed files and run the offline validators before committing.

## 3. Provision Supabase (only after approval)

1. Create a new non-production Supabase project owned by AROUSH Tech.
2. Open **SQL Editor**.
3. Run `apps/visitor-intelligence/supabase/schema.sql`.
4. Copy the project URL and server secret key into the hosting environment as `SUPABASE_URL` and `SUPABASE_SECRET_KEY`.
5. Never expose the secret key in browser code or a `NEXT_PUBLIC_` variable.
6. Test RLS and all RPC functions before using real lead data.

If a previous draft schema was already applied, take a backup and run `supabase/migrations/20261107_aggregate_analytics_and_otp_hardening.sql` first, then run the current `supabase/schema.sql`. This intentionally deletes the old visitor-profile/event tables and stale OTP/rate-limit state while retaining lead records. No production database has been connected by this project.

## 4. Configure provider accounts

- **Resend:** verify a sender domain, create an API key, and configure `RESEND_API_KEY` plus `EMAIL_FROM`.
- **MSG91:** create an approved six-digit OTP template, complete applicable India DLT steps, and configure `MSG91_AUTH_KEY` plus `MSG91_OTP_TEMPLATE_ID`.
- **Cloudflare Turnstile:** create a widget for the exact staging hostname, then configure `NEXT_PUBLIC_TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY`.
- **Administrator:** configure a unique `ADMIN_EMAIL`, long `ADMIN_PASSWORD`, and random `ADMIN_SESSION_SECRET` of at least 32 characters.
- **HMAC secrets:** configure separate random values for `OTP_PEPPER`, `RATE_LIMIT_PEPPER` and `ANALYTICS_SESSION_PEPPER` (each at least 24 characters).

Use the hosting provider's private environment-variable settings. Never paste secrets into GitHub or ChatGPT.

## 5. Configure origins and site IDs

Set `ALLOWED_ORIGINS` to the exact HTTPS origins of the analytics app and the website(s) that will call it. Include `www` only if it is actually used. Set:

```text
ALLOWED_SITE_IDS=aroush-existing,aroush-new
DEFAULT_SITE_ID=aroush-existing
```

The current public site is `https://aroushtech.in`. Keep it untouched. Use a staging hostname or preview URL for the redesigned website. Do not install the tracker on either site until consent, privacy, security and deployment tests are approved.

## 6. Tracker and enquiry links (future use only)

After an approved deployment, the existing-site tracker would use:

```html
<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-existing"></script>
```

The redesigned staging site would use:

```html
<script async src="https://YOUR-DEPLOYED-DOMAIN/aroush-tracker.js" data-site-id="aroush-new"></script>
```

The hosted enquiry form would use `/lead?site=aroush-existing` or `/lead?site=aroush-new`. Do not add these links to the live website until the owner approves the exact hosted domain and integration.

## 7. Release tests

Before any public launch:

- Node 24 dependency install and lockfile review pass.
- Full TypeScript typecheck, lint and production build pass for both Next.js apps independently.
- Supabase RLS, atomic email/SMS verification and atomic lead creation pass in a test project.
- Turnstile Siteverify accepts a valid token and rejects invalid, expired and replayed tokens.
- Email and SMS delivery are tested with owner-controlled addresses/numbers; MSG91 DLT and provider spending limits are verified.
- Analytics sends no event before opt-in, sends no event after rejection, and stops after withdrawal.
- Dashboard exposes aggregate analytics only; it never shows a visitor list, raw IP or persistent visitor ID.
- Privacy notice, contact email, retention schedule and deletion workflow are approved.
- Android Chrome and desktop browser QA pass on a staging URL.

## Current state

Development files only. No deployment, live site modification, DNS change, GitHub push, provider account setup or database creation has been performed. Full build and real browser/provider testing remain pending because the current environment has Node 22.16.0, no Node 24 binary, no installed dependencies and no configured provider credentials.
