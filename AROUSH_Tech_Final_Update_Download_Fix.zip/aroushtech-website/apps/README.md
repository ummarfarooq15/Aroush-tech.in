# AROUSH Tech companion applications

`visitor-intelligence/` is a separate Next.js application for the approved visitor analytics, verified enquiry and admin dashboard service. It intentionally has its own `package.json`, `.nvmrc`, environment variables and deployment lifecycle to avoid collisions with the primary website routes.

See `../docs/security/VISITOR_INTELLIGENCE_INTEGRATION_REVIEW.md` before configuring or deploying it. It is a development integration only; production setup requires owner-controlled Supabase, Resend, MSG91 and hosting accounts plus the listed security/privacy blockers.
