export function toggleComparedCourse(
  selectedSlugs: string[],
  slug: string,
  maxCourses?: number,
): string[];
