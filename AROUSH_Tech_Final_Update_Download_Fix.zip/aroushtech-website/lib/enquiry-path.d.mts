export type EnquiryType = "learner" | "business" | "general";

export const enquiryTypeLabels: Readonly<Record<EnquiryType, string>>;
export function normalizeEnquiryType(value?: string, hasCourse?: boolean): EnquiryType;
export function defaultInterestForType(type: EnquiryType): string;
export function buildEnquiryEmail(details: {
  type: EnquiryType;
  interest: string;
  name: string;
  email: string;
  phone?: string;
  organization?: string;
  teamSize?: string;
  course?: string;
  message: string;
}): { subject: string; body: string };
