export type CourseSortOrder = "featured" | "name-asc" | "name-desc";

export type CourseSortItem = {
  title: string;
};

export function sortCourses<T extends CourseSortItem>(
  items: T[],
  order?: CourseSortOrder,
): T[];
