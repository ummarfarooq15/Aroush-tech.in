export type AnalyticsConsentChoice = "accepted" | "rejected" | null;

export function isValidGaMeasurementId(value: unknown): boolean;
export function normalizeConsentChoice(value: unknown): AnalyticsConsentChoice;
export function shouldLoadAnalytics(input: {
  measurementId: unknown;
  choice: AnalyticsConsentChoice;
}): boolean;
export function safePagePath(pathname: unknown): string;
export function safePageReferrer(referrer: unknown, siteOrigin: string): string | undefined;
export function buildPageViewPayload(input: {
  origin: string;
  pathname: string;
  title?: string;
  referrer?: string;
}): {
  page_title: string;
  page_location: string;
  page_path: string;
  page_referrer?: string;
};
