export type CourseOutlineFilter = "all" | "published" | "confirm";

export type CourseOutlineDetails = {
  outline?: string[];
  sourceNote?: string;
};

export function hasPublishedOutline(
  details: CourseOutlineDetails | undefined,
): boolean;

export function filterCoursesByOutline<T extends { slug: string }>(
  items: T[],
  detailsBySlug: Record<string, CourseOutlineDetails | undefined>,
  filter?: CourseOutlineFilter,
): T[];
