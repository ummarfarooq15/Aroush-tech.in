// Search the published street address instead of pinning an unverified coordinate.
// This lets Google Maps resolve the address without implying a confirmed GPS point.
const mapsSearchUrl = (address: string) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;

const corporateOfficeAddress =
  "#47, 4th Main, 4th Cross, New Gurupanapalya, KEB Layout, Bannerghatta Main Road, Bangalore – 560029";
const registeredOfficeAddress =
  "AROUSH SOLUTIONS (OPC) PRIVATE LIMITED, #9, KH No. 9/9,1, Muniswamy L/O, 20th Main, Sarakki, Bangalore, Karnataka – 560078";

export const company = {
  brand: "Aroush Tech",
  legalName: "AROUSH SOLUTIONS (OPC) PRIVATE LIMITED",
  cin: "U72900KA2022OPC162189",
  email: "taj@aroushtech.in",
  phone: "+91 88676 92074",
  phoneHref: "+918867692074",
  website: "https://aroushtech.in",
  linkedin: "https://in.linkedin.com/company/aroush-solutions-opc-private-limited",
  offices: [
    {
      label: "Corporate Office",
      address: corporateOfficeAddress,
      mapUrl: mapsSearchUrl(corporateOfficeAddress)
    },
    {
      label: "Registered Office",
      address: registeredOfficeAddress,
      mapUrl: mapsSearchUrl(registeredOfficeAddress)
    }
  ],
  vision: "To be the preferred consulting and training services company, providing solutions and training that empower people and businesses around the world.",
  mission: "To help your welfare and inspire people to realize their full potential through our revolutionary and superior training programs.",
  description: "A Bengaluru-based IT consulting and training company with public courses across networking, cybersecurity, cloud, Linux, automation and AI & machine learning.",
  tagline: "Technology, connected to your business.",
  promise: "Connect. Secure. Support. Train."
};


export const approach = [
  { title: "Business context first", text: "Begin with the requirement, operating environment, intended outcome and feasible scope before choosing technology." },
  { title: "Complementary services and visible outputs", text: "Connect infrastructure, security, support and learning where useful. Agree deliverables, acceptance, handover and the people responsible." },
  { title: "Practical prioritization", text: "Turn findings and skills gaps into an ordered action plan. Confirm resources, platform rights, data access and change/testing boundaries before work begins." },
  { title: "Learning beyond handover", text: "Include usable documentation, relevant awareness or hands-on technical learning when agreed. Measure completed tasks and learning evidence rather than promising outcomes outside the engagement." }
];

export const reasonsToChoose = [
  { title: "Professional trainers", text: "The current AROUSH website describes its trainers as experienced and focused on technical clarity." },
  { title: "Hands-on practical learning", text: "Course pages describe instructor-led sessions supported by practical exercises and lab work." },
  { title: "Support for international students", text: "The About page lists a dedicated support cell for international students." },
  { title: "Flexible learning formats", text: "The Contact page describes online, offline and hybrid training formats; availability is confirmed per programme." }
];

export const industries = [
  { title: "Technology & SaaS", priorities: "Customer reviews, application exposure, identity and cloud telemetry.", startingServices: "DPO · PAM · VAPT · SOC/SIEM" },
  { title: "Professional services", priorities: "Sensitive information, connected offices and everyday staff security.", startingServices: "DPO · Infrastructure · Awareness" },
  { title: "Healthcare & pharma", priorities: "Data handling, clinic connectivity, access and incident escalation.", startingServices: "DPO · Network security · Support · SOC" },
  { title: "Education & institutions", priorities: "Campus connectivity, awareness and practical technical skills.", startingServices: "Infrastructure · Awareness · Technical and SOC training" },
  { title: "Retail & e-commerce", priorities: "Data flows, application exposure, branches and account activity.", startingServices: "DPO · VAPT · Network security · SOC" },
  { title: "Manufacturing", priorities: "Industrial asset visibility, safe boundaries and staged improvements.", startingServices: "OT/ICS · Infrastructure · Support · Scoped SOC telemetry" },
  { title: "SMEs & branch businesses", priorities: "New offices, performance, maintenance and limited IT capacity.", startingServices: "Infrastructure · Network security · Support · Readiness" },
  { title: "Regulated entities & SIEM owners", priorities: "Applicable evidence needs, tuning, log coverage and operational skills.", startingServices: "SOC readiness · Health checks · Platform training" }
];

export const pillars = [
  { number: "01", title: "Connect", text: "Networks, structured cabling, Wi-Fi, racks and IT installation.", services: "Service 06" },
  { number: "02", title: "Secure", text: "Privacy, privileged access, testing, industrial and network security, and SOC/SIEM.", services: "Services 01–04, 07, 10" },
  { number: "03", title: "Support", text: "Troubleshooting, maintenance, health reviews and upgrade planning.", services: "Service 08" },
  { number: "04", title: "Train", text: "Workforce awareness, corporate technical skills and SOC analyst learning.", services: "Services 05, 09, 10" }
];

export const services = [
  {
    number: "01", pillar: "Secure", title: "DPO-as-a-Service", summary: "A structured approach to personal-data governance and privacy ownership.",
    bullets: ["Privacy governance and current-state reviews", "Data inventory and data-flow coordination", "Policy and procedure drafts for client approval", "Prioritized action tracking and management reporting"],
    deliverable: "A prioritized action register, coordinated data-inventory pack, policy drafts and periodic management reports.",
    audience: "SaaS, e-commerce, healthcare and professional-services organizations handling personal data.",
    note: "Privacy governance advisory. A statutory DPO appointment is a separate, qualified engagement; legal advice requires separately engaged counsel."
  },
  {
    number: "02", pillar: "Secure", title: "CyberArk PAM Consulting", summary: "Plan and review controls for privileged accounts and administration.",
    bullets: ["Privileged-access and platform health assessments", "Architecture and deployment planning", "Agreed implementation support", "Configuration, policy review and operational handover"],
    deliverable: "A privileged-account inventory, assessment findings, roadmap, deployment plan and handover documentation as agreed.",
    audience: "Mid-market and enterprise organizations using or planning CyberArk PAM.",
    note: "Depends on supported platform versions, licensed environments and qualified resources. No vendor authorization or license supply is implied."
  },
  {
    number: "03", pillar: "Secure", title: "VAPT Subscription", summary: "Identify weaknesses, prioritize remediation and revisit agreed fixes.",
    bullets: ["Authorized asset and test scoping", "Scheduled vulnerability scanning", "Separately defined manual penetration testing", "Risk-prioritized findings, remediation guidance and retesting"],
    deliverable: "Rules of engagement, a risk-prioritized findings report, remediation tracker and retest confirmation for the defined assets.",
    audience: "SaaS providers, web businesses and organizations with defined internet-facing assets.",
    note: "Written authorization and rules of engagement are required. Testing is time-bound and cannot guarantee the absence of vulnerabilities."
  },
  {
    number: "04", pillar: "Secure", title: "OT / ICS Security Consulting", summary: "Improve industrial visibility and network boundaries while respecting plant safety and uptime.",
    bullets: ["Industrial asset and access documentation", "Plant network and boundary reviews", "Risk identification and prioritization", "Segmentation advice and staged remediation planning"],
    deliverable: "An asset and access register, zone and network-boundary diagram, prioritized risk findings and a staged improvement plan.",
    audience: "Manufacturing plants and industrial operators with connected control environments.",
    note: "Active testing is not included by default; it requires explicit approval, specialist resources and production-safety planning."
  },
  {
    number: "05", pillar: "Train", title: "Security Awareness Training", summary: "Help employees recognize everyday risks and know how to report suspicious activity.",
    bullets: ["Phishing recognition and reporting", "Password and access hygiene", "Safe handling of workplace data", "Role-based scenarios and recurring awareness sessions"],
    deliverable: "Session materials, attendance records, role-based scenarios and a feedback summary with learning checks defined in advance.",
    audience: "General staff, new joiners, HR and learning-and-development teams, and roles exposed to sensitive information.",
    note: "Workforce awareness is distinct from technical-skills training. Regulatory certification is not implied."
  },
  {
    number: "06", pillar: "Connect", title: "Network Infrastructure & IT Installation", summary: "Build a dependable foundation for new offices, relocations and growing teams.",
    bullets: ["LAN/WAN planning and structured cabling", "Rack, switch and router installation", "Wireless access-point and Wi-Fi deployment", "Workstation setup, testing and documented handover"],
    deliverable: "A site survey and design, as-built diagrams, tested and labelled cabling, configuration backups and handover pack as scoped.",
    audience: "SMEs, professional offices, schools, clinics and organizations expanding branch locations.",
    note: "Hardware and license supply are included only when expressly scoped. Site access, materials and onsite coverage are confirmed in the proposal."
  },
  {
    number: "07", pillar: "Secure", title: "Network Security Solutions", summary: "Create clear access boundaries that teams can review and maintain.",
    bullets: ["Firewall, VPN and secure remote-access configuration", "Network segmentation and access controls", "Rule-base and configuration reviews", "Documented security configuration and handover"],
    deliverable: "A scoped configuration plan, reviewed rules and access controls, configuration records and handover documentation.",
    audience: "SMEs and mid-market organizations with branches or remote users.",
    note: "Hardware, subscriptions, high availability and incident response are included only when expressly scoped."
  },
  {
    number: "08", pillar: "Support", title: "Technical Support & Network Assessment", summary: "A defined route for troubleshooting, preventive maintenance and upgrade decisions.",
    bullets: ["Agreed remote and onsite troubleshooting", "Preventive maintenance and configuration backups", "Approved firmware updates and incident resolution", "Infrastructure health, Wi-Fi reviews and upgrade planning"],
    deliverable: "A request log, maintenance reports, health-check findings and a prioritized upgrade roadmap for the agreed environment.",
    audience: "Organizations with installed networks and limited in-house support capacity.",
    note: "Service hours, response targets, escalation and coverage are contractual. 24×7 monitoring is not assumed."
  },
  {
    number: "09", pillar: "Train", title: "Corporate IT & Cybersecurity Training", summary: "Build practical technical skills through demonstrations, labs and assessment.",
    bullets: ["Corporate and campus technical programmes", "Curriculum and lab-guide development", "Train-the-trainer engagements", "Networking, firewall, cybersecurity and cloud learning"],
    deliverable: "A training-needs summary, curriculum, lab guides, learner assessment and feedback report for the agreed programme.",
    audience: "Enterprise IT teams, L&D departments, colleges and training organizations.",
    note: "Prerequisites, trainer availability, lab capacity and assessment are confirmed per programme. Exam vouchers, vendor accreditation and placement outcomes are not implied."
  },
  {
    number: "10", pillar: "Secure + Train", title: "SOC / SIEM Services: Deployment & Training", summary: "A practical deployment path, more useful telemetry and the skills to operate an environment.",
    bullets: ["Readiness, log-source coverage and architecture planning", "Authorized platform deployment and source onboarding", "Detection use cases, rule tuning and test evidence", "Dashboards, triage runbooks, handover and analyst/admin learning"],
    deliverable: "A readiness scorecard, source matrix, phased architecture, tested onboarding, detection records, runbooks and knowledge transfer as scoped.",
    audience: "SMEs, mid-market and enterprise IT/security teams, IT service providers, MSSPs and institutions.",
    note: "New business line. Delivery depends on confirmed people, platform access and scope. No current vendor partnership, official vendor accreditation, 24×7 monitoring or guaranteed response is implied."
  }
];

export type PublicCourse = {
  slug: string;
  title: string;
  category: string;
  description: string;
  previousPrice?: string;
  listedPrice?: string;
  feeNote?: string;
};

export const courses: PublicCourse[] = [
  { slug: "ccna", title: "CCNA", category: "Networking", description: "Foundational networking course covering routing, switching, and basic network security concepts.", feeNote: "The live catalogue and individual course page show different amounts. Ask AROUSH to confirm the current fee before payment." },
  { slug: "ccna-devnet", title: "CCNA DevNet", category: "Network Automation", description: "Combines networking knowledge with software development, automation, and APIs.", feeNote: "The live catalogue and individual course page show different amounts. Ask AROUSH to confirm the current fee before payment." },
  { slug: "ccnp-enterprise", title: "CCNP Enterprise", category: "Networking", description: "Advanced networking course focused on enterprise infrastructure, routing, and wireless solutions.", previousPrice: "55,000", listedPrice: "45,000" },
  { slug: "ccnp-security", title: "CCNP Security", category: "Network Security", description: "Covers security protocols, firewalls, VPNs, and securing enterprise networks.", previousPrice: "55,000", listedPrice: "45,000" },
  { slug: "ise-identity-services-engine", title: "ISE (Identity Services Engine)", category: "Network Security", description: "Learn to manage secure network access using Cisco ISE for policy enforcement and identity management.", previousPrice: "25,000", listedPrice: "15,000" },
  { slug: "ansible-terraform", title: "Ansible & Terraform", category: "Network Automation", description: "Automate IT infrastructure using Ansible (configuration management) and Terraform (infrastructure provisioning).", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "checkpoint-firewall", title: "Checkpoint Firewall", category: "Network Security", description: "Hands-on training to configure and manage Checkpoint firewalls for network security.", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "fortinet-certified-engineer", title: "Fortinet Certified Engineer", category: "Network Security", description: "Covers FortiGate firewall setup, security policies, VPNs, and UTM features.", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "palo-alto-firewall-certified-engineer", title: "Palo Alto Firewall Certified Engineer", category: "Network Security", description: "Focus on firewall deployment, configuration, and threat prevention with Palo Alto devices.", previousPrice: "25,000", listedPrice: "21,000" },
  { slug: "ceh-certified-ethical-hacker", title: "CEH (Certified Ethical Hacker)", category: "Cybersecurity", description: "Ethical hacking course that teaches how to find and fix system vulnerabilities.", previousPrice: "35,000", listedPrice: "25,000" },
  { slug: "cybersys", title: "Cybersys", category: "Cybersecurity", description: "Introductory course on cybersecurity tools, threats, and defense mechanisms.", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "linux-basic-cyber-security", title: "Linux + Basic Cyber Security", category: "Linux & Security", description: "Learn Linux fundamentals along with essential cybersecurity practices.", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "linux-advanced-cyber-security", title: "Linux + Advanced Cyber Security", category: "Linux & Security", description: "Deep dive into Linux system security, hardening, and advanced threat mitigation.", previousPrice: "45,000", listedPrice: "35,000" },
  { slug: "pentest-penetration-testing", title: "Pentest (Penetration Testing)", category: "Cybersecurity", description: "Learn how to simulate cyber attacks to identify and fix security weaknesses.", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "web-app-pen-tester", title: "Web App Pen Tester", category: "Cybersecurity", description: "Focus on identifying and exploiting vulnerabilities in web applications.", previousPrice: "25,000", listedPrice: "19,999" },
  { slug: "aws-solutions-architect-associate", title: "AWS Solutions Architect Associate", category: "Cloud", description: "Covers designing and deploying scalable systems on AWS cloud infrastructure.", previousPrice: "20,000", listedPrice: "15,000" },
  { slug: "ai-ml", title: "AI & ML", category: "AI & Machine Learning", description: "Comprehensive course on Artificial Intelligence and Machine Learning concepts and tools.", previousPrice: "65,000", listedPrice: "45,000" },
  { slug: "agentic-ai-langgraph-langchain", title: "Agentic AI with LangGraph & LangChain", category: "AI & Machine Learning", description: "Learn to build intelligent agents using LangGraph and LangChain for AI workflows.", previousPrice: "45,000", listedPrice: "35,000" },
  { slug: "agentic-ai-langchain-hugging-face", title: "Agentic AI with LangChain & Hugging Face", category: "AI & Machine Learning", description: "Explore building AI agents integrating LangChain with Hugging Face for powerful NLP applications.", previousPrice: "45,000", listedPrice: "35,000" },
  { slug: "ccnp-data-center", title: "CCNP Data Center", category: "Data Center", description: "Specialized training for managing complex data center networks and infrastructure.", previousPrice: "65,000", listedPrice: "55,000" }
];

export const socCourses = [
  { slug: "soc-analyst-foundation", title: "SOC Analyst Foundation", duration: "5 days", focus: "Telemetry, failed-login and brute-force analysis, basic triage, reporting and escalation." },
  { slug: "siem-administration-operations", title: "SIEM Administration & Operations", duration: "5 days", focus: "Collection, parsing, roles, retention, dashboards, backup and ingestion troubleshooting." },
  { slug: "threat-detection-log-analysis-incident-response", title: "Threat Detection, Log Analysis & Incident Response", duration: "5 days", focus: "Endpoint, authentication and cloud evidence, timelines, rule tuning and incident handover." },
  { slug: "advanced-soc-analyst-threat-hunting", title: "Advanced SOC Analyst & Threat Hunting", duration: "5 days", focus: "Hypothesis-led queries, multi-source investigations and tested detection improvement." },
  { slug: "platform-specific-siem-course", title: "Platform-specific SIEM course", duration: "3–5 days", focus: "One confirmed Microsoft Sentinel, Splunk, Elastic, Wazuh or supported QRadar environment." },
  { slug: "corporate-soc-readiness-workshop", title: "Corporate SOC Readiness Workshop", duration: "1–2 days", focus: "Business priorities, telemetry, roles, learning gaps and a practical pilot roadmap." }
];

export const platforms = ["Microsoft Sentinel", "Splunk", "Elastic", "Wazuh", "QRadar"];

export const team = [
  { name: "Abdul Aleem Khan", role: "Vertical Head – Cyber Security & Cloud Security", initials: "AK", photo: "https://aroushtech.in/wp-content/uploads/2025/07/Screenshot_11-7-2025_101516_aroushtech.in_-1-e1752307683348.jpeg" },
  { name: "Tajuddin", role: "Technical Head – Networking & Cyber Security", initials: "T", photo: "https://aroushtech.in/wp-content/uploads/2025/07/WhatsApp-Image-2025-07-11-at-21.01.49_9930e3d4-e1752307761559.jpg" },
  { name: "Mohammed Khalid", role: "Technical Head for Networking Security", initials: "MK", photo: "https://aroushtech.in/wp-content/uploads/2025/07/Screenshot_11-7-2025_101541_aroushtech.in_-1-e1752307999506.jpeg" }
];

export const gallery = [
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Training-36-1-1024x768.webp", alt: "Instructor guiding learners through a hands-on networking lab", caption: "Hands-on technical learning" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Traning-04-1024x768.webp", alt: "Learners taking part in a practical computer training session", caption: "Collaborative lab practice" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Training-23.jpg", alt: "Trainer supporting participants during a technical training session", caption: "Trainer-led learning" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Traning-10-1024x768.webp", alt: "Participants working at computers in a training room", caption: "Classroom training" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Training-21-1024x768.webp", alt: "Corporate technical training group in a computer lab", caption: "Corporate learning" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Traning-09-1024x768.webp", alt: "Training participants and instructor after a learning session", caption: "Learning community" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Training-15-1024x768.webp", alt: "Participants attending a practical IT course", caption: "Practical course session" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Traning-11-1024x768.webp", alt: "Learners practising technical skills at desktop computers", caption: "Technical practice" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Screenshot_7-7-2025_11189_aroushtech.in_.jpeg", alt: "A group of learners standing together at a training venue", caption: "Learner group" },
  { src: "https://aroushtech.in/wp-content/uploads/2025/07/Screenshot_7-7-2025_111734_aroushtech.in_.jpeg", alt: "Group photograph from a corporate cybersecurity training engagement", caption: "Corporate training group" }
];

export const testimonials = [
  { quote: "Trainer is great. hands-on experience helped me a lot. i would recommend studying with aroush solutions online to any online learner.", name: "Jamshed (tajakistan)", role: "Student" },
  { quote: "It was a wonderful learning experience with aroush solutions. the course was an eye-opener on future technologies and opportunities. thank you.", name: "Sana (Jordan)", role: "Student" }
];

export const faqs = [
  {
    category: "Courses & learning",
    q: "Which course areas can I explore?",
    a: "The current AROUSH catalogue includes networking, network security, network automation, cybersecurity, Linux and security, cloud, and AI and machine learning. Browse the catalogue for individual course pages and published outline information."
  },
  {
    category: "Courses & learning",
    q: "Is a free course demo available?",
    a: "The current AROUSH homepage advertises a free course demo. The team must confirm whether a demo is available for your selected course, preferred delivery format and timing."
  },
  {
    category: "Courses & learning",
    q: "Can training be delivered online, offline or in a hybrid format?",
    a: "The current AROUSH Contact page describes online, offline and hybrid training formats. Availability depends on the programme, trainer and agreed schedule, so confirm the option for your selected course."
  },
  {
    category: "Courses & learning",
    q: "How do I confirm prerequisites, duration and the next batch?",
    a: "Course pages publish different levels of detail, and this website does not have a verified live batch calendar. Ask the team to confirm the current syllabus, prerequisites, duration, next start date and available delivery format before enrolling."
  },
  {
    category: "Courses & learning",
    q: "Are the course fees shown on the website final?",
    a: "No. Any amount shown in the rebuilt catalogue is copied from the public catalogue and is a reference, not a final quotation. The live CCNA and CCNA DevNet catalogue and individual pages show conflicting amounts, so this rebuild withholds those two numeric fees. Confirm the current fee and payment terms directly with AROUSH before paying."
  },
  {
    category: "Courses & learning",
    q: "Do courses include an official vendor certification or exam voucher?",
    a: "Course completion criteria and assessments must be confirmed for each programme. Official vendor certification, vendor accreditation and exam vouchers are not implied unless AROUSH confirms the exact arrangement in writing."
  },
  {
    category: "Location & enquiries",
    q: "Where is the AROUSH training centre?",
    a: "The current AROUSH Contact page refers to a physical training centre in Bengaluru (J.P. Nagar), but does not provide a complete visitor address. The corporate and registered office addresses published on the same page are separate office details. Confirm the exact session venue with the team before travelling."
  },
  {
    category: "Location & enquiries",
    q: "Does the enquiry form send or store my details automatically?",
    a: "No. The form first shows an email preview on this page. Your details are not sent to or stored on this website. If the preview is correct, choose Open email app and send the message from your own email app. A phone number is optional and is included only if you choose to provide it."
  },
  {
    category: "Location & enquiries",
    q: "Can I pay for a course through this website?",
    a: "This rebuilt website does not process course payments or provide online checkout. Confirm current payment instructions directly with the AROUSH team using the published contact details. Do not rely on an external checkout destination unless AROUSH confirms it directly."
  },
  {
    category: "Services & business enquiries",
    q: "Which IT and cybersecurity services can I discuss with AROUSH?",
    a: "The rebuilt services page organises the portfolio described in the AROUSH company profile and brochure, including privacy governance, privileged access, VAPT, OT/ICS security, network infrastructure, technical support, training and SOC/SIEM. Confirm current service availability, resources, platform scope and deliverables with the team before treating any item as a commitment."
  },
  {
    category: "Services & business enquiries",
    q: "Does SOC/SIEM include continuous 24×7 human monitoring?",
    a: "No continuous human monitoring is assumed. Platform access, log sources, specialist resources, coverage hours, response targets and incident authority must be explicitly agreed in a written scope."
  },
  {
    category: "Location & enquiries",
    q: "How can I contact the AROUSH team?",
    a: "Email taj@aroushtech.in or call +91 88676 92074. For a useful first discussion, include your requirement, environment or course interest, priority, location and preferred timeline."
  }
];

