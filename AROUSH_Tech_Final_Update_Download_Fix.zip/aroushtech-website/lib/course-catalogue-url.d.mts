import type { CourseSortOrder } from "./course-sort.mjs";
import type { CourseOutlineFilter } from "./course-outline-filter.mjs";

export const MAX_COURSE_SEARCH_LENGTH: number;
export const MAX_COMPARISON_PARAMETER_LENGTH: number;

export type CourseCatalogueUrlState = {
  query: string;
  category: string;
  sortOrder: CourseSortOrder;
  outlineFilter: CourseOutlineFilter;
  compareSlugs: string[];
};

export function parseCourseCatalogueState(
  search: string,
  categories?: string[],
  courseSlugs?: string[],
): CourseCatalogueUrlState;

export function buildCourseCatalogueSearch(
  search: string,
  state: CourseCatalogueUrlState,
  categories?: string[],
  courseSlugs?: string[],
): string;
