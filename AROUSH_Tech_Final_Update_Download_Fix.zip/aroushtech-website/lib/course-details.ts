/**
 * Course outlines migrated from the corresponding public course-detail pages on aroushtech.in.
 * Only topics that were visible on the source pages at review time are included here.
 * The catalogue fee remains the source-of-truth amount from /courses/ and must be reconfirmed.
 */
export type CourseDetail = {
  sourceUrl: string;
  outline: string[];
  duration?: string;
  prerequisites?: string[];
  delivery?: string;
  sourceNote?: string;
};

export const courseDetails: Record<string, CourseDetail> = {
  "ai-ml": {
    sourceUrl: "https://aroushtech.in/ai-ml/",
    duration: "40 hours (as stated on the source page)",
    outline: [
      "Module 1 — AI/ML foundations: definitions, key concepts, history, and the differences between AI, machine learning and deep learning",
      "Module 1 — AI/ML in networking: network traffic prediction, anomaly detection and network optimization",
      "Module 1 — Networking basics: network concepts relevant to AI/ML and the relationship between network data and machine learning",
      "Module 2 — Python foundations: data types, variables, operators, loops, conditions and functions",
      "Module 2 — Python practice: file handling, exception handling, NumPy, Pandas and Matplotlib",
      "Module 2 — Network automation libraries listed on the source page: Netmiko, Ncclient and Requests",
      "Module 2 — Working with network data: parsing network logs and basic data manipulation with Pandas",
      "Module 3 — Network data formats: JSON, XML, YAML, syslogs, SNMP data and NetFlow records",
      "Module 3 — Data processing: Pandas cleaning, JSON/XML parsing, and storing network data in CSV files and databases",
      "Module 3 — Visualization: Matplotlib, Seaborn and dashboards for traffic trends and latency patterns",
      "Module 4 — Machine learning: supervised and unsupervised learning, linear regression, decision trees and k-means clustering",
      "Module 4 — Feature engineering: extracting useful features from network logs, normalization and handling missing values",
      "Module 5 — Predictive AI: predictive analytics, how predictive AI differs from traditional machine learning, and network-data preparation",
      "Module 5 — Networking use cases: traffic prediction, network-failure forecasting and load-balancing optimization",
      "Module 6 — Language models: LLMs, n-grams, RNNs, Transformers and the role of large-scale training datasets",
      "Module 6 — Language-model development: training concepts, fine-tuning, automated log analysis, network-support chatbots and natural-language configuration writing",
      "Module 7 — Generative AI: GANs, Transformer models and simulation of network environments",
      "Module 7 — Generative AI for network engineering: automated network-script generation and AI-assisted configuration templates"
    ]
  },
  "agentic-ai-langchain-hugging-face": {
    sourceUrl: "https://aroushtech.in/agentic-ai-with-langchain-hugging-face/",
    outline: [
      "Python foundations: control flow, data structures, functions, modules, file handling, exceptions and classes",
      "Streamlit and NLP prerequisites across machine learning and deep learning",
      "RNN, ANN, LSTM, GRU, bidirectional RNN, encoder-decoder and attention concepts",
      "Transformers, generative AI and large language models",
      "LangChain, OpenAI, Ollama and LCEL application patterns",
      "Conversational chatbots, RAG, document question answering and chat history",
      "Search tools, agents, SQL-connected applications and text summarization",
      "Hugging Face integration, PDF RAG, code assistants and application deployment",
      "CrewAI multi-agent applications, hybrid search, vector databases and graph databases",
      "Fine-tuning language models and stateful multi-actor applications with LangGraph"
    ]
  },
  "agentic-ai-langgraph-langchain": {
    sourceUrl: "https://aroushtech.in/agentic-ai-with-langgraph-and-langchain/",
    outline: [
      "Course introduction, Anaconda and VS Code setup",
      "Python prerequisites and Pydantic",
      "Hands-on LangChain and getting started with OpenAI and Ollama",
      "Building a basic LLM application with LCEL",
      "Building AI agents with conversation history",
      "AI agents compared with agentic AI",
      "LangGraph foundations and components",
      "Debugging LangGraph applications with LangSmith",
      "Different LangGraph workflows and human-in-the-loop patterns",
      "Retrieval-augmented generation with LangGraph"
    ]
  },
  "aws-solutions-architect-associate": {
    sourceUrl: "https://aroushtech.in/aws-solutions-architect-associate/",
    outline: [
      "AWS introduction, account setup, IAM and AWS CLI",
      "EC2 fundamentals, instance storage and compute design",
      "High availability and scalability with ELB and Auto Scaling Groups",
      "RDS, Aurora, ElastiCache and Route 53",
      "Amazon S3, storage options, security and CloudFront",
      "SQS, SNS, Kinesis and ActiveMQ for decoupled applications",
      "Containers with ECS, Fargate, ECR and EKS; serverless architecture",
      "AWS databases, analytics and machine learning services",
      "Monitoring and audit with CloudWatch, CloudTrail and Config",
      "Advanced IAM, KMS, Systems Manager Parameter Store, Shield, WAF and VPC",
      "Disaster recovery, migrations and architecture review"
    ]
  },
  "cybersys": {
    sourceUrl: "https://aroushtech.in/cybersys/",
    outline: [
      "Security-control types, threat intelligence sharing and threat classification",
      "Threat hunting, network forensics and appliance monitoring",
      "Endpoint and email monitoring",
      "SIEM configuration and analysis",
      "Digital forensics and network, host and lateral-movement indicators",
      "Incident-response preparation, detection, containment, eradication and recovery",
      "Risk mitigation, frameworks, policies and procedures",
      "Enumeration tools, vulnerability scanning and remediation",
      "Identity and access management, network architecture and segmentation",
      "Data and privacy controls, application security, cloud and automation"
    ]
  },
  "ceh-certified-ethical-hacker": {
    sourceUrl: "https://aroushtech.in/ceh-certified-ethical-hacker/",
    outline: [],
    sourceNote: "The live CEH detail page attributes its instructor to UniNets and includes provider-specific training and delivery wording. To avoid presenting another provider’s syllabus, trainer or schedule as AROUSH-authored information, those details are not reproduced. Request an AROUSH-approved syllabus, trainer allocation and current delivery details before enrolment."
  },
  "pentest-penetration-testing": {
    sourceUrl: "https://aroushtech.in/pentester/",
    outline: [
      "Introduction, penetration-testing overview and pre-engagement activities",
      "Testing frameworks, information gathering and OSINT",
      "Scanning, enumeration, Nmap and NSE",
      "Scripting basics and scan analysis",
      "Vulnerability discovery and assessment tools",
      "Social-engineering, wireless, network, authentication and host attack topics",
      "Web-application and cloud attack topics",
      "Specialized systems and automated testing",
      "Persistence, lateral movement and exfiltration concepts",
      "Cleanup, restoration and penetration-test reporting"
    ]
  },
  "linux-advanced-cyber-security": {
    sourceUrl: "https://aroushtech.in/linux-advanced-cyber-security/",
    outline: [
      "Linux distributions, kernel, package tools, command line, shell scripting and user management",
      "Cybersecurity foundations, laws, standards, kill chain and security controls",
      "Footprinting and reconnaissance across websites, DNS, email, networks and social media",
      "Network scanning, port and service discovery, fingerprinting and enumeration",
      "Vulnerability analysis, system hacking and malware threats",
      "Sniffing, spoofing, social engineering and denial-of-service concepts",
      "Session hijacking and IDS, firewall and honeypot topics",
      "Web-server, web-application and SQL-injection security",
      "Wireless and mobile-platform security",
      "IoT, OT, cloud computing and cryptography"
    ]
  },
  "linux-basic-cyber-security": {
    sourceUrl: "https://aroushtech.in/linux-basic-cyber-security/",
    outline: [
      "Linux distributions, kernel, installation, package tools, command line and shell scripting",
      "Cybersecurity foundations, laws, standards and cyber kill chain",
      "Footprinting and reconnaissance across websites, DNS, email and networks",
      "Network scanning, port and service discovery, fingerprinting and enumeration",
      "Introductory system, network, OT/IoT and man-in-the-middle attack concepts with lab topics"
    ]
  },
  "web-app-pen-tester": {
    sourceUrl: "https://aroushtech.in/web-app-pen-tester/",
    duration: "10 hours (as stated on the source page)",
    outline: [
      "Web application and penetration-testing foundations",
      "Getting started and bug-bounty context",
      "Cross-site scripting, open redirects and clickjacking",
      "Cross-site request forgery and insecure direct object references",
      "SQL injection, race conditions and server-side request forgery",
      "Insecure deserialization, XML external entities and template injection",
      "Application-logic errors and broken access control",
      "Remote code execution and same-origin-policy issues",
      "Single sign-on security, information disclosure and API testing",
      "Code review, fuzzing and subdomain-takeover topics"
    ]
  },
  "ccna-devnet": {
    sourceUrl: "https://aroushtech.in/ccna-devnet/",
    outline: [
      "Software development and design, data formats, testing, methods and version control with Git",
      "REST APIs, webhooks, HTTP responses, authentication and API troubleshooting",
      "Cisco platform capabilities, SDKs, APIs, YANG, RESTCONF and NETCONF",
      "Application deployment models, virtual machines, containers, CI/CD and application security",
      "Infrastructure as code, automation tools, Python, Ansible and Bash workflows",
      "Network fundamentals, addressing, routing, switching, common services and connectivity troubleshooting"
    ]
  },
  "ccna": {
    sourceUrl: "https://aroushtech.in/ccna/",
    prerequisites: ["Basic computer literacy", "Basic PC operating-system navigation", "Basic internet usage", "Basic IP-address knowledge"],
    outline: [
      "Network components, host-to-host communication and Cisco IOS",
      "LANs, switches, Ethernet and initial switch configuration",
      "IPv4 addressing, subnetting, TCP/IP layers and routing",
      "IPv6 addressing and connectivity",
      "Static routing, VLANs, trunks and inter-VLAN routing",
      "OSPF, STP/RSTP, EtherChannel and Layer 3 redundancy",
      "WAN, VPN, ACL, DHCP, NAT and QoS concepts",
      "Wireless networks, WLCs, architecture and virtualization",
      "Network programmability, SDN, DNA Center, SD-Access and SD-WAN",
      "Monitoring, device management, security threats and device hardening",
      "Practical labs for router access, IOS commands, SSH, DHCP, DNS, routing, OSPF and IPv6"
    ],
    delivery: "The source page describes online live instructor-led training with theory and lab sessions. Confirm current format and lab access before enrolment."
  },
  "ccnp-enterprise": {
    sourceUrl: "https://aroushtech.in/ccnp-enterprise/",
    duration: "3 months (as stated on the source page)",
    prerequisites: ["Basic networking knowledge at approximately CCNA level is recommended."],
    outline: [
      "Enterprise infrastructure with IPv4/IPv6 dual-stack architecture",
      "Security, virtualization, network assurance and automation",
      "Network redundancy and redundant switched topologies",
      "Enterprise network security architecture",
      "Enterprise network architecture and concentration areas such as SD-WAN, design, automation and wireless"
    ],
    delivery: "The source page lists live lectures, recorded videos, an online lab workbook and remote virtual-lab access."
  },
  "ccnp-security": {
    sourceUrl: "https://aroushtech.in/ccnp-security/",
    duration: "3 months (as stated on the source page)",
    prerequisites: ["The source page recommends relevant prior security/network certification or approximately 2–4 years of experience."],
    outline: [
      "Secure access and identity management architectures",
      "Threat-defence architectures and threat defence",
      "Reporting, troubleshooting and monitoring tools",
      "Secure CLI management and security-device GUIs",
      "Management services on Cisco devices",
      "Security components, secure communications and content security",
      "Network threat defence and Cisco Firepower NGIPS"
    ],
    delivery: "The source page describes live instructor-led training, an online lab workbook and remote virtual-lab access."
  },
  "ise-identity-services-engine": {
    sourceUrl: "https://aroushtech.in/ciscoise/",
    duration: "1 month (as stated on the source page)",
    prerequisites: [
      "CCNA Security certification (as listed on the source page)",
      "Basic firewall knowledge and skills",
      "A good understanding of security concepts"
    ],
    outline: [
      "Cisco ISE foundations, architecture, deployment and initial GUI setup",
      "Identity stores, EAP, policy concepts and basic configuration",
      "802.1X access and network access policy configuration",
      "Policy sets, access policies and policy conversion",
      "Guest services, web authentication and guest, sponsor and My Devices portals",
      "ISE profiling, profile configuration and customization",
      "Bring Your Own Device (BYOD) configuration and device blacklisting",
      "Endpoint compliance, client provisioning and policy configuration",
      "ISE integration with AMP and VPN-based services",
      "Cisco ISE configuration for VPN access and threat-centric NAC",
      "ISE APIs, Cisco WSA integration and pxGrid",
      "Network access device integration and device administration",
      "TACACS+ configuration for command authorization"
    ],
    delivery: "The source page describes online weekend classes, live lectures, recorded videos, virtual-lab access and an online workbook. Confirm current class dates and lab availability before enrolment."
  },
  "checkpoint-firewall": {
    sourceUrl: "https://aroushtech.in/checkpoint-firewall/",
    duration: "1 month (as stated on the source page)",
    outline: [
      "Check Point security policy concepts, objects and rules",
      "Introduction to Check Point hardware",
      "VPN configuration",
      "Security Management and distributed Security Gateway deployment",
      "Security-policy administration and policy layers",
      "Administrator operations, licensing and Check Point solutions",
      "Traffic accessibility and troubleshooting concepts"
    ],
    delivery: "The source page describes online and classroom weekend classes, recorded lectures, an online lab workbook and remote virtual-lab access."
  },
  "palo-alto-firewall-certified-engineer": {
    sourceUrl: "https://aroushtech.in/palo-alto-firewall/",
    duration: "1 month (as stated on the source page)",
    prerequisites: ["Basic networking and security concepts, IP addressing, TCP/IP, OSI layers and packet flows are recommended; firewall experience is described as an advantage."],
    outline: [
      "Palo Alto next-generation firewall foundations",
      "Installation, configuration, management and troubleshooting",
      "Instructor-led learning, recorded sessions and lab workbook",
      "Remote virtual-lab access",
      "Preparation context for the PCNSE certification exam (as described on the source page)"
    ]
  },
  "ccnp-data-center": {
    sourceUrl: "https://aroushtech.in/ccnp-data-center/",
    duration: "3 months (as stated on the source page)",
    prerequisites: ["The source page recommends CCNA Data Center or a Cisco CCIE certification."],
    outline: [
      "Data-center routing and switching protocols",
      "Overlay networks in data centers",
      "Cisco cloud services and deployment models",
      "Fibre Channel fabric and Fibre Channel over Ethernet",
      "Data-center security features",
      "Software management and infrastructure monitoring",
      "Cisco UCS Fabric Interconnect and server abstraction"
    ],
    delivery: "The source page describes online live lectures, recorded training videos, an online lab workbook and remote virtual-lab access."
  },
  "ansible-terraform": {
    sourceUrl: "https://aroushtech.in/ansible-and-terraform/",
    outline: [
      "Terraform fundamentals and infrastructure as code",
      "Terraform providers, resources, modules, state management and network configuration",
      "Ansible basics, inventories, configuration management and playbooks",
      "Ansible roles, Jinja2 templates and network-device automation",
      "End-to-end network automation with Terraform and Ansible, Git change tracking and rollback"
    ]
  },
  "fortinet-certified-engineer": {
    sourceUrl: "https://aroushtech.in/fortinet-certified-engineer/",
    outline: [],
    sourceNote: "The live detail page mixes AROUSH wording with course and delivery copy attributed to another training provider. To avoid presenting another provider’s syllabus, batch size or schedule as AROUSH-authored information, those sections have not been reproduced. The new page retains only the current AROUSH catalogue title, summary and listed fee. Request an AROUSH-approved syllabus and current delivery details before enrolment."
  }
};
