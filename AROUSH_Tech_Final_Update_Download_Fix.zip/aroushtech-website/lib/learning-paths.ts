/**
 * Goal-based course collections built only from the published AROUSH catalogue.
 * These are discovery groupings, not mandatory sequences or prerequisite claims.
 */
export const learningPaths = [
  {
    slug: "networking-infrastructure",
    title: "Networking & infrastructure",
    summary:
      "Explore core networking, enterprise environments, data-centre topics and network automation.",
    courseSlugs: [
      "ccna",
      "ccnp-enterprise",
      "ccnp-data-center",
      "ccna-devnet",
    ],
  },
  {
    slug: "network-security",
    title: "Network security",
    summary:
      "Compare network-security learning across identity, enterprise security and firewall platforms.",
    courseSlugs: [
      "ccnp-security",
      "ise-identity-services-engine",
      "checkpoint-firewall",
      "fortinet-certified-engineer",
      "palo-alto-firewall-certified-engineer",
    ],
  },
  {
    slug: "cybersecurity-penetration-testing",
    title: "Cybersecurity & penetration testing",
    summary:
      "Browse Linux security, cybersecurity foundations, ethical hacking and web-application testing.",
    courseSlugs: [
      "linux-basic-cyber-security",
      "cybersys",
      "ceh-certified-ethical-hacker",
      "pentest-penetration-testing",
      "web-app-pen-tester",
      "linux-advanced-cyber-security",
    ],
  },
  {
    slug: "cloud-automation-ai",
    title: "Cloud, automation & AI",
    summary:
      "Explore cloud architecture, infrastructure automation, AI and agent-based application topics.",
    courseSlugs: [
      "aws-solutions-architect-associate",
      "ansible-terraform",
      "agentic-ai-langchain-hugging-face",
      "agentic-ai-langgraph-langchain",
      "ai-ml",
    ],
  },
] as const;
