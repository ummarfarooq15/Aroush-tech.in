export type FAQSearchItem = {
  category: string;
  q: string;
  a: string;
};

export function filterFaqs<T extends FAQSearchItem>(
  items: T[],
  query: string,
  category?: string,
): T[];
