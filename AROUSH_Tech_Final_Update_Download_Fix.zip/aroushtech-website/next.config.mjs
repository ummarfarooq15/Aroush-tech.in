/** @type {import('next').NextConfig} */
const securityHeaders = [
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" }
];

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  images: { unoptimized: true },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: securityHeaders
      }
    ];
  },
  async redirects() {
    return [
      { source: "/aboutus", destination: "/about", permanent: true },
      { source: "/contact-us", destination: "/contact", permanent: true },
      { source: "/meet-our-team", destination: "/team", permanent: true },
      { source: "/ai-ml", destination: "/courses/ai-ml", permanent: true },
      { source: "/agentic-ai-with-langchain-hugging-face", destination: "/courses/agentic-ai-langchain-hugging-face", permanent: true },
      { source: "/agentic-ai-with-langgraph-and-langchain", destination: "/courses/agentic-ai-langgraph-langchain", permanent: true },
      { source: "/aws-solutions-architect-associate", destination: "/courses/aws-solutions-architect-associate", permanent: true },
      { source: "/cybersys", destination: "/courses/cybersys", permanent: true },
      { source: "/ceh-certified-ethical-hacker", destination: "/courses/ceh-certified-ethical-hacker", permanent: true },
      { source: "/pentester", destination: "/courses/pentest-penetration-testing", permanent: true },
      { source: "/linux-advanced-cyber-security", destination: "/courses/linux-advanced-cyber-security", permanent: true },
      { source: "/linux-basic-cyber-security", destination: "/courses/linux-basic-cyber-security", permanent: true },
      { source: "/web-app-pen-tester", destination: "/courses/web-app-pen-tester", permanent: true },
      { source: "/ccna-devnet", destination: "/courses/ccna-devnet", permanent: true },
      { source: "/ccna", destination: "/courses/ccna", permanent: true },
      { source: "/ccnp-enterprise", destination: "/courses/ccnp-enterprise", permanent: true },
      { source: "/ccnp-security", destination: "/courses/ccnp-security", permanent: true },
      { source: "/ciscoise", destination: "/courses/ise-identity-services-engine", permanent: true },
      { source: "/checkpoint-firewall", destination: "/courses/checkpoint-firewall", permanent: true },
      { source: "/palo-alto-firewall", destination: "/courses/palo-alto-firewall-certified-engineer", permanent: true },
      { source: "/ccnp-data-center", destination: "/courses/ccnp-data-center", permanent: true },
      { source: "/ansible-and-terraform", destination: "/courses/ansible-terraform", permanent: true },
      { source: "/fortinet-certified-engineer", destination: "/courses/fortinet-certified-engineer", permanent: true }
    ];
  }
};

export default nextConfig;
